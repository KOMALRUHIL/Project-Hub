@echo off
title ClaimOptima - Temporal & P90 Severity Studio (Port 5174)
echo ======================================================================
echo   Starting ClaimOptima Temporal & P90 Severity Studio (React App)
echo   Listening on: http://localhost:5174
echo   Features: S-Curves, Inflection Map, Category Shift, 3,000+ Claims Scale
echo ======================================================================
echo.
cd /d "%~dp0bill-app-react-app"
call npm.cmd run dev
pause
