import os
import sys
import pandas as pd
import numpy as np
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(BASE_DIR, "backend_output")

LEGACY_FILES_TO_CLEAN = [
    "1_Raw_Ingested_Claims_Data.xlsx",
    "2_Clinical_Complexity_Scoring_Master.xlsx",
    "3_Billed_Amount_Severity_Predictions.xlsx",
    "4_SHAP_Domain_and_Feature_Contributions.xlsx",
    "Temporal_Severity_and_P90_Report.xlsx",
    "ClaimOptima_PowerBI_Dataset.xlsx",
    "ClaimOptima_Calculated_Analysis.xlsx",
    "ClaimOptima_Complete_System_Master_Export.xlsx",
    "ClaimOptima_Complete_System_Master_Dataset.xlsx",
    "ClaimOptima_Master_System_Dataset.xlsx",
    "claims_complexity_master.csv",
    "raw_claims_dataset.csv",
    "master_derived_dataset.csv",
    "PowerBI_Category_Temporal_Matrix.csv",
    "PowerBI_Claims_Dimension.csv",
    "PowerBI_Enriched_Bills_Fact.csv",
    "PowerBI_Milestones_Benchmark.csv",
    "clinical_complexity_working_dataset.csv"
]

def get_export_output_dirs():
    """Returns list of all target output directories including configured SharePoint folder."""
    dirs = [OUTPUT_DIR]
    try:
        from sharepoint_config import SHAREPOINT_FOLDER_PATH
        sp_folder = os.environ.get("SHAREPOINT_FOLDER_PATH", SHAREPOINT_FOLDER_PATH)
        if sp_folder and str(sp_folder).strip():
            sp_path = str(sp_folder).strip()
            os.makedirs(sp_path, exist_ok=True)
            if sp_path not in dirs:
                dirs.append(sp_path)
    except Exception:
        pass
    for d in dirs:
        try:
            os.makedirs(d, exist_ok=True)
        except Exception:
            pass
    return dirs

def apply_excel_styling(ws, header_fill_color="0B132B", header_font_color="00D2FF"):
    """Applies fast professional enterprise styling to header row in openpyxl worksheet."""
    try:
        header_fill = PatternFill(start_color=header_fill_color, end_color=header_fill_color, fill_type="solid")
        header_font = Font(name="Segoe UI", size=10, bold=True, color=header_font_color)
        border_side = Side(border_style="thin", color="334155")
        thin_border = Border(left=border_side, right=border_side, top=border_side, bottom=border_side)
        
        for col in range(1, ws.max_column + 1):
            cell = ws.cell(row=1, column=col)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            cell.border = thin_border
            col_letter = get_column_letter(col)
            header_text = str(cell.value or "")
            ws.column_dimensions[col_letter].width = min(max(len(header_text) + 4, 14), 45)
            
        ws.row_dimensions[1].height = 28
    except Exception:
        pass

def cleanup_legacy_output_files():
    """Removes obsolete intermediate CSV and single-stage Excel files from backend_output."""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    for fname in LEGACY_FILES_TO_CLEAN:
        fpath = os.path.join(OUTPUT_DIR, fname)
        if os.path.exists(fpath):
            try:
                os.remove(fpath)
            except Exception:
                pass

def build_claim_level_billing_summary(bills_df: pd.DataFrame) -> pd.DataFrame:
    """Aggregates record-wise bills per JOB_ID into a clean summary table with high-performance vectorization."""
    if bills_df is None or len(bills_df) == 0:
        return pd.DataFrame(columns=[
            'JOB_ID', 'Total_Billed_Amount', 'Line_Items_Count', 'Distinct_Providers_Count',
            'Primary_Treatment_Categories', 'Earliest_Service_Date', 'Latest_Service_Date', 'Avg_Line_Item_Cost'
        ])
        
    cols_clean = {c: str(c).strip().lower().replace(' ', '_').replace('-', '_') for c in bills_df.columns}
    df = bills_df.rename(columns=cols_clean).copy()
    
    job_col = next((c for c in ['job_id', 'claim_id', 'jobid', 'claimid', 'id'] if c in df.columns), None)
    if not job_col:
        job_col = df.columns[0]
        
    amt_col = next((c for c in ['bill_line_item_build_amount', 'bill_line_item_billed_amount', 'item_billed_amount', 'billed_amount', 'build_amount', 'amount'] if c in df.columns), None)
    cat_col = next((c for c in ['bill_line_item_category', 'category', 'treatment_type', 'service_category'] if c in df.columns), None)
    prov_col = next((c for c in ['provider_name', 'facility_name', 'doctor', 'provider'] if c in df.columns), None)
    date_col = next((c for c in ['bill_line_item_service_date', 'service_date', 'start_date', 'dos', 'date'] if c in df.columns), None)
    
    if amt_col:
        df['clean_amount'] = pd.to_numeric(df[amt_col], errors='coerce').fillna(0.0)
    else:
        df['clean_amount'] = 0.0
        
    if date_col:
        df['clean_date'] = pd.to_datetime(df[date_col], format='mixed', errors='coerce')
    else:
        df['clean_date'] = pd.NaT

    if prov_col is None:
        df['clean_prov'] = 'Medical Provider'
        prov_col = 'clean_prov'
        
    if cat_col is None:
        df['clean_cat'] = 'General Medical'
        cat_col = 'clean_cat'

    grouped = df.groupby(job_col).agg(
        Total_Billed_Amount=('clean_amount', 'sum'),
        Line_Items_Count=('clean_amount', 'count'),
        Avg_Line_Item_Cost=('clean_amount', 'mean'),
        Distinct_Providers_Count=(prov_col, 'nunique'),
        Earliest_Service_Date=('clean_date', 'min'),
        Latest_Service_Date=('clean_date', 'max'),
        Primary_Treatment_Categories=(cat_col, lambda s: ', '.join(list(pd.Series(s).dropna().unique())[:3]))
    ).reset_index()

    grouped['Total_Billed_Amount'] = grouped['Total_Billed_Amount'].round(2)
    grouped['Avg_Line_Item_Cost'] = grouped['Avg_Line_Item_Cost'].round(2)
    grouped['Earliest_Service_Date'] = grouped['Earliest_Service_Date'].dt.strftime('%Y-%m-%d').fillna('N/A')
    grouped['Latest_Service_Date'] = grouped['Latest_Service_Date'].dt.strftime('%Y-%m-%d').fillna('N/A')
    grouped = grouped.rename(columns={job_col: 'JOB_ID'})
    
    return grouped

def export_all_outputs(input_df=None):
    """
    Consolidates file exports strictly to 2 master workbooks in backend_output/ and SharePoint:
    1. clinical_complexity_working_dataset.xlsx (4 sheets: Raw, Complexity Score Calculation, Loss Severity & SHAP Breakdown, Dangerous Cohorts Summary)
    2. medical_bills_working_dataset.xlsx (2 sheets: Medical Bills Line Items, Claim Level Billing Summary)
    """
    cleanup_legacy_output_files()
    output_dirs = get_export_output_dirs()
    exported_files = []

    # 1. Load or use claims dataframe
    if input_df is None or len(input_df) == 0:
        backend_folder = os.path.join(BASE_DIR, "backend_data")
        candidates = [
            os.path.join(backend_folder, "input_file.xlsx"),
            os.path.join(backend_folder, "input_file.csv"),
            os.path.join(backend_folder, "upload.csv"),
            os.path.join(backend_folder, "upload.xlsx"),
            os.path.join(BASE_DIR, "input_file.xlsx"),
            os.path.join(BASE_DIR, "input_file.csv"),
        ]
        # Sort existing candidates by modification time (newest first)
        candidates = [c for c in candidates if os.path.exists(c) and os.path.getsize(c) > 0]
        candidates.sort(key=lambda x: os.path.getmtime(x), reverse=True)
        df = None
        for c in candidates:
            try:
                df = pd.read_excel(c) if c.endswith((".xlsx", ".xls")) else pd.read_csv(c)
                if len(df) > 0:
                    break
            except Exception:
                continue
        if df is None or len(df) == 0:
            df = pd.DataFrame({"JOB_ID": ["JOB-1001"], "Overall Score": [45.0]})
    else:
        df = input_df.copy()

    # Import calculation utilities from app.py
    try:
        from app import (
            calculate_overall_complexity_for_df,
            create_and_save_working_dataset
        )
        has_app = True
    except Exception:
        has_app = False

    # 2. Build and export clinical_complexity_working_dataset.xlsx (4 Sheets)
    try:
        if has_app:
            calc_full = calculate_overall_complexity_for_df(df.copy())
            create_and_save_working_dataset(calc_full, raw_df=df, sync=True)
            f1 = os.path.join(OUTPUT_DIR, "clinical_complexity_working_dataset.xlsx")
            if os.path.exists(f1):
                exported_files.append(f1)
    except Exception as e:
        print(f"[ClaimOptima] Clinical complexity export note: {e}")

    # 3. Build and export medical_bills_working_dataset.xlsx (2 Sheets)
    try:
        bills_file = None
        for b_cand in [
            os.path.join(BASE_DIR, "backend_data", "medical_bills_input.xlsx"),
            os.path.join(BASE_DIR, "medical_bills_input.xlsx"),
            os.path.join(BASE_DIR, "backend_data", "medical_bills_input.csv"),
            os.path.join(BASE_DIR, "medical_bills_input.csv"),
        ]:
            if os.path.exists(b_cand) and os.path.getsize(b_cand) > 100:
                bills_file = b_cand
                break
                
        if bills_file:
            bills_df = pd.read_excel(bills_file) if bills_file.endswith((".xlsx", ".xls")) else pd.read_csv(bills_file)
        else:
            bills_df = pd.DataFrame({
                "job_id": ["JOB-1001", "JOB-1002"],
                "bill_line_item_build_amount": [4500.0, 1200.0],
                "bill_line_item_category": ["Hospital / ER", "Physical Therapy"]
            })
            
        bills_summary_df = build_claim_level_billing_summary(bills_df)
        
        for out_dir in output_dirs:
            os.makedirs(out_dir, exist_ok=True)
            f2 = os.path.join(out_dir, "medical_bills_working_dataset.xlsx")
            tmp_f2 = f2.replace(".xlsx", f"__tmp_{os.getpid()}.xlsx")
            with pd.ExcelWriter(tmp_f2, engine="openpyxl") as writer:
                bills_df.to_excel(writer, sheet_name="Medical Bills Line Items", index=False)
                apply_excel_styling(writer.sheets["Medical Bills Line Items"], header_fill_color="0B132B", header_font_color="00D2FF")
                bills_summary_df.to_excel(writer, sheet_name="Claim Level Billing Summary", index=False)
                apply_excel_styling(writer.sheets["Claim Level Billing Summary"], header_fill_color="0F172A", header_font_color="10B981")
            os.replace(tmp_f2, f2)
            if f2 not in exported_files:
                exported_files.append(f2)
    except Exception as e_bills:
        print(f"[ClaimOptima] Medical bills export note: {e_bills}")

    # 4. Sync to SharePoint link/webhook if configured
    try:
        from sharepoint_config import SHAREPOINT_LINK
        sp_url = os.environ.get("SHAREPOINT_LINK", SHAREPOINT_LINK)
        if sp_url and str(sp_url).strip().startswith(("http://", "https://")):
            import requests
            for target_export in [
                os.path.join(OUTPUT_DIR, "clinical_complexity_working_dataset.xlsx"),
                os.path.join(OUTPUT_DIR, "medical_bills_working_dataset.xlsx")
            ]:
                if os.path.exists(target_export):
                    with open(target_export, "rb") as f_sp:
                        file_bytes = f_sp.read()
                    requests.post(
                        str(sp_url).strip(),
                        data=file_bytes,
                        headers={
                            "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            "X-Source": "ClaimOptima-Excel-Exporter",
                            "X-Filename": os.path.basename(target_export)
                        },
                        timeout=15
                    )
    except Exception:
        pass

    cleanup_legacy_output_files()
    print(f"[ClaimOptima] Verified 2 master workbooks in backend_output/ ({len(exported_files)} files)")
    return exported_files

if __name__ == "__main__":
    files = export_all_outputs()
    print(f"Generated {len(files)} master workbooks.")
