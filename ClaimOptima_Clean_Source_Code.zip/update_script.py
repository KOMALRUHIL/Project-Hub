﻿# Helper to write python script
