import os
import re
import json
import difflib
import pandas as pd
from typing import Tuple, List, Dict, Any, Optional

try:
    import models
except ImportError:
    models = None

try:
    from utils_gpt import gpt_call, _coerce_json_text
except ImportError:
    gpt_call = None
    _coerce_json_text = None

def normalize_name(name: str) -> str:
    """
    Cleans name for comparison: lowercases, removes punctuation,
    and strips extra spaces. Used in fallback logic.
    """
    if pd.isna(name) or not name:
        return ""
    cleaned = str(name).lower()
    cleaned = re.sub(r'[^a-z0-9\s]', '', cleaned)
    cleaned = re.sub(r'\s+', ' ', cleaned).strip()
    return cleaned

def names_match(n1: str, n2: str) -> bool:
    """
    Checks if two normalized names are highly similar or substring matches.
    """
    if not n1 or not n2:
        return False
    if n1 == n2:
        return True
    if n1 in n2 or n2 in n1:
        return True
    similarity = difflib.SequenceMatcher(None, n1, n2).ratio()
    return similarity > 0.85

def get_10_word_desc(desc: str) -> str:
    """
    Normalizes a description to its first 10 alphanumeric words of length > 2.
    """
    if pd.isna(desc) or not desc:
        return ""
    desc_clean = str(desc).strip().lower()
    words = [w for w in re.findall(r'[a-z0-9]+', desc_clean) if len(w) > 2][:10]
    return " ".join(words) if words else ""

def get_50_word_desc(desc: str) -> str:
    """
    Normalizes a description to its first 50 alphanumeric words of length > 2.
    """
    if pd.isna(desc) or not desc:
        return ""
    desc_clean = str(desc).strip().lower()
    words = [w for w in re.findall(r'[a-z0-9]+', desc_clean) if len(w) > 2][:50]
    return " ".join(words) if words else ""

def get_rollup1_claim_id_key(claim_id: str) -> str:
    if not claim_id:
        return ""
    cid_clean = re.sub(r'\s+', '', str(claim_id)).lower()
    if not cid_clean:
        return ""
    
    # Repeatedly strip suffixes from the end
    changed = True
    base = cid_clean
    while changed:
        changed = False
        match = re.search(r'[-_/\s.]([a-zA-Z0-9]{1,4})$', base)
        if match:
            suffix_len = len(match.group(0))
            new_base = base[:-suffix_len]
            if len(new_base) >= 2:
                base = new_base
                changed = True
                
    # If no suffix was found/stripped (meaning base is same as original cleaned claim_id)
    if base == cid_clean:
        if len(base) > 2:
            base = base[:-2]
            
    return base

def get_logic2_key(claim_id):
    if not claim_id:
        return ""
    cid_clean = re.sub(r'\s+', '', str(claim_id)).lower()
    if not cid_clean:
        return ""
    
    # Repeatedly strip suffixes from the end (e.g., -01, -03)
    changed = True
    base = cid_clean
    while changed:
        changed = False
        match = re.search(r'[-_/\s.]([a-zA-Z0-9]{1,4})$', base)
        if match:
            suffix_len = len(match.group(0))
            new_base = base[:-suffix_len]
            if len(new_base) >= 2:
                base = new_base
                changed = True
                
    if base != cid_clean:
        return base
        
    return cid_clean

def generate_programmatic_roll_numbers(df: pd.DataFrame, step_level: int = 3) -> list:
    """
    Groups claims independently based on the step_level:
    1. ROLLUP_1: Grouped by same loss date, claimant name, and state.
       Format: Always desc_[description_slug]&[date]&[state]
    2. ROLLUP_2: Grouped by claim ID variations and 10-word description.
       Format: [base_claim_id]&[description_slug] if grouped, else desc_[description_slug]&[date]&[state]
    3. ROLLUP_3: Grouped by same loss date, state, and 10-word description.
       Format: Always desc_[description_slug]&[date]&[state]
    """
    n = len(df)
    parent = list(range(n))
    
    def find(i):
        path = []
        while parent[i] != i:
            path.append(i)
            i = parent[i]
        for node in path:
            parent[node] = i
        return i

    def union(i, j):
        root_i = find(i)
        root_j = find(j)
        if root_i != root_j:
            parent[root_i] = root_j

    def clean_str(val):
        if pd.isna(val):
            return ""
        return str(val).strip()

    # Extract cleaned fields for all rows
    rows_data = []
    for idx in range(n):
        row = df.iloc[idx]
        
        # Loss Date
        ld = ""
        for field in ["accident_date", "loss_date", "date_of_loss"]:
            if field in row:
                val = clean_str(row[field])
                if val and val.lower() not in ["nan", "none"]:
                    ld = val
                    break
                    
        # Claimant Name
        cl = ""
        for field in ["claimant", "driver", "claimant_name", "driver_name"]:
            if field in row:
                val = clean_str(row[field])
                if val and val.lower() not in ["nan", "none"]:
                    cl = val.lower()
                    break
                    
        # State
        st = ""
        for field in ["accident_state", "garage_state", "coverage_state", "state"]:
            if field in row:
                val = clean_str(row[field])
                if val and val.lower() not in ["nan", "none"]:
                    st = val.upper()
                    break
                    
        # Claim ID
        cid = ""
        for field in ["claim_id", "claim_number"]:
            if field in row:
                val = clean_str(row[field])
                if val and val.lower() not in ["nan", "none"]:
                    cid = val
                    break
                    
        # Description
        desc = ""
        for field in ["claim_description", "description", "event_description", "cause_of_loss"]:
            if field in row:
                val = clean_str(row[field])
                if val and val.lower() not in ["nan", "none"]:
                    desc = val
                    break

        # LOB
        lob_val = "unknown"
        for field in ["lob", "line_of_business", "coverage_subtype"]:
            if field in row:
                val = clean_str(row[field])
                if val and val.lower() not in ["nan", "none"]:
                    lob_val = val.strip().lower()
                    break
                    
        rows_data.append({
            "idx": idx,
            "loss_date": ld,
            "claimant": cl,
            "state": st,
            "claim_id": cid,
            "description": desc,
            "lob": lob_val
        })

    if step_level == 1:
        step1_groups = {}
        for r in rows_data:
            ld = r["loss_date"]
            cl = r["claimant"]
            st = r["state"]
            lob_val = r["lob"]
            if ld and cl and st:
                key = (ld, cl, st, lob_val)
                step1_groups.setdefault(key, []).append(r["idx"])
                
        for key, indices in step1_groups.items():
            if len(indices) > 1:
                for idx in indices[1:]:
                    union(indices[0], idx)

    elif step_level == 2:
        step2_groups = {}
        for idx in range(n):
            cid = rows_data[idx]["claim_id"]
            desc = rows_data[idx]["description"]
            lob_val = rows_data[idx]["lob"]
            if cid:
                key_id = get_logic2_key(cid)
                if key_id:
                    desc_norm = get_10_word_desc(desc)
                    key = (key_id, desc_norm, lob_val)
                    step2_groups.setdefault(key, []).append(idx)
                    
        for key, indices in step2_groups.items():
            if len(indices) > 1:
                for idx in indices[1:]:
                    union(indices[0], idx)

    elif step_level == 3:
        step3_groups = {}
        for idx in range(n):
            ld = rows_data[idx]["loss_date"]
            st = rows_data[idx]["state"]
            desc = rows_data[idx]["description"]
            lob_val = rows_data[idx]["lob"]
            if ld and st and desc:
                desc_norm = get_10_word_desc(desc)
                key = (ld, st, desc_norm, lob_val)
                step3_groups.setdefault(key, []).append(idx)
                
        for key, indices in step3_groups.items():
            if len(indices) > 1:
                for idx in indices[1:]:
                    union(indices[0], idx)

    # Assign roll_no for each group
    root_to_members = {}
    for i in range(n):
        root = find(i)
        root_to_members.setdefault(root, []).append(i)
        
    roll_numbers = [None] * n
    for root, members in root_to_members.items():
        m0 = rows_data[members[0]]
        lob_slug = m0["lob"].replace(" ", "_")
        
        if step_level == 1:
            claimant_slug = m0["claimant"].replace(" ", "_") if m0["claimant"] else "unknown"
            date_slug = m0["loss_date"].replace("/", "-").replace(" ", "_") if m0["loss_date"] else "unknown"
            state_slug = m0["state"].replace(" ", "_").lower() if m0["state"] else "unknown"
            roll_no = f"{claimant_slug}&{date_slug}&{state_slug}&{lob_slug}".lower()
            
        elif step_level == 2:
            k0 = get_logic2_key(m0["claim_id"])
            if not k0:
                k0 = "noclaimid"
            desc_norm = get_10_word_desc(m0["description"])
            desc_slug = desc_norm.replace(" ", "_") if desc_norm else "desc"
            roll_no = f"{k0}&{desc_slug}&{lob_slug}".lower()
            
        elif step_level == 3:
            desc_norm = get_10_word_desc(m0["description"])
            desc_slug = desc_norm.replace(" ", "_") if desc_norm else "desc"
            date_slug = m0["loss_date"].replace("/", "-").replace(" ", "_") if m0["loss_date"] else "unknown"
            state_slug = m0["state"].replace(" ", "_").lower() if m0["state"] else "unknown"
            roll_no = f"desc_{desc_slug}&{date_slug}&{state_slug}&{lob_slug}".lower()

        for m in members:
            roll_numbers[m] = roll_no
            
    return roll_numbers

def run_sequential_rollup(df_raw: pd.DataFrame):
    """
    Performs a 3-step sequential rollup:
    1. Rollup 1: Group df_raw by claim_id variation and 50-word description.
       Aggregates to produce df_rollup1.
    2. Rollup 2: Group df_rollup1 by claimant name, loss date, and state.
       Aggregates to produce df_rollup2.
    3. Rollup 3: Group df_rollup2 by complete description, loss date, and state.
       Aggregates to produce df_rollup3.
       
    Returns:
        df_rollup1, df_rollup2, df_rollup3, final_roll_nos
    """
    def clean_str(val):
        if pd.isna(val):
            return ""
        return str(val).strip()

    def extract_row_fields(row):
        # Loss Date
        ld = ""
        for field in ["accident_date", "loss_date", "date_of_loss"]:
            if field in row:
                val = clean_str(row[field])
                if val and val.lower() not in ["nan", "none"]:
                    ld = val
                    break
                    
        # Claimant Name
        cl = ""
        for field in ["claimant", "driver", "claimant_name", "driver_name"]:
            if field in row:
                val = clean_str(row[field])
                if val and val.lower() not in ["nan", "none"]:
                    cl = val.lower()
                    break
                    
        # State
        st = ""
        for field in ["state_of_loss", "state of loss", "state_of_benefit", "state of benefit", "accident_state", "garage_state", "coverage_state", "state"]:
            if field in row:
                val = clean_str(row[field])
                if val and val.lower() not in ["nan", "none"]:
                    st = val.upper()
                    break
                    
        # Claim ID
        cid = ""
        for field in ["claim_id", "claim_number"]:
            if field in row:
                val = clean_str(row[field])
                if val and val.lower() not in ["nan", "none"]:
                    cid = val
                    break
                    
        # Description
        desc = ""
        for field in ["claim_description", "description", "event_description", "cause_of_loss"]:
            if field in row:
                val = clean_str(row[field])
                if val and val.lower() not in ["nan", "none"]:
                    desc = val
                    break

        # LOB
        lob_val = "unknown"
        for field in ["lob", "line_of_business", "coverage_subtype"]:
            if field in row:
                val = clean_str(row[field])
                if val and val.lower() not in ["nan", "none"]:
                    lob_val = val.strip().lower()
                    break
                    
        return {
            "loss_date": ld,
            "claimant": cl,
            "state": st,
            "claim_id": cid,
            "description": desc,
            "lob": lob_val
        }

    if df_raw.empty:
        return df_raw.copy(), df_raw.copy(), df_raw.copy(), []

    df_raw = df_raw.copy()
    if "roll_no" in df_raw.columns:
        df_raw.drop(columns=["roll_no"], inplace=True)

    n = len(df_raw)
    
    # STEP 1: Rollup 1
    raw_fields = []
    for idx in range(n):
        row = df_raw.iloc[idx]
        raw_fields.append(extract_row_fields(row))
        
    parent1 = list(range(n))
    def find1(i):
        path = []
        while parent1[i] != i:
            path.append(i)
            i = parent1[i]
        for node in path:
            parent1[node] = i
        return i
    def union1(i, j):
        root_i = find1(i)
        root_j = find1(j)
        if root_i != root_j:
            parent1[root_i] = root_j

    step1_groups = {}
    for idx in range(n):
        cid = raw_fields[idx]["claim_id"]
        ldate = raw_fields[idx]["loss_date"]
        desc = raw_fields[idx]["description"]
        state_val = raw_fields[idx]["state"]
        lob_val = raw_fields[idx]["lob"]
        if cid and ldate and cid.lower() not in ["none", "nan", "null"]:
            key_id = get_rollup1_claim_id_key(cid)
            if key_id:
                desc_norm = get_50_word_desc(desc)
                key = (key_id, ldate, desc_norm, state_val, lob_val)
                step1_groups.setdefault(key, []).append(idx)
        else:
            step1_groups.setdefault((f"standalone_s1_{idx}",), []).append(idx)
                
    for key, indices in step1_groups.items():
        if len(indices) > 1 and len(key) == 5:
            for idx in indices[1:]:
                union1(indices[0], idx)
                
    roll_nos_1 = [None] * n
    root_to_members1 = {}
    for i in range(n):
        root = find1(i)
        root_to_members1.setdefault(root, []).append(i)
        
    for root, members in root_to_members1.items():
        m0 = raw_fields[members[0]]
        k0 = get_rollup1_claim_id_key(m0["claim_id"])
        if not k0:
            k0 = f"claim_{root}"
        ldate_slug = m0["loss_date"].replace("/", "-") if m0["loss_date"] else "nodate"
        desc_norm = get_50_word_desc(m0["description"])
        desc_slug = desc_norm.replace(" ", "_") if desc_norm else "desc"
        desc_slug = desc_slug[:50]
        state_slug = m0["state"] if m0["state"] else "nostate"
        lob_slug = m0["lob"].replace(" ", "_")
        roll_no = f"{k0}&{ldate_slug}&{desc_slug}&{state_slug}&{lob_slug}".lower()
        
        for m in members:
            roll_nos_1[m] = roll_no
            
    df_detailed1 = df_raw.copy()
    df_detailed1.insert(0, "roll_no", roll_nos_1)
    
    roll_no_counts1 = pd.Series(roll_nos_1).value_counts()
    df_detailed1['rolledup'] = pd.Series(roll_nos_1).map(lambda x: roll_no_counts1.get(x, 0) > 1).values
    df_rollup1 = aggregate_claims(df_detailed1)
    
    # STEP 2: Rollup 2
    m = len(df_rollup1)
    rollup1_fields = []
    for idx in range(m):
        row = df_rollup1.iloc[idx]
        rollup1_fields.append(extract_row_fields(row))
        
    parent2 = list(range(m))
    def find2(i):
        path = []
        while parent2[i] != i:
            path.append(i)
            i = parent2[i]
        for node in path:
            parent2[node] = i
        return i
    def union2(i, j):
        root_i = find2(i)
        root_j = find2(j)
        if root_i != root_j:
            parent2[root_i] = root_j

    step2_groups = {}
    for idx in range(m):
        ld = rollup1_fields[idx]["loss_date"]
        cl = rollup1_fields[idx]["claimant"]
        st = rollup1_fields[idx]["state"]
        lob_val = rollup1_fields[idx]["lob"]
        if ld and cl and st and cl not in ["unknown", "none", "nan", "insured", ""]:
            key = (ld, st, lob_val)
            step2_groups.setdefault(key, []).append(idx)
        else:
            step2_groups.setdefault((f"standalone_s2_{idx}",), []).append(idx)
            
    for key, indices in step2_groups.items():
        if len(indices) > 1 and len(key) == 3:
            for i_idx in range(len(indices)):
                for j_idx in range(i_idx + 1, len(indices)):
                    idx_a = indices[i_idx]
                    idx_b = indices[j_idx]
                    if names_match(rollup1_fields[idx_a]["claimant"], rollup1_fields[idx_b]["claimant"]):
                        union2(idx_a, idx_b)
                
    roll_nos_2 = [None] * m
    root_to_members2 = {}
    for i in range(m):
        root = find2(i)
        root_to_members2.setdefault(root, []).append(i)
        
    r1_to_r2_map = {}
    for root, members in root_to_members2.items():
        m0 = rollup1_fields[members[0]]
        claimant_slug = m0["claimant"].replace(" ", "_") if m0["claimant"] else f"clm_{root}"
        date_slug = m0["loss_date"].replace("/", "-").replace(" ", "_") if m0["loss_date"] else "nodate"
        state_slug = m0["state"].replace(" ", "_").lower() if m0["state"] else "nostate"
        lob_slug = m0["lob"].replace(" ", "_")
        roll_no = f"{claimant_slug}&{date_slug}&{state_slug}&{lob_slug}".lower()
        
        for m_idx in members:
            roll_nos_2[m_idx] = roll_no
            r1_val = df_rollup1.iloc[m_idx]["roll_no"]
            r1_to_r2_map[r1_val] = roll_no
            
    df_detailed2 = df_rollup1.copy()
    df_detailed2["roll_no"] = roll_nos_2
    
    roll_no_counts2 = pd.Series(roll_nos_2).value_counts()
    df_detailed2['rolledup'] = pd.Series(roll_nos_2).map(lambda x: roll_no_counts2.get(x, 0) > 1).values
    df_rollup2 = aggregate_claims(df_detailed2)
    
    # STEP 3: Rollup 3
    k = len(df_rollup2)
    rollup2_fields = []
    for idx in range(k):
        row = df_rollup2.iloc[idx]
        rollup2_fields.append(extract_row_fields(row))
        
    parent3 = list(range(k))
    def find3(i):
        path = []
        while parent3[i] != i:
            path.append(i)
            i = parent3[i]
        for node in path:
            parent3[node] = i
        return i
    def union3(i, j):
        root_i = find3(i)
        root_j = find3(j)
        if root_i != root_j:
            parent3[root_i] = root_j

    step3_groups = {}
    for idx in range(k):
        ld = rollup2_fields[idx]["loss_date"]
        st = rollup2_fields[idx]["state"]
        desc = rollup2_fields[idx]["description"]
        lob_val = rollup2_fields[idx]["lob"]
        words = [w for w in re.findall(r'[a-z0-9]+', desc.lower()) if len(w) > 2]
        if ld and st and len(words) >= 3 and desc.lower() not in ["commercial loss", "incident", "damage", "claim"]:
            desc_clean = clean_str(desc).lower()
            key = (desc_clean, ld, st, lob_val)
            step3_groups.setdefault(key, []).append(idx)
        else:
            step3_groups.setdefault((f"standalone_s3_{idx}",), []).append(idx)
            
    for key, indices in step3_groups.items():
        if len(indices) > 1 and len(key) == 4:
            for idx in indices[1:]:
                union3(indices[0], idx)
                
    roll_nos_3 = [None] * k
    root_to_members3 = {}
    for i in range(k):
        root = find3(i)
        root_to_members3.setdefault(root, []).append(i)
        
    r2_to_r3_map = {}
    for root, members in root_to_members3.items():
        m0 = rollup2_fields[members[0]]
        words = [w for w in re.findall(r'[a-z0-9]+', m0["description"].lower()) if len(w) > 2]
        desc_slug = "_".join(words[:8]) if words else f"occ_{root}"
        date_slug = m0["loss_date"].replace("/", "-").replace(" ", "_") if m0["loss_date"] else "nodate"
        state_slug = m0["state"].replace(" ", "_").lower() if m0["state"] else "nostate"
        lob_slug = m0["lob"].replace(" ", "_")
        roll_no = f"desc_{desc_slug}&{date_slug}&{state_slug}&{lob_slug}".lower()
        
        for m_idx in members:
            roll_nos_3[m_idx] = roll_no
            r2_val = df_rollup2.iloc[m_idx]["roll_no"]
            r2_to_r3_map[r2_val] = roll_no
            
    df_detailed3 = df_rollup2.copy()
    df_detailed3["roll_no"] = roll_nos_3
    
    roll_no_counts3 = pd.Series(roll_nos_3).value_counts()
    df_detailed3['rolledup'] = pd.Series(roll_nos_3).map(lambda x: roll_no_counts3.get(x, 0) > 1).values
    df_rollup3 = aggregate_claims(df_detailed3)
    
    final_roll_nos = []
    for idx in range(n):
        r1 = roll_nos_1[idx]
        r2 = r1_to_r2_map.get(r1, r1)
        r3 = r2_to_r3_map.get(r2, r2)
        final_roll_nos.append(r3)
        
    for dfr in [df_rollup1, df_rollup2, df_rollup3]:
        if isinstance(dfr, pd.DataFrame) and not dfr.empty:
            if "rolledup" in dfr.columns:
                dfr["rollup"] = dfr["rolledup"].map(lambda x: "Yes" if bool(x) else "No")
            else:
                dfr["rollup"] = "No"

    return df_rollup1, df_rollup2, df_rollup3, final_roll_nos

def programmatic_fallback_roll_numbers(df: pd.DataFrame) -> list:
    _, _, _, final_roll_nos = run_sequential_rollup(df)
    return final_roll_nos

def get_llm_roll_numbers(df: pd.DataFrame) -> list:
    _, _, _, final_roll_nos = run_sequential_rollup(df)
    return final_roll_nos

def aggregate_claims(df: pd.DataFrame) -> pd.DataFrame:
    """
    Groups by roll_no and aggregates all claims.
    """
    numeric_cols = [
        "total_incurred",
        "total_paid",
        "total_reserve",
        "incurred_alae",
        "paid_alae",
        "total_recoveries",
        "incurred_indemnity",
        "incurred_medical",
        "incurred_expense",
        "paid_indemnity",
        "paid_medical",
        "paid_expense",
        "recovery"
    ]
    
    df_clean = df.copy()
    for col in numeric_cols:
        if col in df_clean.columns:
            df_clean[col] = pd.to_numeric(
                df_clean[col].astype(str).str.replace(r'[^\d.-]', '', regex=True),
                errors='coerce'
            ).fillna(0.0)

    agg_funcs = {}
    for col in df_clean.columns:
        if col == 'roll_no':
            continue
        
        if col in numeric_cols:
            agg_funcs[col] = 'sum'
        elif col == 'rolledup':
            agg_funcs[col] = 'first'
        elif col in ['status', 'claim_status']:
            def _aggregate_status(series):
                vals = []
                for val in series:
                    if pd.notna(val):
                        s = str(val).strip()
                        if s != "" and s.lower() != "nan":
                            vals.append(s)
                            
                has_open = any(v.lower() in ("open", "reopened", "reopen", "re-open", "o") for v in vals)
                if has_open:
                    return "Open"
                for v in vals:
                    if v:
                        return v
                return "Closed"
            agg_funcs[col] = _aggregate_status
            
        else:
            def _join_unique(series):
                vals = []
                for val in series:
                    if pd.notna(val):
                        s = str(val).strip()
                        if s != "" and s.lower() != "nan":
                            vals.append(s)
                
                unique_vals = []
                for v in vals:
                    if v not in unique_vals:
                        unique_vals.append(v)
                
                if not unique_vals:
                    return ""
                if len(unique_vals) == 1:
                    return unique_vals[0]
                return ", ".join(unique_vals)
                
            agg_funcs[col] = _join_unique

    aggregated = df_clean.groupby('roll_no', as_index=False).agg(agg_funcs)
    
    cols = ['roll_no'] + [col for col in aggregated.columns if col != 'roll_no']
    aggregated = aggregated[cols]
    
    return aggregated
