import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

try {
  // Execute git log to get the last 10 commits (hash, author email, date, commit message)
  const logOutput = execSync('git log -10 --format="%h:::%an <%ae>:::%cI:::%s"', { stdio: ['pipe', 'pipe', 'ignore'] }).toString().trim();
  
  if (logOutput) {
    const commits = logOutput.split('\n').map((line, idx) => {
      const parts = line.split(':::');
      const hash = parts[0];
      const author = parts[1];
      const date = parts[2];
      const msg = parts.slice(3).join(':::');
      const verNumber = 10 - idx;
      return {
        version: `v2.4.${verNumber}`,
        changedBy: author ? author.trim() : "Azure Developer",
        changedAt: date ? new Date(date.trim()).toISOString() : new Date().toISOString(),
        commitHash: hash ? hash.trim() : "unknown",
        commitMessage: msg ? msg.trim() : "Commit update",
        deployedBy: "Azure CI/CD Pipeline",
        environment: "Production-Azure-US"
      };
    });

    if (commits.length > 0) {
      // 1. Generate version.json (last commit)
      const versionPath = path.join(__dirname, 'public', 'version.json');
      fs.writeFileSync(versionPath, JSON.stringify(commits[0], null, 2), 'utf-8');

      // 2. Generate/Update frontend/public/audit_history.json
      const historyPath = path.join(__dirname, 'public', 'audit_history.json');
      fs.writeFileSync(historyPath, JSON.stringify(commits, null, 2), 'utf-8');

      // 3. Generate/Update backend/audit_history.json
      const backendHistoryPath = path.join(__dirname, '..', 'backend', 'audit_history.json');
      try {
        fs.writeFileSync(backendHistoryPath, JSON.stringify(commits, null, 2), 'utf-8');
      } catch (beErr) {}

      console.log(`[BUILD] Generated audit_history.json with ${commits.length} commits for frontend & backend`);
    }
  } else {
    console.log(`[BUILD] No commits found in Git repository.`);
  }
} catch (e) {
  console.log(`[BUILD] Git command unavailable in this environment, using existing audit history.`);
}
