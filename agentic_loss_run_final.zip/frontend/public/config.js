// Runtime configuration for Azure Blob Storage / Production Hosting
// You can edit this file directly in Azure Blob Storage ( container) without rebuilding React!
window.__BACKEND_URL__ = " \;

