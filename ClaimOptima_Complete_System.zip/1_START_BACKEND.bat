@echo off
title ClaimOptima - FastAPI Backend (Port 5000)
echo ===================================================
echo   Starting ClaimOptima FastAPI Backend Engine...
echo   Listening on: http://127.0.0.1:5000
echo ===================================================
echo.
python -m uvicorn app:app --host 127.0.0.1 --port 5000
pause
