import pandas as pd
import random

# List of the 37 feature score columns
score_cols = [
    "Number of Diagnosis Score", "Repeat Treatment Score", "Serious Injury Presence Score",
    "Gap in Treatment Score", "Surgery Performed Score", "Body Part Injured Score",
    "Chronic Disease History Score", "ER Visit Score", "Hospital Admissions Score",
    "Therapy Sessions Score", "Total Treatment Duration Score", "Diagnostic Procedures Score",
    "Polypharmacy Score", "Opioid Usage Score", "Controlled Substances Score",
    "High-Risk Medication Score", "Number of Providers Score", "Number of Facilities Score",
    "Geographic Dispersion Score", "Attorney Representation Score", "Type of Claim Score",
    "Claim Age Score", "Coverage Dispute Score", "Claim Amount Score", "Age Score",
    "Employment Status Score", "Return to Work Risk Score", "Weight/BMI Score",
    "Drug Use Score", "Mental Health Score", "Smoking Score", "Alcohol Score",
    "Accident Type Score", "LOC Score", "Restrained Score", "Head Impact Score",
    "Third party involvement Score", "no of vehicles Score", "catastrophic indicators Score",
    "other exposures Score"
]

# Clinical text lists for mock generation
diagnoses_options = [
    "Cervical sprain, lumbar radiculopathy, soft tissue whiplash",
    "Lumbar disc herniation, L4-L5 nerve root compression",
    "Traumatic brain injury, mild concussion, scalp laceration",
    "Left rotator cuff tear, shoulder impingement",
    "Knee meniscus tear, patellar tracking disorder",
    "Lumbar strain, myofascial pain syndrome"
]

chronic_options = [
    "Hypertension, hyperlipidemia",
    "Type II Diabetes Mellitus",
    "Osteoarthritis, chronic back pain",
    "blank"
]

mental_health_options = [
    "Anxiety, chronic insomnia",
    "PTSD (post-traumatic stress disorder)",
    "Depression, adjustment disorder",
    "blank"
]

injury_options = [
    "Lumbar disc herniation, L4-L5 herniation",
    "Right knee meniscus tear",
    "Mild traumatic brain injury",
    "blank",
    "none"
]

opioid_options = ["Tramadol, Oxycodone", "Hydrocodone", "blank", "none"]
controlled_options = ["Gabapentin", "Clonazepam, Zolpidem", "blank", "none"]
high_risk_options = ["Cyclobenzaprine, Amitriptyline", "Methocarbamol", "blank", "none"]
surgery_options = ["Epidural steroid injection, lumbar facet block", "Right shoulder arthroscopy", "Laminectomy", "blank", "none"]
neuro_options = ["Left L5 radiculopathy", "Sciatica, cervical radiculopathy", "blank", "none"]
body_parts = ["Lumbar spine", "Cervical spine", "Left shoulder", "Right knee", "Head"]
accident_types = ["rear-end collision", "side-impact collision", "multi-vehicle collision", "rollover accident", "fall accident"]

# Generate 15 rows
data = []
for i in range(1, 16):
    age = random.randint(22, 70)
    gender = "Male" if random.random() > 0.5 else "Female"
    
    # Random feature scores
    feature_scores = {}
    for col in score_cols:
        if "Admissions" in col or "Surgery" in col or "catastrophic" in col:
            feature_scores[col] = random.choice([0, 4]) # larger scores for high weight features
        else:
            feature_scores[col] = random.randint(0, 4)
            
    # Calculate a correlated demand value
    base_demand = 15000
    demand = (
        base_demand +
        feature_scores["Serious Injury Presence Score"] * 12000 +
        feature_scores["Surgery Performed Score"] * 25000 +
        feature_scores["ER Visit Score"] * 5000 +
        feature_scores["Hospital Admissions Score"] * 35000 +
        feature_scores["Opioid Usage Score"] * 4000 +
        random.randint(-5000, 5000)
    )
    
    row = {
        "JOB_ID": f"JOB-{1000 + i}",
        "PatientOrClaimantName": f"Test Claimant {i}",
        "age": age,
        "Gender": gender,
        "demand": max(5000, demand),
        "type_of_claim": "temporary partial disability" if random.random() > 0.4 else "permanent partial disability",
        "employment_status_derived": "employed" if random.random() > 0.3 else "non-employed",
        "return_to_work_risk": "Delayed/Restricted" if random.random() > 0.5 else "no risk",
        "diagnoses": random.choice(diagnoses_options),
        "chronic_diseases": random.choice(chronic_options),
        "mental_health_diseases": random.choice(mental_health_options),
        "serious_injury_presence": random.choice(injury_options),
        "opioid_usage_details": random.choice(opioid_options),
        "controlled_substances_details": random.choice(controlled_options),
        "high_risk_medication_details": random.choice(high_risk_options),
        "surgical_procedures_details": random.choice(surgery_options),
        "neurological_injuries_details": random.choice(neuro_options),
        "permanent_impairment_details": "MMI rating 5%" if random.random() > 0.7 else "blank",
        "body_part_injured_details": random.choice(body_parts),
        "accident_type": random.choice(accident_types),
        "other_exposures": "head" if random.random() > 0.75 else "blank",
        "loss_of_consciousness": "yes" if random.random() > 0.7 else "no",
        "restrained": "yes" if random.random() > 0.2 else "no",
        "head_impact": "yes" if random.random() > 0.6 else "no",
        "third_party_involvement": "yes" if random.random() > 0.4 else "no",
        "number_of_vehicles": "two" if random.random() > 0.3 else "single",
        "catastrophic_indicator": "no" if random.random() > 0.9 else "no",
        **feature_scores
    }
    data.append(row)

# Save to CSV (Note: Flask backend expects CSV upload)
df = pd.DataFrame(data)
df.to_csv("d:\\Komal\\medcon\\sample_claims.csv", index=False)
print("sample_claims.csv generated successfully with 15 rows.")
