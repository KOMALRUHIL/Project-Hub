# ==============================================================================
# 🔗 SHAREPOINT DESTINATION CONFIGURATION
# ==============================================================================
# Paste your SharePoint Folder Link, Direct File URL, OneDrive Sync Link,
# or SharePoint Webhook Endpoint inside the quotes below:
# ==============================================================================

SHAREPOINT_LINK = ""

# Example:
# SHAREPOINT_LINK = "https://yourcompany.sharepoint.com/sites/YourTeam/Shared%20Documents/claims_complexity_master.csv"
# ==============================================================================
