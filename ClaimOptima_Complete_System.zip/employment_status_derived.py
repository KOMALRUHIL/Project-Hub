import os
import json
import time
import csv
import threading
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed

# ----------------------------------------------------
# CONFIGURATION
# ----------------------------------------------------
# Paste your credentials here:
AZURE_AI_CHAT_ENDPOINT = "YOUR_AZURE_ENDPOINT_HERE"
AZURE_AI_CHAT_KEY = "YOUR_AZURE_KEY_HERE"
AZURE_AI_CHAT_MODEL = "Llama-3.3-70B-Instruct"

# Performance settings
MAX_WORKERS = 5  # Number of rows to process in parallel
MAX_RETRIES = 3  # Number of retries for rate limits (429)

# Cost settings ($0.71 per 1 million tokens)
COST_PER_M_TOKENS = 0.71
# ----------------------------------------------------

# Threading locks and trackers
csv_write_lock = threading.Lock()
stats_lock = threading.Lock()
total_input_tokens = 0
total_output_tokens = 0
total_cost_usd = 0.0

def get_llama_credentials():
    endpoint = AZURE_AI_CHAT_ENDPOINT
    key = AZURE_AI_CHAT_KEY
    model = AZURE_AI_CHAT_MODEL
    
    if endpoint == "YOUR_AZURE_ENDPOINT_HERE":
        endpoint = os.getenv("AZURE_AI_CHAT_ENDPOINT", "")
    if key == "YOUR_AZURE_KEY_HERE":
        key = os.getenv("AZURE_AI_CHAT_KEY", "")
    if model == "Llama-3.3-70B-Instruct":
        model = os.getenv("AZURE_AI_CHAT_MODEL", "Llama-3.3-70B-Instruct")
        
    url = endpoint.rstrip("/")
    if not url.endswith("/chat/completions"):
        if url.endswith("/v1"):
            url = f"{url}/chat/completions"
        else:
            url = f"{url}/v1/chat/completions"
            
    return url, key, model

def generate_extraction_prompt(patient_data):
    """
    Constructs the system instructions and patient data inputs for the LLM.
    """
    system_prompt = """
You are a highly precise clinical coding assistant. Your task is to analyze a patient's raw employment status and wage loss details, and return a structured JSON object containing a standardized classification.

You must follow this logic to determine employment_status_derived:
- Primary: Look at the raw text in 'employment_status'. Classify it into one of these three categories:
  * "employed" (if they are working, self-employed, full-time, part-time, active duty, etc.)
  * "non-employed" (if they are unemployed, retired, student, disabled, homemaker, or have no active work history)
  * null (if the field is empty, null, or completely unknown)
- Fallback: If 'employment_status' is empty/null, evaluate the 'special-damages-wage-loss-citation' column. If it mentions wage loss (e.g. missed shifts, lost work days, lost income, missed work), infer "employed".
- If both are empty or don't indicate employment $\rightarrow$ null.

---
Format your response as a strict JSON object with this key:
{
  "employment_status_derived": "value"
}
Do not write any introduction, code blocks, or markdown formatting outside the JSON. Return only the JSON string.
Ensure the JSON key and value are properly wrapped in standard double quotes.
"""
    
    filtered_data = {
        "employment_status": str(patient_data.get("employment_status", "")).strip(),
        "special-damages-wage-loss-citation": str(patient_data.get("special-damages-wage-loss-citation", "")).strip()
    }
    
    # Clean nulls/NaNs
    for k in filtered_data:
        if filtered_data[k] in (None, "", "NaN", "nan", "None", "null"):
            filtered_data[k] = None
        
    user_prompt = f"Patient Record Data:\n{json.dumps(filtered_data, indent=2)}"
    return system_prompt, user_prompt

def call_azure_api_with_retry(payload, url, api_key, row_num):
    """
    Sends POST request with exponential backoff retry logic.
    """
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    backoff = 2
    for attempt in range(MAX_RETRIES):
        try:
            response = requests.post(url, json=payload, headers=headers, timeout=60)
            
            if response.status_code == 429:
                print(f"[ROW {row_num}] Rate limited (429). Retrying in {backoff}s... (Attempt {attempt+1}/{MAX_RETRIES})", flush=True)
                time.sleep(backoff)
                backoff *= 2
                continue
            elif 400 <= response.status_code < 500:
                print(f"[ROW {row_num}] HTTP Client Error {response.status_code} - Skipping retries.", flush=True)
                print(f"[ROW {row_num}] Server response details: {response.text}", flush=True)
                return None
                
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.RequestException as re:
            if re.response is not None and 400 <= re.response.status_code < 500 and re.response.status_code != 429:
                print(f"[ROW {row_num}] API call failed permanently with client error {re.response.status_code}.", flush=True)
                print(f"[ROW {row_num}] Server response details: {re.response.text}", flush=True)
                return None
                
            if attempt == MAX_RETRIES - 1:
                print(f"[ROW {row_num}] API call failed permanently: {re}", flush=True)
                if re.response is not None:
                    print(f"[ROW {row_num}] Server response details: {re.response.text}", flush=True)
                return None
            print(f"[ROW {row_num}] Glitch detected: {re}. Retrying in {backoff}s...", flush=True)
            time.sleep(backoff)
            backoff *= 2
            
    return None

def process_single_row(row_data, row_num, url, api_key, model_name):
    """
    Processes one row: prompt generation, API call, token tracking, and cost calculation.
    """
    sys_msg, user_msg = generate_extraction_prompt(row_data)
    
    payload = {
        "model": model_name,
        "messages": [
            {"role": "system", "content": sys_msg},
            {"role": "user", "content": user_msg}
        ],
        "temperature": 0.0,
        "max_tokens": 100
    }
    
    response_data = call_azure_api_with_retry(payload, url, api_key, row_num)
    if not response_data:
        return row_num, None
        
    try:
        raw_content = response_data["choices"][0]["message"]["content"].strip()
        
        if raw_content.startswith("```"):
            raw_content = raw_content.split("```json")[-1].split("```")[0].strip()
            
        parsed_json = json.loads(raw_content)
        
        # Extract token usage and update metrics
        usage = response_data.get("usage", {})
        prompt_tokens = usage.get("prompt_tokens", 0)
        completion_tokens = usage.get("completion_tokens", 0)
        
        row_cost = ((prompt_tokens + completion_tokens) / 1_000_000) * COST_PER_M_TOKENS
        
        global total_input_tokens, total_output_tokens, total_cost_usd
        with stats_lock:
            total_input_tokens += prompt_tokens
            total_output_tokens += completion_tokens
            total_cost_usd += row_cost
            
        print(f"[ROW {row_num}] Processed. Derived: {parsed_json.get('employment_status_derived')} | Cost: ${row_cost:.5f}", flush=True)
        return row_num, parsed_json
        
    except Exception as e:
        print(f"[ROW {row_num}] Extraction/Parsing failed: {e}", flush=True)
        return row_num, None

def batch_process_csv():
    """
    Reads test.csv, processes rows in parallel, updates data, and saves to test_extracted.csv.
    """
    script_dir = os.path.dirname(os.path.abspath(__file__))
    input_path = os.path.join(script_dir, "test.csv")
    output_path = os.path.join(script_dir, "test_extracted.csv")
    
    if not os.path.exists(input_path):
        print(f"[ERROR] Input file 'test.csv' not found at: {input_path}", flush=True)
        print("Please place your 'test.csv' in the script directory.", flush=True)
        return
        
    url, api_key, model_name = get_llama_credentials()
    if not url or not api_key:
        print("[ERROR] Credentials not set. Please update endpoint/keys directly in the code.", flush=True)
        return
        
    print(f"Reading input file: {input_path}", flush=True)
    try:
        with open(input_path, mode="r", encoding="utf-8-sig") as f:
            reader = list(csv.DictReader(f))
    except UnicodeDecodeError:
        print("[WARNING] Failed to decode with UTF-8-sig. Retrying with cp1252 (Windows ANSI) encoding...", flush=True)
        with open(input_path, mode="r", encoding="cp1252") as f:
            reader = list(csv.DictReader(f))
        
    if not reader:
        print("[ERROR] CSV file is empty.", flush=True)
        return
        
    headers = list(reader[0].keys())
    new_cols = ["employment_status_derived"]
    
    for col in new_cols:
        if col not in headers:
            headers.append(col)
            
    # Check for existing output file to resume progress
    processed_rows = {}
    if os.path.exists(output_path):
        print(f"Resuming progress from existing output file: {output_path}", flush=True)
        try:
            with open(output_path, mode="r", encoding="utf-8-sig") as out_f:
                out_reader = list(csv.DictReader(out_f))
                for idx, out_row in enumerate(out_reader):
                    is_processed = out_row.get("employment_status_derived") not in (None, "", "null")
                    if is_processed:
                        processed_rows[idx] = out_row
        except UnicodeDecodeError:
            with open(output_path, mode="r", encoding="cp1252") as out_f:
                out_reader = list(csv.DictReader(out_f))
                for idx, out_row in enumerate(out_reader):
                    is_processed = out_row.get("employment_status_derived") not in (None, "", "null")
                    if is_processed:
                        processed_rows[idx] = out_row
        print(f"Found {len(processed_rows)} successfully processed rows.", flush=True)
        
    start_time = time.time()
    total_rows = len(reader)
    print(f"Starting batch process. Total rows: {total_rows}. Workers: {MAX_WORKERS}", flush=True)
    
    def save_output_file(current_dataset):
        with csv_write_lock:
            with open(output_path, mode="w", newline="", encoding="utf-8") as out_f:
                writer = csv.DictWriter(out_f, fieldnames=headers)
                writer.writeheader()
                writer.writerows(current_dataset)

    output_dataset = []
    for idx, row in enumerate(reader):
        if idx in processed_rows:
            output_dataset.append(processed_rows[idx])
        else:
            new_row = row.copy()
            for col in new_cols:
                new_row[col] = ""
            output_dataset.append(new_row)
            
    rows_to_process = [i for i in range(len(reader)) if i not in processed_rows]
    
    if not rows_to_process:
        print("[SUCCESS] All rows have already been processed!", flush=True)
        return
        
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {
            executor.submit(process_single_row, reader[idx], idx + 1, url, api_key, model_name): idx 
            for idx in rows_to_process
        }
        
        for future in as_completed(futures):
            idx = futures[future]
            row_num, extracted_features = future.result()
            
            if extracted_features:
                for col_name, val in extracted_features.items():
                    output_dataset[idx][col_name] = val
                save_output_file(output_dataset)
                
            global total_cost_usd
            print(f"Progress: {len(output_dataset) - len(rows_to_process) + sum(1 for i in rows_to_process if output_dataset[i]['employment_status_derived'] != '')}/{total_rows} completed. Accumulated Cost: ${total_cost_usd:.4f}", flush=True)
            
    elapsed_time = time.time() - start_time
    print("\n" + "="*50, flush=True)
    print("[SUCCESS] Processing completed!", flush=True)
    print(f"Output saved to: {output_path}", flush=True)
    print(f"Time elapsed: {elapsed_time/60:.2f} minutes", flush=True)
    print(f"Total API cost: ${total_cost_usd:.4f} USD", flush=True)
    print("="*50, flush=True)

if __name__ == "__main__":
    batch_process_csv()
