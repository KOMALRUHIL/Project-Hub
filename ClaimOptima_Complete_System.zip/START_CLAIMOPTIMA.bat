@echo off
title Launch ClaimOptima AI System
echo ===================================================
echo       Launching ClaimOptima AI Complete System
echo ===================================================
echo.
echo [1/3] Starting FastAPI Backend on http://127.0.0.1:5000...
start "ClaimOptima Backend Server" cmd /k "python -m uvicorn app:app --host 127.0.0.1 --port 5000"

echo [2/3] Starting Vite Frontend on http://localhost:5173...
start "ClaimOptima Frontend Server" cmd /k "cd frontend && npm run dev"

echo [3/3] Waiting for servers to initialize...
timeout /t 3 /nobreak >nul

echo Opening browser at http://localhost:5173...
start http://localhost:5173

echo.
echo ===================================================
echo   ClaimOptima AI is now running!
echo   Frontend: http://localhost:5173
echo   Backend API: http://127.0.0.1:5000
echo ===================================================
echo.
echo Keep the backend and frontend terminal windows open.
pause
