@echo off
title ClaimOptima - Vite Frontend (Port 5173)
echo ===================================================
echo   Starting ClaimOptima Frontend UI...
echo   Listening on: http://localhost:5173
echo ===================================================
echo.
cd frontend
call npm run dev
pause
