import React from 'react';
import { ClaimOptimaApp } from './ai_conclave/ClaimOptimaApp.jsx';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, errorInfo) {
    console.error("App Crash:", error, errorInfo);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div style={{ minHeight: '100vh', background: '#070D1B', color: '#fff', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '20px', fontFamily: 'sans-serif' }}>
          <div style={{ background: '#0F172A', border: '1px solid #ef4444', borderRadius: '16px', padding: '24px', maxWidth: '600px', width: '100%', textAlign: 'center' }}>
            <h2 style={{ color: '#f87171', margin: '0 0 12px 0' }}>ClaimOptima Platform Error</h2>
            <pre style={{ background: '#040814', color: '#38bdf8', padding: '12px', borderRadius: '8px', textAlign: 'left', fontSize: '11px', overflow: 'auto' }}>
              {String(this.state.error?.stack || this.state.error?.message || this.state.error)}
            </pre>
            <button 
              onClick={() => { this.setState({ hasError: false }); window.location.reload(); }}
              style={{ marginTop: '16px', background: '#00D2FF', color: '#000', border: 'none', padding: '10px 20px', borderRadius: '8px', fontWeight: 'bold', cursor: 'pointer' }}
            >
              Reload Dashboard
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  return (
    <ErrorBoundary>
      <ClaimOptimaApp />
    </ErrorBoundary>
  );
}
