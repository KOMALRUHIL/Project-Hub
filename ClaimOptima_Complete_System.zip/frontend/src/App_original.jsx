import React, { useState, useMemo, useEffect, useRef } from "react";

// --- DYNAMIC MOCK DATA GENERATOR ---
const generateMockClaims = () => {
  const claimsList = [];
  const injuryTypes = ["L5 Disc Herniation", "Cervical Whiplash", "Rotator Cuff Tear", "Femur Fracture", "Mild TBI"];
  const genders = ["Male", "Female"];
  
  for (let i = 1; i <= 100; i++) {
      const complexityBase = Math.random() * 15 + 5;
      const claimAmount = Math.round(complexityBase * (Math.random() * 8000 + 4000));
      
      claimsList.push({
          "JOB_ID": `JOB-${1000 + i}`,
          "EXTERNAL_JOB_KEY": `EXT-${2000 + i}`,
          "LOB": "Auto Liability",
          "DateOfSubmission": "2026-06-01",
          "DateOfIncident": "2026-05-15",
          "age": Math.floor(Math.random() * 45) + 20,
          "weight": Math.floor(Math.random() * 80) + 120,
          "Gender": genders[Math.floor(Math.random() * 2)],
          "total_billed_amount": claimAmount + 5000,
          "demand": claimAmount,
          "diagnoses": `${injuryTypes[Math.floor(Math.random() * 5)]}; radiculopathy symptoms`,
          "serious_injury_presence": Math.random() > 0.7 ? "Yes" : "No",
          "surgical_procedures_details": Math.random() > 0.5 ? "Arthroscopic repair performed" : "None",
          "chronic_diseases": Math.random() > 0.8 ? "Hypertension; osteo-arthritis" : "None",
          "opioid_usage_details": Math.random() > 0.6 ? "Hydrocodone 10mg PRN" : "None",
          "controlled_substances_details": "None",
          "high_risk_medication_details": "None",
          "return_to_work_risk": Math.random() > 0.4 ? "Normal return, no restrictions" : "Delayed return due to physical therapy",
          "drug_use": "None",
          "mental_health_diseases": "None",
          "smoking": Math.random() > 0.7 ? "Yes" : "No",
          "alcohol": "Occasional",
          "loss_of_consciousness": "No",
          "restrained": "Yes",
          "head_impact": "No",
          "third_party_involvement": "None",
          "number_of_vehicles": 2,
          "catastrophic_indicator": "No",
          "other_exposures": "None",
          "overall_score": complexityBase,
          "gap_in_treatment": Math.floor(Math.random() * 20)
      });
  }
  return claimsList;
};

// Weight Configurations for the 8 Marker categories (sum to 1.0)
const scoringWeights = {
  clinicalBurden: 0.20,
  utilization: 0.15,
  medicationComplexity: 0.15,
  careFragmentation: 0.10,
  claimDetailComplexity: 0.10,
  claimantDetails: 0.10,
  socioeconomicFactors: 0.10,
  accidentDetails: 0.10
};

const markerFeatures = {
  clinicalBurden: [
      ["diagnosis_burden_score", "Number of Diagnosis Score", "Number of Diagnoses Score"],
      ["repeat_treatment_burden_score", "Repeat Treatment Score"],
      ["serious_injury_presence_score", "Serious Injury Presence Score"],
      ["gap_in_treatment_score", "Gap in Treatment Score"],
      ["surgery_performed_score", "Surgery Performed Score", "Surgical Procedures Score"],
      ["body_part_injured_score", "Body Part Injured Score"],
      ["chronic_disease_history_score", "Chronic Disease History Score", "Chronic Disease Score"]
  ],
  utilization: [
      ["er_visit_burden_score", "ER Visit Score"],
      ["hospital_admission_burden_score", "Hospital Admissions Score"],
      ["therapy_session_burden_score", "Therapy Sessions Score"],
      ["total_treatment_duration_score", "Total Treatment Duration Score"],
      ["diagnostic_test_burden_score", "Diagnostic Procedures Score"]
  ],
  medicationComplexity: [
      ["polypharmacy_burden_score", "Polypharmacy Score"],
      ["opioid_usage_score", "Opioid Usage Score"],
      ["controlled_substance_score", "Controlled Substances Score"],
      ["high_risk_medication_score", "High-Risk Medication Score", "High Risk Medication Score"]
  ],
  careFragmentation: [
      ["provider_fragmentation_score", "Number of Providers Score"],
      ["facility_fragmentation_score", "Number of Facilities Score"],
      ["geographic_dispersion_score", "Geographic Dispersion Score"]
  ],
  claimDetailComplexity: [
      ["attorney_score", "Attorney Representation Score"],
      ["claim_type_score", "Type of Claim Score"],
      ["claim_age_score", "Claim Age Score"],
      ["coverage_dispute_score", "Coverage Dispute Score"],
      ["claim_amount_score", "Claim Amount Score"]
  ],
  claimantDetails: [
      ["age_score", "Age Score"],
      ["employment_score", "Employment Status Score"],
      ["rtw_score", "Return to Work Risk Score"],
      ["weight_score", "Weight/BMI Score", "Weight BMI Score", "Weight/BMI", "Weight BMI"]
  ],
  socioeconomicFactors: [
      ["drug_use_score", "Drug Use Score"],
      ["mental_health_score", "Mental Health Score"],
      ["smoking_score", "Smoking Score"],
      ["alcohol_score", "Alcohol Score"]
  ],
  accidentDetails: [
      ["accident_type_score", "Accident Type Score"],
      ["loc_score", "LOC Score", "loss of consciousness Score", "Loss of Consciousness Score"],
      ["restrained_score", "Restrained Score"],
      ["head_impact_score", "Head Impact Score"],
      ["third_party_score", "Third party involvement Score", "Third Party Involvement Score"],
      ["number_of_vehicles_score", "no of vehicles Score", "No of Vehicles Score", "Number of Vehicles Score"],
      ["catastrophic_score", "catastrophic indicators Score", "Catastrophic Indicators Score", "Catastrophic Indicator Score"],
      ["other_exposure_score", "other exposures Score", "Other Exposures Score", "Other Exposure Score"]
  ]
};

const getScore = (row, aliasList) => {
  if (!row) return 0;
  for (let alias of aliasList) {
      if (row[alias] !== undefined && row[alias] !== null && row[alias] !== "") {
          const parsed = parseFloat(row[alias]);
          if (!isNaN(parsed)) return parsed;
      }
      const normAlias = alias.toLowerCase().replace(/[-_]/g, " ").trim();
      for (let k in row) {
          const normK = k.toLowerCase().replace(/[-_]/g, " ").trim();
          if (normAlias === normK && row[k] !== undefined && row[k] !== null && row[k] !== "") {
              const parsed = parseFloat(row[k]);
              if (!isNaN(parsed)) return parsed;
          }
      }
  }
  return 0;
};

const getClaimId = (row) => {
  if (!row) return "";
  for (let k of ["JOB_ID", "JOB-ID", "job_id", "job-id", "Record ID", "RECORD_ID", "record_id"]) {
      if (row[k] !== undefined && row[k] !== null) return String(row[k]);
  }
  for (let k in row) {
      if (k.toLowerCase().includes("id") && row[k] !== undefined && row[k] !== null) {
          return String(row[k]);
      }
  }
  const firstKey = Object.keys(row)[0];
  return String(row[firstKey] || "");
};

const getTargetValue = (c) => {
  if (!c) return 0;
  const val = parseFloat(c["total_billed_amount"] || c["demand"]);
  return isNaN(val) ? 0 : val;
};

// --- LOCAL OLS SURROGATE SOLVER (Offline Fallback) ---
const fitLocalOLS = (claims) => {
  const featureKeys = Object.values(markerFeatures).flat();
  const y = claims.map(c => {
      const parsedVal = getTargetValue(c);
      return isNaN(parsedVal) ? 0 : parsedVal;
  });
  
  const X = claims.map(c => featureKeys.map(aliases => getScore(c, aliases)));
  const numFeatures = featureKeys.length;
  const weights = new Array(numFeatures).fill(0);
  let bias = y.reduce((sum, val) => sum + val, 0) / y.length;
  
  const means = new Array(numFeatures).fill(0);
  const stds = new Array(numFeatures).fill(1);
  for (let j = 0; j < numFeatures; j++) {
      let sum = 0;
      for (let i = 0; i < X.length; i++) sum += X[i][j];
      means[j] = sum / X.length;
      
      let varSum = 0;
      for (let i = 0; i < X.length; i++) varSum += Math.pow(X[i][j] - means[j], 2);
      stds[j] = Math.sqrt(varSum / X.length) || 1.0;
  }
  
  const normX = X.map(row => row.map((val, j) => (val - means[j]) / stds[j]));
  const lr = 0.05;
  const epochs = 150;
  
  for (let epoch = 0; epoch < epochs; epoch++) {
      for (let i = 0; i < X.length; i++) {
          let pred = bias;
          for (let j = 0; j < numFeatures; j++) {
              pred += weights[j] * normX[i][j];
          }
          const error = pred - y[i];
          bias -= lr * error / X.length;
          for (let j = 0; j < numFeatures; j++) {
              weights[j] -= lr * error * normX[i][j] / X.length;
          }
      }
  }
  
  return {
      weights: weights.map((w, j) => w / stds[j]),
      bias: bias - weights.reduce((sum, w, j) => sum + (w * means[j] / stds[j]), 0),
      featureKeys: featureKeys.map(list => list[0]),
      means: means
  };
};

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    this.setState({ errorInfo });
    console.error("ErrorBoundary caught an error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-950 text-slate-100 p-8 flex flex-col items-center justify-center space-y-4">
          <div className="bg-rose-950/40 border border-rose-500/30 p-6 rounded-xl max-w-3xl w-full shadow-2xl">
            <h1 className="text-xl font-bold text-rose-400 mb-2">⚠️ Something went wrong in the Dashboard</h1>
            <p className="text-sm text-slate-200 font-medium mb-4 font-mono">
              {this.state.error && this.state.error.toString()}
            </p>
            <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg text-xs font-mono text-slate-400 overflow-auto max-h-[300px] whitespace-pre-wrap">
              {this.state.errorInfo && this.state.errorInfo.componentStack}
            </div>
            <button 
              onClick={() => window.location.reload()}
              className="mt-4 px-4 py-2 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold rounded-lg text-xs transition"
            >
              Reload Dashboard
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

// Marker display names & detailed definitions
const markerDefinitions = {
  clinicalBurden: {
      name: "Clinical Burden",
      desc: "Measures the extent of a claimant's clinical conditions, including the total diagnosis count, history of repeat treatment, presence of serious injuries, surgical procedures, and treatment gap periods."
  },
  utilization: {
      name: "Utilization",
      desc: "Tracks healthcare resource usage frequency, scoring items such as emergency room visits, hospital admission records, therapy sessions, overall treatment durations, and diagnostic test frequencies."
  },
  medicationComplexity: {
      name: "Medication Complexity",
      desc: "Evaluates pharmacotherapy risk, including polypharmacy (concurrent medications), opioid prescription durations, controlled substance history, and high-risk drug combinations."
  },
  careFragmentation: {
      name: "Care Fragmentation",
      desc: "Identifies coordination risks based on the number of independent providers seen, unique facilities visited, and the geographic dispersion between clinical treatment locations."
  },
  claimDetailComplexity: {
      name: "Claim Detail Complexity",
      desc: "Measures procedural and financial complexity indicators, including attorney representation, type of claim, age of claim, coverage dispute histories, and total billed amounts."
  },
  claimantDetails: {
      name: "Claimant Details",
      desc: "Analyzes claimant demographic and vocational risk factors, including age, employment status, weight/BMI, and predicted return-to-work delay flags."
  },
  socioeconomicFactors: {
      name: "Socioeconomic Factors",
      desc: "Captures patient behavioral history, history of alcohol abuse, tobacco usage, drug exposures, and diagnosed mental health conditions."
  },
  accidentDetails: {
      name: "Accident Details",
      desc: "Rates the severity of the initial incident, looking at loss of consciousness (LOC) duration, impact forces, restraint usage (e.g. seatbelts), third-party involvement, and vehicle counts."
  }
};

// Map scoring features to raw text columns in the CSV
const featureToTextColumnMap = {
  "diagnosis_burden_score": "diagnoses",
  "Number of Diagnosis Score": "diagnoses",
  "Number of Diagnoses Score": "diagnoses",
  "serious_injury_presence_score": "serious_injury_presence",
  "Serious Injury Presence Score": "serious_injury_presence",
  "surgery_performed_score": "surgical_procedures_details",
  "Surgery Performed Score": "surgical_procedures_details",
  "Surgical Procedures Score": "surgical_procedures_details",
  "chronic_disease_history_score": "chronic_diseases",
  "Chronic Disease History Score": "chronic_diseases",
  "Chronic Disease Score": "chronic_diseases",
  "opioid_usage_score": "opioid_usage_details",
  "Opioid Usage Score": "opioid_usage_details",
  "controlled_substance_score": "controlled_substances_details",
  "Controlled Substances Score": "controlled_substances_details",
  "high_risk_medication_score": "high_risk_medication_details",
  "High-Risk Medication Score": "high_risk_medication_details",
  "High Risk Medication Score": "high_risk_medication_details",
  "age_score": "age",
  "Age Score": "age",
  "employment_score": "employment_status_derived",
  "Employment Status Score": "employment_status_derived",
  "rtw_score": "return_to_work_risk",
  "Return to Work Risk Score": "return_to_work_risk",
  "drug_use_score": "drug_use",
  "Drug Use Score": "drug_use",
  "mental_health_score": "mental_health_diseases",
  "Mental Health Score": "mental_health_diseases",
  "smoking_score": "smoking",
  "Smoking Score": "smoking",
  "alcohol_score": "alcohol",
  "Alcohol Score": "alcohol",
  "accident_type_score": "accident_type",
  "Accident Type Score": "accident_type",
  "loc_score": "loss_of_consciousness",
  "LOC Score": "loss_of_consciousness",
  "restrained_score": "restrained",
  "Restrained Score": "restrained",
  "head_impact_score": "head_impact",
  "Head Impact Score": "head_impact",
  "third_party_score": "third_party_involvement",
  "Third party involvement Score": "third_party_involvement",
  "Third Party Involvement Score": "third_party_involvement",
  "number_of_vehicles_score": "number_of_vehicles",
  "no of vehicles Score": "number_of_vehicles",
  "No of Vehicles Score": "number_of_vehicles",
  "Number of Vehicles Score": "number_of_vehicles",
  "catastrophic_score": "catastrophic_indicator",
  "catastrophic indicators Score": "catastrophic_indicator",
  "Catastrophic Indicators Score": "catastrophic_indicator",
  "Catastrophic Indicator Score": "catastrophic_indicator",
  "other_exposure_score": "other_exposures",
  "other exposures Score": "other_exposures",
  "Other Exposures Score": "other_exposures",
  
  // User provided feature-to-text column mappings
  "er_visit_burden_score": "er_visit_count",
  "ER Visit Score": "er_visit_count",
  "hospital_admission_burden_score": "hospital_admission_count",
  "Hospital Admissions Score": "hospital_admission_count",
  "therapy_session_burden_score": "therapy_session_count",
  "Therapy Sessions Score": "therapy_session_count",
  "diagnostic_test_burden_score": "diagnostic_test_count",
  "Diagnostic Procedures Score": "diagnostic_test_count",
  "total_treatment_duration_score": "treatment_length_days",
  "Total Treatment Duration Score": "treatment_length_days",
  
  "provider_fragmentation_score": "provider_count",
  "Number of Providers Score": "provider_count",
  "facility_fragmentation_score": "facility_count",
  "Number of Facilities Score": "facility_count",
  "geographic_dispersion_score": "provider_state_count",
  "Geographic Dispersion Score": "provider_state_count",
  
  "attorney_score": "attorney_representation_flag",
  "Attorney Representation Score": "attorney_representation_flag",
  "claim_age_score": "claim_Age",
  "Claim Age Score": "claim_Age",
  "coverage_dispute_score": "unsubstantiated amount",
  "Coverage Dispute Score": "unsubstantiated amount",
  "claim_amount_score": "demand",
  "Claim Amount Score": "demand",
  "claim_type_score": "type_of_claim",
  "Type of Claim Score": "type_of_claim",
  
  "repeat_treatment_burden_score": "repeat_diagnosis_cont",
  "Repeat Treatment Score": "repeat_diagnosis_cont",
  "gap_in_treatment_score": "total_treatment_gap_Days",
  "Gap in Treatment Score": "total_treatment_gap_Days",
  "body_part_injured_score": "body_part_injured_details",
  "Body Part Injured Score": "body_part_injured_details",
  "polypharmacy_burden_score": "polypharmacy_medicatoin_count",
  "Polypharmacy Score": "polypharmacy_medicatoin_count",
  "weight_score": "weight",
  "Weight/BMI Score": "weight",
  "Weight BMI Score": "weight"
};

const getClaimTextValue = (claim, colName) => {
    if (!claim || !colName) return "";
    if (claim[colName] !== undefined && claim[colName] !== null) return String(claim[colName]);
    
    // Normalize target column name
    const normTarget = colName.toLowerCase().replace(/[-_]/g, " ").trim();
    for (let k in claim) {
        const normKey = k.toLowerCase().replace(/[-_]/g, " ").trim();
        if (normTarget === normKey && claim[k] !== undefined && claim[k] !== null) {
            return String(claim[k]);
        }
    }
    return "";
};

function App() {
  const [claims, setClaims] = useState([]);
  const [selectedClaimId, setSelectedClaimId] = useState(null); // null means "Overall Level"
  const [weights, setWeights] = useState(scoringWeights);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [analysisMode, setAnalysisMode] = useState("complexity"); // "complexity" or "severity"
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [individualTab, setIndividualTab] = useState("waterfall");
  
  // Tabbed navigation state
  const [activeTab, setActiveTab] = useState("input");
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadStep, setUploadStep] = useState("");
  
  // Drill-down states
  const [activeDetailCategory, setActiveDetailCategory] = useState(null);
  const [activeDetailFeature, setActiveDetailFeature] = useState(null);
  const [activeWeightsRuleCategory, setActiveWeightsRuleCategory] = useState(null);
  const [isCalculatingWeights, setIsCalculatingWeights] = useState(false);
  const [terminalLogs, setTerminalLogs] = useState([]);
  const [activeRuleCategory, setActiveRuleCategory] = useState("clinicalBurden");

  const weightsSum = useMemo(() => {
      return Object.values(weights).reduce((a, b) => a + b, 0);
  }, [weights]);

  const isNot100Percent = useMemo(() => {
      return Math.abs(weightsSum - 1.0) > 0.0011;
  }, [weightsSum]);

  // Real SHAP data states (from Backend)
  const [backendShapData, setBackendShapData] = useState(null);

  // Initialize with Mock Data
  useEffect(() => {
      const initialData = generateMockClaims();
      setClaims(initialData);
  }, []);

  const handleRecalculateWeights = () => {
      setIsCalculatingWeights(true);
      setTerminalLogs(["> Initializing weights recalculation..."]);
      
      const logs = [
          "> Recalculating overall complexity scores based on revised weights...",
          "> Training surrogate OLS model and explanation models...",
          "> Calculating SHAP values for all active claims...",
          "> Compiling portfolio risk coefficients...",
          "> Recalculation successful! Redirecting to dashboard..."
      ];
      
      logs.forEach((log, idx) => {
          setTimeout(() => {
              setTerminalLogs(prev => [...prev, log]);
          }, (idx + 1) * 450);
      });
      
      setTimeout(() => {
          setIsCalculatingWeights(false);
          setActiveTab("analytics");
      }, (logs.length + 1) * 450 + 200);
  };

  // Handle Real File Upload to FastAPI
  const handleFileUpload = async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      
      setLoading(true);
      setErrorMsg("");
      setUploadProgress(0);
      setUploadStep("Cleaning the dataset...");

      // Simulate progress visually
      let progress = 0;
      const progressInterval = setInterval(() => {
          progress += Math.floor(Math.random() * 8) + 2;
          if (progress >= 95) {
              progress = 95;
              clearInterval(progressInterval);
          }
          setUploadProgress(progress);
          if (progress < 30) {
              setUploadStep("Cleaning the dataset...");
          } else if (progress < 65) {
              setUploadStep("Extracting the features...");
          } else {
              setUploadStep("Calculating complexity scores...");
          }
      }, 120);
      
      const formData = new FormData();
      formData.append("file", file);
      
      try {
          const response = await fetch("/api/upload", {
              method: "POST",
              body: formData
          });
          
          clearInterval(progressInterval);
          
          if (!response.ok) {
              const err = await response.json();
              throw new Error(err.detail || err.error || "Failed to process CSV on server.");
          }
          
          const result = await response.json();
          if (!result || !result.claims || !Array.isArray(result.claims)) {
              throw new Error("Invalid response format: 'claims' is missing or not an array.");
          }
          
          setUploadProgress(100);
          setUploadStep("Dataset processed successfully!");
          
          setClaims(result.claims);
          setBackendShapData({
              shapValues: Array.isArray(result.shap_values) ? result.shap_values : [],
              baseValue: typeof result.base_value === 'number' ? result.base_value : 0,
              featureNames: Array.isArray(result.feature_names) ? result.feature_names : [],
              metrics: result.metrics || { r2: 0.88, mae: 14200, rmse: 19800 }
          });
          setSelectedClaimId(null); // Reset selection
          setActiveDetailCategory(null);
          setActiveDetailFeature(null);
      } catch (err) {
          clearInterval(progressInterval);
          setUploadProgress(0);
          setUploadStep("");
          setErrorMsg(err.message);
          console.error("Upload error:", err);
      } finally {
          setLoading(false);
      }
  };

  const handleWeightChange = (key, val) => {
      setWeights(prev => ({
          ...prev,
          [key]: parseFloat(val)
      }));
  };

  const resetWeights = () => {
      setWeights(scoringWeights);
  };

  const localOLSModel = useMemo(() => {
      if (claims.length > 0) {
          try {
              return fitLocalOLS(claims);
          } catch (e) {
              console.error("Failed to fit local OLS model:", e);
          }
      }
      return null;
  }, [claims]);

  // Compute calculated Complexity values dynamically in React
  const calculatedClaims = useMemo(() => {
      return claims.map(c => {
          const markerScores = {};
          let totalScore = 0;
          
          for (let marker in markerFeatures) {
              const sum = markerFeatures[marker].reduce((acc, aliases) => acc + getScore(c, aliases), 0);
              markerScores[marker] = sum;
              totalScore += sum * weights[marker];
          }
          
          return {
              ...c,
              markerScores,
              calculatedComplexity: parseFloat(totalScore.toFixed(3))
          };
      });
  }, [claims, weights]);

  const selectedClaim = useMemo(() => {
      return calculatedClaims.find(c => getClaimId(c) === selectedClaimId);
  }, [calculatedClaims, selectedClaimId]);

  const selectedClaimIndex = useMemo(() => {
      return calculatedClaims.findIndex(c => getClaimId(c) === selectedClaimId);
  }, [calculatedClaims, selectedClaimId]);

  // Master sorted list of all individual sub-features by point contribution
  const allFeaturesContributionList = useMemo(() => {
      if (calculatedClaims.length === 0) return [];
      
      const list = [];
      for (let marker in markerFeatures) {
          const weight = weights[marker] || 0;
          markerFeatures[marker].forEach(aliases => {
              const name = aliases[0];
              
              let scoreVal;
              if (selectedClaim) {
                  scoreVal = getScore(selectedClaim, aliases);
              } else {
                  const totalScore = calculatedClaims.reduce((acc, c) => acc + getScore(c, aliases), 0);
                  scoreVal = calculatedClaims.length > 0 ? totalScore / calculatedClaims.length : 0;
              }
              
              const pointsCont = scoreVal * weight;
              
              list.push({
                  rawName: name,
                  name: name.replace(/_score/g, '').replace(/_/g, ' '),
                  category: markerDefinitions[marker].name,
                  points: pointsCont,
                  rawScore: scoreVal,
                  weight: weight
              });
          });
      }
      
      return list.sort((a, b) => b.points - a.points);
  }, [calculatedClaims, weights, selectedClaim]);

  // Mine combinations of 3+ features leading to the highest score
  const minedDangerousCombinations = useMemo(() => {
      if (calculatedClaims.length === 0) return [];
      
      const candidates = [
          {
              id: "trauma_pharma",
              name: "Trauma & Opioid Dependency Risk",
              features: ["Serious Injury Presence", "Opioid Usage Details", "Polypharmacy Count"],
              check: (c) => {
                  const hasTrauma = getClaimTextValue(c, "serious_injury_presence").toLowerCase() === "yes";
                  const hasOpioids = getClaimTextValue(c, "opioid_usage_details").toLowerCase() !== "none" && getClaimTextValue(c, "opioid_usage_details") !== "";
                  const polyCount = parseInt(getClaimTextValue(c, "polypharmacy_medicatoin_count")) || 0;
                  return hasTrauma && hasOpioids && polyCount >= 4;
              },
              desc: "Traumatic injury paired with active opioid prescriptions and high polypharmacy (4+ concurrent meds). High risk of chronic dependency and recovery delay."
          },
          {
              id: "fragmentation",
              name: "Chronic Care Fragmentation",
              features: ["Chronic Diseases", "Provider Count", "Facility Count"],
              check: (c) => {
                  const hasChronic = getClaimTextValue(c, "chronic_diseases").toLowerCase() !== "none" && getClaimTextValue(c, "chronic_diseases") !== "";
                  const provCount = parseInt(getClaimTextValue(c, "provider_count")) || 0;
                  const facCount = parseInt(getClaimTextValue(c, "facility_count")) || 0;
                  return hasChronic && provCount >= 3 && facCount >= 2;
              },
              desc: "Claimants with pre-existing chronic conditions visiting 3+ distinct providers and 2+ facilities. Suggests duplicate testing and poor care coordination."
          },
          {
              id: "litigated_financial",
              name: "Litigated Financial Escalation",
              features: ["Attorney Representation", "Disputed Amount", "Demand Amount"],
              check: (c) => {
                  const hasAttorney = getClaimTextValue(c, "attorney_representation_flag").toLowerCase() === "yes";
                  const demand = parseFloat(getClaimTextValue(c, "demand")) || 0;
                  const dispute = parseFloat(getClaimTextValue(c, "unsubstantiated amount")) || 0;
                  return hasAttorney && demand >= 20000 && dispute >= 1000;
              },
              desc: "Attorney representation active on a claim with over $20k demand and outstanding coverage disputes. Signifies extremely high litigated leakage risk."
          },
          {
              id: "recovery_barriers",
              name: "Systemic Recovery Barriers",
              features: ["Treatment Gaps", "Treatment Duration", "Body Part Details"],
              check: (c) => {
                  const gapDays = parseFloat(getClaimTextValue(c, "total_treatment_gap_Days")) || 0;
                  const duration = parseFloat(getClaimTextValue(c, "treatment_length_days")) || 0;
                  const hasBodyParts = getClaimTextValue(c, "body_part_injured_details").toLowerCase() !== "none" && getClaimTextValue(c, "body_part_injured_details") !== "";
                  return gapDays >= 8 && duration >= 45 && hasBodyParts;
              },
              desc: "Gaps in treatment of 8+ days combined with 45+ total treatment length and multiple body part injuries. High risk of permanent impairment."
          },
          {
              id: "behavioral_substance",
              name: "Behavioral & Substance Abuse Risk",
              features: ["Controlled Substances", "Mental Health Diseases", "Opioid Usage Details"],
              check: (c) => {
                  const hasControlled = getClaimTextValue(c, "controlled_substances_details").toLowerCase() !== "none" && getClaimTextValue(c, "controlled_substances_details") !== "";
                  const hasMental = getClaimTextValue(c, "mental_health_diseases").toLowerCase() !== "none" && getClaimTextValue(c, "mental_health_diseases") !== "";
                  const hasOpioids = getClaimTextValue(c, "opioid_usage_details").toLowerCase() !== "none" && getClaimTextValue(c, "opioid_usage_details") !== "";
                  return hasControlled && hasMental && hasOpioids;
              },
              desc: "Mental health conditions paired with active controlled substances and opioid usage. Triggers a high risk of medical non-compliance and substance dependency."
          }
      ];
      
      const results = candidates.map(cand => {
          const matchingClaims = calculatedClaims.filter(cand.check);
          const count = matchingClaims.length;
          const prevalence = (count / calculatedClaims.length) * 100;
          
          const avgComplexity = count > 0 
              ? (matchingClaims.reduce((sum, c) => sum + c.calculatedComplexity, 0) / count)
              : 0;
          
          return {
              ...cand,
              count,
              prevalence,
              avgComplexity: parseFloat(avgComplexity.toFixed(2))
          };
      });
      
      return results.sort((a, b) => b.avgComplexity - a.avgComplexity);
  }, [calculatedClaims]);

  const markerContributions = useMemo(() => {
      if (calculatedClaims.length === 0) return [];
      
      const markers = [
          { key: "clinicalBurden", name: "Clinical Burden" },
          { key: "utilization", name: "Utilization" },
          { key: "medicationComplexity", name: "Medication Complexity" },
          { key: "careFragmentation", name: "Care Fragmentation" },
          { key: "claimDetailComplexity", name: "Claim Detail Complexity" },
          { key: "claimantDetails", name: "Claimant Details" },
          { key: "socioeconomicFactors", name: "Socioeconomic Factors" },
          { key: "accidentDetails", name: "Accident Details" }
      ];
      
      const contribs = markers.map(m => {
          const aliasList = markerFeatures[m.key];
          const weight = weights[m.key] || 0;
          
          let scoreVal;
          if (selectedClaim) {
              scoreVal = aliasList.reduce((accFeature, aliases) => accFeature + getScore(selectedClaim, aliases), 0);
          } else {
              const totalScore = calculatedClaims.reduce((accClaim, c) => {
                  const sum = aliasList.reduce((accFeature, aliases) => accFeature + getScore(c, aliases), 0);
                  return accClaim + sum;
              }, 0);
              scoreVal = totalScore / calculatedClaims.length;
          }
          
          const cont = scoreVal * weight;
          
          return {
              key: m.key,
              name: m.name,
              avgScore: scoreVal,
              avgCont: cont,
              weight
          };
      });
      
      const totalCont = contribs.reduce((acc, c) => acc + c.avgCont, 0) || 1.0;
      
      return contribs.map(c => ({
          ...c,
          percentage: (c.avgCont / totalCont) * 100
      })).sort((a, b) => b.avgCont - a.avgCont);
  }, [calculatedClaims, weights, selectedClaim]);



  const filteredClaims = useMemo(() => {
      return calculatedClaims.filter(c => {
          const id = String(c["JOB_ID"] || "").toLowerCase();
          const name = String(c["PatientOrClaimantName"] || c["attorney_name"] || "").toLowerCase();
          const q = searchQuery.toLowerCase();
          return id.includes(q) || name.includes(q);
      });
  }, [calculatedClaims, searchQuery]);

  // Reset feature drill-down if category changes
  useEffect(() => {
      setActiveDetailFeature(null);
  }, [activeDetailCategory]);

  // --- NLP WORD FREQUENCY CALCULATOR ---
  const textTermFrequencies = useMemo(() => {
      if (claims.length === 0 || !activeDetailFeature) return [];
      
      const textColumn = featureToTextColumnMap[activeDetailFeature];
      if (!textColumn) return [];

      // Determine which rows to scan (all rows for global view, or just selected claim in individual view)
      const claimsToScan = selectedClaim ? [selectedClaim] : claims;
      const counts = {};

      claimsToScan.forEach(c => {
          const rawText = c[textColumn];
          if (rawText !== undefined && rawText !== null && rawText !== "") {
              // Split by commas, semicolons, and trim elements
              const parts = String(rawText)
                  .split(/[;,]/)
                  .map(s => s.trim().replace(/^[\s\d.-]+/, "")) // clean numbers/bullets
                  .filter(s => s.length > 2 && !["none", "yes", "no", "nan", "null", "undefined", "blank"].includes(s.toLowerCase()));

              parts.forEach(part => {
                  const capitalized = part.split(" ").map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(" ");
                  counts[capitalized] = (counts[capitalized] || 0) + 1;
              });
          }
      });

      return Object.keys(counts)
          .map(term => ({ term, count: counts[term] }))
          .sort((a, b) => b.count - a.count)
          .slice(0, 10);
  }, [claims, selectedClaim, activeDetailFeature]);

    // --- DANGEROUS RISK COMBINATIONS (Dynamic SHAP/Weights Positive Driver Pairs) ---
  const dangerousCombos = useMemo(() => {
      if (calculatedClaims.length === 0) return [];
      
      const pairCounts = {};
      const pairImpactSums = {};

      // Pre-calculate feature score averages once to avoid O(N^2) browser freezes!
      const featureAverages = {};
      if (analysisMode === "complexity") {
          for (let marker in markerFeatures) {
              markerFeatures[marker].forEach(aliases => {
                  const name = aliases[0];
                  const totalScore = calculatedClaims.reduce((acc, cl) => acc + getScore(cl, aliases), 0);
                  featureAverages[name] = calculatedClaims.length > 0 ? totalScore / calculatedClaims.length : 0;
              });
          }
      }

      calculatedClaims.forEach((c, cIdx) => {
          let contribs = [];
          if (analysisMode === "complexity") {
              for (let marker in markerFeatures) {
                  const w = weights[marker];
                  markerFeatures[marker].forEach(aliases => {
                      const name = aliases[0];
                      const score = getScore(c, aliases);
                      const avgScore = featureAverages[name] || 0;
                      const cont = (score - avgScore) * w;
                      if (cont > 0) {
                          contribs.push({ name, cont });
                      }
                  });
              }
          } else {
              if (backendShapData && Array.isArray(backendShapData.shapValues) && cIdx < backendShapData.shapValues.length) {
                  const rowShap = backendShapData.shapValues[cIdx];
                  if (Array.isArray(rowShap)) {
                      backendShapData.featureNames.forEach((name, idx) => {
                          const val = idx < rowShap.length ? parseFloat(rowShap[idx]) : 0;
                          if (!isNaN(val) && val > 0) {
                              contribs.push({ name, cont: val });
                          }
                      });
                  }
              } else if (localOLSModel) {
                  localOLSModel.featureKeys.forEach((name, idx) => {
                      const aliases = Object.values(markerFeatures).flat()[idx];
                      const x = getScore(c, aliases);
                      const mean = localOLSModel.means[idx];
                      const beta = localOLSModel.weights[idx];
                      const cont = beta * (x - mean);
                      if (cont > 0) {
                          contribs.push({ name, cont });
                      }
                  });
              }
          }

          // Sort positive contributions and take top 4
          contribs.sort((a, b) => b.cont - a.cont);
          const topPos = contribs.slice(0, 4).map(x => x.name);

          // Generate unique pairs of these top positive drivers
          for (let i = 0; i < topPos.length; i++) {
              for (let j = i + 1; j < topPos.length; j++) {
                  const name1 = topPos[i].replace("_score", "").replace(" Score", "");
                  const name2 = topPos[j].replace("_score", "").replace(" Score", "");
                  
                  const comboKey = name1 < name2 ? `${name1} + ${name2}` : `${name2} + ${name1}`;
                  
                  const val1 = contribs.find(x => x.name === topPos[i]).cont;
                  const val2 = contribs.find(x => x.name === topPos[j]).cont;
                  const totalImpact = val1 + val2;

                  pairCounts[comboKey] = (pairCounts[comboKey] || 0) + 1;
                  pairImpactSums[comboKey] = (pairImpactSums[comboKey] || 0) + totalImpact;
              }
          }
      });

      const list = [];
      for (let combo in pairCounts) {
          const count = pairCounts[combo];
          if (count >= 2) {
              const avgImpact = pairImpactSums[combo] / count;
              list.push({
                  combo,
                  count,
                  avgComplexity: parseFloat(avgImpact.toFixed(1))
              });
          }
      }

      return list.sort((a, b) => b.avgComplexity - a.avgComplexity).slice(0, 4);
  }, [calculatedClaims, analysisMode, backendShapData, localOLSModel, weights]);

  // Overall dataset complexity statistics
  const datasetStats = useMemo(() => {
      if (calculatedClaims.length === 0) return { avg: 0, min: 0, max: 0, count: 0, highRiskPct: 0 };
      const complexities = calculatedClaims.map(c => c.calculatedComplexity);
      const sum = complexities.reduce((a, b) => a + b, 0);
      const avg = sum / complexities.length;
      const highRiskCount = complexities.filter(x => x > avg).length;
      
      return {
          count: calculatedClaims.length,
          avg: parseFloat(avg.toFixed(2)),
          min: Math.min(...complexities),
          max: Math.max(...complexities),
          highRiskPct: parseFloat(((highRiskCount / complexities.length) * 100).toFixed(0))
      };
  }, [calculatedClaims]);

  // --- OVERALL LEVEL (GLOBAL IMPORTANCE) CALCULATIONS ---
  const globalComplexityImportance = useMemo(() => {
      if (calculatedClaims.length === 0) return [];
      const sums = {};
      calculatedClaims.forEach(c => {
          for (let marker in markerFeatures) {
              const w = weights[marker];
              markerFeatures[marker].forEach(aliases => {
                  const name = aliases[0];
                  const score = getScore(c, aliases);
                  sums[name] = (sums[name] || 0) + Math.abs(score * w);
              });
          }
      });
      return Object.keys(sums).map(name => ({
          name,
          importance: sums[name] / calculatedClaims.length
      })).sort((a, b) => b.importance - a.importance);
  }, [calculatedClaims, weights]);

  const globalSeverityImportance = useMemo(() => {
      if (claims.length === 0) return [];
      const featureKeys = Object.values(markerFeatures).flat();
      const numFeatures = featureKeys.length;
      const sums = new Array(numFeatures).fill(0);
      
      if (backendShapData && Array.isArray(backendShapData.shapValues)) {
          backendShapData.shapValues.forEach(rowShap => {
              if (Array.isArray(rowShap)) {
                  for (let j = 0; j < Math.min(numFeatures, rowShap.length); j++) {
                      const val = parseFloat(rowShap[j]);
                      if (!isNaN(val)) {
                          sums[j] += Math.abs(val);
                      }
                  }
              }
          });
      } else if (localOLSModel) {
          claims.forEach(c => {
              featureKeys.forEach((aliases, idx) => {
                  const x = getScore(c, aliases);
                  const mean = localOLSModel.means[idx];
                  const beta = localOLSModel.weights[idx];
                  sums[idx] += Math.abs(beta * (x - mean));
              });
          });
      }
      
      return featureKeys.map((aliases, idx) => ({
          name: aliases[0],
          importance: sums[idx] / claims.length
      })).sort((a, b) => b.importance - a.importance);
  }, [claims, backendShapData, localOLSModel]);

  // --- INDIVIDUAL LEVEL (CLAIM LEVEL) SHAP VALUES ---
  const individualShapValues = useMemo(() => {
      if (!selectedClaim) return [];
      
      if (analysisMode === "complexity") {
          const list = [];
          for (let marker in markerFeatures) {
              const w = weights[marker];
              markerFeatures[marker].forEach(aliases => {
                  const name = aliases[0];
                  const score = getScore(selectedClaim, aliases);
                  
                  const totalScore = calculatedClaims.reduce((acc, c) => acc + getScore(c, aliases), 0);
                  const avgScore = calculatedClaims.length > 0 ? totalScore / calculatedClaims.length : 0;
                  
                  list.push({
                      name: name,
                      contribution: (score - avgScore) * w,
                      score: score
                  });
              });
          }
          return list.sort((a, b) => Math.abs(b.contribution) - Math.abs(a.contribution));
      } else {
          if (backendShapData && Array.isArray(backendShapData.shapValues) && selectedClaimIndex !== -1 && selectedClaimIndex < backendShapData.shapValues.length) {
              const rowShap = backendShapData.shapValues[selectedClaimIndex];
              if (Array.isArray(rowShap)) {
                  return backendShapData.featureNames.map((name, idx) => {
                      const aliases = Object.values(markerFeatures).flat()[idx];
                      const val = idx < rowShap.length ? parseFloat(rowShap[idx]) : 0;
                      return {
                          name: name,
                          contribution: isNaN(val) ? 0 : val,
                          score: getScore(selectedClaim, aliases)
                      };
                  }).sort((a, b) => Math.abs(b.contribution) - Math.abs(a.contribution));
              }
          } else if (localOLSModel) {
              return localOLSModel.featureKeys.map((name, idx) => {
                  const aliases = Object.values(markerFeatures).flat()[idx];
                  const x = getScore(selectedClaim, aliases);
                  const mean = localOLSModel.means[idx];
                  const beta = localOLSModel.weights[idx];
                  return {
                      name: name,
                      contribution: beta * (x - mean),
                      score: x
                  };
              }).sort((a, b) => Math.abs(b.contribution) - Math.abs(a.contribution));
          }
      }
      return [];
  }, [selectedClaim, selectedClaimIndex, backendShapData, localOLSModel, analysisMode, weights, calculatedClaims]);

  return (
      <div className="flex h-screen w-screen overflow-hidden bg-slate-950 text-slate-100 font-sans">
          
          {/* LEFT SIDEBAR: Vertical Tab Navigations */}
          <div className="w-52 bg-slate-900 border-r border-slate-800 flex flex-col justify-between shrink-0 p-4 select-none">
              <div className="space-y-6">
                  <div>
                      <h1 className="text-sm font-black text-teal-400 tracking-wider uppercase">Claims Intelligence</h1>
                      <p className="text-3xs text-slate-500 font-mono mt-0.5">Claim Analytics v2.0</p>
                  </div>
                  
                  <nav className="flex flex-col space-y-2">
                      <button 
                          onClick={() => setActiveTab("input")}
                          className={`flex items-center space-x-2.5 px-3 py-2.5 rounded-lg text-xs font-bold transition-all text-left ${activeTab === "input" ? "bg-teal-950/40 border border-teal-500/25 text-teal-400 shadow-inner" : "text-slate-400 hover:text-slate-200 hover:bg-slate-850"}`}
                      >
                          <span>1. Input Data</span>
                      </button>
                      <button 
                          disabled={claims.length === 0}
                          onClick={() => setActiveTab("weights")}
                          className={`flex items-center space-x-2.5 px-3 py-2.5 rounded-lg text-xs font-bold transition-all text-left disabled:opacity-20 disabled:pointer-events-none ${activeTab === "weights" ? "bg-teal-950/40 border border-teal-500/25 text-teal-400 shadow-inner" : "text-slate-400 hover:text-slate-200 hover:bg-slate-850"}`}
                      >
                          <span>2. Measure Weights</span>
                      </button>
                      <button 
                          disabled={claims.length === 0}
                          onClick={() => setActiveTab("analytics")}
                          className={`flex items-center space-x-2.5 px-3 py-2.5 rounded-lg text-xs font-bold transition-all text-left disabled:opacity-20 disabled:pointer-events-none ${activeTab === "analytics" ? "bg-teal-950/40 border border-teal-500/25 text-teal-400 shadow-inner" : "text-slate-400 hover:text-slate-200 hover:bg-slate-850"}`}
                      >
                          <span>3. Visualizations</span>
                      </button>
                      <button 
                          disabled={claims.length === 0}
                          onClick={() => setActiveTab("drivers")}
                          className={`flex items-center space-x-2.5 px-3 py-2.5 rounded-lg text-xs font-bold transition-all text-left disabled:opacity-20 disabled:pointer-events-none ${activeTab === "drivers" ? "bg-teal-950/40 border border-teal-500/25 text-teal-400 shadow-inner" : "text-slate-400 hover:text-slate-200 hover:bg-slate-850"}`}
                      >
                          <span>4. Key Risk Drivers</span>
                      </button>
                  </nav>
              </div>

              {/* Status Indicator */}
              <div className="border-t border-slate-800 pt-3">
                  <div className="flex items-center space-x-2">
                      <span className={`h-2 w-2 rounded-full ${claims.length > 0 ? "bg-emerald-400 animate-pulse" : "bg-slate-600"}`} />
                      <span className="text-3xs text-slate-400 font-medium">
                          {claims.length > 0 ? `${claims.length} Jobs Active` : "No Data Loaded"}
                      </span>
                  </div>
              </div>
          </div>

          {/* ACTIVE TAB CONTENT DISPLAY AREA */}
          <div className="flex-1 flex flex-col min-h-0 bg-slate-950 relative">
              {errorMsg && (
                  <div className="absolute top-4 right-4 z-50 bg-rose-500/10 border border-rose-500/35 text-rose-400 text-2xs p-3 rounded-lg flex items-center space-x-2 shadow-2xl">
                      <span>⚠️</span>
                      <span>{errorMsg}</span>
                      <button onClick={() => setErrorMsg("")} className="hover:text-rose-200 font-bold ml-2">✕</button>
                  </div>
              )}

              {/* TAB 1: INPUT DATA UPLOAD */}
              {activeTab === "input" && (
                  <div className="flex-1 flex flex-col items-center justify-center p-8 select-none">
                      <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 max-w-md w-full shadow-2xl space-y-6 text-center">
                          <div>
                              <div className="text-3xl mb-3">📂</div>
                              <h2 className="text-md font-bold text-slate-100">Upload Dataset</h2>
                              <p className="text-2xs text-slate-400 mt-1 leading-relaxed">
                                  Select and upload your claims CSV file containing Job IDs, Billed Amounts, and extracted feature scores to compute complexity models.
                              </p>
                          </div>

                          {loading || uploadProgress > 0 ? (
                              <div className="bg-slate-950 border border-slate-850 p-5 rounded-lg space-y-4">
                                  <div className="flex justify-between items-center text-3xs font-semibold text-slate-400">
                                      <span className="flex items-center space-x-2">
                                          <span className="h-1.5 w-1.5 rounded-full bg-teal-400 animate-ping" />
                                          <span>{uploadStep}</span>
                                      </span>
                                      <span className="font-mono text-teal-400">{uploadProgress}%</span>
                                  </div>
                                  <div className="h-1.5 w-full bg-slate-900 border border-slate-850 rounded-full overflow-hidden">
                                      <div 
                                          className="h-full bg-gradient-to-r from-teal-500 to-emerald-400 rounded-full transition-all duration-150" 
                                          style={{ width: `${uploadProgress}%` }}
                                      />
                                  </div>
                                  {uploadProgress === 100 && (
                                      <div className="text-3xs text-emerald-400 font-medium pt-1 animate-pulse">
                                          ✅ Processing complete! All records loaded successfully.
                                      </div>
                                  )}
                              </div>
                          ) : (
                              <label className="flex flex-col items-center justify-center border-2 border-dashed border-slate-800 hover:border-teal-500/40 bg-slate-950/40 hover:bg-slate-950 transition p-6 rounded-lg cursor-pointer group">
                                  <span className="text-teal-400 text-xs font-bold group-hover:underline">Choose CSV File</span>
                                  <span className="text-3xs text-slate-500 mt-1">supports test_extracted.csv formats</span>
                                  <input type="file" accept=".csv" onChange={handleFileUpload} className="hidden" />
                              </label>
                          )}

                          {claims.length > 0 && !loading && (
                              <div className="pt-2">
                                  <button 
                                      onClick={() => setActiveTab("weights")}
                                      className="w-full py-2.5 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold rounded-lg text-xs transition shadow-lg"
                                  >
                                      Next: Configure Weights ➔
                                  </button>
                              </div>
                          )}
                      </div>
                  </div>
              )}


              {activeTab === "weights" && (
                  <div className="flex-1 flex flex-col p-6 min-h-0 overflow-hidden">
                      
                      {/* One Unified Big Box */}
                      <div className="flex-1 bg-slate-900 border border-slate-800 rounded-xl p-5 overflow-hidden flex flex-col min-h-0 shadow-lg select-none">
                          
                          {/* Inner Header Block */}
                          <div className="shrink-0 flex justify-between items-center pb-3 border-b border-slate-800 mb-4">
                              <div>
                                  <h2 className="text-sm font-bold text-slate-100">Measure Complexity Weights</h2>
                                  <p className="text-3xs text-slate-500 mt-0.5">Configure contribution percentages. Total weights must sum to exactly 100%.</p>
                              </div>
                              <div className="flex items-center space-x-4">
                                  {isNot100Percent && (
                                      <span className="bg-rose-500/10 border border-rose-500/30 text-rose-400 text-3xs px-3 py-1.5 rounded-lg animate-pulse font-medium">
                                          ⚠️ Current Sum: <strong>{(weightsSum * 100).toFixed(0)}%</strong>
                                      </span>
                                  )}
                                  {!isNot100Percent && (
                                      <span className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-3xs px-3 py-1.5 rounded-lg font-medium">
                                          ✅ Sum: 100%
                                      </span>
                                  )}
                                  <button 
                                      onClick={resetWeights}
                                      className="text-3xs text-teal-400 hover:text-teal-300 font-semibold underline"
                                  >
                                      Reset Default
                                  </button>
                              </div>
                          </div>

                          {/* Flex wrapper for Grid + Right panel */}
                          <div className="flex-1 flex space-x-4 min-h-0 overflow-hidden">
                              
                              {/* Left Panel: Cards Grid (Width transitions based on selection) */}
                              <div className={`h-full flex flex-col min-h-0 transition-all duration-300 ${activeWeightsRuleCategory ? "w-[62%]" : "w-full"}`}>
                                  <div className="flex-1 grid grid-cols-2 grid-rows-4 gap-2.5 min-h-0 h-full">
                                      {Object.keys(markerDefinitions).map((key) => {
                                          const name = markerDefinitions[key].name;
                                          const desc = markerDefinitions[key].desc;
                                          const val = weights[key] || 0;
                                          const isSelected = activeWeightsRuleCategory === key;
                                          return (
                                              <div key={key} className={`bg-slate-950 border p-2.5 rounded-lg transition flex flex-col justify-between space-y-1 ${isSelected ? "border-teal-500/50 shadow-lg shadow-teal-950/10" : "border-slate-850 hover:border-slate-800"}`}>
                                                  <div className="space-y-0.5">
                                                      <div className="flex justify-between items-center text-3xs font-bold">
                                                          <div className="flex items-center space-x-1.5 truncate">
                                                              <h3 className="text-teal-400 truncate">{name}</h3>
                                                              <span className="font-mono text-teal-300">{(val * 100).toFixed(0)}%</span>
                                                          </div>
                                                          <button 
                                                              onClick={() => setActiveWeightsRuleCategory(isSelected ? null : key)}
                                                              title="Click to view scoring rules"
                                                              className={`h-4.5 w-4.5 rounded flex items-center justify-center text-3xs font-black transition border ${isSelected ? "bg-teal-500 border-teal-400 text-slate-950" : "bg-slate-900 border-slate-800 text-slate-400 hover:text-teal-400"}`}
                                                          >
                                                              ❯
                                                          </button>
                                                      </div>
                                                      <p className="text-[10px] text-slate-400 leading-normal font-medium max-h-[44px] overflow-hidden text-ellipsis">
                                                          {desc}
                                                      </p>
                                                  </div>
                                                  <div className="pt-1 flex items-center">
                                                      <input 
                                                          type="range"
                                                          min="0"
                                                          max="0.5"
                                                          step="0.05"
                                                          value={val}
                                                          onChange={(e) => handleWeightChange(key, e.target.value)}
                                                          className="w-full h-1 bg-slate-900 border border-slate-800 rounded-lg appearance-none cursor-pointer accent-teal-400"
                                                      />
                                                  </div>
                                              </div>
                                          );
                                      })}
                                  </div>
                              </div>

                              {/* Right Panel: Scoring Rules list */}
                              {activeWeightsRuleCategory && (
                                  <div className="w-[38%] bg-slate-950 border border-slate-850 rounded-xl p-4 flex flex-col min-h-0 shadow-2xl animate-slide-in relative select-text">
                                      <div className="shrink-0 flex justify-between items-center pb-2 border-b border-slate-850 mb-3 select-none">
                                          <div>
                                              <h3 className="text-xs font-bold text-teal-400 truncate max-w-[150px]" title={markerDefinitions[activeWeightsRuleCategory].name}>
                                                  {markerDefinitions[activeWeightsRuleCategory].name} Rules
                                              </h3>
                                              <span className="text-4xs text-slate-500 font-mono">Feature brackets and points</span>
                                          </div>
                                          <button 
                                              onClick={() => setActiveWeightsRuleCategory(null)}
                                              className="h-5 w-5 rounded bg-slate-900 hover:bg-slate-850 text-slate-400 hover:text-slate-200 flex items-center justify-center text-3xs font-bold transition border border-slate-800"
                                          >
                                              ✕
                                          </button>
                                      </div>

                                      <div className="flex-1 overflow-y-auto pr-0.5 space-y-3 min-h-0 text-3xs">
                                          {activeWeightsRuleCategory === "clinicalBurden" && (
                                              <div className="space-y-3">
                                                  <div className="bg-slate-900/60 border border-slate-900 p-3 rounded-lg space-y-1">
                                                      <span className="text-teal-400 font-bold block">1. Number of Diagnoses</span>
                                                      <ul className="space-y-0.5 text-slate-400 list-disc list-inside">
                                                          <li>None: <strong className="text-emerald-400">0 pts</strong> (Low)</li>
                                                          <li>1 - 2: <strong className="text-teal-300">10 pts</strong> (Medium)</li>
                                                          <li>3 - 5: <strong className="text-amber-400">25 pts</strong> (High)</li>
                                                          <li>&gt; 5: <strong className="text-rose-400">30 pts</strong> (Very High)</li>
                                                      </ul>
                                                  </div>
                                                  <div className="bg-slate-900/60 border border-slate-900 p-3 rounded-lg space-y-1">
                                                      <span className="text-teal-400 font-bold block">2. Repeat Treatment</span>
                                                      <ul className="space-y-0.5 text-slate-400 list-disc list-inside">
                                                          <li>No Repeats: <strong className="text-emerald-400">0 pts</strong></li>
                                                          <li>1 Repeat: <strong className="text-teal-300">5 pts</strong></li>
                                                          <li>&gt; 1 Repeats: <strong className="text-amber-400">10 pts</strong></li>
                                                      </ul>
                                                  </div>
                                                  <div className="bg-slate-900/60 border border-slate-900 p-3 rounded-lg space-y-1">
                                                      <span className="text-teal-400 font-bold block">3. Serious Injury Presence</span>
                                                      <ul className="space-y-0.5 text-slate-400 list-disc list-inside">
                                                          <li>No: <strong className="text-emerald-400">0 pts</strong></li>
                                                          <li>Yes: <strong className="text-rose-400">10 pts</strong></li>
                                                      </ul>
                                                  </div>
                                                  <div className="bg-slate-900/60 border border-slate-900 p-3 rounded-lg space-y-1">
                                                      <span className="text-teal-400 font-bold block">4. Chronic Disease History</span>
                                                      <ul className="space-y-0.5 text-slate-400 list-disc list-inside">
                                                          <li>No Chronic Disease: <strong className="text-emerald-400">0 pts</strong></li>
                                                          <li>1 Chronic Disease: <strong className="text-teal-300">5 pts</strong></li>
                                                          <li>&gt; 1 Chronic: <strong className="text-rose-400">15 pts</strong></li>
                                                      </ul>
                                                  </div>
                                                  <div className="bg-slate-900/60 border border-slate-900 p-3 rounded-lg space-y-1">
                                                      <span className="text-teal-400 font-bold block">5. Gap in Treatment</span>
                                                      <ul className="space-y-0.5 text-slate-400 list-disc list-inside">
                                                          <li>&lt; 3 Days: <strong className="text-emerald-400">0 pts</strong> (None)</li>
                                                          <li>4 - 7 Days: <strong className="text-teal-300">5 pts</strong> (Medium)</li>
                                                          <li>8 - 15 Days: <strong className="text-amber-400">10 pts</strong> (High)</li>
                                                          <li>&gt; 15 Days: <strong className="text-rose-400">15 pts</strong> (Severe)</li>
                                                      </ul>
                                                  </div>
                                                  <div className="bg-slate-900/60 border border-slate-900 p-3 rounded-lg space-y-1">
                                                      <span className="text-teal-400 font-bold block">6. Surgery Performed</span>
                                                      <ul className="space-y-0.5 text-slate-400 list-disc list-inside">
                                                          <li>No Surgery: <strong className="text-emerald-400">0 pts</strong></li>
                                                          <li>1 Surgery: <strong className="text-teal-300">10 pts</strong></li>
                                                          <li>&gt; 1 Surgery: <strong className="text-rose-400">15 pts</strong></li>
                                                      </ul>
                                                  </div>
                                                  <div className="bg-slate-900/60 border border-slate-900 p-3 rounded-lg space-y-1">
                                                      <span className="text-teal-400 font-bold block">7. Body Part Injured</span>
                                                      <ul className="space-y-0.5 text-slate-400 list-disc list-inside">
                                                          <li>1 Body Part: <strong className="text-emerald-400">0 pts</strong></li>
                                                          <li>&gt; 1 Part: <strong className="text-rose-400">5 pts</strong></li>
                                                      </ul>
                                                  </div>
                                              </div>
                                          )}

                                          {activeWeightsRuleCategory === "utilization" && (
                                              <div className="space-y-3">
                                                  <div className="bg-slate-900/60 border border-slate-900 p-3 rounded-lg space-y-1">
                                                      <span className="text-teal-400 font-bold block">1. Hospital Admissions</span>
                                                      <ul className="space-y-0.5 text-slate-400 list-disc list-inside">
                                                          <li>0 Admissions: <strong className="text-emerald-400">0 pts</strong></li>
                                                          <li>1 Admission: <strong className="text-teal-300">10 pts</strong> (Low)</li>
                                                          <li>2 - 3 Admissions: <strong className="text-amber-400">20 pts</strong> (Medium)</li>
                                                          <li>&gt; 3 Admissions: <strong className="text-rose-400">25 pts</strong> (High)</li>
                                                      </ul>
                                                  </div>
                                                  <div className="bg-slate-900/60 border border-slate-900 p-3 rounded-lg space-y-1">
                                                      <span className="text-teal-400 font-bold block">2. ER Visits</span>
                                                      <ul className="space-y-0.5 text-slate-400 list-disc list-inside">
                                                          <li>0 Visits: <strong className="text-emerald-400">0 pts</strong></li>
                                                          <li>1 - 3 Visits: <strong className="text-teal-300">5 pts</strong> (Low)</li>
                                                          <li>4 - 6 Visits: <strong className="text-amber-400">10 pts</strong> (Medium)</li>
                                                          <li>7 - 10 Visits: <strong className="text-rose-350">15 pts</strong> (High)</li>
                                                          <li>&gt; 10 Visits: <strong className="text-rose-500">20 pts</strong> (Very High)</li>
                                                      </ul>
                                                  </div>
                                                  <div className="bg-slate-900/60 border border-slate-900 p-3 rounded-lg space-y-1">
                                                      <span className="text-teal-400 font-bold block">3. Therapy Sessions</span>
                                                      <ul className="space-y-0.5 text-slate-400 list-disc list-inside">
                                                          <li>&lt; 3 Sessions: <strong className="text-emerald-400">5 pts</strong> (Low)</li>
                                                          <li>4 - 6 Sessions: <strong className="text-teal-300">10 pts</strong> (Medium)</li>
                                                          <li>&gt;= 7 Sessions: <strong className="text-rose-400">15 pts</strong> (High)</li>
                                                      </ul>
                                                  </div>
                                                  <div className="bg-slate-900/60 border border-slate-900 p-3 rounded-lg space-y-1">
                                                      <span className="text-teal-400 font-bold block">4. Diagnostic Procedures</span>
                                                      <ul className="space-y-0.5 text-slate-400 list-disc list-inside">
                                                          <li>&lt; 3 Procedures: <strong className="text-teal-300">10 pts</strong> (Low)</li>
                                                          <li>4 - 6 Procedures: <strong className="text-amber-400">20 pts</strong> (Medium)</li>
                                                          <li>&gt;= 7 Procedures: <strong className="text-rose-400">25 pts</strong> (High)</li>
                                                      </ul>
                                                  </div>
                                                  <div className="bg-slate-900/60 border border-slate-900 p-3 rounded-lg space-y-1">
                                                      <span className="text-teal-400 font-bold block">5. Total Treatment Duration</span>
                                                      <ul className="space-y-0.5 text-slate-400 list-disc list-inside">
                                                          <li>&lt; 15 Days: <strong className="text-emerald-400">5 pts</strong></li>
                                                          <li>15 - 45 Days: <strong className="text-teal-300">10 pts</strong></li>
                                                          <li>&gt; 45 Days: <strong className="text-rose-400">15 pts</strong></li>
                                                      </ul>
                                                  </div>
                                              </div>
                                          )}

                                          {activeWeightsRuleCategory === "medicationComplexity" && (
                                              <div className="space-y-3">
                                                  <div className="bg-slate-900/60 border border-slate-900 p-3 rounded-lg space-y-1">
                                                      <span className="text-teal-400 font-bold block">1. Polypharmacy Count</span>
                                                      <ul className="space-y-0.5 text-slate-400 list-disc list-inside">
                                                          <li>&lt; 3 Meds: <strong className="text-emerald-400">10 pts</strong> (Low)</li>
                                                          <li>4 - 6 Meds: <strong className="text-teal-300">20 pts</strong> (Medium)</li>
                                                          <li>7 - 10 Meds: <strong className="text-amber-400">25 pts</strong> (High)</li>
                                                          <li>&gt; 10 Meds: <strong className="text-rose-400">35 pts</strong> (Very High)</li>
                                                      </ul>
                                                  </div>
                                                  <div className="bg-slate-900/60 border border-slate-900 p-3 rounded-lg space-y-1">
                                                      <span className="text-teal-400 font-bold block">2. Opioid Usage</span>
                                                      <ul className="space-y-0.5 text-slate-400 list-disc list-inside">
                                                          <li>No: <strong className="text-emerald-400">0 pts</strong></li>
                                                          <li>Yes: <strong className="text-rose-400">20 pts</strong></li>
                                                      </ul>
                                                  </div>
                                                  <div className="bg-slate-900/60 border border-slate-900 p-3 rounded-lg space-y-1">
                                                      <span className="text-teal-400 font-bold block">3. Controlled Substances</span>
                                                      <ul className="space-y-0.5 text-slate-400 list-disc list-inside">
                                                          <li>No: <strong className="text-emerald-400">0 pts</strong></li>
                                                          <li>Yes: <strong className="text-rose-400">20 pts</strong></li>
                                                      </ul>
                                                  </div>
                                                  <div className="bg-slate-900/60 border border-slate-900 p-3 rounded-lg space-y-1">
                                                      <span className="text-teal-400 font-bold block">4. High-Risk Medication</span>
                                                      <ul className="space-y-0.5 text-slate-400 list-disc list-inside">
                                                          <li>No: <strong className="text-emerald-400">0 pts</strong></li>
                                                          <li>Yes: <strong className="text-rose-400">25 pts</strong></li>
                                                      </ul>
                                                  </div>
                                              </div>
                                          )}

                                          {activeWeightsRuleCategory === "careFragmentation" && (
                                              <div className="space-y-3">
                                                  <div className="bg-slate-900/60 border border-slate-900 p-3 rounded-lg space-y-1">
                                                      <span className="text-teal-400 font-bold block">1. Number of Providers</span>
                                                      <ul className="space-y-0.5 text-slate-400 list-disc list-inside">
                                                          <li>1 Provider: <strong className="text-emerald-400">10 pts</strong> (Low)</li>
                                                          <li>2 - 3 Providers: <strong className="text-teal-300">20 pts</strong> (Medium)</li>
                                                          <li>4 - 5 Providers: <strong className="text-amber-400">35 pts</strong> (High)</li>
                                                          <li>&gt; 5 Providers: <strong className="text-rose-400">40 pts</strong> (Very High)</li>
                                                      </ul>
                                                  </div>
                                                  <div className="bg-slate-900/60 border border-slate-900 p-3 rounded-lg space-y-1">
                                                      <span className="text-teal-400 font-bold block">2. Number of Facilities</span>
                                                      <ul className="space-y-0.5 text-slate-400 list-disc list-inside">
                                                          <li>1 Facility: <strong className="text-emerald-400">10 pts</strong> (Low)</li>
                                                          <li>2 - 3 Facilities: <strong className="text-teal-300">20 pts</strong> (Medium)</li>
                                                          <li>4 - 5 Facilities: <strong className="text-amber-400">30 pts</strong> (High)</li>
                                                          <li>&gt; 5 Facilities: <strong className="text-rose-400">40 pts</strong> (Very High)</li>
                                                      </ul>
                                                  </div>
                                                  <div className="bg-slate-900/60 border border-slate-900 p-3 rounded-lg space-y-1">
                                                      <span className="text-teal-400 font-bold block">3. Geographic Dispersion</span>
                                                      <ul className="space-y-0.5 text-slate-400 list-disc list-inside">
                                                          <li>1 State: <strong className="text-emerald-400">5 pts</strong> (Low)</li>
                                                          <li>2 - 3 States: <strong className="text-teal-300">15 pts</strong> (Medium)</li>
                                                          <li>&gt; 3 States: <strong className="text-rose-400">20 pts</strong> (High)</li>
                                                      </ul>
                                                  </div>
                                              </div>
                                          )}

                                          {activeWeightsRuleCategory === "claimDetailComplexity" && (
                                              <div className="space-y-3">
                                                  <div className="bg-slate-900/60 border border-slate-900 p-3 rounded-lg space-y-1">
                                                      <span className="text-teal-400 font-bold block">1. Attorney Representation</span>
                                                      <ul className="space-y-0.5 text-slate-400 list-disc list-inside">
                                                          <li>No: <strong className="text-emerald-400">0 pts</strong></li>
                                                          <li>Yes: <strong className="text-rose-400">20 pts</strong></li>
                                                      </ul>
                                                  </div>
                                                  <div className="bg-slate-900/60 border border-slate-900 p-3 rounded-lg space-y-1">
                                                      <span className="text-teal-400 font-bold block">2. Claim Age</span>
                                                      <ul className="space-y-0.5 text-slate-400 list-disc list-inside">
                                                          <li>&lt; 30 Days: <strong className="text-emerald-400">5 pts</strong> (Low)</li>
                                                          <li>30 - 90 Days: <strong className="text-teal-300">10 pts</strong> (Medium)</li>
                                                          <li>&gt; 90 Days: <strong className="text-rose-400">15 pts</strong> (High)</li>
                                                      </ul>
                                                  </div>
                                                  <div className="bg-slate-900/60 border border-slate-900 p-3 rounded-lg space-y-1">
                                                      <span className="text-teal-400 font-bold block">3. Coverage Disputes</span>
                                                      <ul className="space-y-0.5 text-slate-400 list-disc list-inside">
                                                          <li>&lt; $1,000: <strong className="text-emerald-400">0 pts</strong> (Low)</li>
                                                          <li>$1,000 - $5,000: <strong className="text-teal-300">10 pts</strong> (Medium)</li>
                                                          <li>&gt; $5,000: <strong className="text-rose-400">20 pts</strong> (High)</li>
                                                      </ul>
                                                  </div>
                                                  <div className="bg-slate-900/60 border border-slate-900 p-3 rounded-lg space-y-1">
                                                      <span className="text-teal-400 font-bold block">4. Claim Amount</span>
                                                      <ul className="space-y-0.5 text-slate-400 list-disc list-inside">
                                                          <li>&lt; $20,000: <strong className="text-emerald-400">5 pts</strong> (Low)</li>
                                                          <li>$20,000 - $50,000: <strong className="text-teal-300">15 pts</strong> (Medium)</li>
                                                          <li>&gt; $50,000: <strong className="text-rose-400">25 pts</strong> (High)</li>
                                                      </ul>
                                                  </div>
                                              </div>
                                          )}

                                          {!["clinicalBurden", "utilization", "medicationComplexity", "careFragmentation", "claimDetailComplexity"].includes(activeWeightsRuleCategory) && (
                                              <div className="h-full flex items-center justify-center text-slate-500 text-xs font-semibold py-20 select-none text-center leading-relaxed">
                                                  Scoring rules for {markerDefinitions[activeWeightsRuleCategory].name} are coming next. Please configure the weights on the left.
                                              </div>
                                          )}
                                      </div>
                                  </div>
                              )}
                              
                          </div>

                          {/* Simulated Recalculation Terminal Modal */}
                          {isCalculatingWeights && (
                              <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-sm z-50 flex items-center justify-center p-6 select-none animate-fade-in rounded-xl">
                                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 max-w-md w-full shadow-2xl flex flex-col space-y-4">
                                      <div className="flex justify-between items-center border-b border-slate-800 pb-2 shrink-0">
                                          <div className="flex items-center space-x-2">
                                              <span className="h-2.5 w-2.5 rounded-full bg-rose-500" />
                                              <span className="h-2.5 w-2.5 rounded-full bg-amber-500" />
                                              <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
                                          </div>
                                          <span className="text-4xs text-slate-500 font-mono">weights_processor.sh</span>
                                      </div>
                                      <div className="bg-slate-950 border border-slate-850 rounded-lg p-3.5 font-mono text-[10px] text-emerald-400 space-y-2 h-44 overflow-y-auto select-text">
                                          {terminalLogs.map((log, idx) => (
                                              <div key={idx} className="leading-normal">
                                                  {log}
                                              </div>
                                          ))}
                                          <div className="flex items-center space-x-1">
                                              <span className="h-2 w-1 bg-emerald-400 animate-pulse" />
                                          </div>
                                      </div>
                                      <div className="h-1.5 w-full bg-slate-950 border border-slate-850 rounded-full overflow-hidden shrink-0">
                                          <div 
                                              className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-300"
                                              style={{ width: `${(terminalLogs.length / 6) * 100}%` }}
                                          />
                                      </div>
                                  </div>
                              </div>
                          )}

                          {/* Footer Next Button Row */}
                          <div className="shrink-0 pt-3 border-t border-slate-800 mt-3 flex justify-end">
                              <button 
                                  onClick={handleRecalculateWeights}
                                  disabled={isNot100Percent}
                                  className="px-8 py-2 bg-teal-500 hover:bg-teal-400 disabled:opacity-30 disabled:pointer-events-none text-slate-950 font-bold rounded-lg text-xs transition shadow-lg"
                              >
                                  Process Selected Weights ➔
                              </button>
                          </div>
                      </div>
                  </div>
              )}              {/* TAB 3: COMPLEXITY SCORE VISUALS */}
              {activeTab === "analytics" && (
                  <div className="flex-1 flex flex-col min-h-0 p-4 space-y-4 overflow-hidden">
                      
                      {/* Top EDA Cards Row */}
                      <div className="grid grid-cols-5 gap-3.5 shrink-0 select-none">
                          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex justify-between items-center shadow-lg hover:border-slate-700 transition">
                              <div>
                                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block">Total Jobs</span>
                                  <span className="text-lg font-extrabold text-slate-100 font-mono mt-1 block">{datasetStats.count.toLocaleString()}</span>
                              </div>
                              <span className="text-md">📊</span>
                          </div>
                          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex justify-between items-center shadow-lg hover:border-slate-700 transition">
                              <div>
                                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block">Avg Complexity</span>
                                  <span className="text-lg font-extrabold text-teal-400 font-mono mt-1 block">{datasetStats.avg}</span>
                              </div>
                              <span className="text-md text-teal-400">⚖️</span>
                          </div>
                          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex justify-between items-center shadow-lg hover:border-slate-700 transition">
                              <div>
                                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block">Min Complexity</span>
                                  <span className="text-lg font-extrabold text-slate-100 font-mono mt-1 block">{datasetStats.min}</span>
                              </div>
                              <span className="text-md">📉</span>
                          </div>
                          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex justify-between items-center shadow-lg hover:border-slate-700 transition">
                              <div>
                                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block">Max Complexity</span>
                                  <span className="text-lg font-extrabold text-slate-100 font-mono mt-1 block">{datasetStats.max}</span>
                              </div>
                              <span className="text-md">📈</span>
                          </div>
                          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex justify-between items-center shadow-lg hover:border-slate-700 transition">
                              <div>
                                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block">High Complexity Cohort</span>
                                  <span className="text-lg font-extrabold text-rose-450 font-mono mt-1 block">{datasetStats.highRiskPct}%</span>
                              </div>
                              <span className="text-md text-rose-400">🔥</span>
                          </div>
                      </div>

                      {/* Main workspace layout */}
                      <div className="flex-1 grid grid-cols-12 gap-4 min-h-0 overflow-hidden">
                          
                           {/* Left Panel: Three-Tier Drill Down Workspace (col-span-12) */}
                           <section className="col-span-12 bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col min-h-0 shadow-lg overflow-hidden">
                               <div className="shrink-0 mb-3 border-b border-slate-800 pb-2 flex justify-between items-center">
                                   <div>
                                       <h3 className="text-xs font-bold text-slate-200">Claims Complexity Analyzer</h3>
                                       <p className="text-3xs text-slate-500">Hierarchical Drill-Down: Complexity Domain ➔ Feature Driver ➔ Clinical Narrative</p>
                                   </div>
                                   
                                   {/* Right side search and toggle controls */}
                                   <div className="flex items-center space-x-3 select-none">
                                       
                                       {/* Search Box */}
                                       <div className="relative w-48">
                                           <input 
                                               type="text" 
                                               placeholder="Search Job ID (e.g. JOB-1001)..." 
                                               value={searchQuery}
                                               onChange={(e) => setSearchQuery(e.target.value)}
                                               className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1 text-xs text-slate-200 focus:outline-none focus:border-teal-500 font-medium transition placeholder-slate-600"
                                           />
                                           {searchQuery.trim() !== "" && (
                                               <div className="absolute left-0 right-0 top-7 bg-slate-955 border border-slate-800 rounded-lg max-h-[140px] overflow-y-auto shadow-2xl z-35 divide-y divide-slate-900 font-mono font-semibold">
                                                   {filteredClaims.slice(0, 8).map((c, idx) => {
                                                       const cId = getClaimId(c);
                                                       return (
                                                           <div 
                                                               key={idx}
                                                               onClick={() => {
                                                                   setSelectedClaimId(cId);
                                                                   setSearchQuery("");
                                                               }}
                                                               className="p-1.5 text-[10px] text-slate-305 hover:bg-slate-900 hover:text-teal-400 cursor-pointer flex justify-between"
                                                           >
                                                               <span>{cId}</span>
                                                               <span className="text-slate-500 font-mono">Score: {c.calculatedComplexity}</span>
                                                           </div>
                                                       );
                                                   })}
                                                   {filteredClaims.length === 0 && (
                                                       <div className="p-1.5 text-[10px] text-slate-500">No matches.</div>
                                                   )}
                                               </div>
                                           )}
                                       </div>

                                       {/* Clear Selection Button */}
                                       {selectedClaimId !== null && (
                                           <button 
                                               onClick={() => {
                                                   setSelectedClaimId(null);
                                                   setActiveDetailCategory(null);
                                                   setActiveDetailFeature(null);
                                               }}
                                               className="bg-rose-500/10 border border-rose-500/25 px-2.5 py-1 rounded-md text-[10px] font-bold text-rose-455 hover:bg-rose-500/20 transition-all flex items-center space-x-1"
                                           >
                                               <span>✕</span>
                                               <span>Job: <strong className="font-mono">{selectedClaimId}</strong></span>
                                           </button>
                                       )}

                                       {/* Toggle Switcher */}
                                       <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-850 text-[10px] font-bold">
                                           <button 
                                               onClick={() => setAnalysisMode("complexity")}
                                               className={`px-3.5 py-1 rounded-md transition-all ${analysisMode === "complexity" ? "bg-teal-500 text-slate-950 font-extrabold" : "text-slate-400 hover:text-slate-200"}`}
                                           >
                                               Complexity
                                           </button>
                                           <button 
                                               onClick={() => setAnalysisMode("severity")}
                                               className={`px-3.5 py-1 rounded-md transition-all ${analysisMode === "severity" ? "bg-teal-500 text-slate-950 font-extrabold" : "text-slate-400 hover:text-slate-200"}`}
                                           >
                                               Billed Amount
                                           </button>
                                       </div>

                                   </div>
                               </div>

                              <div className="flex-1 flex space-x-3.5 min-h-0 overflow-hidden relative">
                                  
                                  {/* Column 1: First Cut (Category list) */}
                                  <div className={`flex flex-col min-h-0 transition-all duration-300 ${activeDetailCategory ? (activeDetailFeature ? "w-1/5" : "w-1/3") : "w-full"}`}>
                                      <div className="text-3xs font-bold text-slate-500 uppercase tracking-wider mb-2 shrink-0">
                                          1. Complexity Domains
                                      </div>
                                      <div className="flex-1 overflow-y-auto space-y-2 pr-0.5">
                                          {markerContributions.map((c, idx) => {
                                              const isActive = activeDetailCategory === c.key;
                                              return (
                                                  <div 
                                                      key={idx}
                                                      onClick={() => {
                                                          setActiveDetailCategory(isActive ? null : c.key);
                                                          setActiveDetailFeature(null);
                                                      }}
                                                      className={`border rounded-lg p-3 cursor-pointer transition select-none flex flex-col justify-center space-y-1.5 ${isActive ? "bg-teal-950/30 border-teal-500/45 text-teal-300 shadow-md" : "bg-slate-950/40 border-slate-850 hover:bg-slate-900/60 hover:border-slate-800 text-slate-300"}`}
                                                  >
                                                      <div className="flex justify-between items-center text-xs font-bold">
                                                          <span className="truncate pr-1 text-slate-200">{c.name}</span>
                                                          <div className="flex items-center space-x-2 shrink-0 select-none">
                                                              {!activeDetailCategory && (
                                                                  <span className="bg-slate-900 border border-slate-800 px-2 py-0.5 rounded text-[10px] font-mono text-slate-400 font-bold">
                                                                      {c.avgCont.toFixed(2)} pts
                                                                  </span>
                                                              )}
                                                              <span className="bg-teal-500/10 border border-teal-500/20 px-2 py-0.5 rounded text-[10px] font-mono text-teal-400 font-extrabold">
                                                                  {c.percentage.toFixed(0)}%
                                                              </span>
                                                          </div>
                                                      </div>
                                                  </div>
                                              );
                                          })}
                                      </div>
                                  </div>

                                  {/* Column 2: Second Cut (Sub-feature list) */}
                                  {activeDetailCategory && (
                                      <div className={`flex flex-col min-h-0 bg-slate-950 border border-slate-800 rounded-xl p-3 shadow-2xl relative z-10 transition-all duration-300 ${activeDetailFeature ? "w-[30%]" : "flex-1"}`}>
                                          <div className="shrink-0 mb-3 border-b border-slate-850 pb-2 flex justify-between items-center">
                                              <div>
                                                  <h4 className="text-2xs font-bold text-teal-400 truncate max-w-[110px]" title={markerDefinitions[activeDetailCategory].name}>
                                                      {markerDefinitions[activeDetailCategory].name}
                                                  </h4>
                                                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mt-0.5">2. Feature Drivers</span>
                                              </div>
                                              <button 
                                                  onClick={() => {
                                                      setActiveDetailCategory(null);
                                                      setActiveDetailFeature(null);
                                                  }}
                                                  className="h-5 w-5 rounded bg-slate-900 hover:bg-slate-850 text-slate-400 hover:text-slate-200 flex items-center justify-center text-3xs font-bold transition border border-slate-800"
                                              >
                                                  ✕
                                              </button>
                                          </div>

                                          <div className="flex-1 overflow-y-auto space-y-2 pr-0.5">
                                              {(() => {
                                                  const aliasList = markerFeatures[activeDetailCategory];
                                                  const weight = weights[activeDetailCategory] || 0;
                                                  
                                                  const featuresData = aliasList.map(aliases => {
                                                      const score = selectedClaim ? getScore(selectedClaim, aliases) : 0;
                                                      const totalScore = calculatedClaims.reduce((acc, c) => acc + getScore(c, aliases), 0);
                                                      const avgScore = calculatedClaims.length > 0 ? totalScore / calculatedClaims.length : 0;
                                                      
                                                      return {
                                                          name: aliases[0],
                                                          score: selectedClaim ? score : avgScore,
                                                          contribution: (selectedClaim ? (score - avgScore) : avgScore) * weight,
                                                      };
                                                  }).sort((a, b) => Math.abs(b.contribution) - Math.abs(a.contribution));

                                                  return featuresData.map((f, fIdx) => {
                                                      const isFeatureActive = activeDetailFeature === f.name;
                                                      return (
                                                          <div 
                                                              key={fIdx} 
                                                              onClick={() => setActiveDetailFeature(isFeatureActive ? null : f.name)}
                                                              className={`border p-2 rounded-lg text-3xs cursor-pointer transition flex flex-col justify-between ${isFeatureActive ? "bg-teal-950/20 border-teal-500/40 text-teal-300" : "bg-slate-900/60 border-slate-850 hover:bg-slate-900 hover:border-slate-800 text-slate-300"}`}
                                                          >
                                                              <div className="flex justify-between text-slate-300 font-semibold truncate" title={f.name.replace("_score", "")}>
                                                                  <span className="truncate pr-1">{f.name.replace("_score", "").replace(" Score", "")}</span>
                                                                  <span className="font-mono text-slate-400">v={f.score.toFixed(1)}</span>
                                                              </div>
                                                              {!activeDetailFeature && (
                                                                  <div className="flex justify-between items-center text-4xs font-mono text-slate-500 mt-1">
                                                                      <span>Impact</span>
                                                                      <span className={f.contribution >= 0 ? "text-emerald-400 font-bold" : "text-rose-400 font-bold"}>
                                                                          {f.contribution >= 0 ? `+${f.contribution.toFixed(2)}` : f.contribution.toFixed(2)} pts
                                                                      </span>
                                                                  </div>
                                                              )}
                                                          </div>
                                                      );
                                                  });
                                              })()}
                                          </div>
                                      </div>
                                  )}

                                  {/* Column 3: Third Cut (Raw Text NLP Analysis or Job Text details) */}
                                  {activeDetailCategory && activeDetailFeature && (
                                      <div className="flex-1 bg-slate-950 border border-slate-800 rounded-xl p-3 flex flex-col min-h-0 shadow-2xl relative z-10 animate-slide-in">
                                          <div className="shrink-0 mb-3 border-b border-slate-850 pb-2 flex justify-between items-center">
                                              <div>
                                                  <h4 className="text-xs font-bold text-teal-400 truncate max-w-[155px]">
                                                      {featureToTextColumnMap[activeDetailFeature] ? featureToTextColumnMap[activeDetailFeature].split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ') : 'Details'}
                                                  </h4>
                                                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mt-0.5">3. Clinical Narrative</span>
                                              </div>
                                              <button 
                                                  onClick={() => setActiveDetailFeature(null)}
                                                  className="h-5 w-5 rounded bg-slate-900 hover:bg-slate-850 text-slate-400 hover:text-slate-200 flex items-center justify-center text-3xs font-bold transition border border-slate-800"
                                              >
                                                  ✕
                                              </button>
                                          </div>

                                           {/* Text Content display */}
                                           <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
                                               {selectedClaim ? (
                                                   // Single job text values - stretched full height case reader
                                                   <div className="flex-1 bg-slate-900/40 border border-slate-850 p-4 rounded-xl flex flex-col space-y-2.5 h-full min-h-0 select-none">
                                                       <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block shrink-0">Case Value / Narrative</span>
                                                       <div className="flex-1 bg-slate-955 border border-slate-900/60 rounded-lg p-4 text-xs text-slate-200 leading-relaxed overflow-y-auto select-text font-medium flex items-center justify-center min-h-0">
                                                           {(() => {
                                                               const rawVal = getClaimTextValue(selectedClaim, featureToTextColumnMap[activeDetailFeature]);
                                                               if (!rawVal || rawVal.trim().toLowerCase() === "none" || rawVal.trim() === "") {
                                                                   return <span className="text-slate-500 italic">No narrative or record value found.</span>;
                                                               }
                                                               if (rawVal.length < 35) {
                                                                   return (
                                                                       <div className="text-center space-y-2 select-none">
                                                                           <span className="text-[9px] text-slate-500 uppercase font-bold tracking-widest block">Recorded Value</span>
                                                                           <strong className="text-teal-400 text-3xl font-mono block tracking-tight">{rawVal}</strong>
                                                                       </div>
                                                                   );
                                                               }
                                                               return <span className="block w-full h-full text-slate-300 leading-relaxed text-left whitespace-pre-wrap">{rawVal}</span>;
                                                           })()}
                                                       </div>
                                                   </div>
                                               ) : (
                                                   // Global Word Frequency chart
                                                   <div className="w-full flex-1 flex flex-col min-h-0 text-3xs">
                                                       <span className="text-4xs text-slate-500 font-bold uppercase tracking-wider mb-2.5 block shrink-0">Top 10 Most Common Terms</span>
                                                       {textTermFrequencies.length === 0 ? (
                                                           <div className="text-slate-500 text-center py-4">No text details available to parse.</div>
                                                       ) : (
                                                           <div className="space-y-2.5 flex-1 overflow-y-auto pr-0.5">
                                                               {textTermFrequencies.map((tf, tfIdx) => {
                                                                   const maxCount = Math.max(...textTermFrequencies.map(x => x.count), 1);
                                                                   const wPercent = (tf.count / maxCount) * 100;
                                                                   return (
                                                                       <div key={tfIdx} className="space-y-1">
                                                                           <div className="flex justify-between text-slate-300 font-semibold">
                                                                               <span className="truncate pr-1">{tfIdx + 1}. {tf.term}</span>
                                                                               <span className="font-mono text-teal-400">{tf.count}x</span>
                                                                           </div>
                                                                           <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
                                                                               <div className="h-full bg-teal-500 rounded-full" style={{ width: `${wPercent}%` }} />
                                                                           </div>
                                                                       </div>
                                                                   );
                                                               })}
                                                           </div>
                                                       )}
                                                   </div>
                                               )}
                                           </div>
                                           </div>
                                   )}
                              </div>
                          </section>

                      </div>
                  </div>
              )}
              
              {/* TAB 4: KEY RISK DRIVERS PORTFOLIO & COMBINATIONS */}
              {activeTab === "drivers" && (
                  <div className="flex-1 flex flex-col min-h-0 p-4 space-y-4 overflow-hidden">
                      
                      {/* Top EDA statistics matching other tabs */}
                      <div className="grid grid-cols-5 gap-3.5 shrink-0 select-none">
                          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex justify-between items-center shadow-lg hover:border-slate-700 transition">
                              <div>
                                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block">Total Jobs</span>
                                  <span className="text-lg font-extrabold text-slate-100 font-mono mt-1 block">{datasetStats.count.toLocaleString()}</span>
                              </div>
                              <span className="text-md">📊</span>
                          </div>
                          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex justify-between items-center shadow-lg hover:border-slate-700 transition">
                              <div>
                                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block">Avg Complexity</span>
                                  <span className="text-lg font-extrabold text-teal-400 font-mono mt-1 block">{datasetStats.avg}</span>
                              </div>
                              <span className="text-md text-teal-400">⚖️</span>
                          </div>
                          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex justify-between items-center shadow-lg hover:border-slate-700 transition">
                              <div>
                                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block">Min Complexity</span>
                                  <span className="text-lg font-extrabold text-slate-100 font-mono mt-1 block">{datasetStats.min}</span>
                              </div>
                              <span className="text-md">📉</span>
                          </div>
                          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex justify-between items-center shadow-lg hover:border-slate-700 transition">
                              <div>
                                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block">Max Complexity</span>
                                  <span className="text-lg font-extrabold text-slate-100 font-mono mt-1 block">{datasetStats.max}</span>
                              </div>
                              <span className="text-md">📈</span>
                          </div>
                          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex justify-between items-center shadow-lg hover:border-slate-700 transition">
                              <div>
                                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block">High Complexity Cohort</span>
                                  <span className="text-lg font-extrabold text-rose-450 font-mono mt-1 block">{datasetStats.highRiskPct}%</span>
                              </div>
                              <span className="text-md text-rose-400">🔥</span>
                          </div>
                      </div>

                      {/* Main Split Layout: Key Features (Left) | Risk Combinations (Right) */}
                      <div className="flex-1 grid grid-cols-12 gap-4 min-h-0 overflow-hidden">
                          
                          {/* Left Panel: All Features sorted by point contribution */}
                          <section className="col-span-6 bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col min-h-0 shadow-lg overflow-hidden">
                              <div className="shrink-0 mb-3 border-b border-slate-800 pb-2 flex justify-between items-center">
                                  <div>
                                      <h3 className="text-xs font-bold text-slate-200">Point Contribution Rankings</h3>
                                      <p className="text-3xs text-slate-500">
                                          {selectedClaimId 
                                              ? `Showing individual feature point impacts for Job: ${selectedClaimId}`
                                              : "Showing average feature point impacts across all claims"}
                                      </p>
                                  </div>
                                  {selectedClaimId && (
                                      <span className="bg-teal-500/10 border border-teal-500/20 px-2 py-0.5 rounded text-[10px] font-mono text-teal-400 font-bold select-none">
                                          Job: {selectedClaimId}
                                      </span>
                                  )}
                              </div>

                              <div className="flex-1 overflow-y-auto space-y-2 pr-0.5 select-none">
                                  {allFeaturesContributionList.map((f, idx) => {
                                      const maxPoints = Math.max(...allFeaturesContributionList.map(x => x.points), 0.1);
                                      const pctBar = (f.points / maxPoints) * 100;
                                      return (
                                          <div key={idx} className="bg-slate-950/40 border border-slate-850 p-2.5 rounded-lg flex flex-col space-y-1 hover:border-slate-800 transition">
                                              <div className="flex justify-between items-center text-xs font-bold">
                                                  <div className="flex items-center space-x-2 truncate">
                                                      <span className="text-slate-500 font-mono text-[10px]">{idx + 1}.</span>
                                                      <span className="text-slate-200 truncate capitalize" title={f.name}>{f.name}</span>
                                                      <span className="bg-slate-900 border border-slate-800/80 px-1.5 py-0.2 rounded text-[8px] font-medium text-slate-400 tracking-wider">
                                                          {f.category}
                                                      </span>
                                                  </div>
                                                  <div className="flex items-center space-x-2 shrink-0">
                                                      <span className="text-slate-500 font-mono text-[10px]">(v={f.rawScore.toFixed(1)})</span>
                                                      <span className="text-teal-400 font-mono font-extrabold">{f.points.toFixed(2)} pts</span>
                                                  </div>
                                              </div>
                                              
                                              {/* Simple visual bar */}
                                              <div className="h-1 bg-slate-900 border border-slate-900 rounded overflow-hidden">
                                                  <div 
                                                      className="h-full bg-gradient-to-r from-teal-500 to-emerald-400 rounded-r"
                                                      style={{ width: `${pctBar}%` }}
                                                  />
                                              </div>
                                          </div>
                                      );
                                  })}
                              </div>
                          </section>

                          {/* Right Panel: Mined Dangerous Combinations */}
                          <section className="col-span-6 bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col min-h-0 shadow-lg overflow-hidden">
                              <div className="shrink-0 mb-3 border-b border-slate-800 pb-2">
                                  <h3 className="text-xs font-bold text-slate-200">High-Risk Feature Combinations (3+ Drivers)</h3>
                                  <p className="text-3xs text-slate-500">Mined correlations among the top complexity jobs in the dataset</p>
                              </div>

                              <div className="flex-1 overflow-y-auto space-y-3.5 pr-0.5">
                                  {minedDangerousCombinations.map((combo, idx) => {
                                      // Skip combos with 0 matches to keep it professional
                                      if (combo.count === 0) return null;
                                      
                                      return (
                                          <div key={idx} className="bg-slate-950/50 border border-slate-850 p-4 rounded-xl flex flex-col space-y-3 hover:border-slate-800 transition">
                                              
                                              {/* Header Info */}
                                              <div className="flex justify-between items-start">
                                                  <div>
                                                      <h4 className="text-xs font-extrabold text-slate-200 tracking-tight">{combo.name}</h4>
                                                      <p className="text-3xs text-slate-400 mt-0.5">
                                                          Prevalence: <strong className="text-slate-300 font-mono">{combo.prevalence.toFixed(1)}%</strong> ({combo.count} claims)
                                                      </p>
                                                  </div>
                                                  <div className="text-right shrink-0 select-none">
                                                      <span className="text-[9px] text-slate-500 font-bold block uppercase tracking-wider">Avg Complexity</span>
                                                      <span className="text-sm font-black font-mono text-rose-400">{combo.avgComplexity} pts</span>
                                                  </div>
                                              </div>

                                              {/* Pill Row */}
                                              <div className="flex flex-wrap gap-1.5 select-none">
                                                  {combo.features.map((feat, fIdx) => (
                                                      <span key={fIdx} className="bg-rose-500/10 border border-rose-500/20 text-rose-400 px-2 py-0.5 rounded-full text-[9px] font-bold">
                                                          {feat}
                                                      </span>
                                                  ))}
                                              </div>

                                              {/* Description */}
                                              <p className="text-2xs text-slate-350 leading-relaxed bg-slate-900/40 border border-slate-900/60 p-2.5 rounded-lg select-text font-medium">
                                                  {combo.desc}
                                              </p>
                                          </div>
                                      );
                                  })}
                                  {minedDangerousCombinations.every(c => c.count === 0) && (
                                      <div className="text-center py-12 text-slate-500 text-2xs italic">
                                          No high-risk combinations found in the current claims cohort.
                                      </div>
                                  )}
                              </div>
                          </section>

                      </div>

                  </div>
              )}

          </div>

      </div>
  );
}

export default function AppWithErrorBoundary() {
  return (
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  );
}
