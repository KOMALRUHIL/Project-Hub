import os
import json
import time
import csv
import threading
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed

# ----------------------------------------------------
# CONFIGURATION
# ----------------------------------------------------
# Paste your credentials here:
AZURE_AI_CHAT_ENDPOINT = "YOUR_AZURE_ENDPOINT_HERE"
AZURE_AI_CHAT_KEY = "YOUR_AZURE_KEY_HERE"
AZURE_AI_CHAT_MODEL = "Llama-3.3-70B-Instruct"

# Performance settings
MAX_WORKERS = 5  # Number of rows to process in parallel. Increase this for more speed.
MAX_RETRIES = 3  # Number of retries if the API rate limits you (HTTP 429)

# Cost settings (Llama 3.3 pricing on Azure is ~$0.71 per 1 million tokens for input & output)
COST_PER_M_TOKENS = 0.71
# ----------------------------------------------------

# Threading locks and trackers
csv_write_lock = threading.Lock()
stats_lock = threading.Lock()
total_input_tokens = 0
total_output_tokens = 0
total_cost_usd = 0.0

def get_llama_credentials():
    endpoint = AZURE_AI_CHAT_ENDPOINT
    key = AZURE_AI_CHAT_KEY
    model = AZURE_AI_CHAT_MODEL
    
    if endpoint == "YOUR_AZURE_ENDPOINT_HERE":
        endpoint = os.getenv("AZURE_AI_CHAT_ENDPOINT", "")
    if key == "YOUR_AZURE_KEY_HERE":
        key = os.getenv("AZURE_AI_CHAT_KEY", "")
    if model == "Llama-3.3-70B-Instruct":
        model = os.getenv("AZURE_AI_CHAT_MODEL", "Llama-3.3-70B-Instruct")
        
    # Standardize endpoint
    url = endpoint.rstrip("/")
    if not url.endswith("/chat/completions"):
        if url.endswith("/v1"):
            url = f"{url}/chat/completions"
        else:
            url = f"{url}/v1/chat/completions"
            
    return url, key, model

def generate_extraction_prompt(patient_data):
    """
    Constructs the system instructions and patient data inputs for the LLM.
    """
    system_prompt = """
You are a highly precise clinical coding assistant. Your task is to analyze patient medical records and insurance claim citations, and return a structured JSON object containing exactly 25 columns.

CRITICAL ENCODING RULE FOR EMPTY VS NEGATIVE DATA:
1. Output "blank" ONLY when the source input column(s) referred to are completely empty, null, N/A, NA, or missing in the patient record.
2. Output "none" (or "no" for yes/no columns) if the source input column is populated with text, but the specific item, condition, injury, or exposure is NOT present or found in that text.
3. Ensure that all listed items in comma-separated fields (such as diagnoses, chronic diseases, serious injuries, medications, surgical procedures, neurological injuries, body parts) are unique and do not contain duplicate or repeating entries.

You must follow these strict logic hierarchies for each target output column:

1. type_of_claim:
   - If the primary disability fields ('disability-insight-type', 'disability-severity', 'disability-citation') are completely empty/null/NA $\rightarrow$ "blank".
   - If they are populated, classify as: "permanent full disability", "permanent partial disability", "temporary full disability", or "temporary partial disability".
   - Fallback: If those disability fields are populated but do not specify a type, or if injury/accident citations are populated but indicate minor soft-tissue injuries $\rightarrow$ "none".
   - Outputs MUST be one of: "permanent full disability", "permanent partial disability", "temporary full disability", "temporary partial disability", "none", "blank".

2. employment_status_derived:
   - Primary: Check the 'employment_status' column.
   - Fallback 1: If empty/null/NA, check 'special-damages-wage-loss-citation'. If it contains any text mentioning work, joining work, missed shifts, lost income, or return to work, read the sentence and infer whether they are "employed" or "non-employed".
   - Fallback 2: If both input columns are completely empty/null/NA $\rightarrow$ "blank".
   - Outputs MUST be one of: "employed", "non-employed", "blank".

3. return_to_work_risk:
   - Primary: Check 'disability-citation', 'disability-length', and 'special-damages-wage-loss-citation'.
     * If the input columns are completely empty/null/NA $\rightarrow$ "blank".
     * If they are populated and the patient immediately returned to work, had no missed days, or had only minor injuries with no restrictions $\rightarrow$ "no risk".
     * If they are populated and the patient experienced a delay (missed work for a few weeks before returning) OR has active work restrictions limiting their tasks $\rightarrow$ "Delayed/Restricted".
     * If they are populated and indicate permanent disability and cannot return to work at all $\rightarrow$ "Yes".
     * If they are populated but indicate no risk or restrictions $\rightarrow$ "none".
   - Outputs MUST be one of: "no risk", "Delayed/Restricted", "Yes", "none", "blank".

4. drug_use:
   - If the 'general-damages-drug-use-citation' is completely empty/null/NA $\rightarrow$ "blank".
   - If populated and positive $\rightarrow$ "yes".
   - If populated and negative $\rightarrow$ "no".
   - Outputs MUST be one of: "yes", "no", "blank".

5. diagnoses:
   - If 'treatment-diagnosis-citation' and 'INJURY_FOCUS' are completely empty/null/NA $\rightarrow$ "blank".
   - If they are populated but list no diagnoses $\rightarrow$ "none".
   - Otherwise, list all diagnoses as a comma-separated string.

6. chronic_diseases:
   - If 'patient-medical-history-condition-citation' and 'treatment-diagnosis-citation' are completely empty/null/NA $\rightarrow$ "blank".
   - If they are populated but list no chronic conditions $\rightarrow$ "none".
   - Otherwise, list all chronic conditions as a comma-separated string.

7. mental_health_diseases:
   - Scan diagnoses, chronic diseases, and 'patient-medical-history-condition-citation'.
   - If all these source columns are completely empty/null/NA $\rightarrow$ "blank".
   - If they are populated but list no mental health diseases/conditions $\rightarrow$ "none".
   - Otherwise, list all mental health conditions (depression, anxiety, PTSD, insomnia, panic attacks, adjustment disorder, chronic stress, etc.) as a comma-separated string.

8. smoking:
   - If 'general-damages-use-of-tobacco-citation' is completely empty/null/NA $\rightarrow$ "blank".
   - If populated and positive $\rightarrow$ "yes".
   - If populated and negative $\rightarrow$ "no".
   - Outputs MUST be one of: "yes", "no", "blank".

9. alcohol:
   - If 'general-damages-alcohol-citation' is completely empty/null/NA $\rightarrow$ "blank".
   - If populated and positive $\rightarrow$ "yes".
   - If populated and negative $\rightarrow$ "no".
   - Outputs MUST be one of: "yes", "no", "blank".

10. loss_of_consciousness:
    - If 'accident-loss-of-consciousness-citation' and 'accident-moi-citation' are completely empty/null/NA $\rightarrow$ "blank".
    - If populated and positive $\rightarrow$ "yes".
    - If populated and negative $\rightarrow$ "no".
    - Outputs MUST be one of: "yes", "no", "blank".

11. restrained:
    - If 'accident-restrained-citation' and 'accident-moi-citation' are completely empty/null/NA $\rightarrow$ "blank".
    - If populated and positive $\rightarrow$ "yes".
    - If populated and negative $\rightarrow$ "no".
    - Outputs MUST be one of: "yes", "no", "blank".

12. head_impact:
    - If 'accident-condition-or-injury-citation', 'INJURY_FOCUS', and 'accident-moi-citation' are completely empty/null/NA $\rightarrow$ "blank".
    - If populated and positive (head strike, concussion, head trauma) $\rightarrow$ "yes".
    - If populated and negative $\rightarrow$ "no".
    - Outputs MUST be one of: "yes", "no", "blank".

13. third_party_involvement:
    - If 'accident-moi-citation' is completely empty/null/NA $\rightarrow$ "blank".
    - If populated and another vehicle, pedestrian, passenger status, or animal was involved $\rightarrow$ "yes".
    - If populated and single-vehicle accident (driver hit static guardrail/tree on their own) $\rightarrow$ "no".
    - Outputs MUST be one of: "yes", "no", "blank".

14. number_of_vehicles:
    - If 'accident-moi-citation' is completely empty/null/NA $\rightarrow$ "blank".
    - If populated and single-vehicle $\rightarrow "single"$.
    - If populated and two vehicles $\rightarrow$ "two".
    - If populated and multiple vehicles $\rightarrow$ "multiple".
    - If populated but unspecified $\rightarrow$ "none".
    - Outputs MUST be one of: "single", "two", "multiple", "none", "blank".

15. catastrophic_indicator:
    - If 'INJURY_FOCUS' and 'treatment-diagnosis-citation' are completely empty/null/NA $\rightarrow$ "blank".
    - If populated and positive (paralysis, amputation, severe TBI, third-degree burns) $\rightarrow$ "yes".
    - If populated and negative (soft-tissue whiplash, neck/back strains) $\rightarrow$ "no".
    - Outputs MUST be one of: "yes", "no", "blank".

16. accident_type:
    - If 'accident-moi-citation' and 'accident-condition-or-injury-citation' are completely empty/null/NA $\rightarrow$ "blank".
    - If populated, classify as one of: "animal-related injury", "fall accident", "recreational vehicle accident", "rollover accident", "rear-end collision", "side-impact collision", "multi-vehicle collision", "work-related accident", "single-vehicle accident", "unknown".
    - Outputs MUST be one of the above 10 categories, or "blank".

17. other_exposures:
    - If 'accident-moi-citation' and 'accident-condition-or-injury-citation' are completely empty/null/NA $\rightarrow$ "blank".
    - If populated:
      * If head went through window/windshield glass $\rightarrow$ "head in glass".
      * If head strike/impact but no glass contact $\rightarrow$ "head".
      * If exposed to breaking/shattering glass but no head impact $\rightarrow$ "glass".
      * If populated but none of these occurred $\rightarrow$ "none".
    - Outputs MUST be one of: "head", "glass", "head in glass", "none", "blank".

18. serious_injury_presence:
    - If 'accident-claimed-injury-citation' and 'accident-condition-or-injury-citation' are completely empty/null/NA $\rightarrow$ "blank".
    - If populated but no serious injuries (internal bleeding, organ damage, fractures, brain injury, herniated discs, severe burns) are present $\rightarrow$ "none".
    - Otherwise, list only the unique serious injuries identified as a comma-separated string. Do not state or include the count of injuries.

19. opioid_usage_details:
    - If 'medication-pre-injury-citation', 'medication-post-injury-citation', 'pre_meds', and 'post_meds' are completely empty/null/NA $\rightarrow$ "blank".
    - If populated but no opioid medications (Tramadol, Oxycodone, Hydrocodone, Codeine, Fentanyl, Morphine) are found $\rightarrow$ "none".
    - Otherwise, list the names of the identified opioids.

20. controlled_substances_details:
    - If 'medication-pre-injury-citation', 'medication-post-injury-citation', 'pre_meds', and 'post_meds' are completely empty/null/NA $\rightarrow$ "blank".
    - If populated but no controlled substances (Gabapentin, Alprazolam, Clonazepam, Diazepam, Zolpidem, Pregabalin, Methylphenidate) are found $\rightarrow$ "none".
    - Otherwise, list the names of the identified controlled substances.

21. high_risk_medication_details:
    - If 'medication-pre-injury-citation', 'medication-post-injury-citation', 'pre_meds', and 'post_meds' are completely empty/null/NA $\rightarrow$ "blank".
    - If populated but no high-risk medications (Amitriptyline, Cyclobenzaprine, Methocarbamol, Baclofen, Tizanidine, Anticoagulants) are found $\rightarrow$ "none".
    - Otherwise, list the names of the identified high-risk medications.

22. surgical_procedures_details:
    - If 'treatment-plan-citation' and 'treatment-diagnosis-citation' are completely empty/null/NA $\rightarrow$ "blank".
    - If populated but no surgical/invasive procedures (discectomy, laminectomy, fusion, block/dural injections) are found $\rightarrow$ "none".
    - Otherwise, list the identified surgical/invasive procedures.

23. neurological_injuries_details:
    - If 'treatment-diagnosis-citation' and 'INJURY_FOCUS' are completely empty/null/NA $\rightarrow$ "blank".
    - If populated but no neurological injuries (radiculopathy, sciatica, concussion, nerve damage, numbness, tingling) are found $\rightarrow$ "none".
    - Otherwise, list the identified neurological injuries.

24. permanent_impairment_details:
    - If 'treatment-diagnosis-citation', 'disability-citation', and 'INJURY_FOCUS' are completely empty/null/NA $\rightarrow$ "blank".
    - If populated but no permanent impairment indicators (permanent restriction, will not return to baseline, MMI rating) are found $\rightarrow$ "none".
    - Otherwise, list the identified indicators.

25. body_part_injured_details:
    - If 'treatment-diagnosis-citation', 'INJURY_FOCUS', and 'accident-condition-or-injury-citation' are completely empty/null/NA $\rightarrow$ "blank".
    - If populated but no injured body parts are found $\rightarrow$ "none".
    - Otherwise, list all injured body parts (lumbar, cervical, head, knee, shoulder, etc.).

---
Format your response as a strict JSON object with these keys:
{
  "type_of_claim": "value",
  "employment_status_derived": "value",
  "return_to_work_risk": "value",
  "drug_use": "value",
  "diagnoses": "value",
  "chronic_diseases": "value",
  "mental_health_diseases": "value",
  "smoking": "value",
  "alcohol": "value",
  "loss_of_consciousness": "value",
  "restrained": "value",
  "head_impact": "value",
  "third_party_involvement": "value",
  "number_of_vehicles": "value",
  "catastrophic_indicator": "value",
  "accident_type": "value",
  "other_exposures": "value",
  "serious_injury_presence": "value",
  "opioid_usage_details": "value",
  "controlled_substances_details": "value",
  "high_risk_medication_details": "value",
  "surgical_procedures_details": "value",
  "neurological_injuries_details": "value",
  "permanent_impairment_details": "value",
  "body_part_injured_details": "value"
}
Do not write any introduction, code blocks, or markdown formatting outside the JSON. Return only the JSON string.
Ensure all JSON keys and string values are properly wrapped in standard double quotes, and escape any internal double quotes with a backslash. Do not include raw newlines within string values.
"""
    
    # Filter the input patient row data to only the columns the model needs
    relevant_keys = [
        "employment_status", "special-damages-wage-loss-citation", "employment_relevance",
        "disability-citation", "disability-insight-type", "disability-severity", "disability-length",
        "general-damages-drug-use-citation", "general-damages-use-of-tobacco-citation", "general-damages-alcohol-citation",
        "treatment-diagnosis-citation", "INJURY_FOCUS", "patient-medical-history-condition-citation",
        "accident-loss-of-consciousness-citation", "accident-moi-citation", "accident-restrained-citation",
        "accident-condition-or-injury-citation", "treatment-plan-citation",
        "accident-claimed-injury-citation", "medication-pre-injury-citation", "medication-post-injury-citation",
        "pre_meds", "post_meds"
    ]
    
    filtered_data = {}
    for k in relevant_keys:
        val = patient_data.get(k, "")
        # Clean nulls/NaNs from CSV inputs
        if val is None or val == "NaN" or val == "nan" or val == "":
            filtered_data[k] = None
        else:
            filtered_data[k] = str(val).strip()
            
    user_prompt = f"Patient Record Data:\n{json.dumps(filtered_data, indent=2)}"
    return system_prompt, user_prompt

def call_azure_api_with_retry(payload, url, api_key, row_num):
    """
    Sends POST request with exponential backoff retry logic.
    """
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    backoff = 2
    for attempt in range(MAX_RETRIES):
        try:
            response = requests.post(url, json=payload, headers=headers, timeout=60)
            
            if response.status_code == 429:
                print(f"[ROW {row_num}] Rate limited (429). Retrying in {backoff}s... (Attempt {attempt+1}/{MAX_RETRIES})", flush=True)
                time.sleep(backoff)
                backoff *= 2
                continue
            elif 400 <= response.status_code < 500:
                print(f"[ROW {row_num}] HTTP Client Error {response.status_code} - Skipping retries.", flush=True)
                print(f"[ROW {row_num}] Server response details: {response.text}", flush=True)
                return None
                
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.RequestException as re:
            # Check if this is a client error that shouldn't be retried
            if re.response is not None and 400 <= re.response.status_code < 500 and re.response.status_code != 429:
                print(f"[ROW {row_num}] API call failed permanently with client error {re.response.status_code}.", flush=True)
                print(f"[ROW {row_num}] Server response details: {re.response.text}", flush=True)
                return None
                
            if attempt == MAX_RETRIES - 1:
                print(f"[ROW {row_num}] API call failed permanently: {re}", flush=True)
                if re.response is not None:
                    print(f"[ROW {row_num}] Server response details: {re.response.text}", flush=True)
                return None
            print(f"[ROW {row_num}] Glitch detected: {re}. Retrying in {backoff}s...", flush=True)
            time.sleep(backoff)
            backoff *= 2
            
    return None

def process_single_row(row_data, row_num, url, api_key, model_name):
    """
    Processes one row: prompt generation, API call, token tracking, and cost calculation.
    """
    sys_msg, user_msg = generate_extraction_prompt(row_data)
    
    payload = {
        "model": model_name,
        "messages": [
            {"role": "system", "content": sys_msg},
            {"role": "user", "content": user_msg}
        ],
        "temperature": 0.0,
        "max_tokens": 1500
    }
    
    response_data = call_azure_api_with_retry(payload, url, api_key, row_num)
    if not response_data:
        return row_num, None
        
    try:
        raw_content = response_data["choices"][0]["message"]["content"].strip()
        
        # Clean markdown wrapper if returned
        if raw_content.startswith("```"):
            raw_content = raw_content.split("```json")[-1].split("```")[0].strip()
            
        parsed_json = json.loads(raw_content)
        
        # Format arrays as strings and remove duplicate items
        for key in parsed_json:
            val = parsed_json[key]
            if isinstance(val, list):
                cleaned_items = [str(x).strip() for x in val if x and str(x).strip() != ""]
                unique_items = list(dict.fromkeys(cleaned_items))
                parsed_json[key] = ", ".join(unique_items)
            elif isinstance(val, str):
                if "," in val:
                    cleaned_items = [x.strip() for x in val.split(",") if x and x.strip() != ""]
                    unique_items = list(dict.fromkeys(cleaned_items))
                    parsed_json[key] = ", ".join(unique_items)
                    
            if parsed_json[key] is None or str(parsed_json[key]).strip() == "":
                parsed_json[key] = "blank"
            
        # Extract token usage and update metrics
        usage = response_data.get("usage", {})
        prompt_tokens = usage.get("prompt_tokens", 0)
        completion_tokens = usage.get("completion_tokens", 0)
        
        # Calculate cost for this row
        row_cost = ((prompt_tokens + completion_tokens) / 1_000_000) * COST_PER_M_TOKENS
        
        global total_input_tokens, total_output_tokens, total_cost_usd
        with stats_lock:
            total_input_tokens += prompt_tokens
            total_output_tokens += completion_tokens
            total_cost_usd += row_cost
            
        print(f"[ROW {row_num}] Processed. Cost: ${row_cost:.5f} ({prompt_tokens} in / {completion_tokens} out tokens)", flush=True)
        return row_num, parsed_json
        
    except Exception as e:
        print(f"[ROW {row_num}] Extraction/Parsing failed: {e}", flush=True)
        return row_num, None

def batch_process_csv():
    """
    Reads test.csv, processes rows in parallel, updates data, and saves to test_extracted.csv.
    """
    script_dir = os.path.dirname(os.path.abspath(__file__))
    input_path = os.path.join(script_dir, "test.csv")
    output_path = os.path.join(script_dir, "test_extracted.csv")
    
    if not os.path.exists(input_path):
        print(f"[ERROR] Input file 'test.csv' not found at: {input_path}", flush=True)
        print("Please export your excel sheet as 'test.csv' in the script directory.", flush=True)
        return
        
    url, api_key, model_name = get_llama_credentials()
    if not url or not api_key:
        print("[ERROR] Credentials not set. Please update endpoint/keys directly in the code.", flush=True)
        return
        
    # Read the CSV file
    print(f"Reading input file: {input_path}", flush=True)
    try:
        with open(input_path, mode="r", encoding="utf-8-sig") as f:
            reader = list(csv.DictReader(f))
    except UnicodeDecodeError:
        print("[WARNING] Failed to decode with UTF-8-sig. Retrying with cp1252 (Windows ANSI) encoding...", flush=True)
        with open(input_path, mode="r", encoding="cp1252") as f:
            reader = list(csv.DictReader(f))
        
    if not reader:
        print("[ERROR] CSV file is empty.", flush=True)
        return
        
    headers = list(reader[0].keys())
    new_cols = [
        "type_of_claim", "employment_status_derived", "return_to_work_risk", "drug_use",
        "diagnoses", "chronic_diseases", "mental_health_diseases", "smoking", "alcohol",
        "loss_of_consciousness", "restrained", "head_impact", "third_party_involvement",
        "number_of_vehicles", "catastrophic_indicator", "accident_type", "other_exposures",
        "serious_injury_presence",
        "opioid_usage_details",
        "controlled_substances_details",
        "high_risk_medication_details",
        "surgical_procedures_details",
        "neurological_injuries_details",
        "permanent_impairment_details",
        "body_part_injured_details"
    ]
    
    # Add new output headers if they are not already there
    for col in new_cols:
        if col not in headers:
            headers.append(col)
            
    # Check for existing output file to resume progress
    processed_rows = {}
    if os.path.exists(output_path):
        print(f"Resuming progress from existing output file: {output_path}", flush=True)
        try:
            with open(output_path, mode="r", encoding="utf-8-sig") as out_f:
                out_reader = list(csv.DictReader(out_f))
                for idx, out_row in enumerate(out_reader):
                    is_processed = any(out_row.get(col) not in (None, "", "null", "blank") for col in new_cols)
                    if is_processed:
                        processed_rows[idx] = out_row
        except UnicodeDecodeError:
            with open(output_path, mode="r", encoding="cp1252") as out_f:
                out_reader = list(csv.DictReader(out_f))
                for idx, out_row in enumerate(out_reader):
                    is_processed = any(out_row.get(col) not in (None, "", "null", "blank") for col in new_cols)
                    if is_processed:
                        processed_rows[idx] = out_row
        print(f"Found {len(processed_rows)} successfully processed rows.", flush=True)
        
    # Prepare task list
    start_time = time.time()
    total_rows = len(reader)
    print(f"Starting batch process. Total rows: {total_rows}. Workers: {MAX_WORKERS}", flush=True)
    
    # Open output file in append/write mode
    def save_output_file(current_dataset):
        with csv_write_lock:
            with open(output_path, mode="w", newline="", encoding="utf-8") as out_f:
                writer = csv.DictWriter(out_f, fieldnames=headers)
                writer.writeheader()
                writer.writerows(current_dataset)

    # Initialize output dataset with existing data or copy input data
    output_dataset = []
    for idx, row in enumerate(reader):
        if idx in processed_rows:
            output_dataset.append(processed_rows[idx])
        else:
            # Prepare new rows with blank extraction cells
            new_row = row.copy()
            for col in new_cols:
                new_row[col] = ""
            output_dataset.append(new_row)
            
    # Submit unprocessed rows to the thread pool
    rows_to_process = [i for i in range(len(reader)) if i not in processed_rows]
    
    if not rows_to_process:
        print("[SUCCESS] All rows have already been processed!", flush=True)
        return
        
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {
            executor.submit(process_single_row, reader[idx], idx + 1, url, api_key, model_name): idx 
            for idx in rows_to_process
        }
        
        for future in as_completed(futures):
            idx = futures[future]
            row_num, extracted_features = future.result()
            
            if extracted_features:
                # Merge features back into our thread-safe output dataset
                for col_name, val in extracted_features.items():
                    output_dataset[idx][col_name] = val
                    
                # Save progress immediately
                save_output_file(output_dataset)
                
            global total_cost_usd
            print(f"Progress: {len(output_dataset) - len(rows_to_process) + sum(1 for i in rows_to_process if output_dataset[i]['type_of_claim'] not in ('', 'blank'))}/{total_rows} completed. Accumulated Cost: ${total_cost_usd:.4f}", flush=True)
            
    elapsed_time = time.time() - start_time
    print("\n" + "="*50, flush=True)
    print("[SUCCESS] Processing completed!", flush=True)
    print(f"Output saved to: {output_path}", flush=True)
    print(f"Time elapsed: {elapsed_time/60:.2f} minutes", flush=True)
    print(f"Total input tokens: {total_input_tokens}", flush=True)
    print(f"Total output tokens: {total_output_tokens}", flush=True)
    print(f"Total API cost: ${total_cost_usd:.4f} USD", flush=True)
    print("="*50, flush=True)

if __name__ == "__main__":
    batch_process_csv()
