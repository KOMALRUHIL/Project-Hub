@echo off
title ClaimOptima - One-Time Setup & Installation
echo ===================================================
echo   ClaimOptima AI Engine - Dependency Installation
echo ===================================================
echo.
echo [1/2] Installing Python packages...
pip install -r requirements.txt
echo.
echo [2/2] Installing Frontend Node dependencies...
cd frontend
call npm install
cd ..
echo.
echo ===================================================
echo   Setup Complete!
echo   You can now launch the app by double-clicking:
echo   START_CLAIMOPTIMA.bat
echo ===================================================
pause
