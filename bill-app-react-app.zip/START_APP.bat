@echo off
title ClaimOptima - Temporal & P90 Severity Studio (React App)
echo ======================================================================
echo   ClaimOptima Temporal Severity & P90 Studio (React App)
echo ======================================================================
echo.

cd /d %~dp0

if not exist node_modules (
    echo [Setup] Installing dependencies (first-time only)...
    call npm.cmd install
    echo.
)

echo [Start] Launching React Development Server on http://localhost:5174...
call npm.cmd run dev
pause
