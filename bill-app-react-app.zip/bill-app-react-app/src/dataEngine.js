import * as XLSX from 'xlsx';

// Standard Milestone Windows
export const MILESTONE_WINDOWS = [
  { key: 'M30', name: 'Day 0 - 30 (Acute Phase)', minD: 0, maxD: 30, evalDay: 30 },
  { key: 'M60', name: 'Day 31 - 60 (Subacute / PT)', minD: 31, maxD: 60, evalDay: 60 },
  { key: 'M90', name: 'Day 61 - 90 (Specialist / Diag)', minD: 61, maxD: 90, evalDay: 90 },
  { key: 'M180', name: 'Day 91 - 180 (Surgical / Inpatient)', minD: 91, maxD: 180, evalDay: 180 },
  { key: 'M270', name: 'Day 181 - 270 (Extended Chronic Rehab)', minD: 181, maxD: 270, evalDay: 270 },
  { key: 'M293', name: 'Day 271 - 293+ (Long-Term Resolution)', minD: 271, maxD: 999, evalDay: 293 }
];

export const CATEGORY_COLORS = {
  'Inpatient Surgery': '#ef4444',
  'Hospital / ER': '#3b82f6',
  'Inpatient / ICU': '#dc2626',
  'Diagnostic Imaging': '#8b5cf6',
  'Physical Therapy': '#10b981',
  'Pain Management': '#f59e0b',
  'Treating Physician': '#06b6d4',
  'Chiropractic': '#ec4899',
  'General Medical Treatment': '#64748b'
};

const ALIASES = {
  job_id: ['job_id', 'job id', 'jobid', 'claim_id', 'claim number'],
  record_id: ['record_id', 'record id', 'recordid', 'bill_id'],
  tag_id: ['tag_id', 'tag id', 'tagid'],
  facility_name: ['facility_name', 'facility name', 'facility', 'hospital', 'clinic'],
  provider_name: ['provider_name', 'provider name', 'doctor', 'physician', 'payee'],
  provider_billing_state: ['provider_billing_state', 'provider billing state', 'state', 'billing_state'],
  provider_billing_zip_code: ['provider_billing_zip_code', 'provider billing zip code', 'billing_zip', 'zip_code', 'zip'],
  start_date: ['start_date', 'start date', 'from_date', 'statement_from'],
  end_date: ['end_date', 'end date', 'thru_date', 'statement_to'],
  bill_line_item_service_date: ['bill_line_item_service_date', 'service_date', 'service date', 'line_service_date', 'dos'],
  bill_line_item_build_amount: [
    'bill_line_item_build_amount', 'bill_line_item_billed_amount', 'item_billed_amount',
    'billed_amount', 'build_amount', 'billed amount', 'line_item_amount', 'amount'
  ],
  bill_line_item_category: [
    'bill_line_item_category', 'bill line item category', 'category', 'item_category',
    'treatment_type', 'record_type', 'service_category'
  ]
};

function parseDateRobust(val) {
  if (!val) return null;
  if (val instanceof Date && !isNaN(val)) return val;
  const s = String(val).trim();
  const parsed = new Date(s);
  if (!isNaN(parsed.getTime())) return parsed;
  const match = s.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
  if (match) {
    return new Date(parseInt(match[3]), parseInt(match[1]) - 1, parseInt(match[2]));
  }
  return null;
}

export function parseAndAnalyzeRawBills(rawRows) {
  if (!rawRows || !rawRows.length) return null;

  const firstRow = rawRows[0];
  const colKeys = Object.keys(firstRow);
  const mapping = {};

  for (const [targetKey, aliasList] of Object.entries(ALIASES)) {
    for (const key of colKeys) {
      const cleanKey = key.trim().toLowerCase().replace(/[\s-]/g, '_');
      if (aliasList.some(a => a.replace(/[\s-]/g, '_') === cleanKey || cleanKey.includes(a.replace(/[\s-]/g, '_')))) {
        mapping[targetKey] = key;
        break;
      }
    }
  }

  const normalized = [];
  for (let i = 0; i < rawRows.length; i++) {
    const r = rawRows[i];
    const jobId = String(r[mapping.job_id] || `JOB_${1001 + i}`).trim();
    const recId = String(r[mapping.record_id] || `REC_${i + 1}`).trim();
    const tagId = String(r[mapping.tag_id] || `TAG_${i + 1}`).trim();
    const facility = String(r[mapping.facility_name] || 'Medical Center').trim();
    const provider = String(r[mapping.provider_name] || 'Attending Physician').trim();
    const state = String(r[mapping.provider_billing_state] || 'CA').trim();
    const zip = String(r[mapping.provider_billing_zip_code] || '90210').trim();
    const cat = String(r[mapping.bill_line_item_category] || 'General Medical Treatment').trim();

    const sDate = parseDateRobust(r[mapping.start_date]);
    const eDate = parseDateRobust(r[mapping.end_date]) || sDate;
    const svcDate = parseDateRobust(r[mapping.bill_line_item_service_date]) || sDate;
    const effectiveDate = svcDate || sDate;

    if (!effectiveDate) continue;

    let amt = r[mapping.bill_line_item_build_amount];
    if (typeof amt === 'string') {
      amt = parseFloat(amt.replace(/[$,]/g, '').trim()) || 0.0;
    } else {
      amt = Number(amt) || 0.0;
    }

    normalized.push({
      job_id: jobId,
      record_id: recId,
      tag_id: tagId,
      facility_name: facility,
      provider_name: provider,
      provider_billing_state: state,
      provider_billing_zip_code: zip,
      start_date: sDate,
      end_date: eDate,
      bill_line_item_service_date: svcDate,
      effective_service_date: effectiveDate,
      bill_line_item_build_amount: amt,
      bill_line_item_category: cat
    });
  }

  if (!normalized.length) return null;

  // Baseline Day 0 per claim
  const claimEarliestDate = {};
  for (const row of normalized) {
    if (!claimEarliestDate[row.job_id] || row.effective_service_date < claimEarliestDate[row.job_id]) {
      claimEarliestDate[row.job_id] = row.effective_service_date;
    }
  }

  for (const row of normalized) {
    const base = claimEarliestDate[row.job_id];
    const diffMs = row.effective_service_date.getTime() - base.getTime();
    row.elapsed_days = Math.max(0, Math.floor(diffMs / (1000 * 60 * 60 * 24)));
    
    // Assign temporal phase bin
    const d = row.elapsed_days;
    if (d <= 30) row.temporal_bin = 'Days 0-30 (Acute)';
    else if (d <= 60) row.temporal_bin = 'Days 31-60 (Subacute)';
    else if (d <= 90) row.temporal_bin = 'Days 61-90 (Specialist)';
    else if (d <= 180) row.temporal_bin = 'Days 91-180 (Surgical)';
    else if (d <= 270) row.temporal_bin = 'Days 181-270 (Rehab)';
    else row.temporal_bin = 'Days 271+ (Resolution)';
  }

  normalized.sort((a, b) => {
    if (a.job_id !== b.job_id) return a.job_id.localeCompare(b.job_id);
    return a.elapsed_days - b.elapsed_days;
  });

  const claimTotals = {};
  const claimGroups = {};
  for (const row of normalized) {
    claimTotals[row.job_id] = (claimTotals[row.job_id] || 0) + row.bill_line_item_build_amount;
    if (!claimGroups[row.job_id]) claimGroups[row.job_id] = [];
    claimGroups[row.job_id].push(row);
  }

  for (const [jobId, rows] of Object.entries(claimGroups)) {
    let cum = 0;
    const tot = claimTotals[jobId] || 1;
    for (const r of rows) {
      cum += r.bill_line_item_build_amount;
      r.cumulative_spend = cum;
      r.cumulative_spend_pct = cum / tot;
    }
  }

  const allJobIds = Object.keys(claimTotals);
  const totalClaims = allJobIds.length;
  const totalMedicalSpend = Object.values(claimTotals).reduce((a, b) => a + b, 0);

  // Milestone Percentiles
  const milestoneStats = [];
  const claimSpendAtMilestone = {};

  for (const m of MILESTONE_WINDOWS) {
    claimSpendAtMilestone[m.evalDay] = {};
    const amounts = [];

    for (const jid of allJobIds) {
      const rows = claimGroups[jid] || [];
      const filtered = rows.filter(r => r.elapsed_days <= m.evalDay);
      const spend = filtered.reduce((sum, r) => sum + r.bill_line_item_build_amount, 0);
      claimSpendAtMilestone[m.evalDay][jid] = spend;
      amounts.push(spend);
    }

    amounts.sort((a, b) => a - b);
    const getP = (p) => {
      if (!amounts.length) return 0;
      const idx = (p / 100) * (amounts.length - 1);
      const low = Math.floor(idx);
      const high = Math.ceil(idx);
      if (low === high) return amounts[low];
      return amounts[low] + (amounts[high] - amounts[low]) * (idx - low);
    };

    const p25 = getP(25);
    const p50 = getP(50);
    const p75 = getP(75);
    const p90 = getP(90);
    const avg = amounts.reduce((a, b) => a + b, 0) / (amounts.length || 1);

    const prevM = milestoneStats[milestoneStats.length - 1];
    const prevP50 = prevM ? prevM.p50 : 0;
    const daysSpan = prevM ? Math.max(1, m.evalDay - prevM.evalDay) : m.evalDay;
    const velocity = Math.max(0, (p50 - prevP50) / daysSpan);

    milestoneStats.push({
      milestone_name: m.name,
      eval_day: m.evalDay,
      min_d: m.minD,
      max_d: m.maxD,
      p25,
      p50,
      p75,
      p90,
      average: avg,
      velocity_per_day: velocity
    });
  }

  const finalP90 = milestoneStats[milestoneStats.length - 1]?.p90 || 0;
  const finalP75 = milestoneStats[milestoneStats.length - 1]?.p75 || 0;
  const finalP25 = milestoneStats[milestoneStats.length - 1]?.p25 || 0;

  const claimSummaries = [];
  let p90OutlierCount = 0;

  for (const jid of allJobIds) {
    const rows = claimGroups[jid] || [];
    const totAmt = claimTotals[jid] || 0;
    const bCnt = rows.length;
    const firstDate = claimEarliestDate[jid];
    const maxDays = Math.max(...rows.map(r => r.elapsed_days), 0);

    const earlySpend = rows.filter(r => r.elapsed_days <= 30).reduce((s, r) => s + r.bill_line_item_build_amount, 0);
    const midSpend = rows.filter(r => r.elapsed_days > 30 && r.elapsed_days <= 90).reduce((s, r) => s + r.bill_line_item_build_amount, 0);
    const lateSpend = rows.filter(r => r.elapsed_days > 90).reduce((s, r) => s + r.bill_line_item_build_amount, 0);

    let maxJumpRow = rows[0];
    for (const r of rows) {
      if (r.bill_line_item_build_amount > maxJumpRow.bill_line_item_build_amount) {
        maxJumpRow = r;
      }
    }

    let p90Breached = false;
    let firstP90Window = 'Within Limits';
    for (const m of milestoneStats) {
      const cumAtM = claimSpendAtMilestone[m.eval_day][jid] || 0;
      if (cumAtM >= m.p90 && m.p90 > 0) {
        p90Breached = true;
        firstP90Window = `Day ${m.eval_day}`;
        break;
      }
    }

    if (p90Breached) p90OutlierCount++;

    let severityClass = 'Low Severity (Routine)';
    let isOutlier = 0;
    if (totAmt >= finalP90 && finalP90 > 0) {
      severityClass = 'P90 Outlier (Catastrophic)';
      isOutlier = 1;
    } else if (totAmt >= finalP75) {
      severityClass = 'High Severity (Escalating)';
    } else if (totAmt >= final_p25) {
      severityClass = 'Moderate Severity';
    }

    let progression = 'Continuous Gradual Therapy';
    if (earlySpend / (totAmt || 1) >= 0.70) {
      progression = 'Acute Front-Loaded (Immediate ER/Trauma)';
    } else if (lateSpend / (totAmt || 1) >= 0.50) {
      progression = 'Late-Surge Escalation (Surgical/Chronic)';
    } else if (midSpend / (totAmt || 1) >= 0.40) {
      progression = 'Mid-Phase Intervention (Day 31-90)';
    }

    // Early Warning Risk Score: evaluates early spend & daily velocity
    const dailyVelocity = totAmt / Math.max(1, maxDays);
    let earlyRiskScore = 15;
    if (earlySpend > 10000 || dailyVelocity > 400) earlyRiskScore = 92;
    else if (earlySpend > 3500 || dailyVelocity > 150) earlyRiskScore = 65;
    else if (maxDays > 90 && lateSpend > 5000) earlyRiskScore = 78;

    claimSummaries.push({
      job_id: jid,
      billing_state: rows[0]?.provider_billing_state || 'CA',
      billing_zip: rows[0]?.provider_billing_zip_code || '90017',
      first_treatment_date: firstDate ? firstDate.toLocaleDateString() : 'N/A',
      total_treatment_span_days: maxDays,
      total_bills_count: bCnt,
      total_billed_amount: totAmt,
      early_spend_0_30d: earlySpend,
      mid_spend_31_90d: midSpend,
      late_spend_91d_plus: lateSpend,
      spend_velocity_per_day: dailyVelocity,
      inflection_point_day: `Day ${maxJumpRow?.elapsed_days || 0}`,
      inflection_day_num: maxJumpRow?.elapsed_days || 0,
      inflection_category: maxJumpRow?.bill_line_item_category || 'N/A',
      inflection_facility: maxJumpRow?.facility_name || 'N/A',
      inflection_doctor: maxJumpRow?.provider_name || 'N/A',
      inflection_jump_amount: maxJumpRow?.bill_line_item_build_amount || 0,
      p90_status: p90Breached ? 'P90 BREACH' : 'Normal Range',
      is_p90_outlier: isOutlier,
      early_risk_score: earlyRiskScore,
      first_p90_breach_milestone: firstP90Window,
      severity_classification: severityClass,
      clinical_progression_pattern: progression,
      bill_rows: rows
    });
  }

  claimSummaries.sort((a, b) => b.total_billed_amount - a.total_billed_amount);

  // Category Shift
  const categoryPhaseTotals = {};
  const phaseTotals = { M30: 0, M60: 0, M90: 0, M180: 0, M270: 0, M293: 0 };

  for (const r of normalized) {
    const cat = r.bill_line_item_category;
    if (!categoryPhaseTotals[cat]) {
      categoryPhaseTotals[cat] = { category: cat, M30: 0, M60: 0, M90: 0, M180: 0, M270: 0, M293: 0, total: 0 };
    }

    const d = r.elapsed_days;
    let pKey = 'M293';
    if (d <= 30) pKey = 'M30';
    else if (d <= 60) pKey = 'M60';
    else if (d <= 90) pKey = 'M90';
    else if (d <= 180) pKey = 'M180';
    else if (d <= 270) pKey = 'M270';

    categoryPhaseTotals[cat][pKey] += r.bill_line_item_build_amount;
    categoryPhaseTotals[cat].total += r.bill_line_item_build_amount;
    phaseTotals[pKey] += r.bill_line_item_build_amount;
  }

  const categoryShiftList = Object.values(categoryPhaseTotals).sort((a, b) => b.total - a.total);

  // Trajectory Curves
  const trajectoryCurves = MILESTONE_WINDOWS.map((m) => {
    const point = {
      name: `Day ${m.evalDay}`,
      day: m.evalDay,
      P90: Math.round(milestoneStats.find(s => s.eval_day === m.evalDay)?.p90 || 0),
      P75: Math.round(milestoneStats.find(s => s.eval_day === m.evalDay)?.p75 || 0),
      P50: Math.round(milestoneStats.find(s => s.eval_day === m.evalDay)?.p50 || 0),
      P25: Math.round(milestoneStats.find(s => s.eval_day === m.evalDay)?.p25 || 0),
      Average: Math.round(milestoneStats.find(s => s.eval_day === m.evalDay)?.average || 0)
    };

    const top8 = claimSummaries.slice(0, 8);
    for (const c of top8) {
      point[c.job_id] = Math.round(claimSpendAtMilestone[m.evalDay][c.job_id] || 0);
    }
    return point;
  });

  return {
    rawBills: normalized,
    claimSummaries,
    milestoneStats,
    categoryShiftList,
    phaseTotals,
    trajectoryCurves,
    topClaimIds: claimSummaries.slice(0, 8).map(c => c.job_id),
    portfolioStats: {
      totalClaims,
      totalMedicalSpend,
      averageClaimSpend: totalMedicalSpend / (totalClaims || 1),
      maxTreatmentDays: Math.max(...claimSummaries.map(c => c.total_treatment_span_days), 0),
      p90OutlierCount,
      finalP90Threshold: finalP90,
      p90SpendShare: (claimSummaries.filter(c => c.total_billed_amount >= finalP90).reduce((s, c) => s + c.total_billed_amount, 0) / (totalMedicalSpend || 1)) * 100
    }
  };
}

// Download Power BI Data Bundle (.xlsx and .csv files)
export function exportPowerBiModel(analysisData) {
  if (!analysisData) return;

  const wb = XLSX.utils.book_new();

  // Dim_Claims
  const dimClaims = analysisData.claimSummaries.map(c => ({
    JobID: c.job_id,
    State: c.billing_state,
    Zip: c.billing_zip,
    FirstTreatmentDate: c.first_treatment_date,
    TotalDurationDays: c.total_treatment_span_days,
    TotalBillsCount: c.total_bills_count,
    TotalBilledAmount: c.total_billed_amount,
    EarlySpend0_30d: c.early_spend_0_30d,
    MidSpend31_90d: c.mid_spend_31_90d,
    LateSpend91dPlus: c.late_spend_91d_plus,
    DailySpendVelocity: c.spend_velocity_per_day,
    InflectionDay: c.inflection_day_num,
    InflectionCategory: c.inflection_category,
    InflectionFacility: c.inflection_facility,
    InflectionDoctor: c.inflection_doctor,
    InflectionSpikeAmount: c.inflection_jump_amount,
    IsP90Outlier: c.is_p90_outlier,
    P90Status: c.p90_status,
    SeverityClassification: c.severity_classification,
    ProgressionPattern: c.clinical_progression_pattern,
    EarlyWarningRiskScore: c.early_risk_score
  }));
  const wsClaims = XLSX.utils.json_to_sheet(dimClaims);
  XLSX.utils.book_append_sheet(wb, wsClaims, 'Dim_Claims');

  // Fact_Bills
  const factBills = analysisData.rawBills.map(b => ({
    JobID: b.job_id,
    RecordID: b.record_id,
    TagID: b.tag_id,
    FacilityName: b.facility_name,
    ProviderName: b.provider_name,
    State: b.provider_billing_state,
    Zip: b.provider_billing_zip_code,
    ServiceDate: b.effective_service_date ? b.effective_service_date.toISOString().split('T')[0] : '',
    Category: b.bill_line_item_category,
    BilledAmount: b.bill_line_item_build_amount,
    ElapsedDays: b.elapsed_days,
    CumulativeSpend: b.cumulative_spend,
    CumulativeSpendPct: b.cumulative_spend_pct,
    TemporalPhaseBin: b.temporal_bin
  }));
  const wsBills = XLSX.utils.json_to_sheet(factBills);
  XLSX.utils.book_append_sheet(wb, wsBills, 'Fact_Bills');

  // Dim_Milestones
  const wsMilestones = XLSX.utils.json_to_sheet(analysisData.milestoneStats);
  XLSX.utils.book_append_sheet(wb, wsMilestones, 'Dim_Milestones');

  // Matrix_Category_Shift
  const wsCategory = XLSX.utils.json_to_sheet(analysisData.categoryShiftList);
  XLSX.utils.book_append_sheet(wb, wsCategory, 'Matrix_Category_Shift');

  XLSX.writeFile(wb, 'ClaimOptima_PowerBI_Dataset.xlsx');
}

export function generate3000ClaimsDemo() {
  const categories = ['Hospital / ER', 'Inpatient Surgery', 'Physical Therapy', 'Treating Physician', 'Diagnostic Imaging', 'Pain Management', 'Inpatient / ICU'];
  const states = ['CA', 'TX', 'FL', 'NY', 'IL', 'OH', 'PA', 'AZ', 'GA', 'WA'];
  const facilities = ['Metro Trauma Center', 'Spine & Ortho Hospital', 'Active Rehab Clinic', 'Advanced Radiology Center', 'County General ER', 'Precision Surgery Pavillion'];
  const doctors = ['Dr. Sarah Jenkins', 'Dr. Marcus Vance', 'Dr. Elena Rostova', 'Dr. Kevin Patel', 'Dr. Susan Davis', 'Dr. Carlos Ruiz', 'Dr. Emily Taylor'];

  const rows = [];
  const baseDate = new Date(2024, 0, 15);
  let recCounter = 10000;
  let tagCounter = 50000;

  for (let i = 1; i <= 3000; i++) {
    const jobId = `CLM-${1000 + i}`;
    const state = states[i % states.length];
    const zip = `${90000 + (i % 800)}`;

    const rand = Math.random();
    let numBills = 3;
    let daysOffsets = [0, 10, 25];
    let amounts = [850, 450, 380];
    let cats = ['Treating Physician', 'Physical Therapy', 'Physical Therapy'];

    if (rand < 0.05) {
      numBills = 8;
      daysOffsets = [0, 0, 14, 45, 90, 150, 220, 290];
      amounts = [75000 + Math.random() * 40000, 15000, 6200, 4500, 3800, 3100, 2400, 1900];
      cats = ['Hospital / ER', 'Inpatient / ICU', 'Inpatient Surgery', 'Physical Therapy', 'Treating Physician', 'Physical Therapy', 'Pain Management', 'Treating Physician'];
    } else if (rand < 0.20) {
      numBills = 7;
      daysOffsets = [0, 12, 35, 58, 85, 185, 280];
      amounts = [1850, 650, 2200, 38500 + Math.random() * 15000, 4800, 6200, 3200];
      cats = ['Hospital / ER', 'Treating Physician', 'Diagnostic Imaging', 'Inpatient Surgery', 'Physical Therapy', 'Pain Management', 'Physical Therapy'];
    } else if (rand < 0.60) {
      numBills = 5;
      daysOffsets = [0, 14, 30, 60, 90];
      amounts = [1200, 450, 1450, 1600, 1100];
      cats = ['Hospital / ER', 'Treating Physician', 'Physical Therapy', 'Physical Therapy', 'Treating Physician'];
    }

    for (let b = 0; b < numBills; b++) {
      recCounter++;
      tagCounter++;
      const dOff = daysOffsets[b] || 0;
      const d = new Date(baseDate.getTime() + dOff * 24 * 60 * 60 * 1000);
      const dateStr = `${d.getMonth() + 1}/${d.getDate()}/${d.getFullYear()} 12:00:00 AM`;

      rows.push({
        job_id: jobId,
        record_id: `REC-${recCounter}`,
        tag_id: `TAG-${tagCounter}`,
        facility_name: facilities[(i + b) % facilities.length],
        provider_name: doctors[(i + b) % doctors.length],
        provider_billing_state: state,
        provider_billing_zip_code: zip,
        start_date: dateStr,
        end_date: dateStr,
        bill_line_item_service_date: dateStr,
        bill_line_item_build_amount: amounts[b],
        bill_line_item_category: cats[b]
      });
    }
  }

  return rows;
}
