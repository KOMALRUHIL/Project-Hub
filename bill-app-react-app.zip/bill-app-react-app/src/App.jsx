import React, { useState, useEffect, useMemo, useRef } from 'react';
import * as XLSX from 'xlsx';
import {
  TrendingUp, AlertTriangle, Activity, Calendar, DollarSign,
  Upload, Layers, BarChart3, Clock, CheckCircle2, ChevronRight,
  Search, Filter, Download, Sparkles, FileSpreadsheet, Eye, X,
  ArrowUpDown, ShieldAlert, Zap, Compass, Database, UserCheck
} from 'lucide-react';
import {
  ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip,
  Legend, CartesianGrid, BarChart, Bar, AreaChart, Area, ScatterChart,
  Scatter, ZAxis, Cell, ReferenceLine
} from 'recharts';
import { parseAndAnalyzeRawBills, generate3000ClaimsDemo, CATEGORY_COLORS, exportPowerBiModel } from './dataEngine';

const INITIAL_SAMPLE_BILLS = [
  {"job_id": "CLM-1001", "record_id": "REC-1001", "tag_id": "TAG-5001", "facility_name": "Metro Health ER", "provider_name": "Dr. Sarah Jenkins", "provider_billing_state": "CA", "provider_billing_zip_code": "90017", "start_date": "1/15/2024 12:00:00 AM", "end_date": "1/15/2024 12:00:00 AM", "bill_line_item_service_date": "1/15/2024 12:00:00 AM", "bill_line_item_build_amount": 4250, "bill_line_item_category": "Hospital / ER"},
  {"job_id": "CLM-1001", "record_id": "REC-1002", "tag_id": "TAG-5002", "facility_name": "Apex Diagnostics", "provider_name": "Dr. Robert Chen", "provider_billing_state": "CA", "provider_billing_zip_code": "90017", "start_date": "1/23/2024 12:00:00 AM", "end_date": "1/23/2024 12:00:00 AM", "bill_line_item_service_date": "1/23/2024 12:00:00 AM", "bill_line_item_build_amount": 1850, "bill_line_item_category": "Diagnostic Imaging"},
  {"job_id": "CLM-1001", "record_id": "REC-1003", "tag_id": "TAG-5003", "facility_name": "Ortho Spine Institute", "provider_name": "Dr. Marcus Vance", "provider_billing_state": "CA", "provider_billing_zip_code": "90017", "start_date": "2/6/2024 12:00:00 AM", "end_date": "2/6/2024 12:00:00 AM", "bill_line_item_service_date": "2/6/2024 12:00:00 AM", "bill_line_item_build_amount": 750, "bill_line_item_category": "Treating Physician"},
  {"job_id": "CLM-1001", "record_id": "REC-1004", "tag_id": "TAG-5004", "facility_name": "Regional Surgical Hospital", "provider_name": "Dr. Marcus Vance", "provider_billing_state": "CA", "provider_billing_zip_code": "90017", "start_date": "3/13/2024 12:00:00 AM", "end_date": "3/15/2024 12:00:00 AM", "bill_line_item_service_date": "3/13/2024 12:00:00 AM", "bill_line_item_build_amount": 38500, "bill_line_item_category": "Inpatient Surgery"},
  {"job_id": "CLM-1001", "record_id": "REC-1005", "tag_id": "TAG-5005", "facility_name": "Ortho Spine Institute", "provider_name": "Dr. Marcus Vance", "provider_billing_state": "CA", "provider_billing_zip_code": "90017", "start_date": "3/13/2024 12:00:00 AM", "end_date": "3/13/2024 12:00:00 AM", "bill_line_item_service_date": "3/13/2024 12:00:00 AM", "bill_line_item_build_amount": 8900, "bill_line_item_category": "Treating Physician"},
  {"job_id": "CLM-1001", "record_id": "REC-1006", "tag_id": "TAG-5006", "facility_name": "Peak Physical Therapy", "provider_name": "Active Rehab LLC", "provider_billing_state": "CA", "provider_billing_zip_code": "90017", "start_date": "4/9/2024 12:00:00 AM", "end_date": "4/9/2024 12:00:00 AM", "bill_line_item_service_date": "4/9/2024 12:00:00 AM", "bill_line_item_build_amount": 4800, "bill_line_item_category": "Physical Therapy"},
  {"job_id": "CLM-1001", "record_id": "REC-1007", "tag_id": "TAG-5007", "facility_name": "Precision Interventional", "provider_name": "Dr. Alan Brody", "provider_billing_state": "CA", "provider_billing_zip_code": "90017", "start_date": "7/18/2024 12:00:00 AM", "end_date": "7/18/2024 12:00:00 AM", "bill_line_item_service_date": "7/18/2024 12:00:00 AM", "bill_line_item_build_amount": 6200, "bill_line_item_category": "Pain Management"},
  {"job_id": "CLM-1001", "record_id": "REC-1008", "tag_id": "TAG-5008", "facility_name": "Peak Physical Therapy", "provider_name": "Active Rehab LLC", "provider_billing_state": "CA", "provider_billing_zip_code": "90017", "start_date": "11/3/2024 12:00:00 AM", "end_date": "11/3/2024 12:00:00 AM", "bill_line_item_service_date": "11/3/2024 12:00:00 AM", "bill_line_item_build_amount": 3600, "bill_line_item_category": "Physical Therapy"},

  {"job_id": "CLM-1005", "record_id": "REC-1019", "tag_id": "TAG-5019", "facility_name": "Chicago Trauma Center", "provider_name": "Dr. Elena Rostova", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "1/15/2024 12:00:00 AM", "end_date": "1/17/2024 12:00:00 AM", "bill_line_item_service_date": "1/15/2024 12:00:00 AM", "bill_line_item_build_amount": 84500, "bill_line_item_category": "Hospital / ER"},
  {"job_id": "CLM-1005", "record_id": "REC-1020", "tag_id": "TAG-5020", "facility_name": "Chicago Trauma Center", "provider_name": "Dr. Elena Rostova", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "1/15/2024 12:00:00 AM", "end_date": "1/17/2024 12:00:00 AM", "bill_line_item_service_date": "1/15/2024 12:00:00 AM", "bill_line_item_build_amount": 14200, "bill_line_item_category": "Inpatient Surgery"},
  {"job_id": "CLM-1005", "record_id": "REC-1021", "tag_id": "TAG-5021", "facility_name": "Neuro Recovery Institute", "provider_name": "Dr. Elena Rostova", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "1/30/2024 12:00:00 AM", "end_date": "2/1/2024 12:00:00 AM", "bill_line_item_service_date": "1/30/2024 12:00:00 AM", "bill_line_item_build_amount": 5800, "bill_line_item_category": "Inpatient / ICU"},
  {"job_id": "CLM-1005", "record_id": "REC-1022", "tag_id": "TAG-5022", "facility_name": "Dr. Kevin Patel Clinic", "provider_name": "Dr. Kevin Patel", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "2/24/2024 12:00:00 AM", "end_date": "2/24/2024 12:00:00 AM", "bill_line_item_service_date": "2/24/2024 12:00:00 AM", "bill_line_item_build_amount": 3400, "bill_line_item_category": "Treating Physician"},
  {"job_id": "CLM-1005", "record_id": "REC-1023", "tag_id": "TAG-5023", "facility_name": "Premier PT", "provider_name": "Premier Rehab Staff", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "4/19/2024 12:00:00 AM", "end_date": "4/19/2024 12:00:00 AM", "bill_line_item_service_date": "4/19/2024 12:00:00 AM", "bill_line_item_build_amount": 2800, "bill_line_item_category": "Physical Therapy"},
  {"job_id": "CLM-1005", "record_id": "REC-1024", "tag_id": "TAG-5024", "facility_name": "Dr. Kevin Patel Clinic", "provider_name": "Dr. Kevin Patel", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "6/23/2024 12:00:00 AM", "end_date": "6/23/2024 12:00:00 AM", "bill_line_item_service_date": "6/23/2024 12:00:00 AM", "bill_line_item_build_amount": 2400, "bill_line_item_category": "Treating Physician"},
  {"job_id": "CLM-1005", "record_id": "REC-1025", "tag_id": "TAG-5025", "facility_name": "Dr. Kevin Patel Clinic", "provider_name": "Dr. Kevin Patel", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "9/1/2024 12:00:00 AM", "end_date": "9/1/2024 12:00:00 AM", "bill_line_item_service_date": "9/1/2024 12:00:00 AM", "bill_line_item_build_amount": 2100, "bill_line_item_category": "Treating Physician"},
  {"job_id": "CLM-1005", "record_id": "REC-1026", "tag_id": "TAG-5026", "facility_name": "Midwest Occupational", "provider_name": "Dr. David Kim", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "10/31/2024 12:00:00 AM", "end_date": "10/31/2024 12:00:00 AM", "bill_line_item_service_date": "10/31/2024 12:00:00 AM", "bill_line_item_build_amount": 1900, "bill_line_item_category": "Treating Physician"},

  {"job_id": "CLM-1008", "record_id": "REC-1037", "tag_id": "TAG-5037", "facility_name": "Penn General Hospital", "provider_name": "Dr. Susan Davis", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "1/15/2024 12:00:00 AM", "end_date": "1/15/2024 12:00:00 AM", "bill_line_item_service_date": "1/15/2024 12:00:00 AM", "bill_line_item_build_amount": 3200, "bill_line_item_category": "Hospital / ER"},
  {"job_id": "CLM-1008", "record_id": "REC-1038", "tag_id": "TAG-5038", "facility_name": "Dr. Susan Davis Clinic", "provider_name": "Dr. Susan Davis", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "2/2/2024 12:00:00 AM", "end_date": "2/2/2024 12:00:00 AM", "bill_line_item_service_date": "2/2/2024 12:00:00 AM", "bill_line_item_build_amount": 1800, "bill_line_item_category": "Treating Physician"},
  {"job_id": "CLM-1008", "record_id": "REC-1039", "tag_id": "TAG-5039", "facility_name": "Penn Radiology", "provider_name": "Dr. Arthur Conan", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "3/1/2024 12:00:00 AM", "end_date": "3/1/2024 12:00:00 AM", "bill_line_item_service_date": "3/1/2024 12:00:00 AM", "bill_line_item_build_amount": 4500, "bill_line_item_category": "Diagnostic Imaging"},
  {"job_id": "CLM-1008", "record_id": "REC-1040", "tag_id": "TAG-5040", "facility_name": "Penn Spine Institute", "provider_name": "Dr. William Sterling", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "4/14/2024 12:00:00 AM", "end_date": "4/16/2024 12:00:00 AM", "bill_line_item_service_date": "4/14/2024 12:00:00 AM", "bill_line_item_build_amount": 62000, "bill_line_item_category": "Inpatient Surgery"},
  {"job_id": "CLM-1008", "record_id": "REC-1041", "tag_id": "TAG-5041", "facility_name": "Penn Rehab Hospital", "provider_name": "Dr. William Sterling", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "5/29/2024 12:00:00 AM", "end_date": "5/31/2024 12:00:00 AM", "bill_line_item_service_date": "5/29/2024 12:00:00 AM", "bill_line_item_build_amount": 12500, "bill_line_item_category": "Inpatient / ICU"},
  {"job_id": "CLM-1008", "record_id": "REC-1042", "tag_id": "TAG-5042", "facility_name": "Keystone Therapy", "provider_name": "Keystone PT Team", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "7/28/2024 12:00:00 AM", "end_date": "7/28/2024 12:00:00 AM", "bill_line_item_service_date": "7/28/2024 12:00:00 AM", "bill_line_item_build_amount": 8400, "bill_line_item_category": "Physical Therapy"},
  {"job_id": "CLM-1008", "record_id": "REC-1043", "tag_id": "TAG-5043", "facility_name": "Pain Solutions Clinic", "provider_name": "Dr. Rachel Green", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "9/26/2024 12:00:00 AM", "end_date": "9/26/2024 12:00:00 AM", "bill_line_item_service_date": "9/26/2024 12:00:00 AM", "bill_line_item_build_amount": 5200, "bill_line_item_category": "Pain Management"},
  {"job_id": "CLM-1008", "record_id": "REC-1044", "tag_id": "TAG-5044", "facility_name": "Dr. Susan Davis Clinic", "provider_name": "Dr. Susan Davis", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "10/31/2024 12:00:00 AM", "end_date": "10/31/2024 12:00:00 AM", "bill_line_item_service_date": "10/31/2024 12:00:00 AM", "bill_line_item_build_amount": 3100, "bill_line_item_category": "Treating Physician"}
];

export default function App() {
  const [data, setData] = useState(null);
  const [activeTab, setActiveTab] = useState('executive'); // 'executive', 'scatter_outliers', 'curves', 'shift', 'explorer'
  const [datasetLabel, setDatasetLabel] = useState('Default 10 Claims Sample (63 Bills)');
  const [selectedClaim, setSelectedClaim] = useState(null);
  const [pinnedJobId, setPinnedJobId] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [severityFilter, setSeverityFilter] = useState('ALL');
  const [visibleClaimLines, setVisibleClaimLines] = useState({});
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef(null);

  useEffect(() => {
    const res = parseAndAnalyzeRawBills(INITIAL_SAMPLE_BILLS);
    setData(res);
    if (res?.topClaimIds) {
      const initVis = { 'CLM-1001': true, 'CLM-1005': true, 'CLM-1008': true };
      setVisibleClaimLines(initVis);
      setPinnedJobId('CLM-1001');
    }
  }, []);

  const handleFileUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsProcessing(true);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsName = wb.SheetNames[0];
        const rawJson = XLSX.utils.sheet_to_json(wb.Sheets[wsName]);
        const res = parseAndAnalyzeRawBills(rawJson);
        if (res) {
          setData(res);
          setDatasetLabel(`${file.name} (${res.portfolioStats.totalClaims.toLocaleString()} Claims, ${res.rawBills.length.toLocaleString()} Bills)`);
          const initVis = {};
          res.topClaimIds.slice(0, 3).forEach(id => { initVis[id] = true; });
          setVisibleClaimLines(initVis);
          setPinnedJobId(res.claimSummaries[0]?.job_id || null);
          setCurrentPage(1);
        } else {
          alert('Could not find valid claim/bill records in uploaded file.');
        }
      } catch (err) {
        alert(`Error reading file: ${err.message}`);
      } finally {
        setIsProcessing(false);
      }
    };
    reader.readAsBinaryString(file);
  };

  const handleLoad3000 = () => {
    setIsProcessing(true);
    setTimeout(() => {
      const synthetic = generate3000ClaimsDemo();
      const res = parseAndAnalyzeRawBills(synthetic);
      setData(res);
      setDatasetLabel(`High-Scale Synthetic Dataset (3,000 Claims, ${res.rawBills.length.toLocaleString()} Bills)`);
      const initVis = {};
      res.topClaimIds.slice(0, 3).forEach(id => { initVis[id] = true; });
      setVisibleClaimLines(initVis);
      setPinnedJobId(res.claimSummaries[0]?.job_id || null);
      setCurrentPage(1);
      setIsProcessing(false);
    }, 50);
  };

  // Download Power BI Dataset Model
  const handleDownloadPowerBi = () => {
    if (!data) return;
    exportPowerBiModel(data);
  };

  const filteredClaims = useMemo(() => {
    if (!data?.claimSummaries) return [];
    return data.claimSummaries.filter(c => {
      const matchSearch = (
        c.job_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.inflection_category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.inflection_facility.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.billing_state.toLowerCase().includes(searchQuery.toLowerCase())
      );
      if (!matchSearch) return false;
      if (severityFilter === 'P90_ONLY') return c.p90_status.includes('BREACH');
      if (severityFilter === 'HIGH') return c.severity_classification.includes('High') || c.severity_classification.includes('P90');
      return true;
    });
  }, [data, searchQuery, severityFilter]);

  const paginatedClaims = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredClaims.slice(start, start + pageSize);
  }, [filteredClaims, currentPage, pageSize]);

  const totalPages = Math.ceil(filteredClaims.length / pageSize) || 1;

  const activePinnedClaim = useMemo(() => {
    if (!data?.claimSummaries || !pinnedJobId) return data?.claimSummaries?.[0] || null;
    return data.claimSummaries.find(c => c.job_id === pinnedJobId) || data.claimSummaries[0];
  }, [data, pinnedJobId]);

  if (!data) return <div className="min-h-screen bg-slate-950 flex items-center justify-center text-slate-400 font-sans">Loading Temporal Analytics...</div>;

  const { portfolioStats, milestoneStats, categoryShiftList, trajectoryCurves, claimSummaries } = data;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Top Header */}
      <header className="border-b border-slate-800/80 bg-slate-900/60 backdrop-blur-md sticky top-0 z-40 px-6 py-3.5">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight text-white m-0">ClaimOptima</h1>
                <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 font-medium">Executive Studio</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 font-medium flex items-center gap-1">
                  <Database className="w-3 h-3" /> Power BI Ready
                </span>
              </div>
              <p className="text-xs text-slate-400 m-0">Temporal Severity, P90 Inflection Discovery & Portfolio Health (3,000+ Claims)</p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center flex-wrap gap-2">
            <span className="text-xs text-slate-400 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700/60 flex items-center gap-2">
              <FileSpreadsheet className="w-3.5 h-3.5 text-blue-400" />
              {datasetLabel}
            </span>

            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept=".xlsx,.xls,.csv"
              className="hidden"
            />

            <button
              onClick={() => fileInputRef.current?.click()}
              className="cursor-pointer text-xs font-semibold px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 transition flex items-center gap-1.5"
            >
              <Upload className="w-3.5 h-3.5" />
              Upload Excel
            </button>

            <button
              onClick={handleDownloadPowerBi}
              className="cursor-pointer text-xs font-semibold px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-lg shadow-md transition flex items-center gap-1.5"
              title="Download Star-Schema Excel & CSVs formatted for Power BI"
            >
              <Download className="w-3.5 h-3.5" />
              Power BI Dataset
            </button>

            <button
              onClick={handleLoad3000}
              className="cursor-pointer text-xs font-semibold px-3 py-1.5 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white rounded-lg shadow-md transition flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              3,000 Claims Demo
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto w-full px-6 py-6 flex-1 flex flex-col gap-6">
        {/* Executive KPI Cards */}
        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-sm">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 m-0">Portfolio Scope</p>
                <h3 className="text-2xl font-black text-white mt-1 mb-0">{portfolioStats.totalClaims.toLocaleString()} Claims</h3>
                <p className="text-xs text-slate-400 mt-1 mb-0">{data.rawBills.length.toLocaleString()} bill lines • Max {portfolioStats.maxTreatmentDays} Days</p>
              </div>
              <div className="p-2.5 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400">
                <Layers className="w-5 h-5" />
              </div>
            </div>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-sm">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 m-0">Total Medical Exposure</p>
                <h3 className="text-2xl font-black text-emerald-400 mt-1 mb-0">${portfolioStats.totalMedicalSpend.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h3>
                <p className="text-xs text-slate-400 mt-1 mb-0">Avg ${Math.round(portfolioStats.averageClaimSpend).toLocaleString()} / claim</p>
              </div>
              <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
                <DollarSign className="w-5 h-5" />
              </div>
            </div>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-sm">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 m-0">Portfolio P90 Ceiling</p>
                <h3 className="text-2xl font-black text-rose-400 mt-1 mb-0">${Math.round(portfolioStats.finalP90Threshold).toLocaleString()}</h3>
                <p className="text-xs text-rose-400/80 mt-1 mb-0">Top 10% Catastrophic Threshold</p>
              </div>
              <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400">
                <AlertTriangle className="w-5 h-5" />
              </div>
            </div>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-sm">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 m-0">P90 Outlier Impact</p>
                <h3 className="text-2xl font-black text-amber-400 mt-1 mb-0">{portfolioStats.p90OutlierCount} Outliers</h3>
                <p className="text-xs text-amber-400/80 mt-1 mb-0">Accounts for {Math.round(portfolioStats.p90SpendShare)}% of total portfolio spend</p>
              </div>
              <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
                <ShieldAlert className="w-5 h-5" />
              </div>
            </div>
          </div>
        </section>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2 overflow-x-auto">
          {[
            { id: 'executive', label: '1. Executive Scatter & Outlier Map', icon: Activity },
            { id: 'curves', label: '2. Cumulative S-Curves & P90', icon: TrendingUp },
            { id: 'shift', label: '3. Clinical Category Shift', icon: BarChart3 },
            { id: 'explorer', label: '4. Claim Explorer & Drilldown', icon: Layers }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`cursor-pointer px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* TAB 1: EXECUTIVE SCATTER & OUTLIER MAP (ALL DATA POINTS + OUTLIER HIGHLIGHTS + JOB ID DRILLDOWN) */}
        {activeTab === 'executive' && (
          <div className="space-y-6">
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-white m-0">Portfolio Inflection & Outlier Scatter Map</h3>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20 font-semibold">
                      Outliers Glowing in Red
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1 mb-0">
                    Shows all claims across treatment elapsed days. Click any point or select a Job ID below to inspect its trajectory.
                  </p>
                </div>

                {/* Job ID Quick Selector */}
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400">Select Job ID:</span>
                  <select
                    value={pinnedJobId || ''}
                    onChange={(e) => setPinnedJobId(e.target.value)}
                    className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-cyan-400 font-bold focus:outline-none focus:border-cyan-400"
                  >
                    {claimSummaries.map(c => (
                      <option key={c.job_id} value={c.job_id}>
                        {c.job_id} (${Math.round(c.total_billed_amount).toLocaleString()} • {c.severity_classification})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Scatter Plot */}
              <div className="h-96 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <ScatterChart margin={{ top: 20, right: 30, bottom: 20, left: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis type="number" dataKey="inflection_day_num" name="Elapsed Day" unit="d" stroke="#64748b" tick={{ fontSize: 11 }} />
                    <YAxis type="number" dataKey="inflection_jump_amount" name="Spike Amount" unit="$" stroke="#64748b" tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} tick={{ fontSize: 11 }} />
                    <ZAxis type="number" dataKey="total_billed_amount" range={[70, 450]} name="Total Spend" />
                    <ReferenceLine y={portfolioStats.finalP90Threshold} stroke="#ef4444" strokeDasharray="4 4" label={{ value: 'P90 Ceiling', fill: '#ef4444', fontSize: 11, position: 'top' }} />
                    
                    <Tooltip
                      cursor={{ strokeDasharray: '3 3' }}
                      content={({ payload }) => {
                        if (!payload || !payload.length) return null;
                        const d = payload[0].payload;
                        return (
                          <div className="bg-slate-900 border border-slate-700 p-3.5 rounded-xl shadow-2xl text-xs space-y-1 z-50">
                            <p className="font-bold text-white text-sm m-0 flex items-center gap-2">
                              {d.job_id}
                              {d.is_p90_outlier ? (
                                <span className="px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-400 text-[10px] font-bold">P90 OUTLIER</span>
                              ) : (
                                <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px]">Standard</span>
                              )}
                            </p>
                            <p className="text-emerald-400 font-bold m-0">Cost Spike: ${d.inflection_jump_amount.toLocaleString()} at {d.inflection_point_day}</p>
                            <p className="text-slate-300 m-0">Category: {d.inflection_category}</p>
                            <p className="text-slate-400 m-0">Facility: {d.inflection_facility}</p>
                            <p className="text-slate-400 m-0">Total Exposure: ${d.total_billed_amount.toLocaleString()} ({d.total_treatment_span_days} days)</p>
                            <p className="text-cyan-400 font-semibold pt-1 m-0">👉 Click to drill down into this claim</p>
                          </div>
                        );
                      }}
                    />

                    <Scatter name="All Claims" data={claimSummaries.slice(0, 300)}>
                      {claimSummaries.slice(0, 300).map((entry, index) => {
                        const isPinned = entry.job_id === pinnedJobId;
                        const isOutlier = entry.is_p90_outlier === 1 || entry.p90_status.includes('BREACH');
                        
                        let fillColor = isOutlier ? '#ef4444' : (CATEGORY_COLORS[entry.inflection_category] || '#38bdf8');
                        let strokeColor = isOutlier ? '#fecaca' : '#0f172a';
                        let strokeWidth = isOutlier ? 2.5 : 1;

                        if (isPinned) {
                          fillColor = '#06b6d4';
                          strokeColor = '#ffffff';
                          strokeWidth = 3;
                        }

                        return (
                          <Cell
                            key={`cell-${index}`}
                            fill={fillColor}
                            stroke={strokeColor}
                            strokeWidth={strokeWidth}
                            className="cursor-pointer transition-all hover:scale-125"
                            onClick={() => {
                              setPinnedJobId(entry.job_id);
                              setSelectedClaim(entry);
                            }}
                          />
                        );
                      })}
                    </Scatter>
                  </ScatterChart>
                </ResponsiveContainer>
              </div>

              {/* Legend for Scatter */}
              <div className="flex items-center justify-between flex-wrap gap-4 pt-4 border-t border-slate-800 text-xs text-slate-400">
                <div className="flex items-center gap-4 flex-wrap">
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-full bg-rose-500 ring-2 ring-rose-400/50"></span>
                    <span className="font-semibold text-rose-400">P90 Catastrophic Outlier</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-full bg-cyan-400 ring-2 ring-white"></span>
                    <span className="font-semibold text-cyan-400">Currently Selected Claim</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-slate-500"></span>
                    <span>Standard Claims</span>
                  </div>
                </div>
                <div className="text-slate-500 italic">
                  Bubble size corresponds to total claim dollar exposure
                </div>
              </div>
            </div>

            {/* MANAGEMENT DRILLDOWN BANNER: Selected Claim Profile */}
            {activePinnedClaim && (
              <div className="bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-indigo-500/30 rounded-2xl p-6 shadow-xl relative overflow-hidden">
                <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
                  <div className="space-y-2">
                    <div className="flex items-center gap-3">
                      <span className="px-3 py-1 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 font-black text-sm">
                        {activePinnedClaim.job_id}
                      </span>
                      <h4 className="text-lg font-bold text-white m-0">Executive Claim Lifecycle Profile</h4>
                      {activePinnedClaim.p90_status.includes('BREACH') ? (
                        <span className="px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/40 font-bold text-xs">
                          P90 OUTLIER
                        </span>
                      ) : (
                        <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-bold text-xs">
                          WITHIN NORMAL LIMITS
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-300 m-0">
                      Treated in <strong className="text-white">{activePinnedClaim.billing_state} {activePinnedClaim.billing_zip}</strong> • First Treatment: <strong className="text-white">{activePinnedClaim.first_treatment_date}</strong> • Active Duration: <strong className="text-white">{activePinnedClaim.total_treatment_span_days} Days</strong> ({activePinnedClaim.total_bills_count} bills)
                    </p>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setSelectedClaim(activePinnedClaim)}
                      className="cursor-pointer text-xs font-bold px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl shadow-lg transition flex items-center gap-2"
                    >
                      <Eye className="w-4 h-4" />
                      View Bill-by-Bill Timeline
                    </button>
                  </div>
                </div>

                {/* Metrics Matrix for Selected Claim */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6 pt-6 border-t border-slate-800">
                  <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800">
                    <p className="text-slate-400 font-medium m-0 text-xs">Total Exposure</p>
                    <p className="text-xl font-extrabold text-emerald-400 mt-1 mb-0">${activePinnedClaim.total_billed_amount.toLocaleString()}</p>
                    <p className="text-[11px] text-slate-500 m-0">Daily Velocity: ${Math.round(activePinnedClaim.spend_velocity_per_day)}/day</p>
                  </div>

                  <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800">
                    <p className="text-slate-400 font-medium m-0 text-xs">Primary Inflection</p>
                    <p className="text-xl font-extrabold text-amber-400 mt-1 mb-0">{activePinnedClaim.inflection_point_day}</p>
                    <p className="text-[11px] text-slate-400 m-0">{activePinnedClaim.inflection_category} (${activePinnedClaim.inflection_jump_amount.toLocaleString()})</p>
                  </div>

                  <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800">
                    <p className="text-slate-400 font-medium m-0 text-xs">Early vs Late Severity</p>
                    <p className="text-sm font-bold text-white mt-1 mb-0">
                      Early: ${Math.round(activePinnedClaim.early_spend_0_30d).toLocaleString()} (0-30d)
                    </p>
                    <p className="text-[11px] text-amber-400 m-0">Late: ${Math.round(activePinnedClaim.late_spend_91d_plus).toLocaleString()} (91d+)</p>
                  </div>

                  <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800">
                    <p className="text-slate-400 font-medium m-0 text-xs">Clinical Progression</p>
                    <p className="text-xs font-bold text-indigo-300 mt-1 mb-0">{activePinnedClaim.clinical_progression_pattern}</p>
                    <p className="text-[11px] text-slate-400 m-0">{activePinnedClaim.inflection_facility}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: CUMULATIVE S-CURVES & P90 BENCHMARKS */}
        {activeTab === 'curves' && (
          <div className="space-y-6">
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
                <div>
                  <h3 className="text-base font-bold text-white m-0">Temporal Trajectory S-Curves (Day 0 to Day 293+)</h3>
                  <p className="text-xs text-slate-400 mt-1 mb-0">Compares cumulative spend trajectories against P90, P75, and Median benchmarks</p>
                </div>

                {/* Claim Line Toggles */}
                <div className="flex items-center flex-wrap gap-2">
                  <span className="text-xs text-slate-400 mr-1">Overlay Claims:</span>
                  {data.topClaimIds.slice(0, 6).map((jid, idx) => {
                    const colors = ['#38bdf8', '#fbbf24', '#f472b6', '#a78bfa', '#34d399', '#f97316'];
                    const isVis = !!visibleClaimLines[jid];
                    return (
                      <button
                        key={jid}
                        onClick={() => setVisibleClaimLines(prev => ({ ...prev, [jid]: !prev[jid] }))}
                        className={`cursor-pointer text-xs px-2.5 py-1 rounded-md border font-semibold transition flex items-center gap-1.5 ${
                          isVis
                            ? 'bg-slate-800 border-slate-600 text-white'
                            : 'bg-slate-950/60 border-slate-800 text-slate-500'
                        }`}
                      >
                        <span className="w-2 h-2 rounded-full" style={{ backgroundColor: colors[idx % colors.length] }}></span>
                        {jid}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Line Chart */}
              <div className="h-84 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={trajectoryCurves} margin={{ top: 10, right: 30, left: 10, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="name" stroke="#64748b" tick={{ fontSize: 11 }} />
                    <YAxis stroke="#64748b" tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} tick={{ fontSize: 11 }} />
                    <Tooltip
                      formatter={(val) => [`$${Number(val).toLocaleString()}`, 'Spend']}
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                    />
                    <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />

                    <Line type="monotone" dataKey="P90" name="P90 Benchmark (Top 10%)" stroke="#ef4444" strokeWidth={3.5} dot={{ r: 4 }} />
                    <Line type="monotone" dataKey="P75" name="P75 (Moderate-High)" stroke="#f59e0b" strokeWidth={2} strokeDasharray="4 4" dot={{ r: 3 }} />
                    <Line type="monotone" dataKey="P50" name="P50 Median (Standard Claim)" stroke="#10b981" strokeWidth={2.5} dot={{ r: 3 }} />
                    <Line type="monotone" dataKey="P25" name="P25 (Low Severity)" stroke="#64748b" strokeWidth={1.5} dot={{ r: 2 }} />

                    {Object.entries(visibleClaimLines).map(([jid, isVis], idx) => {
                      if (!isVis) return null;
                      const colors = ['#38bdf8', '#fbbf24', '#f472b6', '#a78bfa', '#34d399', '#f97316'];
                      return (
                        <Line
                          key={jid}
                          type="monotone"
                          dataKey={jid}
                          name={`Claim ${jid}`}
                          stroke={colors[idx % colors.length]}
                          strokeWidth={2.5}
                          dot={{ r: 4 }}
                        />
                      );
                    })}
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Milestones & Velocity Table */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6">
              <h3 className="text-sm font-bold text-white mb-3">Portfolio Milestones & Velocity Table</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
                    <tr>
                      <th className="p-3">Milestone Care Phase</th>
                      <th className="p-3 text-center">Eval Day</th>
                      <th className="p-3 text-right">P25 (Low)</th>
                      <th className="p-3 text-right">P50 (Median)</th>
                      <th className="p-3 text-right">P75 (Moderate)</th>
                      <th className="p-3 text-right text-rose-400">P90 (Catastrophic)</th>
                      <th className="p-3 text-right">Average Spend</th>
                      <th className="p-3 text-right">Spend Velocity ($/Day)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {milestoneStats.map((m) => (
                      <tr key={m.eval_day} className="hover:bg-slate-800/40">
                        <td className="p-3 font-semibold text-white">{m.milestone_name}</td>
                        <td className="p-3 text-center font-mono">Day {m.eval_day}</td>
                        <td className="p-3 text-right font-mono">${Math.round(m.p25).toLocaleString()}</td>
                        <td className="p-3 text-right font-mono text-emerald-400 font-bold">${Math.round(m.p50).toLocaleString()}</td>
                        <td className="p-3 text-right font-mono">${Math.round(m.p75).toLocaleString()}</td>
                        <td className="p-3 text-right font-mono text-rose-400 font-extrabold">${Math.round(m.p90).toLocaleString()}</td>
                        <td className="p-3 text-right font-mono">${Math.round(m.average).toLocaleString()}</td>
                        <td className="p-3 text-right font-mono font-semibold">${Math.round(m.velocity_per_day)}/day</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: CLINICAL CATEGORY SHIFT OVER TIME */}
        {activeTab === 'shift' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6">
                <h3 className="text-base font-bold text-white m-0">Category Spend Across Temporal Windows</h3>
                <p className="text-xs text-slate-400 mt-1 mb-4">Migration from Acute ER in Days 0-30 to Surgeries and Chronic PT</p>
                <div className="h-80 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={[
                        { phase: '0-30d (Acute)', ...categoryShiftList.reduce((acc, c) => ({ ...acc, [c.category]: c.M30 }), {}) },
                        { phase: '31-60d (PT)', ...categoryShiftList.reduce((acc, c) => ({ ...acc, [c.category]: c.M60 }), {}) },
                        { phase: '61-90d (Diag)', ...categoryShiftList.reduce((acc, c) => ({ ...acc, [c.category]: c.M90 }), {}) },
                        { phase: '91-180d (Surg)', ...categoryShiftList.reduce((acc, c) => ({ ...acc, [c.category]: c.M180 }), {}) },
                        { phase: '181-270d (Rehab)', ...categoryShiftList.reduce((acc, c) => ({ ...acc, [c.category]: c.M270 }), {}) },
                        { phase: '271d+ (Res)', ...categoryShiftList.reduce((acc, c) => ({ ...acc, [c.category]: c.M293 }), {}) }
                      ]}
                      margin={{ top: 10, right: 20, left: 10, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                      <XAxis dataKey="phase" stroke="#64748b" tick={{ fontSize: 11 }} />
                      <YAxis stroke="#64748b" tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} tick={{ fontSize: 11 }} />
                      <Tooltip
                        formatter={(val, name) => [`$${Number(val).toLocaleString()}`, name]}
                        contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                      />
                      {categoryShiftList.slice(0, 6).map((c) => (
                        <Bar key={c.category} dataKey={c.category} stackId="a" fill={CATEGORY_COLORS[c.category] || '#64748b'} />
                      ))}
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6">
                <h3 className="text-base font-bold text-white m-0">Category Transition Volume Area</h3>
                <p className="text-xs text-slate-400 mt-1 mb-4">Volume evolution of clinical interventions over elapsed days</p>
                <div className="h-80 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart
                      data={[
                        { phase: '0-30d', ...categoryShiftList.reduce((acc, c) => ({ ...acc, [c.category]: c.M30 }), {}) },
                        { phase: '31-60d', ...categoryShiftList.reduce((acc, c) => ({ ...acc, [c.category]: c.M60 }), {}) },
                        { phase: '61-90d', ...categoryShiftList.reduce((acc, c) => ({ ...acc, [c.category]: c.M90 }), {}) },
                        { phase: '91-180d', ...categoryShiftList.reduce((acc, c) => ({ ...acc, [c.category]: c.M180 }), {}) },
                        { phase: '181-270d', ...categoryShiftList.reduce((acc, c) => ({ ...acc, [c.category]: c.M270 }), {}) },
                        { phase: '271d+', ...categoryShiftList.reduce((acc, c) => ({ ...acc, [c.category]: c.M293 }), {}) }
                      ]}
                      margin={{ top: 10, right: 20, left: 10, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                      <XAxis dataKey="phase" stroke="#64748b" tick={{ fontSize: 11 }} />
                      <YAxis stroke="#64748b" tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} tick={{ fontSize: 11 }} />
                      <Tooltip
                        formatter={(val, name) => [`$${Number(val).toLocaleString()}`, name]}
                        contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                      />
                      {categoryShiftList.slice(0, 5).map((c) => (
                        <Area
                          key={c.category}
                          type="monotone"
                          dataKey={c.category}
                          stackId="1"
                          stroke={CATEGORY_COLORS[c.category] || '#64748b'}
                          fill={CATEGORY_COLORS[c.category] || '#64748b'}
                          fillOpacity={0.6}
                        />
                      ))}
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6">
              <h3 className="text-sm font-bold text-white mb-3">Clinical Category Migration Matrix</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
                    <tr>
                      <th className="p-3">Category</th>
                      <th className="p-3 text-right">Days 0-30</th>
                      <th className="p-3 text-right">Days 31-60</th>
                      <th className="p-3 text-right">Days 61-90</th>
                      <th className="p-3 text-right">Days 91-180</th>
                      <th className="p-3 text-right">Days 181-270</th>
                      <th className="p-3 text-right">Days 271+</th>
                      <th className="p-3 text-right font-bold text-white">Total Spend</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {categoryShiftList.map((c) => (
                      <tr key={c.category} className="hover:bg-slate-800/40">
                        <td className="p-3 font-semibold text-white flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: CATEGORY_COLORS[c.category] || '#64748b' }}></span>
                          {c.category}
                        </td>
                        <td className="p-3 text-right font-mono">${Math.round(c.M30).toLocaleString()}</td>
                        <td className="p-3 text-right font-mono">${Math.round(c.M60).toLocaleString()}</td>
                        <td className="p-3 text-right font-mono">${Math.round(c.M90).toLocaleString()}</td>
                        <td className="p-3 text-right font-mono">${Math.round(c.M180).toLocaleString()}</td>
                        <td className="p-3 text-right font-mono">${Math.round(c.M270).toLocaleString()}</td>
                        <td className="p-3 text-right font-mono">${Math.round(c.M293).toLocaleString()}</td>
                        <td className="p-3 text-right font-mono font-extrabold text-emerald-400">${Math.round(c.total).toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: CLAIM EXPLORER (3,000+ Records Supported) */}
        {activeTab === 'explorer' && (
          <div className="space-y-4">
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
              <div className="flex items-center gap-3 flex-1">
                <div className="relative flex-1 max-w-md">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    placeholder="Search by Claim ID, Category, Facility, State..."
                    value={searchQuery}
                    onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <select
                  value={severityFilter}
                  onChange={(e) => { setSeverityFilter(e.target.value); setCurrentPage(1); }}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-indigo-500"
                >
                  <option value="ALL">All Severity Levels</option>
                  <option value="P90_ONLY">P90 Outliers Only (Top 10%)</option>
                  <option value="HIGH">High Severity & P90</option>
                </select>
              </div>

              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span>Showing {filteredClaims.length.toLocaleString()} matching claims</span>
                <select
                  value={pageSize}
                  onChange={(e) => { setPageSize(Number(e.target.value)); setCurrentPage(1); }}
                  className="bg-slate-950 border border-slate-800 rounded-lg px-2 py-1 text-xs text-slate-300"
                >
                  <option value={10}>10 / page</option>
                  <option value={15}>15 / page</option>
                  <option value={25}>25 / page</option>
                  <option value={50}>50 / page</option>
                  <option value={100}>100 / page</option>
                </select>
              </div>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-800">
                    <tr>
                      <th className="p-3.5">Claim ID</th>
                      <th className="p-3.5">State / Zip</th>
                      <th className="p-3.5 text-center">Duration</th>
                      <th className="p-3.5 text-right">Early (0-30d)</th>
                      <th className="p-3.5 text-right">Mid (31-90d)</th>
                      <th className="p-3.5 text-right">Late (91d+)</th>
                      <th className="p-3.5 text-right font-bold text-white">Total Exposure</th>
                      <th className="p-3.5">Inflection Point</th>
                      <th className="p-3.5">P90 Status</th>
                      <th className="p-3.5 text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {paginatedClaims.map((c) => (
                      <tr key={c.job_id} className="hover:bg-slate-800/40 transition">
                        <td className="p-3.5 font-bold text-white flex items-center gap-1.5">
                          {c.job_id}
                        </td>
                        <td className="p-3.5 text-slate-400">{c.billing_state} • {c.billing_zip}</td>
                        <td className="p-3.5 text-center font-mono">{c.total_treatment_span_days}d ({c.total_bills_count} bills)</td>
                        <td className="p-3.5 text-right font-mono">${Math.round(c.early_spend_0_30d).toLocaleString()}</td>
                        <td className="p-3.5 text-right font-mono">${Math.round(c.mid_spend_31_90d).toLocaleString()}</td>
                        <td className="p-3.5 text-right font-mono">${Math.round(c.late_spend_91d_plus).toLocaleString()}</td>
                        <td className="p-3.5 text-right font-mono font-extrabold text-emerald-400">${Math.round(c.total_billed_amount).toLocaleString()}</td>
                        <td className="p-3.5">
                          <span className="font-semibold text-amber-400">{c.inflection_point_day}:</span> {c.inflection_category}
                        </td>
                        <td className="p-3.5">
                          {c.p90_status.includes('BREACH') ? (
                            <span className="px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20 font-bold text-[10px]">
                              P90 OUTLIER
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-medium text-[10px]">
                              NORMAL
                            </span>
                          )}
                        </td>
                        <td className="p-3.5 text-center">
                          <button
                            onClick={() => {
                              setPinnedJobId(c.job_id);
                              setSelectedClaim(c);
                            }}
                            className="cursor-pointer text-xs px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-md font-semibold transition flex items-center gap-1 mx-auto"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            View
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="p-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
                <div>Page {currentPage} of {totalPages}</div>
                <div className="flex items-center gap-2">
                  <button
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                    className="cursor-pointer px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-white font-semibold"
                  >
                    Previous
                  </button>
                  <button
                    disabled={currentPage >= totalPages}
                    onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                    className="cursor-pointer px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-white font-semibold"
                  >
                    Next
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* CLAIM DETAIL MODAL / DRAWER */}
      {selectedClaim && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 font-bold">
                  {selectedClaim.job_id.slice(-4)}
                </div>
                <div>
                  <h3 className="text-base font-bold text-white m-0 flex items-center gap-2">
                    {selectedClaim.job_id}
                    <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-normal">
                      {selectedClaim.severity_classification}
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400 m-0">Location: {selectedClaim.billing_state} {selectedClaim.billing_zip} • First Treatment: {selectedClaim.first_treatment_date}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedClaim(null)}
                className="cursor-pointer p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs">
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800/80">
                  <p className="text-slate-400 font-semibold m-0">Total Claim Exposure</p>
                  <p className="text-lg font-extrabold text-emerald-400 mt-1 mb-0">${selectedClaim.total_billed_amount.toLocaleString()}</p>
                </div>
                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800/80">
                  <p className="text-slate-400 font-semibold m-0">Inflection Point</p>
                  <p className="text-lg font-extrabold text-amber-400 mt-1 mb-0">{selectedClaim.inflection_point_day}</p>
                  <p className="text-[11px] text-slate-400 m-0">{selectedClaim.inflection_category} (${selectedClaim.inflection_jump_amount.toLocaleString()})</p>
                </div>
                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800/80">
                  <p className="text-slate-400 font-semibold m-0">Progression Pattern</p>
                  <p className="text-sm font-bold text-white mt-1 mb-0">{selectedClaim.clinical_progression_pattern}</p>
                </div>
              </div>

              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">Chronological Bill Timeline ({selectedClaim.bill_rows.length} records)</h4>
                <div className="space-y-2">
                  {selectedClaim.bill_rows.map((b, bIdx) => (
                    <div key={bIdx} className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 flex items-center justify-between gap-3 hover:border-slate-700 transition">
                      <div className="flex items-center gap-3">
                        <div className="w-12 text-center py-1 bg-slate-900 rounded-lg border border-slate-800 font-mono text-xs font-bold text-indigo-400">
                          Day {b.elapsed_days}
                        </div>
                        <div>
                          <p className="font-bold text-white m-0">{b.bill_line_item_category}</p>
                          <p className="text-slate-400 text-[11px] m-0">{b.facility_name} • {b.provider_name}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-mono font-bold text-white text-sm m-0">${b.bill_line_item_build_amount.toLocaleString()}</p>
                        <p className="text-slate-400 text-[11px] m-0">Cum: ${b.cumulative_spend?.toLocaleString()} ({Math.round((b.cumulative_spend_pct || 0) * 100)}%)</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
