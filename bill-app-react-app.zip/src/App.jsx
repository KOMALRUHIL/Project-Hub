import React, { useState, useEffect, useMemo, useRef } from 'react';
import * as XLSX from 'xlsx';
import {
  TrendingUp, AlertTriangle, Activity, DollarSign,
  Upload, Layers, BarChart3, Download, Sparkles, FileSpreadsheet, X,
  ShieldAlert, Database, Search, Crosshair, Zap, ArrowUpRight, Flame,
  SlidersHorizontal, Sparkle, BarChart2
} from 'lucide-react';
import {
  ResponsiveContainer, LineChart, Line, AreaChart, Area, XAxis, YAxis, Tooltip,
  Legend, CartesianGrid, BarChart, Bar, ScatterChart,
  Scatter, ZAxis, Cell, ReferenceLine
} from 'recharts';
import { parseAndAnalyzeRawBills, generate3000ClaimsDemo, CATEGORY_COLORS, exportPowerBiModel } from './dataEngine';

const CLAIM_LINE_COLORS = [
  '#06b6d4', // Cyan
  '#ec4899', // Pink / Fuchsia
  '#f59e0b', // Amber
  '#10b981', // Emerald
  '#a855f7', // Purple
  '#38bdf8', // Sky Blue
  '#f97316', // Orange
  '#14b8a6', // Teal
  '#e11d48'  // Rose
];

// Sample dataset with CLM-1008 having 18 distinct bill records to demonstrate the 18-dot timeline and dual inflections
const INITIAL_SAMPLE_BILLS = [
  // CLM-1008: 18 Bill Records spanning 265 days with surgical P90 inflection on Day 89 (Primary) and ICU stay on Day 92 (Secondary)
  {"job_id": "CLM-1008", "record_id": "REC-1031", "tag_id": "TAG-5031", "facility_name": "Penn General Hospital", "provider_name": "Dr. Susan Davis", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "1/15/2024 12:00:00 AM", "end_date": "1/15/2024 12:00:00 AM", "bill_line_item_service_date": "1/15/2024 12:00:00 AM", "bill_line_item_build_amount": 3200, "bill_line_item_category": "Hospital / ER"},
  {"job_id": "CLM-1008", "record_id": "REC-1032", "tag_id": "TAG-5032", "facility_name": "Dr. Susan Davis Clinic", "provider_name": "Dr. Susan Davis", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "1/23/2024 12:00:00 AM", "end_date": "1/23/2024 12:00:00 AM", "bill_line_item_service_date": "1/23/2024 12:00:00 AM", "bill_line_item_build_amount": 1200, "bill_line_item_category": "Treating Physician"},
  {"job_id": "CLM-1008", "record_id": "REC-1033", "tag_id": "TAG-5033", "facility_name": "Penn Radiology", "provider_name": "Dr. Arthur Conan", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "1/29/2024 12:00:00 AM", "end_date": "1/29/2024 12:00:00 AM", "bill_line_item_service_date": "1/29/2024 12:00:00 AM", "bill_line_item_build_amount": 4500, "bill_line_item_category": "Diagnostic Imaging"},
  {"job_id": "CLM-1008", "record_id": "REC-1034", "tag_id": "TAG-5034", "facility_name": "Penn Spine Institute", "provider_name": "Dr. William Sterling", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "2/6/2024 12:00:00 AM", "end_date": "2/6/2024 12:00:00 AM", "bill_line_item_service_date": "2/6/2024 12:00:00 AM", "bill_line_item_build_amount": 1800, "bill_line_item_category": "Treating Physician"},
  {"job_id": "CLM-1008", "record_id": "REC-1035", "tag_id": "TAG-5035", "facility_name": "Keystone Therapy", "provider_name": "Keystone PT Team", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "2/19/2024 12:00:00 AM", "end_date": "2/19/2024 12:00:00 AM", "bill_line_item_service_date": "2/19/2024 12:00:00 AM", "bill_line_item_build_amount": 450, "bill_line_item_category": "Physical Therapy"},
  {"job_id": "CLM-1008", "record_id": "REC-1036", "tag_id": "TAG-5036", "facility_name": "Keystone Therapy", "provider_name": "Keystone PT Team", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "2/26/2024 12:00:00 AM", "end_date": "2/26/2024 12:00:00 AM", "bill_line_item_service_date": "2/26/2024 12:00:00 AM", "bill_line_item_build_amount": 450, "bill_line_item_category": "Physical Therapy"},
  {"job_id": "CLM-1008", "record_id": "REC-1037", "tag_id": "TAG-5037", "facility_name": "Keystone Therapy", "provider_name": "Keystone PT Team", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "3/5/2024 12:00:00 AM", "end_date": "3/5/2024 12:00:00 AM", "bill_line_item_service_date": "3/5/2024 12:00:00 AM", "bill_line_item_build_amount": 450, "bill_line_item_category": "Physical Therapy"},
  {"job_id": "CLM-1008", "record_id": "REC-1038", "tag_id": "TAG-5038", "facility_name": "Keystone Therapy", "provider_name": "Keystone PT Team", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "3/12/2024 12:00:00 AM", "end_date": "3/12/2024 12:00:00 AM", "bill_line_item_service_date": "3/12/2024 12:00:00 AM", "bill_line_item_build_amount": 450, "bill_line_item_category": "Physical Therapy"},
  {"job_id": "CLM-1008", "record_id": "REC-1039", "tag_id": "TAG-5039", "facility_name": "Pain Solutions Clinic", "provider_name": "Dr. Rachel Green", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "3/26/2024 12:00:00 AM", "end_date": "3/26/2024 12:00:00 AM", "bill_line_item_service_date": "3/26/2024 12:00:00 AM", "bill_line_item_build_amount": 2200, "bill_line_item_category": "Pain Management"},
  {"job_id": "CLM-1008", "record_id": "REC-1040", "tag_id": "TAG-5040", "facility_name": "Penn Spine Institute", "provider_name": "Dr. William Sterling", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "4/14/2024 12:00:00 AM", "end_date": "4/16/2024 12:00:00 AM", "bill_line_item_service_date": "4/14/2024 12:00:00 AM", "bill_line_item_build_amount": 62000, "bill_line_item_category": "Inpatient Surgery"},
  {"job_id": "CLM-1008", "record_id": "REC-1041", "tag_id": "TAG-5041", "facility_name": "Penn Rehab Hospital", "provider_name": "Dr. William Sterling", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "4/17/2024 12:00:00 AM", "end_date": "4/19/2024 12:00:00 AM", "bill_line_item_service_date": "4/17/2024 12:00:00 AM", "bill_line_item_build_amount": 12500, "bill_line_item_category": "Inpatient / ICU"},
  {"job_id": "CLM-1008", "record_id": "REC-1042", "tag_id": "TAG-5042", "facility_name": "Dr. Susan Davis Clinic", "provider_name": "Dr. Susan Davis", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "5/5/2024 12:00:00 AM", "end_date": "5/5/2024 12:00:00 AM", "bill_line_item_service_date": "5/5/2024 12:00:00 AM", "bill_line_item_build_amount": 1600, "bill_line_item_category": "Treating Physician"},
  {"job_id": "CLM-1008", "record_id": "REC-1043", "tag_id": "TAG-5043", "facility_name": "Keystone Therapy", "provider_name": "Keystone PT Team", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "5/20/2024 12:00:00 AM", "end_date": "5/20/2024 12:00:00 AM", "bill_line_item_service_date": "5/20/2024 12:00:00 AM", "bill_line_item_build_amount": 650, "bill_line_item_category": "Physical Therapy"},
  {"job_id": "CLM-1008", "record_id": "REC-1044", "tag_id": "TAG-5044", "facility_name": "Keystone Therapy", "provider_name": "Keystone PT Team", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "6/4/2024 12:00:00 AM", "end_date": "6/4/2024 12:00:00 AM", "bill_line_item_service_date": "6/4/2024 12:00:00 AM", "bill_line_item_build_amount": 650, "bill_line_item_category": "Physical Therapy"},
  {"job_id": "CLM-1008", "record_id": "REC-1045", "tag_id": "TAG-5045", "facility_name": "Keystone Therapy", "provider_name": "Keystone PT Team", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "6/24/2024 12:00:00 AM", "end_date": "6/24/2024 12:00:00 AM", "bill_line_item_service_date": "6/24/2024 12:00:00 AM", "bill_line_item_build_amount": 650, "bill_line_item_category": "Physical Therapy"},
  {"job_id": "CLM-1008", "record_id": "REC-1046", "tag_id": "TAG-5046", "facility_name": "Pain Solutions Clinic", "provider_name": "Dr. Rachel Green", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "7/29/2024 12:00:00 AM", "end_date": "7/29/2024 12:00:00 AM", "bill_line_item_service_date": "7/29/2024 12:00:00 AM", "bill_line_item_build_amount": 5200, "bill_line_item_category": "Pain Management"},
  {"job_id": "CLM-1008", "record_id": "REC-1047", "tag_id": "TAG-5047", "facility_name": "Penn Occupational Rehab", "provider_name": "Dr. Susan Davis", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "9/2/2024 12:00:00 AM", "end_date": "9/2/2024 12:00:00 AM", "bill_line_item_service_date": "9/2/2024 12:00:00 AM", "bill_line_item_build_amount": 2800, "bill_line_item_category": "Physical Therapy"},
  {"job_id": "CLM-1008", "record_id": "REC-1048", "tag_id": "TAG-5048", "facility_name": "Dr. Susan Davis Clinic", "provider_name": "Dr. Susan Davis", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "10/7/2024 12:00:00 AM", "end_date": "10/7/2024 12:00:00 AM", "bill_line_item_service_date": "10/7/2024 12:00:00 AM", "bill_line_item_build_amount": 1900, "bill_line_item_category": "Treating Physician"},

  // CLM-1005: 8 Bills (Acute Phase ER Outlier Spike)
  {"job_id": "CLM-1005", "record_id": "REC-1019", "tag_id": "TAG-5019", "facility_name": "Chicago Trauma Center", "provider_name": "Dr. Elena Rostova", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "1/15/2024 12:00:00 AM", "end_date": "1/17/2024 12:00:00 AM", "bill_line_item_service_date": "1/15/2024 12:00:00 AM", "bill_line_item_build_amount": 84500, "bill_line_item_category": "Hospital / ER"},
  {"job_id": "CLM-1005", "record_id": "REC-1020", "tag_id": "TAG-5020", "facility_name": "Chicago Trauma Center", "provider_name": "Dr. Elena Rostova", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "1/15/2024 12:00:00 AM", "end_date": "1/17/2024 12:00:00 AM", "bill_line_item_service_date": "1/15/2024 12:00:00 AM", "bill_line_item_build_amount": 14200, "bill_line_item_category": "Inpatient Surgery"},
  {"job_id": "CLM-1005", "record_id": "REC-1021", "tag_id": "TAG-5021", "facility_name": "Neuro Recovery Institute", "provider_name": "Dr. Elena Rostova", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "1/30/2024 12:00:00 AM", "end_date": "2/1/2024 12:00:00 AM", "bill_line_item_service_date": "1/30/2024 12:00:00 AM", "bill_line_item_build_amount": 5800, "bill_line_item_category": "Inpatient / ICU"},
  {"job_id": "CLM-1005", "record_id": "REC-1022", "tag_id": "TAG-5022", "facility_name": "Dr. Kevin Patel Clinic", "provider_name": "Dr. Kevin Patel", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "2/24/2024 12:00:00 AM", "end_date": "2/24/2024 12:00:00 AM", "bill_line_item_service_date": "2/24/2024 12:00:00 AM", "bill_line_item_build_amount": 3400, "bill_line_item_category": "Treating Physician"},
  {"job_id": "CLM-1005", "record_id": "REC-1023", "tag_id": "TAG-5023", "facility_name": "Premier PT", "provider_name": "Premier Rehab Staff", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "4/19/2024 12:00:00 AM", "end_date": "4/19/2024 12:00:00 AM", "bill_line_item_service_date": "4/19/2024 12:00:00 AM", "bill_line_item_build_amount": 2800, "bill_line_item_category": "Physical Therapy"},
  {"job_id": "CLM-1005", "record_id": "REC-1024", "tag_id": "TAG-5024", "facility_name": "Dr. Kevin Patel Clinic", "provider_name": "Dr. Kevin Patel", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "6/23/2024 12:00:00 AM", "end_date": "6/23/2024 12:00:00 AM", "bill_line_item_service_date": "6/23/2024 12:00:00 AM", "bill_line_item_build_amount": 2400, "bill_line_item_category": "Treating Physician"},
  {"job_id": "CLM-1005", "record_id": "REC-1025", "tag_id": "TAG-5025", "facility_name": "Dr. Kevin Patel Clinic", "provider_name": "Dr. Kevin Patel", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "9/1/2024 12:00:00 AM", "end_date": "9/1/2024 12:00:00 AM", "bill_line_item_service_date": "9/1/2024 12:00:00 AM", "bill_line_item_build_amount": 2100, "bill_line_item_category": "Treating Physician"},
  {"job_id": "CLM-1005", "record_id": "REC-1026", "tag_id": "TAG-5026", "facility_name": "Midwest Occupational", "provider_name": "Dr. David Kim", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "10/31/2024 12:00:00 AM", "end_date": "10/31/2024 12:00:00 AM", "bill_line_item_service_date": "10/31/2024 12:00:00 AM", "bill_line_item_build_amount": 1900, "bill_line_item_category": "Treating Physician"}
];

export default function App() {
  const [data, setData] = useState(null);
  const [activeTab, setActiveTab] = useState('executive');
  const [datasetLabel, setDatasetLabel] = useState('Default Sample (3,000 Claims & Outlier Focus)');
  const [pinnedJobId, setPinnedJobId] = useState('CLM-1001');
  const [tab2SelectedJobIds, setTab2SelectedJobIds] = useState(['CLM-1001', 'CLM-1008']);
  const [scatterSortBy, setScatterSortBy] = useState('sequence'); // 'sequence' (Claim 1..N)
  const [selectedPhaseBreach, setSelectedPhaseBreach] = useState('ALL');
  const [selectedBillDot, setSelectedBillDot] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [severityFilter, setSeverityFilter] = useState('ALL');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 15;
  const fileInputRef = useRef(null);
  const deepDiveRef = useRef(null);
  const [deepDiveModalClaim, setDeepDiveModalClaim] = useState(null);

  useEffect(() => {
    const synthetic = generate3000ClaimsDemo();
    const res = parseAndAnalyzeRawBills(synthetic);
    setData(res);
    setDatasetLabel(`High-Scale Portfolio Dataset (3,000 Claims, ${res.rawBills.length.toLocaleString()} Bills)`);
    setPinnedJobId('CLM-1001');
  }, []);

  const handleFileUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsName = wb.SheetNames[0];
        const rawJson = XLSX.utils.sheet_to_json(wb.Sheets[wsName]);
        const res = parseAndAnalyzeRawBills(rawJson);
        if (res) {
          setData(res);
          setDatasetLabel(`${file.name} (${res.portfolioStats.totalClaims.toLocaleString()} Claims, ${res.rawBills.length.toLocaleString()} Bills)`);
          const outliers = res.claimSummaries.filter(c => c.is_p90_outlier === 1 || c.p90_status.includes('BREACH'));
          setPinnedJobId(outliers[0]?.job_id || res.claimSummaries[0]?.job_id || null);
          setCurrentPage(1);
          setSelectedBillDot(null);
        } else {
          alert('Could not find valid claim/bill records in uploaded file.');
        }
      } catch (err) {
        alert(`Error reading file: ${err.message}`);
      }
    };
    reader.readAsBinaryString(file);
  };

  const handleLoad3000 = () => {
    setTimeout(() => {
      const synthetic = generate3000ClaimsDemo();
      const res = parseAndAnalyzeRawBills(synthetic);
      setData(res);
      setDatasetLabel(`High-Scale Synthetic Dataset (3,000 Claims, ${res.rawBills.length.toLocaleString()} Bills)`);
      const outliers = res.claimSummaries.filter(c => c.is_p90_outlier === 1 || c.p90_status.includes('BREACH'));
      setPinnedJobId(outliers[0]?.job_id || res.claimSummaries[0]?.job_id || null);
      setCurrentPage(1);
      setSelectedBillDot(null);
    }, 50);
  };

  const handleDownloadPowerBi = () => {
    if (!data) return;
    exportPowerBiModel(data);
  };

  const outlierClaims = useMemo(() => {
    if (!data?.claimSummaries) return [];
    return data.claimSummaries.filter(c => c.is_p90_outlier === 1 || c.p90_status.includes('BREACH'));
  }, [data]);

  const activePinnedClaim = useMemo(() => {
    if (!data?.claimSummaries || !pinnedJobId) return data?.claimSummaries?.[0] || null;
    return data.claimSummaries.find(c => c.job_id === pinnedJobId) || data.claimSummaries[0];
  }, [data, pinnedJobId]);

  const activeClaimBills = useMemo(() => {
    if (!activePinnedClaim?.bill_rows) return [];
    return activePinnedClaim.bill_rows;
  }, [activePinnedClaim]);

  // Claims plotted on Top Scatter (Sequential Claim 1..N on X-axis vs Total Billed Amount on Y-axis)
  const portfolioScatterClaims = useMemo(() => {
    if (!data?.claimSummaries) return [];
    const list = [...data.claimSummaries].sort((a, b) => a.claim_index - b.claim_index);
    const p90 = data.portfolioStats?.finalP90Threshold || 0;
    return list.map((c, idx) => {
      const isAboveP90 = c.total_billed_amount >= p90;
      return {
        ...c,
        plot_x_index: idx + 1,
        plot_x_label: `Claim #${idx + 1}`,
        is_above_p90: isAboveP90,
        // Make red dots significantly larger so they pop out immediately
        dot_z_score: isAboveP90 ? 800 : 70
      };
    });
  }, [data]);

  const allJobIdList = useMemo(() => {
    if (!data?.claimSummaries) return [];
    return data.claimSummaries.map(c => c.job_id);
  }, [data]);

  const categoryMigrationPhases = useMemo(() => {
    return data?.categoryMigrationPhases || [];
  }, [data]);

  const categoryShiftList = useMemo(() => {
    return data?.categoryShiftList || [];
  }, [data]);

  // All claims that have breached P90 in any phase or in total
  const allBreachedClaims = useMemo(() => {
    if (!data?.claimSummaries) return [];
    return data.claimSummaries.filter(c => 
      (c.breached_phases && c.breached_phases.length > 0) || 
      c.is_p90_outlier === 1 || 
      c.p90_status.includes('BREACH') ||
      c.total_billed_amount >= (data.portfolioStats?.finalP90Threshold || 0)
    );
  }, [data]);

  // S-Curve dataset comparing P90 Ceiling Line against the multiple selected Job IDs
  const tab2MultiCurveData = useMemo(() => {
    if (!data?.milestoneStats) return [];
    return data.milestoneStats.map(m => {
      const p90Val = Math.round(m.p90);
      const point = {
        name: `Day ${m.eval_day}`,
        eval_day: m.eval_day,
        milestone_name: m.milestone_name,
        p90: p90Val
      };

      tab2SelectedJobIds.forEach(jobId => {
        let spend = 0;
        if (data.claimSpendAtMilestone?.[m.eval_day]?.[jobId] !== undefined) {
          spend = Math.round(data.claimSpendAtMilestone[m.eval_day][jobId]);
        } else {
          const claim = data.claimSummaries?.find(c => c.job_id === jobId);
          if (claim?.bill_rows) {
            spend = Math.round(
              claim.bill_rows
                .filter(b => b.elapsed_days <= m.eval_day)
                .reduce((sum, b) => sum + b.bill_line_item_build_amount, 0)
            );
          }
        }
        point[jobId] = spend;
      });

      return point;
    });
  }, [data, tab2SelectedJobIds]);

  // Phase breach filtered claims for Tab 2
  const phaseFilteredClaims = useMemo(() => {
    if (!data?.claimSummaries) return [];
    if (selectedPhaseBreach === 'ALL') return data.claimSummaries.filter(c => c.is_p90_outlier === 1);
    const mDay = parseInt(selectedPhaseBreach.replace('M', '')) || 30;
    return data.claimSummaries.filter(c => c.breached_phases?.some(p => p.eval_day === mDay));
  }, [data, selectedPhaseBreach]);

  const filteredClaims = useMemo(() => {
    if (!data?.claimSummaries) return [];
    const list = [...data.claimSummaries].sort((a, b) => a.claim_index - b.claim_index);
    return list.filter(c => {
      const matchSearch = (
        c.job_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.inflection_category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.inflection_facility.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.billing_state.toLowerCase().includes(searchQuery.toLowerCase())
      );
      if (!matchSearch) return false;
      if (severityFilter === 'P90_ONLY') return c.p90_status.includes('BREACH') || c.is_p90_outlier === 1;
      if (severityFilter === 'HIGH') return c.severity_classification.includes('High') || c.severity_classification.includes('P90');
      return true;
    });
  }, [data, searchQuery, severityFilter]);

  const paginatedClaims = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredClaims.slice(start, start + pageSize);
  }, [filteredClaims, currentPage, pageSize]);

  const totalPages = Math.ceil(filteredClaims.length / pageSize) || 1;

  if (!data) return <div className="min-h-screen bg-slate-950 flex items-center justify-center text-slate-400 font-sans">Loading Temporal Analytics...</div>;

  const { portfolioStats, milestoneStats, trajectoryCurves, claimSummaries } = data;

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white relative overflow-x-hidden">
      {/* Dynamic Ambient Background Mesh Glows */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute -top-40 left-1/4 w-[650px] h-[650px] bg-indigo-600/15 rounded-full blur-[140px]" />
        <div className="absolute top-1/3 -right-40 w-[550px] h-[550px] bg-blue-600/10 rounded-full blur-[140px]" />
        <div className="absolute -bottom-20 left-1/3 w-[600px] h-[600px] bg-rose-600/10 rounded-full blur-[150px]" />
        <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:24px_24px] opacity-25" />
      </div>

      {/* Top Header */}
      <header className="border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-xl sticky top-0 z-40 px-6 py-3.5 shadow-2xl">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-400 flex items-center justify-center shadow-lg shadow-indigo-500/25 ring-1 ring-white/20">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-black tracking-tight text-white m-0">ClaimOptima</h1>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/15 text-indigo-300 border border-indigo-500/30 font-bold shadow-sm">
                  Executive Studio
                </span>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 font-bold flex items-center gap-1">
                  <Database className="w-3 h-3" /> Power BI Ready
                </span>
              </div>
              <p className="text-xs text-slate-400 m-0">Temporal Severity, Multi-Inflection Discovery & Milestone Phase Breaches</p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center flex-wrap gap-2">
            <span className="text-xs text-slate-300 bg-slate-900/90 px-3 py-1.5 rounded-xl border border-slate-700/80 shadow-inner flex items-center gap-2">
              <FileSpreadsheet className="w-3.5 h-3.5 text-blue-400" />
              {datasetLabel}
            </span>

            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept=".xlsx,.xls,.csv"
              className="hidden"
            />

            <button
              onClick={() => fileInputRef.current?.click()}
              className="cursor-pointer text-xs font-semibold px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-200 rounded-xl border border-slate-700/80 shadow-md transition hover:border-slate-500 flex items-center gap-1.5"
            >
              <Upload className="w-3.5 h-3.5" />
              Upload Excel
            </button>

            <button
              onClick={handleDownloadPowerBi}
              className="cursor-pointer text-xs font-bold px-3.5 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-xl shadow-lg shadow-amber-600/20 transition flex items-center gap-1.5"
              title="Download Star-Schema Excel & CSVs formatted for Power BI"
            >
              <Download className="w-3.5 h-3.5" />
              Power BI Dataset
            </button>

            <button
              onClick={handleLoad3000}
              className="cursor-pointer text-xs font-bold px-3.5 py-1.5 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white rounded-xl shadow-lg shadow-indigo-600/25 transition flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              3,000 Claims Demo
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto w-full px-6 py-6 flex-1 flex flex-col gap-6 relative z-10">
        {/* Executive KPI Cards */}
        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-slate-900/70 border border-slate-800/90 rounded-2xl p-4 shadow-xl backdrop-blur-md hover:border-indigo-500/40 transition-all">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-slate-400 m-0">Portfolio Scope</p>
                <h3 className="text-2xl font-black text-white mt-1 mb-0">{portfolioStats.totalClaims.toLocaleString()} Claims</h3>
                <p className="text-xs text-slate-400 mt-1 mb-0">{data.rawBills.length.toLocaleString()} bill lines • Max {portfolioStats.maxTreatmentDays} Days</p>
              </div>
              <div className="p-2.5 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400 shadow-inner">
                <Layers className="w-5 h-5" />
              </div>
            </div>
          </div>

          <div className="bg-slate-900/70 border border-slate-800/90 rounded-2xl p-4 shadow-xl backdrop-blur-md hover:border-emerald-500/40 transition-all">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-slate-400 m-0">Total Medical Exposure</p>
                <h3 className="text-2xl font-black text-emerald-400 mt-1 mb-0">${portfolioStats.totalMedicalSpend.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h3>
                <p className="text-xs text-slate-400 mt-1 mb-0">Avg ${Math.round(portfolioStats.averageClaimSpend).toLocaleString()} / claim</p>
              </div>
              <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 shadow-inner">
                <DollarSign className="w-5 h-5" />
              </div>
            </div>
          </div>

          <div className="bg-slate-900/70 border border-slate-800/90 rounded-2xl p-4 shadow-xl backdrop-blur-md hover:border-rose-500/40 transition-all">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-slate-400 m-0">Portfolio P90 Ceiling</p>
                <h3 className="text-2xl font-black text-rose-400 mt-1 mb-0">${Math.round(portfolioStats.finalP90Threshold).toLocaleString()}</h3>
                <p className="text-xs text-rose-400/80 mt-1 mb-0">Top 10% Catastrophic Threshold</p>
              </div>
              <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 shadow-inner">
                <AlertTriangle className="w-5 h-5" />
              </div>
            </div>
          </div>

          <div className="bg-slate-900/70 border border-slate-800/90 rounded-2xl p-4 shadow-xl backdrop-blur-md hover:border-amber-500/40 transition-all">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-slate-400 m-0">P90 Outlier Impact</p>
                <h3 className="text-2xl font-black text-amber-400 mt-1 mb-0">{portfolioStats.p90OutlierCount} Outliers</h3>
                <p className="text-xs text-amber-400/80 mt-1 mb-0">Accounts for {Math.round(portfolioStats.p90SpendShare)}% of total portfolio spend</p>
              </div>
              <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 shadow-inner">
                <ShieldAlert className="w-5 h-5" />
              </div>
            </div>
          </div>
        </section>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2 overflow-x-auto">
          {[
            { id: 'executive', label: '1. Executive Scatter & Outlier Map', icon: Activity },
            { id: 'curves', label: '2. Milestone Phase P90 Breaches & S-Curves', icon: TrendingUp },
            { id: 'shift', label: '3. Clinical Category Shift', icon: BarChart3 },
            { id: 'explorer', label: '4. All Claims Explorer', icon: Layers }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`cursor-pointer px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap ${
                  isActive
                    ? 'bg-gradient-to-r from-indigo-600 to-blue-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/80'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* TAB 1: EXECUTIVE SCATTER & OUTLIER MAP */}
        {activeTab === 'executive' && (
          <div className="space-y-8">
            {/* GRAPH 1: PORTFOLIO ALL-CLAIMS DISTRIBUTION SCATTER MAP (Claims 1..N on X-axis vs Total Spend on Y-axis with P90 Ceiling) */}
            <div className="bg-slate-900/80 border border-slate-800/90 rounded-2xl p-6 shadow-2xl backdrop-blur-xl relative overflow-hidden">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-white m-0">
                      Portfolio P90 Outlier Distribution Map (Sequential Claim 1..{portfolioStats.totalClaims.toLocaleString()})
                    </h3>
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/30 font-bold flex items-center gap-1">
                      <Flame className="w-3.5 h-3.5 text-rose-400" /> {portfolioStats.p90OutlierCount} Outliers Above Ceiling
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1 mb-0">
                    X-Axis shows individual claims in sequential order (Claim #1 to #{portfolioStats.totalClaims}). The <strong className="text-rose-400">${Math.round(portfolioStats.finalP90Threshold).toLocaleString()} P90 Ceiling</strong> line clearly isolates catastrophic red outlier claims above from normal green claims below.
                  </p>
                </div>

                <div className="flex items-center gap-2 bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-800 text-xs text-slate-300">
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
                  <span>Sequential Portfolio Mode (Claim 1..{portfolioStats.totalClaims})</span>
                </div>
              </div>

              {/* All Claims Scatter Plot */}
              <div className="h-96 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <ScatterChart margin={{ top: 20, right: 30, bottom: 20, left: 15 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis
                      type="number"
                      dataKey="plot_x_index"
                      name="Claim Sequence Number"
                      unit="#"
                      stroke="#64748b"
                      domain={[1, portfolioScatterClaims.length || 'dataMax']}
                      tick={{ fontSize: 11 }}
                    />
                    <YAxis
                      type="number"
                      dataKey="total_billed_amount"
                      name="Total Claim Billed Amount"
                      unit="$"
                      stroke="#64748b"
                      tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`}
                      tick={{ fontSize: 11 }}
                    />
                    <ZAxis type="number" dataKey="dot_z_score" range={[60, 480]} name="P90 Status" />
                    
                    {/* Horizontal P90 Ceiling Reference Line */}
                    <ReferenceLine
                      y={portfolioStats.finalP90Threshold}
                      stroke="#ef4444"
                      strokeDasharray="4 4"
                      strokeWidth={2.5}
                      label={{ value: `Portfolio P90 Ceiling: $${Math.round(portfolioStats.finalP90Threshold).toLocaleString()}`, fill: '#ef4444', fontSize: 11, position: 'top' }}
                    />
                    
                    <Tooltip
                      cursor={{ strokeDasharray: '3 3' }}
                      content={({ payload }) => {
                        if (!payload || !payload.length) return null;
                        const d = payload[0].payload;
                        return (
                          <div className="bg-slate-900 border border-slate-700 p-4 rounded-xl shadow-2xl text-xs space-y-1.5 z-50 min-w-[250px]">
                            <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
                              <span className="font-bold text-white text-sm">{d.job_id} ({d.plot_x_label})</span>
                              {d.is_above_p90 ? (
                                <span className="px-2 py-0.5 rounded bg-rose-500/30 text-rose-300 text-[10px] font-black">
                                  🚨 P90 OUTLIER
                                </span>
                              ) : (
                                <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-semibold">
                                  Normal Range
                                </span>
                              )}
                            </div>
                            <p className="text-emerald-400 font-black text-sm m-0">Total Exposure: ${Math.round(d.total_billed_amount).toLocaleString()}</p>
                            <p className="text-slate-300 m-0">1st Spike: <strong className="text-rose-300">${d.inflection_jump_amount.toLocaleString()}</strong> ({d.inflection_category})</p>
                            <p className="text-slate-400 m-0">Facility: {d.inflection_facility}</p>
                            <p className="text-slate-400 m-0">Treatment Span: {d.total_treatment_span_days} days ({d.total_bills_count} bills)</p>
                            <p className="text-cyan-400 font-semibold pt-1 m-0">👇 Click to deep-dive into this claim below</p>
                          </div>
                        );
                      }}
                    />

                    <Scatter name="All Claims" data={portfolioScatterClaims}>
                      {portfolioScatterClaims.map((entry, index) => {
                        const isPinned = entry.job_id === pinnedJobId;
                        const isAboveP90 = entry.is_above_p90;
                        
                        // Strict Red / Green rule with significantly bigger and bolder Red Outlier Dots
                        let fillColor = isAboveP90 ? '#ef4444' : '#10b981';
                        let strokeColor = isAboveP90 ? '#ffffff' : '#047857';
                        let strokeWidth = isAboveP90 ? 2.5 : 1;

                        if (isPinned) {
                          fillColor = '#06b6d4';
                          strokeColor = '#ffffff';
                          strokeWidth = 3.5;
                        }

                        return (
                          <Cell
                            key={`all-claim-cell-${index}`}
                            fill={fillColor}
                            stroke={strokeColor}
                            strokeWidth={strokeWidth}
                            className={`cursor-pointer transition-all hover:scale-150 ${isAboveP90 ? 'filter drop-shadow-[0_0_8px_rgba(239,68,68,0.9)]' : ''}`}
                            onClick={() => {
                              setPinnedJobId(entry.job_id);
                            }}
                          />
                        );
                      })}
                    </Scatter>
                  </ScatterChart>
                </ResponsiveContainer>
              </div>

              {/* Legend for Top Scatter */}
              <div className="flex items-center justify-between flex-wrap gap-4 pt-4 border-t border-slate-800 text-xs text-slate-400">
                <div className="flex items-center gap-4 flex-wrap">
                  <div className="flex items-center gap-1.5">
                    <span className="w-3.5 h-3.5 rounded-full bg-rose-500 ring-4 ring-rose-500/30"></span>
                    <span className="font-bold text-rose-400">🔴 Red Dot = Above P90 Ceiling (&gt; ${Math.round(portfolioStats.finalP90Threshold).toLocaleString()}) - Outliers</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-3.5 h-3.5 rounded-full bg-emerald-500 ring-4 ring-emerald-500/30"></span>
                    <span className="font-bold text-emerald-400">🟢 Green Dot = Below P90 Ceiling (&lt;= ${Math.round(portfolioStats.finalP90Threshold).toLocaleString()}) - Normal Range</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-3.5 h-3.5 rounded-full bg-cyan-400 ring-2 ring-white"></span>
                    <span className="font-semibold text-cyan-300">🔵 Cyan = Selected Claim (Details Below)</span>
                  </div>
                </div>
                <div className="text-slate-400 font-medium">
                  Click any Job ID dot above to inspect all its individual bill records below
                </div>
              </div>
            </div>

            {/* GRAPH 2: OUTLIER DEEP-DIVE & MULTI-INFLECTION TRAJECTORY ANALYSIS */}
            <div className="bg-gradient-to-br from-slate-900/90 via-slate-900/80 to-indigo-950/40 border border-indigo-500/40 rounded-2xl p-6 shadow-2xl backdrop-blur-xl">
              {/* Outlier Claim Selector Header */}
              <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 pb-4 border-b border-slate-800">
                <div>
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-lg bg-indigo-500/20 text-indigo-400">
                      <Crosshair className="w-4 h-4" />
                    </div>
                    <h3 className="text-base font-bold text-white m-0">Outlier Claim Deep-Dive: Multi-Inflection Trajectory</h3>
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 font-black">
                      {activePinnedClaim?.job_id}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1 mb-0">
                    Detailed chronological timeline showing every single bill dot with <strong className="text-rose-400">Primary (1st)</strong> and <strong className="text-purple-400">Secondary (2nd) Inflection Spikes</strong> highlighted.
                  </p>
                </div>

                {/* Job ID Dropdown (Focusing on Outlier Claims) */}
                <div className="flex items-center gap-2 bg-slate-950 border border-slate-700 px-3 py-1.5 rounded-xl">
                  <span className="text-xs font-semibold text-slate-400">Select Outlier Job ID:</span>
                  <select
                    value={pinnedJobId || ''}
                    onChange={(e) => {
                      setPinnedJobId(e.target.value);
                      setSelectedBillDot(null);
                    }}
                    className="bg-transparent text-cyan-400 font-bold text-xs focus:outline-none cursor-pointer"
                  >
                    <optgroup label="🚨 P90 Outlier Claims">
                      {outlierClaims.map(c => (
                        <option key={c.job_id} value={c.job_id} className="bg-slate-900 text-white font-semibold">
                          {c.job_id} • ${Math.round(c.total_billed_amount).toLocaleString()} ({c.total_bills_count} bills, Spike: ${Math.round(c.inflection_jump_amount).toLocaleString()})
                        </option>
                      ))}
                    </optgroup>
                    <optgroup label="Standard Claims">
                      {claimSummaries.filter(c => c.is_p90_outlier === 0).slice(0, 10).map(c => (
                        <option key={c.job_id} value={c.job_id} className="bg-slate-900 text-slate-300">
                          {c.job_id} • ${Math.round(c.total_billed_amount).toLocaleString()}
                        </option>
                      ))}
                    </optgroup>
                  </select>
                </div>
              </div>

              {/* Dual Inflection Callout Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-5">
                {/* 1st Primary Inflection Point Card */}
                {activePinnedClaim?.primary_inflection && (
                  <div className="p-4 rounded-xl bg-rose-950/30 border border-rose-500/50 shadow-md flex items-start gap-3">
                    <div className="w-9 h-9 rounded-lg bg-rose-500/20 border border-rose-500/60 flex items-center justify-center text-rose-400 font-black text-sm shrink-0">
                      1st
                    </div>
                    <div className="space-y-0.5 flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-rose-300 uppercase tracking-wider">Primary Inflection Point (Largest Spike)</span>
                        <span className="text-[10px] px-2 py-0.2 rounded bg-rose-500/40 text-rose-200 font-mono font-bold">
                          Record #{activePinnedClaim.primary_inflection.record_id}
                        </span>
                      </div>
                      <p className="text-base font-black text-rose-400 m-0">
                        ${activePinnedClaim.primary_inflection.amount.toLocaleString()} <span className="text-xs font-normal text-slate-300">({activePinnedClaim.primary_inflection.category})</span>
                      </p>
                      <p className="text-xs text-slate-300 m-0">
                        Occurred on <strong className="text-white">Day {activePinnedClaim.primary_inflection.day}</strong> at <strong className="text-white">{activePinnedClaim.primary_inflection.facility}</strong>
                      </p>
                    </div>
                  </div>
                )}

                {/* 2nd Secondary Inflection Point Card */}
                {activePinnedClaim?.secondary_inflection ? (
                  <div className="p-4 rounded-xl bg-purple-950/30 border border-purple-500/50 shadow-md flex items-start gap-3">
                    <div className="w-9 h-9 rounded-lg bg-purple-500/20 border border-purple-500/60 flex items-center justify-center text-purple-400 font-black text-sm shrink-0">
                      2nd
                    </div>
                    <div className="space-y-0.5 flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-purple-300 uppercase tracking-wider">Secondary Inflection Spike</span>
                        <span className="text-[10px] px-2 py-0.2 rounded bg-purple-500/40 text-purple-200 font-mono font-bold">
                          Record #{activePinnedClaim.secondary_inflection.record_id}
                        </span>
                      </div>
                      <p className="text-base font-black text-purple-400 m-0">
                        ${activePinnedClaim.secondary_inflection.amount.toLocaleString()} <span className="text-xs font-normal text-slate-300">({activePinnedClaim.secondary_inflection.category})</span>
                      </p>
                      <p className="text-xs text-slate-300 m-0">
                        Occurred on <strong className="text-white">Day {activePinnedClaim.secondary_inflection.day}</strong> at <strong className="text-white">{activePinnedClaim.secondary_inflection.facility}</strong>
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="p-4 rounded-xl bg-slate-950/40 border border-slate-800 flex items-center justify-center text-slate-500 text-xs">
                    No secondary spike detected (Single sharp surgical/trauma escalation)
                  </div>
                )}
              </div>

              {/* Line & Scatter Stepped Trajectory Chart */}
              <div className="h-96 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={activeClaimBills} margin={{ top: 20, right: 30, bottom: 20, left: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis
                      dataKey="elapsed_days"
                      type="number"
                      domain={[0, 'dataMax + 15']}
                      stroke="#64748b"
                      name="Elapsed Days"
                      unit="d"
                      tick={{ fontSize: 11 }}
                    />
                    <YAxis stroke="#64748b" tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} tick={{ fontSize: 11 }} />
                    <ReferenceLine
                      y={portfolioStats.finalP90Threshold}
                      stroke="#ef4444"
                      strokeDasharray="4 4"
                      label={{ value: `P90 Ceiling: $${Math.round(portfolioStats.finalP90Threshold).toLocaleString()}`, fill: '#ef4444', fontSize: 11, position: 'top' }}
                    />

                    <Tooltip
                      content={({ payload }) => {
                        if (!payload || !payload.length) return null;
                        const d = payload[0].payload;
                        return (
                          <div className="bg-slate-900 border border-slate-700 p-4 rounded-xl shadow-2xl text-xs space-y-1.5 z-50 min-w-[250px]">
                            <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
                              <span className="font-bold text-white text-sm">{d.job_id} • {d.record_id}</span>
                              {d.is_primary_inflection ? (
                                <span className="px-2 py-0.5 rounded bg-rose-500/30 text-rose-300 text-[10px] font-black">
                                  ⭐ 1ST PRIMARY INFLECTION
                                </span>
                              ) : d.is_secondary_inflection ? (
                                <span className="px-2 py-0.5 rounded bg-purple-500/30 text-purple-300 text-[10px] font-black">
                                  ⚡ 2ND SECONDARY INFLECTION
                                </span>
                              ) : (
                                <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px]">
                                  Day {d.elapsed_days}
                                </span>
                              )}
                            </div>
                            <p className="text-emerald-400 font-bold text-sm m-0">Bill Amount: ${d.bill_line_item_build_amount.toLocaleString()}</p>
                            <p className="text-slate-200 m-0">Category: <strong className="text-white">{d.bill_line_item_category}</strong></p>
                            <p className="text-slate-300 m-0">Facility: {d.facility_name}</p>
                            <p className="text-slate-400 m-0">Doctor: {d.provider_name}</p>
                            <div className="pt-1.5 border-t border-slate-800/80 flex justify-between text-[11px]">
                              <span className="text-slate-400">Cumulative Claim Total:</span>
                              <span className="text-cyan-400 font-bold">${d.cumulative_spend.toLocaleString()}</span>
                            </div>
                          </div>
                        );
                      }}
                    />

                    {/* Smooth Curvy Cumulative Spend Trajectory Line */}
                    <Line
                      type="monotone"
                      dataKey="cumulative_spend"
                      stroke="#06b6d4"
                      strokeWidth={3.5}
                      name="Cumulative Spend Path"
                      dot={(dotProps) => {
                        const { cx, cy, payload } = dotProps;
                        const isPrimary = payload.is_primary_inflection;
                        const isSecondary = payload.is_secondary_inflection;

                        if (isPrimary) {
                          return (
                            <g key={`primary-dot-${payload.record_id}`} className="cursor-pointer" onClick={() => setSelectedBillDot(payload)}>
                              {/* Pulsing Outer Glow */}
                              <circle cx={cx} cy={cy} r={18} fill="#ef4444" opacity={0.25} className="animate-ping" />
                              <circle cx={cx} cy={cy} r={14} fill="none" stroke="#ef4444" strokeWidth={2} />
                              <circle cx={cx} cy={cy} r={9} fill="#ef4444" stroke="#ffffff" strokeWidth={3} />
                              
                              {/* Direct Visible Floating Banner Callout for Inflection Point 1 */}
                              <g transform={`translate(${cx}, ${cy - 30})`}>
                                <rect x="-65" y="-13" width="130" height="22" rx="6" fill="#ef4444" stroke="#ffffff" strokeWidth="1.5" className="filter drop-shadow-lg" />
                                <text x="0" y="2" fill="#ffffff" fontSize="10" fontWeight="900" textAnchor="middle">⭐ Inflection Point 1</text>
                              </g>
                            </g>
                          );
                        }
                        if (isSecondary) {
                          return (
                            <g key={`sec-dot-${payload.record_id}`} className="cursor-pointer" onClick={() => setSelectedBillDot(payload)}>
                              {/* Secondary Outer Halo */}
                              <circle cx={cx} cy={cy} r={14} fill="none" stroke="#a855f7" strokeWidth={2} />
                              <circle cx={cx} cy={cy} r={8} fill="#9333ea" stroke="#ffffff" strokeWidth={2.5} />
                              
                              {/* Direct Visible Floating Banner Callout for Inflection Point 2 */}
                              <g transform={`translate(${cx}, ${cy - 30})`}>
                                <rect x="-65" y="-13" width="130" height="22" rx="6" fill="#9333ea" stroke="#ffffff" strokeWidth="1.5" className="filter drop-shadow-lg" />
                                <text x="0" y="2" fill="#ffffff" fontSize="10" fontWeight="900" textAnchor="middle">⚡ Inflection Point 2</text>
                              </g>
                            </g>
                          );
                        }
                        return (
                          <circle
                            key={`dot-${payload.record_id}`}
                            cx={cx}
                            cy={cy}
                            r={5}
                            fill={CATEGORY_COLORS[payload.bill_line_item_category] || '#38bdf8'}
                            stroke="#ffffff"
                            strokeWidth={1.5}
                            className="cursor-pointer hover:r-7 transition-all filter drop-shadow-sm"
                            onClick={() => setSelectedBillDot(payload)}
                          />
                        );
                      }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Legend for Curvy Trajectory */}
              <div className="flex items-center justify-between flex-wrap gap-4 pt-4 border-t border-slate-800 text-xs text-slate-400">
                <div className="flex items-center gap-4 flex-wrap">
                  <div className="flex items-center gap-1.5">
                    <span className="w-3.5 h-3.5 rounded-full bg-rose-500 ring-4 ring-rose-500/30"></span>
                    <span className="font-bold text-rose-400">⭐ Inflection Point 1 (Primary Surgical/Trauma Spike)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-3.5 h-3.5 rounded-full bg-purple-500 ring-4 ring-purple-500/30"></span>
                    <span className="font-bold text-purple-400">⚡ Inflection Point 2 (Secondary Escalation Spike)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span>
                    <span>Smooth Cumulative Spend S-Curve</span>
                  </div>
                </div>
                <div className="text-slate-400 font-medium">
                  Click any dot on the curve to inspect its bill record below
                </div>
              </div>

              {/* Selected Bill Dot Card */}
              {selectedBillDot && (
                <div className="mt-4 p-4 rounded-xl bg-slate-950 border border-cyan-500/40 shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-mono text-xs font-bold">
                        Selected Dot: Record #{selectedBillDot.record_id}
                      </span>
                      {selectedBillDot.is_primary_inflection && (
                        <span className="text-xs px-2 py-0.5 rounded bg-rose-500/20 text-rose-400 font-bold">
                          ⭐ 1ST PRIMARY INFLECTION
                        </span>
                      )}
                      {selectedBillDot.is_secondary_inflection && (
                        <span className="text-xs px-2 py-0.5 rounded bg-purple-500/20 text-purple-400 font-bold">
                          ⚡ 2ND SECONDARY INFLECTION
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-300 m-0">
                      <strong>Facility:</strong> {selectedBillDot.facility_name} • <strong>Doctor:</strong> {selectedBillDot.provider_name} • <strong>Category:</strong> {selectedBillDot.bill_line_item_category}
                    </p>
                    <p className="text-xs text-slate-400 m-0">
                      <strong>Service Date:</strong> {new Date(selectedBillDot.effective_service_date).toLocaleDateString()} (Day {selectedBillDot.elapsed_days}) • <strong>Cumulative Claim Spend:</strong> ${selectedBillDot.cumulative_spend.toLocaleString()}
                    </p>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-[10px] text-slate-400 uppercase tracking-wider m-0">Bill Amount</p>
                      <p className="text-lg font-black text-emerald-400 m-0">${selectedBillDot.bill_line_item_build_amount.toLocaleString()}</p>
                    </div>
                    <button
                      onClick={() => setSelectedBillDot(null)}
                      className="cursor-pointer p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* Chronological Table of All Bill Records for Selected Claim */}
              <div className="mt-6 border-t border-slate-800 pt-5">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-3 flex items-center justify-between">
                  <span>Chronological Bill Records Ledger ({activeClaimBills.length} Bill Items)</span>
                  <span className="text-slate-500 font-normal normal-case">Red/Purple rows = Primary & Secondary Inflection Spikes</span>
                </h4>
                <div className="overflow-x-auto rounded-xl border border-slate-800">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-slate-950 text-slate-400 border-b border-slate-800">
                        <th className="p-2.5">#</th>
                        <th className="p-2.5">Record ID</th>
                        <th className="p-2.5">Elapsed</th>
                        <th className="p-2.5">Service Date</th>
                        <th className="p-2.5">Category</th>
                        <th className="p-2.5">Facility / Provider</th>
                        <th className="p-2.5 text-right">Billed Amount</th>
                        <th className="p-2.5 text-right">Cumulative Spend</th>
                        <th className="p-2.5 text-center">Inflection Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {activeClaimBills.map((b, idx) => {
                        const isPrimary = b.is_primary_inflection;
                        const isSecondary = b.is_secondary_inflection;
                        return (
                          <tr
                            key={b.record_id}
                            onClick={() => setSelectedBillDot(b)}
                            className={`cursor-pointer transition ${
                              isPrimary
                                ? 'bg-rose-950/40 hover:bg-rose-950/60 border-l-4 border-l-rose-500 font-medium'
                                : isSecondary
                                ? 'bg-purple-950/40 hover:bg-purple-950/60 border-l-4 border-l-purple-500 font-medium'
                                : 'hover:bg-slate-800/50'
                            }`}
                          >
                            <td className="p-2.5 text-slate-500">{idx + 1}</td>
                            <td className="p-2.5 font-mono text-cyan-400 font-bold">{b.record_id}</td>
                            <td className="p-2.5 font-semibold text-slate-300">Day {b.elapsed_days}</td>
                            <td className="p-2.5 text-slate-400">{new Date(b.effective_service_date).toLocaleDateString()}</td>
                            <td className="p-2.5">
                              <span className="px-2 py-0.5 rounded text-[11px] font-medium" style={{ backgroundColor: `${CATEGORY_COLORS[b.bill_line_item_category] || '#64748b'}20`, color: CATEGORY_COLORS[b.bill_line_item_category] || '#cbd5e1' }}>
                                {b.bill_line_item_category}
                              </span>
                            </td>
                            <td className="p-2.5 text-slate-300">
                              <span className="font-semibold text-white">{b.facility_name}</span>
                              <span className="text-slate-500 text-[11px] block">{b.provider_name}</span>
                            </td>
                            <td className="p-2.5 text-right font-mono font-bold text-white">
                              ${b.bill_line_item_build_amount.toLocaleString()}
                            </td>
                            <td className="p-2.5 text-right font-mono text-cyan-400">
                              ${b.cumulative_spend.toLocaleString()}
                            </td>
                            <td className="p-2.5 text-center">
                              {isPrimary ? (
                                <span className="px-2 py-0.5 rounded bg-rose-500/30 text-rose-300 text-[10px] font-black">
                                  ⭐ 1ST PRIMARY SPIKE
                                </span>
                              ) : isSecondary ? (
                                <span className="px-2 py-0.5 rounded bg-purple-500/30 text-purple-300 text-[10px] font-black">
                                  ⚡ 2ND SECONDARY SPIKE
                                </span>
                              ) : (
                                <span className="text-slate-500 text-[11px]">Routine</span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: MILESTONE PHASE P90 BREACHES & S-CURVES */}
        {activeTab === 'curves' && (
          <div className="space-y-6">
            <div className="bg-slate-900/80 border border-slate-800/90 rounded-2xl p-6 shadow-2xl backdrop-blur-xl">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4">
                <div>
                  <h3 className="text-base font-bold text-white m-0">Milestone Phase P90 Ceiling & Multi-Claim S-Curves</h3>
                  <p className="text-xs text-slate-400 mt-1 mb-0">
                    Compare multiple claim trajectory curves directly against the <strong className="text-rose-400">P90 Milestone Ceiling Line</strong> across all treatment days.
                  </p>
                </div>
              </div>

              {/* Multi-Claim Job ID Selector Panel */}
              <div className="p-4 rounded-xl bg-slate-950/90 border border-slate-800 shadow-lg space-y-3 mb-5">
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <SlidersHorizontal className="w-4 h-4 text-indigo-400" />
                    <span className="text-xs font-bold text-white uppercase tracking-wider">Select Job IDs to Overlay:</span>
                  </div>

                  {/* Dropdown showing ONLY the pure Job ID */}
                  <div className="flex items-center gap-2 w-full md:w-auto">
                    <select
                      value=""
                      onChange={(e) => {
                        const jid = e.target.value;
                        if (jid && !tab2SelectedJobIds.includes(jid)) {
                          setTab2SelectedJobIds([...tab2SelectedJobIds, jid]);
                        }
                      }}
                      className="cursor-pointer bg-slate-900 border border-indigo-500/50 text-white text-xs font-bold rounded-xl px-3 py-2 focus:ring-2 focus:ring-indigo-500 outline-none min-w-[200px]"
                    >
                      <option value="">+ Add Job ID...</option>
                      {allJobIdList.map(jid => (
                        <option key={`jid-opt-${jid}`} value={jid} className="bg-slate-900 text-white">
                          {jid}
                        </option>
                      ))}
                    </select>

                    <button
                      onClick={() => setTab2SelectedJobIds([])}
                      className="cursor-pointer text-xs px-2.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition"
                    >
                      Clear All
                    </button>
                  </div>
                </div>

                {/* Selected Job ID Badges / Chips */}
                <div className="flex items-center gap-2 flex-wrap pt-1 border-t border-slate-900">
                  <span className="text-[11px] text-slate-500 font-semibold">Plotted Claims ({tab2SelectedJobIds.length}):</span>
                  {tab2SelectedJobIds.length === 0 && (
                    <span className="text-xs text-slate-400 italic">No claims selected. Pick Job IDs from the dropdown above to display their curves.</span>
                  )}
                  {tab2SelectedJobIds.map((jid, idx) => {
                    const color = CLAIM_LINE_COLORS[idx % CLAIM_LINE_COLORS.length];
                    return (
                      <span
                        key={`chip-${jid}`}
                        style={{ borderColor: color }}
                        className="px-3 py-1 rounded-xl bg-slate-900/90 border text-white text-xs font-bold flex items-center gap-2 shadow-md transition hover:scale-105"
                      >
                        <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color }}></span>
                        <span className="font-mono">{jid}</span>
                        <button
                          onClick={() => setTab2SelectedJobIds(tab2SelectedJobIds.filter(id => id !== jid))}
                          className="cursor-pointer text-slate-400 hover:text-white font-bold ml-1"
                          title={`Remove ${jid}`}
                        >
                          ✕
                        </button>
                      </span>
                    );
                  })}
                </div>
              </div>

              {/* S-Curve Chart (ONLY P90 Ceiling Line + Selected Job ID Lines) */}
              <div className="h-96 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={tab2MultiCurveData} margin={{ top: 25, right: 35, bottom: 20, left: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis
                      dataKey="eval_day"
                      stroke="#64748b"
                      name="Milestone Day"
                      unit="d"
                      tick={{ fontSize: 11 }}
                    />
                    <YAxis stroke="#64748b" tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} tick={{ fontSize: 11 }} />
                    <Tooltip
                      content={({ payload, label }) => {
                        if (!payload || !payload.length) return null;
                        const pointData = tab2MultiCurveData.find(d => d.eval_day === label) || payload[0].payload;
                        return (
                          <div className="bg-slate-900 border border-slate-700 p-4 rounded-xl shadow-2xl text-xs space-y-1.5 z-50 min-w-[240px]">
                            <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
                              <span className="font-bold text-white text-sm">Day {label} ({pointData.milestone_name})</span>
                              <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 text-[10px] font-bold">
                                P90 Ceiling: ${pointData.p90.toLocaleString()}
                              </span>
                            </div>
                            {tab2SelectedJobIds.map((jid, idx) => {
                              const spend = pointData[jid] || 0;
                              const isBreached = spend >= pointData.p90 && pointData.p90 > 0;
                              const color = CLAIM_LINE_COLORS[idx % CLAIM_LINE_COLORS.length];
                              return (
                                <div key={jid} className="flex items-center justify-between gap-3">
                                  <div className="flex items-center gap-1.5">
                                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color }}></span>
                                    <span className="font-bold text-white font-mono">{jid}:</span>
                                  </div>
                                  <div className="flex items-center gap-1.5">
                                    <span className="font-bold text-white">${spend.toLocaleString()}</span>
                                    {isBreached && (
                                      <span className="px-1.5 py-0.2 rounded bg-rose-500/30 text-rose-300 text-[10px] font-black">
                                        🚨 BREACH
                                      </span>
                                    )}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        );
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: 11, paddingTop: 10 }} />

                    {/* ONLY 1: P90 Ceiling Line */}
                    <Line
                      type="monotone"
                      dataKey="p90"
                      stroke="#ef4444"
                      strokeWidth={3.5}
                      strokeDasharray="5 5"
                      name="P90 Ceiling Line"
                      dot={{ r: 5, fill: '#ef4444', stroke: '#ffffff', strokeWidth: 2 }}
                    />

                    {/* ONLY 2: Lines for each selected Job ID */}
                    {tab2SelectedJobIds.map((jid, idx) => {
                      const color = CLAIM_LINE_COLORS[idx % CLAIM_LINE_COLORS.length];
                      return (
                        <Line
                          key={`line-${jid}`}
                          type="monotone"
                          dataKey={jid}
                          stroke={color}
                          strokeWidth={3.5}
                          name={jid}
                          dot={(dotProps) => {
                            const { cx, cy, payload } = dotProps;
                            const spend = payload[jid] || 0;
                            const isBreached = spend >= payload.p90 && payload.p90 > 0;

                            if (isBreached) {
                              return (
                                <g key={`breach-dot-${jid}-${payload.eval_day}`} className="cursor-pointer">
                                  <circle cx={cx} cy={cy} r={14} fill={color} opacity={0.3} className="animate-ping" />
                                  <circle cx={cx} cy={cy} r={9} fill="#ef4444" stroke="#ffffff" strokeWidth={2.5} />
                                  <circle cx={cx} cy={cy} r={4} fill="#ffffff" />
                                </g>
                              );
                            }
                            return (
                              <circle
                                key={`normal-dot-${jid}-${payload.eval_day}`}
                                cx={cx}
                                cy={cy}
                                r={4.5}
                                fill={color}
                                stroke="#ffffff"
                                strokeWidth={1.5}
                                className="cursor-pointer hover:r-7 transition-all"
                              />
                            );
                          }}
                        />
                      );
                    })}
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Legend Summary */}
              <div className="flex items-center justify-between flex-wrap gap-4 pt-4 border-t border-slate-800 text-xs text-slate-400">
                <div className="flex items-center gap-4 flex-wrap">
                  <div className="flex items-center gap-1.5">
                    <span className="w-3.5 h-1.5 bg-rose-500 rounded"></span>
                    <span className="font-bold text-rose-400">🔴 P90 Ceiling Line</span>
                  </div>
                  {tab2SelectedJobIds.map((jid, idx) => (
                    <div key={`leg-${jid}`} className="flex items-center gap-1.5">
                      <span className="w-3.5 h-1.5 rounded" style={{ backgroundColor: CLAIM_LINE_COLORS[idx % CLAIM_LINE_COLORS.length] }}></span>
                      <span className="font-bold text-white font-mono">{jid}</span>
                    </div>
                  ))}
                </div>
                <div className="text-slate-400 font-medium">
                  Select 2 or more Job IDs above to compare multiple curves against the P90 ceiling line
                </div>
              </div>
            </div>

            {/* Multi-Claim Milestone Matrix Table */}
            {tab2SelectedJobIds.length > 0 && (
              <div className="bg-slate-900/80 border border-slate-800/90 rounded-2xl p-6 shadow-2xl backdrop-blur-xl">
                <div className="flex justify-between items-center mb-4">
                  <h4 className="text-sm font-bold text-white m-0">
                    Selected Job IDs vs P90 Milestone Ceiling Matrix
                  </h4>
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 font-bold">
                    {tab2SelectedJobIds.length} Claims Plotted
                  </span>
                </div>
                <div className="overflow-x-auto rounded-xl border border-slate-800">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-slate-950 text-slate-400 border-b border-slate-800">
                        <th className="p-3">Milestone Phase</th>
                        <th className="p-3">Evaluation Day</th>
                        <th className="p-3 text-right text-rose-400 font-bold">P90 Ceiling Line</th>
                        {tab2SelectedJobIds.map((jid, idx) => (
                          <th key={`th-${jid}`} className="p-3 text-right font-mono font-bold" style={{ color: CLAIM_LINE_COLORS[idx % CLAIM_LINE_COLORS.length] }}>
                            {jid} Spend
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {tab2MultiCurveData.map(m => (
                        <tr key={m.milestone_name} className="hover:bg-slate-800/40 transition">
                          <td className="p-3 font-semibold text-white">{m.milestone_name}</td>
                          <td className="p-3 text-slate-400">Day {m.eval_day}</td>
                          <td className="p-3 text-right text-rose-400 font-black">${m.p90.toLocaleString()}</td>
                          {tab2SelectedJobIds.map(jid => {
                            const spend = m[jid] || 0;
                            const isBreached = spend >= m.p90 && m.p90 > 0;
                            return (
                              <td key={`td-${jid}-${m.eval_day}`} className="p-3 text-right font-mono">
                                <span className={`font-bold ${isBreached ? 'text-rose-400 bg-rose-500/20 px-2 py-0.5 rounded border border-rose-500/40' : 'text-slate-200'}`}>
                                  ${spend.toLocaleString()}
                                </span>
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 3: CLINICAL CATEGORY SHIFT & MIGRATION METRICS */}
        {activeTab === 'shift' && (
          <div className="space-y-6">
            {/* 1. Clinical Category Migration Volume Area Chart */}
            <div className="bg-slate-900/80 border border-slate-800/90 rounded-2xl p-6 shadow-2xl backdrop-blur-xl">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4">
                <div>
                  <h3 className="text-base font-bold text-white m-0">Clinical Category Migration Volume Across Treatment Phases</h3>
                  <p className="text-xs text-slate-400 mt-1 mb-0">
                    Visualizes how treatment dollars shift chronologically from acute trauma/ER into surgical intervention, ICU care, and rehabilitative physical therapy.
                  </p>
                </div>
                <div className="px-3 py-1.5 rounded-xl bg-indigo-500/15 border border-indigo-500/30 text-indigo-300 text-xs font-bold">
                  {Object.keys(CATEGORY_COLORS).length} Clinical Specialties
                </div>
              </div>

              <div className="h-96 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={categoryMigrationPhases} margin={{ top: 20, right: 30, bottom: 20, left: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="phase" stroke="#64748b" tick={{ fontSize: 11 }} />
                    <YAxis stroke="#64748b" tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} tick={{ fontSize: 11 }} />
                    <Tooltip
                      content={({ payload, label }) => {
                        if (!payload || !payload.length) return null;
                        const phaseData = categoryMigrationPhases.find(p => p.phase === label) || {};
                        return (
                          <div className="bg-slate-900 border border-slate-700 p-4 rounded-xl shadow-2xl text-xs space-y-1.5 z-50 min-w-[260px]">
                            <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
                              <span className="font-bold text-white text-sm">{phaseData.phase_name || label}</span>
                              <span className="text-emerald-400 font-black">${(phaseData.total || 0).toLocaleString()}</span>
                            </div>
                            {payload.map((item, idx) => (
                              <div key={idx} className="flex justify-between items-center gap-4">
                                <div className="flex items-center gap-1.5">
                                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }}></span>
                                  <span className="text-slate-300 font-medium">{item.name}:</span>
                                </div>
                                <span className="font-bold text-white">${Math.round(item.value).toLocaleString()}</span>
                              </div>
                            ))}
                          </div>
                        );
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: 11, paddingTop: 10 }} />
                    {Object.keys(CATEGORY_COLORS).map(cat => (
                      <Area
                        key={cat}
                        type="monotone"
                        dataKey={cat}
                        stackId="1"
                        stroke={CATEGORY_COLORS[cat]}
                        fill={CATEGORY_COLORS[cat]}
                        fillOpacity={0.8}
                        name={cat}
                      />
                    ))}
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              {/* Color Swatch Reference */}
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 mt-6 pt-4 border-t border-slate-800">
                {Object.entries(CATEGORY_COLORS).map(([cat, col]) => (
                  <div key={cat} className="flex items-center gap-2 p-2 rounded-lg bg-slate-950 border border-slate-800">
                    <span className="w-3.5 h-3.5 rounded-md shrink-0 shadow-sm" style={{ backgroundColor: col }}></span>
                    <span className="text-xs text-slate-300 font-medium truncate">{cat}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* 2. Clinical Category Migration Metrics Table */}
            <div className="bg-slate-900/80 border border-slate-800/90 rounded-2xl p-6 shadow-2xl backdrop-blur-xl">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h4 className="text-sm font-bold text-white m-0">Clinical Category Migration Metrics & Spend Distribution</h4>
                  <p className="text-xs text-slate-400 mt-0.5 mb-0">Phase-by-phase medical spend migration and peak escalation windows across specialties.</p>
                </div>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold">
                  Total Spend: ${Math.round(portfolioStats.totalMedicalSpend).toLocaleString()}
                </span>
              </div>

              <div className="overflow-x-auto rounded-xl border border-slate-800">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-950 text-slate-400 border-b border-slate-800">
                      <th className="p-3">Clinical Specialty</th>
                      <th className="p-3 text-right">Total Spend</th>
                      <th className="p-3 text-right">Portfolio Share</th>
                      <th className="p-3 text-right">Day 0–30 (ER)</th>
                      <th className="p-3 text-right">Day 31–60 (Diag)</th>
                      <th className="p-3 text-right">Day 61–90 (Surg)</th>
                      <th className="p-3 text-right">Day 91–180 (ICU)</th>
                      <th className="p-3 text-right">Day 181–270 (Rehab)</th>
                      <th className="p-3 text-right">Day 271+ (Chronic)</th>
                      <th className="p-3 text-center">Peak Phase</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {categoryShiftList.map((c) => {
                      const color = CATEGORY_COLORS[c.category] || '#38bdf8';
                      return (
                        <tr key={c.category} className="hover:bg-slate-800/40 transition">
                          <td className="p-3 font-semibold text-white flex items-center gap-2">
                            <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: color }}></span>
                            <span>{c.category}</span>
                          </td>
                          <td className="p-3 text-right font-mono font-black text-emerald-400">
                            ${Math.round(c.total || 0).toLocaleString()}
                          </td>
                          <td className="p-3 text-right font-semibold text-slate-300">
                            {c.totalSharePct}%
                          </td>
                          <td className="p-3 text-right text-slate-300 font-mono">
                            ${Math.round(c.M30 || 0).toLocaleString()}
                          </td>
                          <td className="p-3 text-right text-slate-300 font-mono">
                            ${Math.round(c.M60 || 0).toLocaleString()}
                          </td>
                          <td className="p-3 text-right text-slate-300 font-mono">
                            ${Math.round(c.M90 || 0).toLocaleString()}
                          </td>
                          <td className="p-3 text-right text-slate-300 font-mono">
                            ${Math.round(c.M180 || 0).toLocaleString()}
                          </td>
                          <td className="p-3 text-right text-slate-300 font-mono">
                            ${Math.round(c.M270 || 0).toLocaleString()}
                          </td>
                          <td className="p-3 text-right text-slate-300 font-mono">
                            ${Math.round(c.M293 || 0).toLocaleString()}
                          </td>
                          <td className="p-3 text-center">
                            <span
                              className="px-2 py-0.5 rounded-full text-[10px] font-bold border"
                              style={{ backgroundColor: `${color}20`, color: color, borderColor: `${color}40` }}
                            >
                              {c.peakPhase} ({c.peakPct}%)
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: ALL CLAIMS EXPLORER & DEEP DIVE */}
        {activeTab === 'explorer' && (
          <div className="space-y-8">
            {/* 1. All Claims Explorer Table */}
            <div className="bg-slate-900/80 border border-slate-800/90 rounded-2xl p-6 shadow-2xl backdrop-blur-xl">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-white m-0">All Claims Explorer & Severity Progression Engine</h3>
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-bold">
                      {filteredClaims.length.toLocaleString()} Claims
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1 mb-0">
                    Claims listed in sequential order starting from Job ID 1..N. Inspect early, mid, late spend phases, inflection points, and progression patterns. Click <strong className="text-cyan-400">Deep Dive ➔</strong> to inspect the full timeline and bill ledger below.
                  </p>
                </div>

                <div className="flex items-center gap-3 w-full md:w-auto">
                  {/* Search Input */}
                  <div className="relative flex-1 md:w-64">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      placeholder="Search Job ID, Category, State, Facility..."
                      value={searchQuery}
                      onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  {/* Filter Selector */}
                  <select
                    value={severityFilter}
                    onChange={(e) => { setSeverityFilter(e.target.value); setCurrentPage(1); }}
                    className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-slate-300 focus:outline-none focus:border-indigo-500 cursor-pointer"
                  >
                    <option value="ALL">All Severities</option>
                    <option value="P90_ONLY">P90 Outliers Only</option>
                    <option value="HIGH">High Severity & P90</option>
                  </select>
                </div>
              </div>

              {/* Table with the exact requested columns */}
              <div className="overflow-x-auto rounded-xl border border-slate-800">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-950 text-slate-400 border-b border-slate-800">
                      <th className="p-3">Job ID</th>
                      <th className="p-3">State / Zip</th>
                      <th className="p-3">Duration</th>
                      <th className="p-3 text-right">Early (0–30d)</th>
                      <th className="p-3 text-right">Mid (31–90d)</th>
                      <th className="p-3 text-right">Late (91d+)</th>
                      <th className="p-3 text-right">Total Exposure</th>
                      <th className="p-3">Inflection Point</th>
                      <th className="p-3">Progression Pattern</th>
                      <th className="p-3 text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {paginatedClaims.map(c => {
                      const isPinned = c.job_id === pinnedJobId;
                      return (
                        <tr
                          key={c.job_id}
                          className={`hover:bg-slate-800/40 transition cursor-pointer ${
                            isPinned ? 'bg-indigo-950/40 border-l-4 border-l-cyan-400 shadow-inner' : ''
                          }`}
                          onClick={() => {
                            setPinnedJobId(c.job_id);
                            setSelectedBillDot(null);
                            setTimeout(() => {
                              deepDiveRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                            }, 50);
                          }}
                        >
                          {/* 1. Job ID */}
                          <td className="p-3 font-mono font-bold text-cyan-400">
                            {c.job_id}
                          </td>

                          {/* 2. State / Zip */}
                          <td className="p-3 text-slate-300">
                            {c.billing_state} {c.billing_zip}
                          </td>

                          {/* 3. Duration */}
                          <td className="p-3 text-slate-300 font-medium">
                            {c.total_treatment_span_days}d <span className="text-slate-500 text-[11px]">({c.total_bills_count} bills)</span>
                          </td>

                          {/* 4. Early Spend (0-30d) */}
                          <td className="p-3 text-right font-mono text-slate-300">
                            ${Math.round(c.early_spend_0_30d).toLocaleString()}
                          </td>

                          {/* 5. Mid Spend (31-90d) */}
                          <td className="p-3 text-right font-mono text-slate-300">
                            ${Math.round(c.mid_spend_31_90d).toLocaleString()}
                          </td>

                          {/* 6. Late Spend (91d+) */}
                          <td className="p-3 text-right font-mono text-slate-300">
                            ${Math.round(c.late_spend_91d_plus).toLocaleString()}
                          </td>

                          {/* 7. Total Exposure */}
                          <td className="p-3 text-right font-mono font-black text-emerald-400">
                            ${Math.round(c.total_billed_amount).toLocaleString()}
                          </td>

                          {/* 8. Inflection Point */}
                          <td className="p-3">
                            <span className="font-bold text-rose-300">
                              ${c.primary_inflection?.amount.toLocaleString() || c.inflection_jump_amount.toLocaleString()}
                            </span>
                            <span className="text-slate-400 text-[11px] block truncate max-w-[170px]" title={`${c.inflection_category} (Day ${c.primary_inflection?.day || c.inflection_day_num})`}>
                              {c.inflection_category} (Day {c.primary_inflection?.day || c.inflection_day_num})
                            </span>
                          </td>

                          {/* 9. Progression Pattern */}
                          <td className="p-3">
                            <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                              c.clinical_progression_pattern.includes('Acute')
                                ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                                : c.clinical_progression_pattern.includes('Late')
                                ? 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                                : c.clinical_progression_pattern.includes('Mid')
                                ? 'bg-purple-500/15 text-purple-300 border-purple-500/30'
                                : 'bg-blue-500/15 text-blue-300 border-blue-500/30'
                            }`}>
                              {c.clinical_progression_pattern}
                            </span>
                            <span className="text-slate-500 text-[10px] block mt-0.5">{c.severity_classification}</span>
                          </td>

                          {/* 10. Action View */}
                          <td className="p-3 text-center">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setDeepDiveModalClaim(c);
                              }}
                              className="cursor-pointer text-[11px] px-3.5 py-1.5 rounded-xl font-bold transition flex items-center justify-center gap-1.5 mx-auto bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-md shadow-cyan-600/25 hover:scale-105"
                            >
                              <span>Deep Dive</span>
                              <ArrowUpRight className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Pagination */}
              <div className="flex items-center justify-between pt-4 text-xs text-slate-400">
                <span>Showing {paginatedClaims.length} of {filteredClaims.length} filtered claims</span>
                <div className="flex items-center gap-2">
                  <button
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                    className="cursor-pointer px-3 py-1 rounded-lg bg-slate-800 text-white disabled:opacity-40 hover:bg-slate-700 transition"
                  >
                    Previous
                  </button>
                  <span>Page {currentPage} of {totalPages}</span>
                  <button
                    disabled={currentPage === totalPages}
                    onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                    className="cursor-pointer px-3 py-1 rounded-lg bg-slate-800 text-white disabled:opacity-40 hover:bg-slate-700 transition"
                  >
                    Next
                  </button>
                </div>
              </div>
            </div>

            {/* DEEP DIVE POPUP MODAL WINDOW */}
            {deepDiveModalClaim && (
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
                <div className="bg-[#090e1a] border border-slate-700/80 rounded-2xl w-full max-w-5xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden ring-1 ring-white/10">
                  {/* Modal Header */}
                  <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/80">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                        <Crosshair className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-lg font-black text-white m-0">
                            Claim Deep Dive: <span className="text-cyan-400 font-mono">{deepDiveModalClaim.job_id}</span>
                          </h3>
                          <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 font-bold">
                            {deepDiveModalClaim.billing_state} {deepDiveModalClaim.billing_zip}
                          </span>
                          {deepDiveModalClaim.p90_status.includes('BREACH') ? (
                            <span className="text-xs px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/40 font-black">
                              🚨 P90 OUTLIER
                            </span>
                          ) : (
                            <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-semibold">
                              Normal Range
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-400 mt-0.5 mb-0">
                          Chronological timeline & record ledger for {deepDiveModalClaim.job_id}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => setDeepDiveModalClaim(null)}
                      className="cursor-pointer p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
                      title="Close window"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Modal Body: Scrollable */}
                  <div className="p-6 overflow-y-auto space-y-6 flex-1">
                    {/* Top 3 Metric Boxes */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {/* Box 1: Total Claim Exposure */}
                      <div className="bg-slate-900/90 border border-emerald-500/40 rounded-xl p-4 shadow-lg backdrop-blur-sm">
                        <div className="flex items-center justify-between">
                          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider m-0">Total Claim Exposure</p>
                          <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
                            <DollarSign className="w-4 h-4" />
                          </div>
                        </div>
                        <h4 className="text-2xl font-black text-emerald-400 mt-2 mb-0">
                          ${Math.round(deepDiveModalClaim.total_billed_amount).toLocaleString()}
                        </h4>
                        <p className="text-xs text-slate-400 mt-1 mb-0">
                          {deepDiveModalClaim.total_treatment_span_days} treatment days • {deepDiveModalClaim.total_bills_count} bills
                        </p>
                      </div>

                      {/* Box 2: Inflection Point */}
                      <div className="bg-slate-900/90 border border-rose-500/40 rounded-xl p-4 shadow-lg backdrop-blur-sm">
                        <div className="flex items-center justify-between">
                          <p className="text-xs font-bold text-rose-300 uppercase tracking-wider m-0">Inflection Point</p>
                          <span className="text-[10px] px-2 py-0.5 rounded bg-rose-500/30 text-rose-300 font-bold border border-rose-500/40">
                            Day {deepDiveModalClaim.primary_inflection?.day || deepDiveModalClaim.inflection_day_num}
                          </span>
                        </div>
                        <h4 className="text-2xl font-black text-rose-400 mt-2 mb-0">
                          ${deepDiveModalClaim.primary_inflection?.amount.toLocaleString() || deepDiveModalClaim.inflection_jump_amount.toLocaleString()}
                        </h4>
                        <p className="text-xs text-slate-300 mt-1 mb-0 truncate" title={`${deepDiveModalClaim.inflection_category} • ${deepDiveModalClaim.inflection_facility}`}>
                          {deepDiveModalClaim.inflection_category} • {deepDiveModalClaim.inflection_facility}
                        </p>
                      </div>

                      {/* Box 3: Progression Pattern */}
                      <div className="bg-slate-900/90 border border-indigo-500/40 rounded-xl p-4 shadow-lg backdrop-blur-sm">
                        <div className="flex items-center justify-between">
                          <p className="text-xs font-bold text-indigo-300 uppercase tracking-wider m-0">Progression Pattern</p>
                          <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                            Risk {deepDiveModalClaim.early_risk_score}/100
                          </span>
                        </div>
                        <h4 className="text-sm font-bold text-white mt-2.5 mb-0 truncate" title={deepDiveModalClaim.clinical_progression_pattern}>
                          {deepDiveModalClaim.clinical_progression_pattern}
                        </h4>
                        <p className="text-xs text-slate-400 mt-1 mb-0">
                          {deepDiveModalClaim.severity_classification}
                        </p>
                      </div>
                    </div>

                    {/* Chronological Bill Timeline / Ledger Table */}
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-bold text-white m-0">
                          Chronological Bill Timeline & Ledger ({deepDiveModalClaim.bill_rows?.length || 0} Records)
                        </h4>
                        <span className="text-xs text-rose-400 font-semibold flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse"></span>
                          Highlighted row indicates the Primary Inflection Spike
                        </span>
                      </div>

                      <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/80">
                        <table className="w-full text-left text-xs border-collapse">
                          <thead>
                            <tr className="bg-slate-950 text-slate-400 border-b border-slate-800">
                              <th className="p-3">#</th>
                              <th className="p-3">Record ID</th>
                              <th className="p-3">Elapsed</th>
                              <th className="p-3">Service Date</th>
                              <th className="p-3">Category</th>
                              <th className="p-3">Facility / Provider</th>
                              <th className="p-3 text-right">Billed Amount</th>
                              <th className="p-3 text-right">Cumulative Spend</th>
                              <th className="p-3 text-center">Status</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-800/60">
                            {(deepDiveModalClaim.bill_rows || []).map((b, idx) => {
                              const isPrimary = b.is_primary_inflection;
                              const isSecondary = b.is_secondary_inflection;
                              return (
                                <tr
                                  key={`modal-bill-${b.record_id || idx}`}
                                  className={`transition ${
                                    isPrimary
                                      ? 'bg-rose-950/50 hover:bg-rose-950/70 border-l-4 border-l-rose-500 font-semibold'
                                      : isSecondary
                                      ? 'bg-purple-950/40 hover:bg-purple-950/60 border-l-4 border-l-purple-500 font-medium'
                                      : 'hover:bg-slate-800/40'
                                  }`}
                                >
                                  <td className="p-3 text-slate-500">{idx + 1}</td>
                                  <td className="p-3 font-mono text-cyan-400 font-bold">{b.record_id}</td>
                                  <td className="p-3 font-semibold text-slate-300">Day {b.elapsed_days}</td>
                                  <td className="p-3 text-slate-400">{b.effective_service_date ? new Date(b.effective_service_date).toLocaleDateString() : b.bill_line_item_service_date}</td>
                                  <td className="p-3">
                                    <span className="px-2 py-0.5 rounded text-[11px] font-medium" style={{ backgroundColor: `${CATEGORY_COLORS[b.bill_line_item_category] || '#64748b'}25`, color: CATEGORY_COLORS[b.bill_line_item_category] || '#cbd5e1' }}>
                                      {b.bill_line_item_category}
                                    </span>
                                  </td>
                                  <td className="p-3 text-slate-300">
                                    <span className="font-semibold text-white">{b.facility_name}</span>
                                    <span className="text-slate-500 text-[11px] block">{b.provider_name}</span>
                                  </td>
                                  <td className="p-3 text-right font-mono font-bold text-white">
                                    ${b.bill_line_item_build_amount.toLocaleString()}
                                  </td>
                                  <td className="p-3 text-right font-mono text-cyan-400 font-bold">
                                    ${b.cumulative_spend.toLocaleString()}
                                  </td>
                                  <td className="p-3 text-center">
                                    {isPrimary ? (
                                      <span className="px-2.5 py-0.5 rounded-full bg-rose-500/30 text-rose-300 border border-rose-500/50 text-[10px] font-black">
                                        ⭐ INFLECTION POINT
                                      </span>
                                    ) : isSecondary ? (
                                      <span className="px-2.5 py-0.5 rounded-full bg-purple-500/30 text-purple-300 border border-purple-500/50 text-[10px] font-black">
                                        ⚡ SECONDARY SPIKE
                                      </span>
                                    ) : (
                                      <span className="text-slate-500 text-[11px]">Routine</span>
                                    )}
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>

                  {/* Modal Footer */}
                  <div className="px-6 py-3 border-t border-slate-800 bg-slate-900/80 flex items-center justify-between text-xs text-slate-400">
                    <span>Job ID: <strong className="text-cyan-400 font-mono">{deepDiveModalClaim.job_id}</strong> • Total Records: {deepDiveModalClaim.bill_rows?.length || 0}</span>
                    <button
                      onClick={() => setDeepDiveModalClaim(null)}
                      className="cursor-pointer px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold transition"
                    >
                      Close
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950/70 py-4 px-6 text-center text-xs text-slate-500 relative z-10">
        ClaimOptima™ Temporal Severity Studio • Dynamic P90 Inflection Discovery • Ready for Power BI Star-Schema Export
      </footer>
    </div>
  );
}
