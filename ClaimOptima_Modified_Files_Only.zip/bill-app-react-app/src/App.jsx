import React, { useState, useEffect, useMemo, useRef } from 'react';
import * as XLSX from 'xlsx';
import {
  TrendingUp, AlertTriangle, Activity, DollarSign,
  Upload, Layers, BarChart3, Download, Sparkles, FileSpreadsheet, X,
  ShieldAlert, Database, Search, Crosshair, Zap, ArrowUpRight, Flame,
  SlidersHorizontal, Sparkle, BarChart2, FileText, Printer, Check, Copy,
  Info, Filter, Stethoscope, ChevronRight, User, Calendar, MapPin
} from 'lucide-react';
import {
  ResponsiveContainer, LineChart, Line, AreaChart, Area, XAxis, YAxis, Tooltip,
  Legend, CartesianGrid, BarChart, Bar, ScatterChart,
  Scatter, ZAxis, Cell, ReferenceLine
} from 'recharts';
import { parseAndAnalyzeRawBills, generate3000ClaimsDemo, CATEGORY_COLORS, exportPowerBiModel } from './dataEngine';

const CLAIM_LINE_COLORS = [
  '#06b6d4', // Cyan
  '#ec4899', // Pink / Fuchsia
  '#f59e0b', // Amber
  '#10b981', // Emerald
  '#a855f7', // Purple
  '#38bdf8', // Sky Blue
  '#f97316', // Orange
  '#14b8a6', // Teal
  '#e11d48'  // Rose
];

// Sample dataset with CLM-1008 having 18 distinct bill records with Date of Service (DOS)
const INITIAL_SAMPLE_BILLS = [
  {"job_id": "CLM-1008", "claim_status": "Open", "claimant_name": "Marcus Vance", "diagnosis": "L4-S1 Lumbar Disc Herniation with Radiculopathy", "body_part": "Lumbar Spine", "line_of_business": "Commercial Auto Liability", "procedure_description": "Emergency Trauma Triage & X-Rays", "record_id": "REC-1031", "tag_id": "TAG-5031", "facility_name": "Penn General Hospital", "provider_name": "Dr. Susan Davis", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "1/15/2024 12:00:00 AM", "end_date": "1/15/2024 12:00:00 AM", "bill_line_item_service_date": "1/15/2024 12:00:00 AM", "bill_line_item_build_amount": 3200, "bill_line_item_category": "Hospital / ER"},
  {"job_id": "CLM-1008", "claim_status": "Open", "claimant_name": "Marcus Vance", "diagnosis": "L4-S1 Lumbar Disc Herniation with Radiculopathy", "body_part": "Lumbar Spine", "line_of_business": "Commercial Auto Liability", "procedure_description": "Initial Attending Physician Evaluation", "record_id": "REC-1032", "tag_id": "TAG-5032", "facility_name": "Dr. Susan Davis Clinic", "provider_name": "Dr. Susan Davis", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "1/23/2024 12:00:00 AM", "end_date": "1/23/2024 12:00:00 AM", "bill_line_item_service_date": "1/23/2024 12:00:00 AM", "bill_line_item_build_amount": 1200, "bill_line_item_category": "Treating Physician"},
  {"job_id": "CLM-1008", "claim_status": "Open", "claimant_name": "Marcus Vance", "diagnosis": "L4-S1 Lumbar Disc Herniation with Radiculopathy", "body_part": "Lumbar Spine", "line_of_business": "Commercial Auto Liability", "procedure_description": "MRI Lumbar Spine 3T Imaging", "record_id": "REC-1033", "tag_id": "TAG-5033", "facility_name": "Penn Radiology", "provider_name": "Dr. Arthur Conan", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "1/29/2024 12:00:00 AM", "end_date": "1/29/2024 12:00:00 AM", "bill_line_item_service_date": "1/29/2024 12:00:00 AM", "bill_line_item_build_amount": 4500, "bill_line_item_category": "Diagnostic Imaging"},
  {"job_id": "CLM-1008", "claim_status": "Open", "claimant_name": "Marcus Vance", "diagnosis": "L4-S1 Lumbar Disc Herniation with Radiculopathy", "body_part": "Lumbar Spine", "line_of_business": "Commercial Auto Liability", "procedure_description": "Neurosurgical Specialist Consult", "record_id": "REC-1034", "tag_id": "TAG-5034", "facility_name": "Penn Spine Institute", "provider_name": "Dr. William Sterling", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "2/6/2024 12:00:00 AM", "end_date": "2/6/2024 12:00:00 AM", "bill_line_item_service_date": "2/6/2024 12:00:00 AM", "bill_line_item_build_amount": 1800, "bill_line_item_category": "Treating Physician"},
  {"job_id": "CLM-1008", "claim_status": "Open", "claimant_name": "Marcus Vance", "diagnosis": "L4-S1 Lumbar Disc Herniation with Radiculopathy", "body_part": "Lumbar Spine", "line_of_business": "Commercial Auto Liability", "procedure_description": "Physical Therapy Evaluation & Core Rehab", "record_id": "REC-1035", "tag_id": "TAG-5035", "facility_name": "Keystone Therapy", "provider_name": "Keystone PT Team", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "2/19/2024 12:00:00 AM", "end_date": "2/19/2024 12:00:00 AM", "bill_line_item_service_date": "2/19/2024 12:00:00 AM", "bill_line_item_build_amount": 450, "bill_line_item_category": "Physical Therapy"},
  {"job_id": "CLM-1008", "claim_status": "Open", "claimant_name": "Marcus Vance", "diagnosis": "L4-S1 Lumbar Disc Herniation with Radiculopathy", "body_part": "Lumbar Spine", "line_of_business": "Commercial Auto Liability", "procedure_description": "Physical Therapy Session 2", "record_id": "REC-1036", "tag_id": "TAG-5036", "facility_name": "Keystone Therapy", "provider_name": "Keystone PT Team", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "2/26/2024 12:00:00 AM", "end_date": "2/26/2024 12:00:00 AM", "bill_line_item_service_date": "2/26/2024 12:00:00 AM", "bill_line_item_build_amount": 450, "bill_line_item_category": "Physical Therapy"},
  {"job_id": "CLM-1008", "claim_status": "Open", "claimant_name": "Marcus Vance", "diagnosis": "L4-S1 Lumbar Disc Herniation with Radiculopathy", "body_part": "Lumbar Spine", "line_of_business": "Commercial Auto Liability", "procedure_description": "Physical Therapy Session 3", "record_id": "REC-1037", "tag_id": "TAG-5037", "facility_name": "Keystone Therapy", "provider_name": "Keystone PT Team", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "3/5/2024 12:00:00 AM", "end_date": "3/5/2024 12:00:00 AM", "bill_line_item_service_date": "3/5/2024 12:00:00 AM", "bill_line_item_build_amount": 450, "bill_line_item_category": "Physical Therapy"},
  {"job_id": "CLM-1008", "claim_status": "Open", "claimant_name": "Marcus Vance", "diagnosis": "L4-S1 Lumbar Disc Herniation with Radiculopathy", "body_part": "Lumbar Spine", "line_of_business": "Commercial Auto Liability", "procedure_description": "Physical Therapy Session 4", "record_id": "REC-1038", "tag_id": "TAG-5038", "facility_name": "Keystone Therapy", "provider_name": "Keystone PT Team", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "3/12/2024 12:00:00 AM", "end_date": "3/12/2024 12:00:00 AM", "bill_line_item_service_date": "3/12/2024 12:00:00 AM", "bill_line_item_build_amount": 450, "bill_line_item_category": "Physical Therapy"},
  {"job_id": "CLM-1008", "claim_status": "Open", "claimant_name": "Marcus Vance", "diagnosis": "L4-S1 Lumbar Disc Herniation with Radiculopathy", "body_part": "Lumbar Spine", "line_of_business": "Commercial Auto Liability", "procedure_description": "L5-S1 Epidural Steroid Injection", "record_id": "REC-1039", "tag_id": "TAG-5039", "facility_name": "Pain Solutions Clinic", "provider_name": "Dr. Rachel Green", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "3/26/2024 12:00:00 AM", "end_date": "3/26/2024 12:00:00 AM", "bill_line_item_service_date": "3/26/2024 12:00:00 AM", "bill_line_item_build_amount": 2200, "bill_line_item_category": "Pain Management"},
  {"job_id": "CLM-1008", "claim_status": "Open", "claimant_name": "Marcus Vance", "diagnosis": "L4-S1 Lumbar Disc Herniation with Radiculopathy", "body_part": "Lumbar Spine", "line_of_business": "Commercial Auto Liability", "procedure_description": "L4-S1 TLIF Spinal Fusion & Decompression Surgery", "record_id": "REC-1040", "tag_id": "TAG-5040", "facility_name": "Penn Spine Institute", "provider_name": "Dr. William Sterling", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "4/14/2024 12:00:00 AM", "end_date": "4/16/2024 12:00:00 AM", "bill_line_item_service_date": "4/14/2024 12:00:00 AM", "bill_line_item_build_amount": 62000, "bill_line_item_category": "Inpatient Surgery"},
  {"job_id": "CLM-1008", "claim_status": "Open", "claimant_name": "Marcus Vance", "diagnosis": "L4-S1 Lumbar Disc Herniation with Radiculopathy", "body_part": "Lumbar Spine", "line_of_business": "Commercial Auto Liability", "procedure_description": "Post-Op ICU Intensive Monitoring & Recovery", "record_id": "REC-1041", "tag_id": "TAG-5041", "facility_name": "Penn Rehab Hospital", "provider_name": "Dr. William Sterling", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "4/17/2024 12:00:00 AM", "end_date": "4/19/2024 12:00:00 AM", "bill_line_item_service_date": "4/17/2024 12:00:00 AM", "bill_line_item_build_amount": 12500, "bill_line_item_category": "Inpatient / ICU"},
  {"job_id": "CLM-1008", "claim_status": "Open", "claimant_name": "Marcus Vance", "diagnosis": "L4-S1 Lumbar Disc Herniation with Radiculopathy", "body_part": "Lumbar Spine", "line_of_business": "Commercial Auto Liability", "procedure_description": "Post-Op Attending Progress Follow-up", "record_id": "REC-1042", "tag_id": "TAG-5042", "facility_name": "Dr. Susan Davis Clinic", "provider_name": "Dr. Susan Davis", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "5/5/2024 12:00:00 AM", "end_date": "5/5/2024 12:00:00 AM", "bill_line_item_service_date": "5/5/2024 12:00:00 AM", "bill_line_item_build_amount": 1600, "bill_line_item_category": "Treating Physician"},
  {"job_id": "CLM-1008", "claim_status": "Open", "claimant_name": "Marcus Vance", "diagnosis": "L4-S1 Lumbar Disc Herniation with Radiculopathy", "body_part": "Lumbar Spine", "line_of_business": "Commercial Auto Liability", "procedure_description": "Post-Surgical Physical Rehab Session 1", "record_id": "REC-1043", "tag_id": "TAG-5043", "facility_name": "Keystone Therapy", "provider_name": "Keystone PT Team", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "5/20/2024 12:00:00 AM", "end_date": "5/20/2024 12:00:00 AM", "bill_line_item_service_date": "5/20/2024 12:00:00 AM", "bill_line_item_build_amount": 650, "bill_line_item_category": "Physical Therapy"},
  {"job_id": "CLM-1008", "claim_status": "Open", "claimant_name": "Marcus Vance", "diagnosis": "L4-S1 Lumbar Disc Herniation with Radiculopathy", "body_part": "Lumbar Spine", "line_of_business": "Commercial Auto Liability", "procedure_description": "Post-Surgical Physical Rehab Session 2", "record_id": "REC-1044", "tag_id": "TAG-5044", "facility_name": "Keystone Therapy", "provider_name": "Keystone PT Team", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "6/4/2024 12:00:00 AM", "end_date": "6/4/2024 12:00:00 AM", "bill_line_item_service_date": "6/4/2024 12:00:00 AM", "bill_line_item_build_amount": 650, "bill_line_item_category": "Physical Therapy"},
  {"job_id": "CLM-1008", "claim_status": "Open", "claimant_name": "Marcus Vance", "diagnosis": "L4-S1 Lumbar Disc Herniation with Radiculopathy", "body_part": "Lumbar Spine", "line_of_business": "Commercial Auto Liability", "procedure_description": "Post-Surgical Physical Rehab Session 3", "record_id": "REC-1045", "tag_id": "TAG-5045", "facility_name": "Keystone Therapy", "provider_name": "Keystone PT Team", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "6/24/2024 12:00:00 AM", "end_date": "6/24/2024 12:00:00 AM", "bill_line_item_service_date": "6/24/2024 12:00:00 AM", "bill_line_item_build_amount": 650, "bill_line_item_category": "Physical Therapy"},
  {"job_id": "CLM-1008", "claim_status": "Open", "claimant_name": "Marcus Vance", "diagnosis": "L4-S1 Lumbar Disc Herniation with Radiculopathy", "body_part": "Lumbar Spine", "line_of_business": "Commercial Auto Liability", "procedure_description": "Facet Joint Radiofrequency Ablation", "record_id": "REC-1046", "tag_id": "TAG-5046", "facility_name": "Pain Solutions Clinic", "provider_name": "Dr. Rachel Green", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "7/29/2024 12:00:00 AM", "end_date": "7/29/2024 12:00:00 AM", "bill_line_item_service_date": "7/29/2024 12:00:00 AM", "bill_line_item_build_amount": 5200, "bill_line_item_category": "Pain Management"},
  {"job_id": "CLM-1008", "claim_status": "Open", "claimant_name": "Marcus Vance", "diagnosis": "L4-S1 Lumbar Disc Herniation with Radiculopathy", "body_part": "Lumbar Spine", "line_of_business": "Commercial Auto Liability", "procedure_description": "Occupational Conditioning & Work Hardening", "record_id": "REC-1047", "tag_id": "TAG-5047", "facility_name": "Penn Occupational Rehab", "provider_name": "Dr. Susan Davis", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "9/2/2024 12:00:00 AM", "end_date": "9/2/2024 12:00:00 AM", "bill_line_item_service_date": "9/2/2024 12:00:00 AM", "bill_line_item_build_amount": 2800, "bill_line_item_category": "Physical Therapy"},
  {"job_id": "CLM-1008", "claim_status": "Open", "claimant_name": "Marcus Vance", "diagnosis": "L4-S1 Lumbar Disc Herniation with Radiculopathy", "body_part": "Lumbar Spine", "line_of_business": "Commercial Auto Liability", "procedure_description": "Final MMI & Impairment Evaluation", "record_id": "REC-1048", "tag_id": "TAG-5048", "facility_name": "Dr. Susan Davis Clinic", "provider_name": "Dr. Susan Davis", "provider_billing_state": "PA", "provider_billing_zip_code": "19104", "start_date": "10/7/2024 12:00:00 AM", "end_date": "10/7/2024 12:00:00 AM", "bill_line_item_service_date": "10/7/2024 12:00:00 AM", "bill_line_item_build_amount": 1900, "bill_line_item_category": "Treating Physician"},

  // CLM-1005: 8 Bills (Closed Claim Example - Acute Phase ER Outlier Spike)
  {"job_id": "CLM-1005", "claim_status": "Closed", "claimant_name": "Elena Rostova", "diagnosis": "Right Glenohumeral Rotator Cuff Tear & Impingement", "body_part": "Right Shoulder", "line_of_business": "Workers Compensation", "procedure_description": "Emergency Trauma Resuscitation", "record_id": "REC-1019", "tag_id": "TAG-5019", "facility_name": "Chicago Trauma Center", "provider_name": "Dr. Elena Rostova", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "1/15/2024 12:00:00 AM", "end_date": "1/17/2024 12:00:00 AM", "bill_line_item_service_date": "1/15/2024 12:00:00 AM", "bill_line_item_build_amount": 84500, "bill_line_item_category": "Hospital / ER"},
  {"job_id": "CLM-1005", "claim_status": "Closed", "claimant_name": "Elena Rostova", "diagnosis": "Right Glenohumeral Rotator Cuff Tear & Impingement", "body_part": "Right Shoulder", "line_of_business": "Workers Compensation", "procedure_description": "Urgent Arthroscopic Repair Surgery", "record_id": "REC-1020", "tag_id": "TAG-5020", "facility_name": "Chicago Trauma Center", "provider_name": "Dr. Elena Rostova", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "1/15/2024 12:00:00 AM", "end_date": "1/17/2024 12:00:00 AM", "bill_line_item_service_date": "1/15/2024 12:00:00 AM", "bill_line_item_build_amount": 14200, "bill_line_item_category": "Inpatient Surgery"},
  {"job_id": "CLM-1005", "claim_status": "Closed", "claimant_name": "Elena Rostova", "diagnosis": "Right Glenohumeral Rotator Cuff Tear & Impingement", "body_part": "Right Shoulder", "line_of_business": "Workers Compensation", "procedure_description": "ICU Hemodynamic Stabilization", "record_id": "REC-1021", "tag_id": "TAG-5021", "facility_name": "Neuro Recovery Institute", "provider_name": "Dr. Elena Rostova", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "1/30/2024 12:00:00 AM", "end_date": "2/1/2024 12:00:00 AM", "bill_line_item_service_date": "1/30/2024 12:00:00 AM", "bill_line_item_build_amount": 5800, "bill_line_item_category": "Inpatient / ICU"},
  {"job_id": "CLM-1005", "claim_status": "Closed", "claimant_name": "Elena Rostova", "diagnosis": "Right Glenohumeral Rotator Cuff Tear & Impingement", "body_part": "Right Shoulder", "line_of_business": "Workers Compensation", "procedure_description": "Surgical Follow-up Evaluation", "record_id": "REC-1022", "tag_id": "TAG-5022", "facility_name": "Dr. Kevin Patel Clinic", "provider_name": "Dr. Kevin Patel", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "2/24/2024 12:00:00 AM", "end_date": "2/24/2024 12:00:00 AM", "bill_line_item_service_date": "2/24/2024 12:00:00 AM", "bill_line_item_build_amount": 3400, "bill_line_item_category": "Treating Physician"},
  {"job_id": "CLM-1005", "claim_status": "Closed", "claimant_name": "Elena Rostova", "diagnosis": "Right Glenohumeral Rotator Cuff Tear & Impingement", "body_part": "Right Shoulder", "line_of_business": "Workers Compensation", "procedure_description": "Post-Op Shoulder Physical Therapy", "record_id": "REC-1023", "tag_id": "TAG-5023", "facility_name": "Premier PT", "provider_name": "Premier Rehab Staff", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "4/19/2024 12:00:00 AM", "end_date": "4/19/2024 12:00:00 AM", "bill_line_item_service_date": "4/19/2024 12:00:00 AM", "bill_line_item_build_amount": 2800, "bill_line_item_category": "Physical Therapy"},
  {"job_id": "CLM-1005", "claim_status": "Closed", "claimant_name": "Elena Rostova", "diagnosis": "Right Glenohumeral Rotator Cuff Tear & Impingement", "body_part": "Right Shoulder", "line_of_business": "Workers Compensation", "procedure_description": "Clinical Progress Check", "record_id": "REC-1024", "tag_id": "TAG-5024", "facility_name": "Dr. Kevin Patel Clinic", "provider_name": "Dr. Kevin Patel", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "6/23/2024 12:00:00 AM", "end_date": "6/23/2024 12:00:00 AM", "bill_line_item_service_date": "6/23/2024 12:00:00 AM", "bill_line_item_build_amount": 2400, "bill_line_item_category": "Treating Physician"},
  {"job_id": "CLM-1005", "claim_status": "Closed", "claimant_name": "Elena Rostova", "diagnosis": "Right Glenohumeral Rotator Cuff Tear & Impingement", "body_part": "Right Shoulder", "line_of_business": "Workers Compensation", "procedure_description": "Functional Assessment", "record_id": "REC-1025", "tag_id": "TAG-5025", "facility_name": "Dr. Kevin Patel Clinic", "provider_name": "Dr. Kevin Patel", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "9/1/2024 12:00:00 AM", "end_date": "9/1/2024 12:00:00 AM", "bill_line_item_service_date": "9/1/2024 12:00:00 AM", "bill_line_item_build_amount": 2100, "bill_line_item_category": "Treating Physician"},
  {"job_id": "CLM-1005", "claim_status": "Closed", "claimant_name": "Elena Rostova", "diagnosis": "Right Glenohumeral Rotator Cuff Tear & Impingement", "body_part": "Right Shoulder", "line_of_business": "Workers Compensation", "procedure_description": "Settlement & Final Clearance", "record_id": "REC-1026", "tag_id": "TAG-5026", "facility_name": "Midwest Occupational", "provider_name": "Dr. David Kim", "provider_billing_state": "IL", "provider_billing_zip_code": "60611", "start_date": "10/31/2024 12:00:00 AM", "end_date": "10/31/2024 12:00:00 AM", "bill_line_item_service_date": "10/31/2024 12:00:00 AM", "bill_line_item_build_amount": 1900, "bill_line_item_category": "Treating Physician"}
];

export default function App() {
  const [data, setData] = useState(null);
  const [activeTab, setActiveTab] = useState('executive');
  const [datasetLabel, setDatasetLabel] = useState('Default Sample (3,000 Claims & Outlier Focus)');
  const [pinnedJobId, setPinnedJobId] = useState('CLM-1001');
  const [tab2SelectedJobIds, setTab2SelectedJobIds] = useState(['CLM-1001', 'CLM-1008']);
  const [scatterSortBy, setScatterSortBy] = useState('sequence');
  const [selectedPhaseBreach, setSelectedPhaseBreach] = useState('ALL');
  const [selectedBillDot, setSelectedBillDot] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [severityFilter, setSeverityFilter] = useState('ALL');
  
  // Status filter state: 'ALL', 'OPEN', 'CLOSED'
  const [statusFilter, setStatusFilter] = useState('ALL');

  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 15;
  const fileInputRef = useRef(null);
  
  // Modal State for Medical Summary Document / Claim Dossier
  const [deepDiveModalClaim, setDeepDiveModalClaim] = useState(null);
  const [modalViewMode, setModalViewMode] = useState('dossier'); // 'dossier' or 'ledger'
  const [copiedText, setCopiedText] = useState(false);

  useEffect(() => {
    const synthetic = generate3000ClaimsDemo();
    const res = parseAndAnalyzeRawBills(synthetic);
    setData(res);
    setDatasetLabel(`High-Scale Portfolio Dataset (3,000 Claims, ${res.rawBills.length.toLocaleString()} Bills)`);
    setPinnedJobId('CLM-1001');
  }, []);

  const handleFileUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsName = wb.SheetNames[0];
        const rawJson = XLSX.utils.sheet_to_json(wb.Sheets[wsName]);
        const res = parseAndAnalyzeRawBills(rawJson);
        if (res) {
          setData(res);
          setDatasetLabel(`${file.name} (${res.portfolioStats.totalClaims.toLocaleString()} Claims, ${res.rawBills.length.toLocaleString()} Bills)`);
          const outliers = res.claimSummaries.filter(c => c.is_p90_outlier === 1 || c.p90_status.includes('BREACH'));
          setPinnedJobId(outliers[0]?.job_id || res.claimSummaries[0]?.job_id || null);
          setCurrentPage(1);
          setSelectedBillDot(null);
        } else {
          alert('Could not find valid claim/bill records in uploaded file.');
        }
      } catch (err) {
        alert(`Error reading file: ${err.message}`);
      }
    };
    reader.readAsBinaryString(file);
  };

  const handleLoad3000 = () => {
    setTimeout(() => {
      const synthetic = generate3000ClaimsDemo();
      const res = parseAndAnalyzeRawBills(synthetic);
      setData(res);
      setDatasetLabel(`High-Scale Synthetic Dataset (3,000 Claims, ${res.rawBills.length.toLocaleString()} Bills)`);
      const outliers = res.claimSummaries.filter(c => c.is_p90_outlier === 1 || c.p90_status.includes('BREACH'));
      setPinnedJobId(outliers[0]?.job_id || res.claimSummaries[0]?.job_id || null);
      setCurrentPage(1);
      setSelectedBillDot(null);
    }, 50);
  };

  const handleDownloadPowerBi = () => {
    if (!data) return;
    exportPowerBiModel(data);
  };

  const handleDownloadCalculatedJson = () => {
    if (!data) return;
    const exportObj = {
      portfolioStats: data.portfolioStats,
      milestoneStats: data.milestoneStats,
      categoryShiftList: data.categoryShiftList,
      categoryMigrationPhases: data.categoryMigrationPhases,
      claimSummaries: data.claimSummaries.map(c => {
        const { bill_rows, ...summary } = c;
        return summary;
      }),
      rawBills: data.rawBills
    };
    const blob = new Blob([JSON.stringify(exportObj, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ClaimOptima_Calculated_Analysis_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Status Filtered Claims
  const statusFilteredClaimSummaries = useMemo(() => {
    if (!data?.claimSummaries) return [];
    if (statusFilter === 'ALL') return data.claimSummaries;
    return data.claimSummaries.filter(c => c.claim_status.toUpperCase() === statusFilter);
  }, [data, statusFilter]);

  // Recalculated dynamic KPI metrics based on Status Filter
  const activeKpis = useMemo(() => {
    if (!statusFilteredClaimSummaries.length) {
      return {
        totalClaims: 0,
        totalSpend: 0,
        avgSpend: 0,
        p90Ceiling: data?.portfolioStats?.finalP90Threshold || 0,
        outlierCount: 0,
        outlierShare: 0
      };
    }
    const totSpend = statusFilteredClaimSummaries.reduce((sum, c) => sum + c.total_billed_amount, 0);
    const p90 = data?.portfolioStats?.finalP90Threshold || 0;
    const outliers = statusFilteredClaimSummaries.filter(c => c.total_billed_amount >= p90 || c.is_p90_outlier === 1 || c.p90_status.includes('BREACH'));
    const outlierSpend = outliers.reduce((sum, c) => sum + c.total_billed_amount, 0);
    return {
      totalClaims: statusFilteredClaimSummaries.length,
      totalSpend: totSpend,
      avgSpend: totSpend / (statusFilteredClaimSummaries.length || 1),
      p90Ceiling: p90,
      outlierCount: outliers.length,
      outlierShare: Math.round((outlierSpend / (totSpend || 1)) * 100)
    };
  }, [statusFilteredClaimSummaries, data]);

  const activePinnedClaim = useMemo(() => {
    if (!statusFilteredClaimSummaries.length) return null;
    return statusFilteredClaimSummaries.find(c => c.job_id === pinnedJobId) || statusFilteredClaimSummaries[0];
  }, [statusFilteredClaimSummaries, pinnedJobId]);

  // Claims plotted on Top Scatter (Sequential Claim 1..N on X-axis vs Total Billed Amount on Y-axis)
  const portfolioScatterClaims = useMemo(() => {
    if (!statusFilteredClaimSummaries.length) return [];
    const list = [...statusFilteredClaimSummaries].sort((a, b) => a.claim_index - b.claim_index);
    const p90 = data?.portfolioStats?.finalP90Threshold || 0;
    return list.map((c, idx) => {
      const isAboveP90 = c.total_billed_amount >= p90;
      return {
        ...c,
        plot_x_index: idx + 1,
        plot_x_label: `Claim #${idx + 1}`,
        is_above_p90: isAboveP90,
        dot_z_score: isAboveP90 ? 800 : 70
      };
    });
  }, [statusFilteredClaimSummaries, data]);

  const allJobIdList = useMemo(() => {
    if (!statusFilteredClaimSummaries.length) return [];
    return statusFilteredClaimSummaries.map(c => c.job_id);
  }, [statusFilteredClaimSummaries]);

  const categoryMigrationPhases = useMemo(() => {
    return data?.categoryMigrationPhases || [];
  }, [data]);

  const categoryShiftList = useMemo(() => {
    return data?.categoryShiftList || [];
  }, [data]);

  const uniqueCategories = useMemo(() => {
    if (data?.uniqueCategories?.length) return data.uniqueCategories;
    if (data?.categoryShiftList?.length) return data.categoryShiftList.map(c => c.category);
    return Object.keys(CATEGORY_COLORS);
  }, [data]);

  const dynamicCategoryColors = useMemo(() => {
    return data?.dynamicCategoryColors || CATEGORY_COLORS;
  }, [data]);

  // S-Curve dataset comparing P90 Ceiling Line against multiple selected Job IDs
  const tab2MultiCurveData = useMemo(() => {
    if (!data?.milestoneStats) return [];
    return data.milestoneStats.map(m => {
      const p90Val = Math.round(m.p90);
      const point = {
        name: `Day ${m.eval_day}`,
        eval_day: m.eval_day,
        milestone_name: m.milestone_name,
        p90: p90Val
      };

      tab2SelectedJobIds.forEach(jobId => {
        let spend = 0;
        if (data.claimSpendAtMilestone?.[m.eval_day]?.[jobId] !== undefined) {
          spend = Math.round(data.claimSpendAtMilestone[m.eval_day][jobId]);
        } else {
          const claim = statusFilteredClaimSummaries.find(c => c.job_id === jobId);
          if (claim?.bill_rows) {
            spend = Math.round(
              claim.bill_rows
                .filter(b => b.elapsed_days <= m.eval_day)
                .reduce((sum, b) => sum + b.bill_line_item_build_amount, 0)
            );
          }
        }
        point[jobId] = spend;
      });

      return point;
    });
  }, [data, tab2SelectedJobIds, statusFilteredClaimSummaries]);

  // All claims for Explorer Tab
  const filteredClaims = useMemo(() => {
    if (!statusFilteredClaimSummaries.length) return [];
    const list = [...statusFilteredClaimSummaries].sort((a, b) => a.claim_index - b.claim_index);
    return list.filter(c => {
      const matchSearch = (
        c.job_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.claimant_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.diagnosis.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.inflection_category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.inflection_facility.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.billing_state.toLowerCase().includes(searchQuery.toLowerCase())
      );
      if (!matchSearch) return false;
      if (severityFilter === 'P90_ONLY') return c.p90_status.includes('BREACH') || c.is_p90_outlier === 1;
      if (severityFilter === 'HIGH') return c.severity_classification.includes('High') || c.severity_classification.includes('P90');
      return true;
    });
  }, [statusFilteredClaimSummaries, searchQuery, severityFilter]);

  const paginatedClaims = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredClaims.slice(start, start + pageSize);
  }, [filteredClaims, currentPage, pageSize]);

  const totalPages = Math.ceil(filteredClaims.length / pageSize) || 1;

  const handleCopyDossier = (claim) => {
    if (!claim) return;
    const text = `CLAIMOPTIMA MEDICAL & FINANCIAL CLAIM DOSSIER
Job ID: ${claim.job_id} | Status: ${claim.claim_status} | State: ${claim.billing_state} ${claim.billing_zip}
Claimant: ${claim.claimant_name} | LOB: ${claim.line_of_business}
Primary Diagnosis: ${claim.diagnosis} (${claim.body_part})
Total Claim Exposure: $${Math.round(claim.total_billed_amount).toLocaleString()} (${claim.total_bills_count} bills, ${claim.total_treatment_span_days} days)
Severity: ${claim.severity_classification} | Milestone P90 Status: ${claim.p90_status}

CRITICAL ESCALATIONS & TOP JUMPS:
Top Jump 1: Day ${claim.primary_inflection?.day || claim.inflection_day_num} (DOS: ${claim.primary_inflection?.service_date ? new Date(claim.primary_inflection.service_date).toLocaleDateString() : 'N/A'}) - $${claim.primary_inflection?.amount?.toLocaleString() || claim.inflection_jump_amount?.toLocaleString()} for ${claim.primary_inflection?.category || claim.inflection_category} at ${claim.primary_inflection?.facility || claim.inflection_facility} (${claim.primary_inflection?.doctor || claim.inflection_doctor})
${claim.secondary_inflection ? `Top Jump 2: Day ${claim.secondary_inflection.day} (DOS: ${new Date(claim.secondary_inflection.service_date).toLocaleDateString()}) - $${claim.secondary_inflection.amount.toLocaleString()} for ${claim.secondary_inflection.category} at ${claim.secondary_inflection.facility} (${claim.secondary_inflection.doctor})
` : ''}
CLINICAL COMMENTARY:
${claim.genai_narrative}
`;
    navigator.clipboard.writeText(text);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  if (!data) return <div className="min-h-screen bg-slate-950 flex items-center justify-center text-slate-400 font-sans">Loading Temporal Analytics...</div>;

  const { milestoneStats } = data;

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white relative overflow-x-hidden">
      {/* Dynamic Ambient Background Mesh Glows */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute -top-40 left-1/4 w-[650px] h-[650px] bg-indigo-600/15 rounded-full blur-[140px]" />
        <div className="absolute top-1/3 -right-40 w-[550px] h-[550px] bg-blue-600/10 rounded-full blur-[140px]" />
        <div className="absolute -bottom-20 left-1/3 w-[600px] h-[600px] bg-rose-600/10 rounded-full blur-[150px]" />
        <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:24px_24px] opacity-25" />
      </div>

      {/* Top Header */}
      <header className="border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-xl sticky top-0 z-40 px-6 py-3.5 shadow-2xl">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-400 flex items-center justify-center shadow-lg shadow-indigo-500/25 ring-1 ring-white/20">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-black tracking-tight text-white m-0">ClaimOptima</h1>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/15 text-indigo-300 border border-indigo-500/30 font-bold shadow-sm">
                  Executive Studio
                </span>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 font-bold flex items-center gap-1">
                  <Database className="w-3 h-3" /> Power BI Ready
                </span>
              </div>
              <p className="text-xs text-slate-400 m-0">Temporal Severity, Inflection Jumps & Medical Claim Dossiers</p>
            </div>
          </div>

          {/* Action Buttons & Status Filter */}
          <div className="flex items-center flex-wrap gap-2">
            {/* Global Claim Status Filter Toggle */}
            <div className="flex items-center bg-slate-900/90 rounded-xl p-0.5 border border-slate-700/80 shadow-inner">
              <span className="text-[11px] font-bold text-slate-400 px-2 flex items-center gap-1">
                <Filter className="w-3 h-3 text-cyan-400" /> Status:
              </span>
              {[
                { id: 'ALL', label: 'All' },
                { id: 'OPEN', label: 'Open' },
                { id: 'CLOSED', label: 'Closed' }
              ].map(st => (
                <button
                  key={st.id}
                  onClick={() => {
                    setStatusFilter(st.id);
                    setCurrentPage(1);
                  }}
                  className={`cursor-pointer px-2.5 py-1 text-xs font-bold rounded-lg transition ${
                    statusFilter === st.id
                      ? 'bg-gradient-to-r from-indigo-600 to-blue-600 text-white shadow'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                  }`}
                >
                  {st.label}
                </button>
              ))}
            </div>

            <span className="text-xs text-slate-300 bg-slate-900/90 px-3 py-1.5 rounded-xl border border-slate-700/80 shadow-inner flex items-center gap-2">
              <FileSpreadsheet className="w-3.5 h-3.5 text-blue-400" />
              {datasetLabel}
            </span>

            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept=".xlsx,.xls,.csv"
              className="hidden"
            />

            <button
              onClick={() => fileInputRef.current?.click()}
              className="cursor-pointer text-xs font-semibold px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-200 rounded-xl border border-slate-700/80 shadow-md transition hover:border-slate-500 flex items-center gap-1.5"
            >
              <Upload className="w-3.5 h-3.5" />
              Upload Excel
            </button>

            <button
              onClick={handleDownloadPowerBi}
              className="cursor-pointer text-xs font-bold px-3.5 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-xl shadow-lg shadow-amber-600/20 transition flex items-center gap-1.5"
              title="Download Star-Schema Excel & Matrix Sheets"
            >
              <Download className="w-3.5 h-3.5" />
              Export Calculated (.xlsx)
            </button>

            <button
              onClick={handleDownloadCalculatedJson}
              className="cursor-pointer text-xs font-bold px-3.5 py-1.5 bg-teal-600 hover:bg-teal-500 text-white rounded-xl shadow-lg shadow-teal-600/20 transition flex items-center gap-1.5"
              title="Download Calculated Portfolio & Claims Analytics JSON"
            >
              <Download className="w-3.5 h-3.5" />
              Export JSON
            </button>

            <button
              onClick={handleLoad3000}
              className="cursor-pointer text-xs font-bold px-3.5 py-1.5 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white rounded-xl shadow-lg shadow-indigo-600/25 transition flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              3,000 Claims Demo
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto w-full px-6 py-6 flex-1 flex flex-col gap-6 relative z-10">
        {/* Executive KPI Cards */}
        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-slate-900/70 border border-slate-800/90 rounded-2xl p-4 shadow-xl backdrop-blur-md hover:border-indigo-500/40 transition-all">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-slate-400 m-0">Filtered Scope ({statusFilter})</p>
                <h3 className="text-2xl font-black text-white mt-1 mb-0">{activeKpis.totalClaims.toLocaleString()} Claims</h3>
                <p className="text-xs text-slate-400 mt-1 mb-0">
                  {statusFilter === 'ALL' ? 'Both Open & Closed' : `${statusFilter} Claims only`} • Max {data.portfolioStats.maxTreatmentDays} Days
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400 shadow-inner">
                <Layers className="w-5 h-5" />
              </div>
            </div>
          </div>

          <div className="bg-slate-900/70 border border-slate-800/90 rounded-2xl p-4 shadow-xl backdrop-blur-md hover:border-emerald-500/40 transition-all">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-slate-400 m-0">Total Medical Exposure</p>
                <h3 className="text-2xl font-black text-emerald-400 mt-1 mb-0">${activeKpis.totalSpend.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h3>
                <p className="text-xs text-slate-400 mt-1 mb-0">Avg ${Math.round(activeKpis.avgSpend).toLocaleString()} / claim</p>
              </div>
              <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 shadow-inner">
                <DollarSign className="w-5 h-5" />
              </div>
            </div>
          </div>

          <div className="bg-slate-900/70 border border-slate-800/90 rounded-2xl p-4 shadow-xl backdrop-blur-md hover:border-rose-500/40 transition-all">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-slate-400 m-0">Portfolio P90 Ceiling</p>
                <h3 className="text-2xl font-black text-rose-400 mt-1 mb-0">${Math.round(activeKpis.p90Ceiling).toLocaleString()}</h3>
                <p className="text-xs text-rose-400/80 mt-1 mb-0">Top 10% Catastrophic Threshold</p>
              </div>
              <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 shadow-inner">
                <AlertTriangle className="w-5 h-5" />
              </div>
            </div>
          </div>

          <div className="bg-slate-900/70 border border-slate-800/90 rounded-2xl p-4 shadow-xl backdrop-blur-md hover:border-amber-500/40 transition-all">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-slate-400 m-0">P90 Outlier Impact</p>
                <h3 className="text-2xl font-black text-amber-400 mt-1 mb-0">{activeKpis.outlierCount} Outliers</h3>
                <p className="text-xs text-amber-400/80 mt-1 mb-0">Accounts for {activeKpis.outlierShare}% of filtered portfolio spend</p>
              </div>
              <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 shadow-inner">
                <ShieldAlert className="w-5 h-5" />
              </div>
            </div>
          </div>
        </section>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2 overflow-x-auto">
          {[
            { id: 'executive', label: '1. Executive Scatter & Outlier Map', icon: Activity },
            { id: 'curves', label: '2. Milestone Phase P90 Breaches & S-Curves', icon: TrendingUp },
            { id: 'shift', label: '3. Clinical Category Shift', icon: BarChart3 },
            { id: 'explorer', label: '4. All Claims Explorer', icon: Layers }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`cursor-pointer px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 whitespace-nowrap ${
                  isActive
                    ? 'bg-gradient-to-r from-indigo-600 to-blue-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/80'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* TAB 1: Executive Scatter & Outlier Map */}
        {activeTab === 'executive' && (
          <div className="flex flex-col gap-6">
            <div className="bg-slate-900/70 border border-slate-800/90 rounded-2xl p-6 shadow-2xl backdrop-blur-md">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                <div>
                  <h3 className="text-base font-black text-white m-0 flex items-center gap-2">
                    <Activity className="w-5 h-5 text-indigo-400" />
                    Portfolio Sequential Claims P90 Outlier Distribution Map
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 mb-0">
                    Each plotted dot represents an individual claim (Sequential Claim #1 to #{portfolioScatterClaims.length}). Red dots indicate P90 Outliers.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs px-3 py-1 rounded-lg bg-rose-500/15 text-rose-400 border border-rose-500/30 font-bold flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
                    P90 Ceiling: ${Math.round(activeKpis.p90Ceiling).toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Scatter Plot */}
              <div className="h-[340px] w-full bg-slate-950/60 rounded-xl p-4 border border-slate-800/80">
                <ResponsiveContainer width="100%" height="100%">
                  <ScatterChart margin={{ top: 20, right: 30, bottom: 25, left: 30 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis
                      dataKey="plot_x_index"
                      type="number"
                      domain={[1, portfolioScatterClaims.length || 1]}
                      name="Claim Sequence"
                      tick={{ fill: '#94a3b8', fontSize: 11 }}
                      tickFormatter={(val) => `#${val}`}
                    />
                    <YAxis
                      dataKey="total_billed_amount"
                      type="number"
                      name="Total Billed Amount"
                      tick={{ fill: '#94a3b8', fontSize: 11 }}
                      tickFormatter={(val) => `$${(val / 1000).toFixed(0)}k`}
                    />
                    <ZAxis type="number" dataKey="dot_z_score" range={[70, 700]} name="P90 Status" />
                    <Tooltip
                      content={({ payload }) => {
                        if (!payload || !payload.length) return null;
                        const c = payload[0].payload;
                        return (
                          <div className="bg-slate-900 border border-slate-700 p-3 rounded-xl shadow-2xl text-xs space-y-1 z-50">
                            <div className="flex items-center justify-between gap-3">
                              <strong className="text-cyan-400 font-mono">{c.job_id}</strong>
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${c.is_above_p90 ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' : 'bg-slate-800 text-slate-300'}`}>
                                {c.is_above_p90 ? '🚨 P90 BREACH' : 'Normal Range'}
                              </span>
                            </div>
                            <p className="text-slate-300 m-0">Claimant: <strong className="text-white">{c.claimant_name}</strong> ({c.claim_status})</p>
                            <p className="text-emerald-400 font-bold m-0">Total Exposure: ${Math.round(c.total_billed_amount).toLocaleString()}</p>
                            <p className="text-slate-400 m-0">Top Jump #1: Day {c.primary_inflection?.day || c.inflection_day_num} (${c.primary_inflection?.amount?.toLocaleString() || c.inflection_jump_amount?.toLocaleString()})</p>
                            <p className="text-indigo-300 text-[11px] m-0">{c.inflection_category} • {c.inflection_facility}</p>
                          </div>
                        );
                      }}
                    />
                    <ReferenceLine
                      y={activeKpis.p90Ceiling}
                      stroke="#f43f5e"
                      strokeWidth={2}
                      strokeDasharray="4 4"
                      label={{ value: `P90 Threshold: $${Math.round(activeKpis.p90Ceiling).toLocaleString()}`, fill: '#f43f5e', position: 'top', fontSize: 11, fontWeight: 'bold' }}
                    />
                    <Scatter
                      data={portfolioScatterClaims}
                      onClick={(node) => {
                        if (node?.job_id) {
                          setPinnedJobId(node.job_id);
                          const claim = statusFilteredClaimSummaries.find(c => c.job_id === node.job_id);
                          if (claim) setDeepDiveModalClaim(claim);
                        }
                      }}
                      className="cursor-pointer"
                    >
                      {portfolioScatterClaims.map((entry, index) => (
                        <Cell
                          key={`cell-${index}`}
                          fill={entry.is_above_p90 ? '#ef4444' : '#3b82f6'}
                          opacity={entry.is_above_p90 ? 0.95 : 0.45}
                          stroke={entry.is_above_p90 ? '#ffffff' : '#1e3a8a'}
                          strokeWidth={entry.is_above_p90 ? 1.5 : 0.5}
                        />
                      ))}
                    </Scatter>
                  </ScatterChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: Milestone Phase P90 Breaches & S-Curves */}
        {activeTab === 'curves' && (
          <div className="flex flex-col gap-6">
            <div className="bg-slate-900/70 border border-slate-800/90 rounded-2xl p-6 shadow-2xl backdrop-blur-md">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                <div>
                  <h3 className="text-base font-black text-white m-0 flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-indigo-400" />
                    Milestone Phase P90 Ceiling & Multi-Claim S-Curves
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 mb-0">
                    Comparing cumulative spend trajectory against the P90 Ceiling. Select claims to compare.
                  </p>
                </div>

                {/* Multi-Select Job ID Selector */}
                <div className="flex items-center gap-3">
                  <span className="text-xs text-slate-400 font-bold">Select Claims:</span>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {allJobIdList.slice(0, 10).map(jid => {
                      const isSelected = tab2SelectedJobIds.includes(jid);
                      return (
                        <button
                          key={jid}
                          onClick={() => {
                            if (isSelected) {
                              if (tab2SelectedJobIds.length > 1) {
                                setTab2SelectedJobIds(tab2SelectedJobIds.filter(id => id !== jid));
                              }
                            } else {
                              setTab2SelectedJobIds([...tab2SelectedJobIds, jid]);
                            }
                          }}
                          className={`cursor-pointer px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition ${
                            isSelected
                              ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/25 ring-1 ring-cyan-300'
                              : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                          }`}
                        >
                          {jid}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* S-Curve Chart */}
              <div className="h-[380px] w-full bg-slate-950/60 rounded-xl p-4 border border-slate-800/80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={tab2MultiCurveData} margin={{ top: 20, right: 30, bottom: 20, left: 30 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="name" tick={{ fill: '#94a3b8', fontSize: 11 }} />
                    <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} tickFormatter={(val) => `$${(val / 1000).toFixed(0)}k`} />
                    <Tooltip
                      formatter={(val) => [`$${Number(val).toLocaleString()}`, '']}
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.75rem', fontSize: '12px' }}
                    />
                    <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
                    {/* Only P90 Ceiling Line */}
                    <Line
                      type="monotone"
                      dataKey="p90"
                      name="P90 Ceiling Threshold"
                      stroke="#f43f5e"
                      strokeWidth={3}
                      strokeDasharray="5 5"
                      dot={{ r: 5, fill: '#f43f5e' }}
                    />
                    {tab2SelectedJobIds.map((jid, idx) => (
                      <Line
                        key={jid}
                        type="monotone"
                        dataKey={jid}
                        name={`Claim ${jid}`}
                        stroke={CLAIM_LINE_COLORS[idx % CLAIM_LINE_COLORS.length]}
                        strokeWidth={3}
                        dot={{ r: 5 }}
                      />
                    ))}
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: Clinical Category Shift */}
        {activeTab === 'shift' && (
          <div className="flex flex-col gap-6">
            <div className="bg-slate-900/70 border border-slate-800/90 rounded-2xl p-6 shadow-2xl backdrop-blur-md">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                <div>
                  <h3 className="text-base font-black text-white m-0 flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-indigo-400" />
                    Clinical Category Migration Across Treatment Phases
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 mb-0">
                    Temporal evolution of spend across clinical and discharge categories from Day 0 to Day 271+.
                  </p>
                </div>
              </div>

              {/* Stacked Area Chart */}
              <div className="h-[380px] w-full bg-slate-950/60 rounded-xl p-4 border border-slate-800/80">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={categoryMigrationPhases} margin={{ top: 20, right: 30, bottom: 20, left: 30 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="phase" tick={{ fill: '#94a3b8', fontSize: 11 }} />
                    <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} tickFormatter={(val) => `$${(val / 1000).toFixed(0)}k`} />
                    <Tooltip
                      formatter={(val, name) => [`$${Number(val).toLocaleString()}`, name]}
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.75rem', fontSize: '12px' }}
                    />
                    <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
                    {uniqueCategories.map(cat => (
                      <Area
                        key={cat}
                        type="monotone"
                        dataKey={cat}
                        name={cat}
                        stackId="1"
                        stroke={dynamicCategoryColors[cat] || '#64748b'}
                        fill={dynamicCategoryColors[cat] || '#64748b'}
                        fillOpacity={0.8}
                      />
                    ))}
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              {/* Category Migration Table */}
              <div className="mt-6 overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/80">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-950 text-slate-400 border-b border-slate-800">
                      <th className="p-3">Clinical Category</th>
                      <th className="p-3 text-right">Total Spend ($)</th>
                      <th className="p-3 text-right">Early Phase (0-60d)</th>
                      <th className="p-3 text-right">Late Phase (91d+)</th>
                      <th className="p-3 text-right">Early Share %</th>
                      <th className="p-3 text-right">Late Share %</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {categoryShiftList.map((c, idx) => (
                      <tr key={idx} className="hover:bg-slate-800/40 transition">
                        <td className="p-3 font-semibold text-white flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: dynamicCategoryColors[c.category] || '#64748b' }} />
                          {c.category}
                        </td>
                        <td className="p-3 text-right font-mono font-bold text-white">${Math.round(c.total_spend).toLocaleString()}</td>
                        <td className="p-3 text-right font-mono text-slate-300">${Math.round(c.early_spend).toLocaleString()}</td>
                        <td className="p-3 text-right font-mono text-slate-300">${Math.round(c.late_spend).toLocaleString()}</td>
                        <td className="p-3 text-right font-semibold text-blue-400">{Math.round(c.early_share)}%</td>
                        <td className="p-3 text-right font-semibold text-purple-400">{Math.round(c.late_share)}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: All Claims Explorer */}
        {activeTab === 'explorer' && (
          <div className="flex flex-col gap-6">
            <div className="bg-slate-900/70 border border-slate-800/90 rounded-2xl p-6 shadow-2xl backdrop-blur-md space-y-4">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <h3 className="text-base font-black text-white m-0 flex items-center gap-2">
                    <Layers className="w-5 h-5 text-indigo-400" />
                    All Claims Explorer & Medical Dossiers ({filteredClaims.length.toLocaleString()} Claims)
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 mb-0">
                    Select any claim to view its comprehensive Medical & Financial Dossier or drill down into the chronological bill timeline.
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="relative">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      placeholder="Search Job ID, Claimant, Diagnosis, Facility..."
                      value={searchQuery}
                      onChange={(e) => {
                        setSearchQuery(e.target.value);
                        setCurrentPage(1);
                      }}
                      className="bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 w-64"
                    />
                  </div>

                  <select
                    value={severityFilter}
                    onChange={(e) => {
                      setSeverityFilter(e.target.value);
                      setCurrentPage(1);
                    }}
                    className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="ALL">All Severities</option>
                    <option value="P90_ONLY">P90 Outliers Only</option>
                    <option value="HIGH">High Severity + P90</option>
                  </select>
                </div>
              </div>

              {/* Table */}
              <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/80">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-950 text-slate-400 border-b border-slate-800">
                      <th className="p-3">#</th>
                      <th className="p-3">Job ID</th>
                      <th className="p-3">Status</th>
                      <th className="p-3">Claimant & Diagnosis</th>
                      <th className="p-3">State</th>
                      <th className="p-3">Duration</th>
                      <th className="p-3 text-right">Total Exposure</th>
                      <th className="p-3">Top Jump #1 (Primary)</th>
                      <th className="p-3 text-center">P90 Status</th>
                      <th className="p-3 text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {paginatedClaims.map((c, idx) => {
                      const rowNum = (currentPage - 1) * pageSize + idx + 1;
                      const isBreach = c.p90_status.includes('BREACH') || c.is_p90_outlier === 1;
                      return (
                        <tr key={c.job_id} className="hover:bg-slate-800/40 transition">
                          <td className="p-3 text-slate-500">{rowNum}</td>
                          <td className="p-3 font-mono font-bold text-cyan-400">{c.job_id}</td>
                          <td className="p-3">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              c.claim_status === 'Open' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-slate-800 text-slate-400'
                            }`}>
                              {c.claim_status}
                            </span>
                          </td>
                          <td className="p-3 max-w-[220px]">
                            <span className="font-bold text-white block truncate" title={c.claimant_name}>{c.claimant_name}</span>
                            <span className="text-slate-400 text-[11px] block truncate" title={c.diagnosis}>{c.diagnosis}</span>
                          </td>
                          <td className="p-3 text-slate-300 font-semibold">{c.billing_state}</td>
                          <td className="p-3 text-slate-300">{c.total_treatment_span_days}d ({c.total_bills_count} bills)</td>
                          <td className="p-3 text-right font-mono font-bold text-emerald-400">${Math.round(c.total_billed_amount).toLocaleString()}</td>
                          <td className="p-3">
                            <span className="font-bold text-rose-300 block">
                              Day {c.primary_inflection?.day || c.inflection_day_num} (${c.primary_inflection?.amount?.toLocaleString() || c.inflection_jump_amount?.toLocaleString()})
                            </span>
                            <span className="text-[11px] text-slate-400 truncate block max-w-[160px]">{c.inflection_category}</span>
                          </td>
                          <td className="p-3 text-center">
                            {isBreach ? (
                              <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/40 text-[10px] font-black">
                                🚨 P90 BREACH
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 text-[10px] font-semibold">
                                Normal Range
                              </span>
                            )}
                          </td>
                          <td className="p-3 text-center">
                            <button
                              onClick={() => setDeepDiveModalClaim(c)}
                              className="cursor-pointer px-3 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-bold text-xs shadow-md shadow-indigo-600/20 transition flex items-center gap-1.5 mx-auto"
                            >
                              <FileText className="w-3.5 h-3.5" />
                              Dossier & Ledger
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Pagination */}
              <div className="flex items-center justify-between pt-2">
                <span className="text-xs text-slate-400">
                  Showing Page {currentPage} of {totalPages} ({filteredClaims.length.toLocaleString()} claims)
                </span>
                <div className="flex items-center gap-2">
                  <button
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                    className="cursor-pointer px-3 py-1 bg-slate-800 disabled:opacity-40 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
                  >
                    Previous
                  </button>
                  <button
                    disabled={currentPage === totalPages}
                    onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                    className="cursor-pointer px-3 py-1 bg-slate-800 disabled:opacity-40 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
                  >
                    Next
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* COMPREHENSIVE MEDICAL & FINANCIAL CLAIM DOSSIER / DEEP DIVE MODAL         */}
        {/* ========================================================================= */}
        {deepDiveModalClaim && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
            <div className="bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl w-full max-w-5xl max-h-[92vh] flex flex-col overflow-hidden ring-1 ring-white/10">
              {/* Modal Header */}
              <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white shadow-lg">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-lg font-black text-white m-0">
                        Medical & Financial Claim Dossier: <span className="text-cyan-400 font-mono">{deepDiveModalClaim.job_id}</span>
                      </h3>
                      <span className={`text-xs px-2.5 py-0.5 rounded-full font-bold ${
                        deepDiveModalClaim.claim_status === 'Open' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-slate-800 text-slate-400'
                      }`}>
                        {deepDiveModalClaim.claim_status}
                      </span>
                      {deepDiveModalClaim.p90_status.includes('BREACH') ? (
                        <span className="text-xs px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/40 font-black">
                          🚨 P90 OUTLIER
                        </span>
                      ) : (
                        <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-semibold">
                          Normal Range
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5 mb-0">
                      Claimant: <strong className="text-white">{deepDiveModalClaim.claimant_name}</strong> • Venue: {deepDiveModalClaim.billing_state} {deepDiveModalClaim.billing_zip} • LOB: {deepDiveModalClaim.line_of_business}
                    </p>
                  </div>
                </div>

                {/* View Mode Toggle & Action Buttons */}
                <div className="flex items-center gap-2">
                  <div className="flex items-center bg-slate-900 rounded-xl p-0.5 border border-slate-800">
                    <button
                      onClick={() => setModalViewMode('dossier')}
                      className={`cursor-pointer px-3 py-1 text-xs font-bold rounded-lg transition ${
                        modalViewMode === 'dossier' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Dossier View
                    </button>
                    <button
                      onClick={() => setModalViewMode('ledger')}
                      className={`cursor-pointer px-3 py-1 text-xs font-bold rounded-lg transition ${
                        modalViewMode === 'ledger' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Bill Ledger ({deepDiveModalClaim.bill_rows?.length || 0})
                    </button>
                  </div>

                  <button
                    onClick={() => handleCopyDossier(deepDiveModalClaim)}
                    className="cursor-pointer p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition flex items-center gap-1 text-xs"
                    title="Copy summary text"
                  >
                    {copiedText ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>

                  <button
                    onClick={() => window.print()}
                    className="cursor-pointer p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
                    title="Print Dossier"
                  >
                    <Printer className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => setDeepDiveModalClaim(null)}
                    className="cursor-pointer p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
                    title="Close window"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Modal Body */}
              <div className="p-6 overflow-y-auto space-y-6 flex-1 bg-slate-900/60">
                {modalViewMode === 'dossier' ? (
                  <>
                    {/* Top 3 Summary Cards */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {/* Card 1: Total Claim Exposure */}
                      <div className="bg-slate-950/80 border border-emerald-500/40 rounded-xl p-4 shadow-lg">
                        <div className="flex items-center justify-between">
                          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider m-0">Total Claim Exposure</p>
                          <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
                            <DollarSign className="w-4 h-4" />
                          </div>
                        </div>
                        <h4 className="text-2xl font-black text-emerald-400 mt-2 mb-0">
                          ${Math.round(deepDiveModalClaim.total_billed_amount).toLocaleString()}
                        </h4>
                        <p className="text-xs text-slate-400 mt-1 mb-0">
                          {deepDiveModalClaim.total_treatment_span_days} days span • {deepDiveModalClaim.total_bills_count} bills
                        </p>
                      </div>

                      {/* Card 2: Top Jump #1 */}
                      <div className="bg-slate-950/80 border border-rose-500/40 rounded-xl p-4 shadow-lg">
                        <div className="flex items-center justify-between">
                          <p className="text-xs font-bold text-rose-300 uppercase tracking-wider m-0">Top Jump #1 (Primary)</p>
                          <span className="text-[10px] px-2 py-0.5 rounded bg-rose-500/30 text-rose-300 font-bold border border-rose-500/40">
                            Day {deepDiveModalClaim.primary_inflection?.day || deepDiveModalClaim.inflection_day_num}
                          </span>
                        </div>
                        <h4 className="text-2xl font-black text-rose-400 mt-2 mb-0">
                          ${deepDiveModalClaim.primary_inflection?.amount?.toLocaleString() || deepDiveModalClaim.inflection_jump_amount?.toLocaleString()}
                        </h4>
                        <p className="text-xs text-slate-300 mt-1 mb-0 truncate" title={`${deepDiveModalClaim.inflection_category} • ${deepDiveModalClaim.inflection_facility}`}>
                          {deepDiveModalClaim.inflection_category} • {deepDiveModalClaim.inflection_facility}
                        </p>
                      </div>

                      {/* Card 3: Progression Pattern */}
                      <div className="bg-slate-950/80 border border-indigo-500/40 rounded-xl p-4 shadow-lg">
                        <div className="flex items-center justify-between">
                          <p className="text-xs font-bold text-indigo-300 uppercase tracking-wider m-0">Progression Pattern</p>
                          <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                            Risk {deepDiveModalClaim.early_risk_score}/100
                          </span>
                        </div>
                        <h4 className="text-sm font-bold text-white mt-2.5 mb-0 truncate" title={deepDiveModalClaim.clinical_progression_pattern}>
                          {deepDiveModalClaim.clinical_progression_pattern}
                        </h4>
                        <p className="text-xs text-slate-400 mt-1 mb-0 truncate">
                          {deepDiveModalClaim.severity_classification}
                        </p>
                      </div>
                    </div>

                    {/* Section: Clinical Impairment & Diagnoses */}
                    <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-3">
                      <div className="flex items-center gap-2 border-b border-slate-800/80 pb-2">
                        <Stethoscope className="w-4 h-4 text-cyan-400" />
                        <h4 className="text-xs font-bold uppercase tracking-wider text-white m-0">Clinical Diagnosis & Impairment Profile</h4>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                        <div>
                          <p className="text-slate-400 m-0">Primary Diagnosis:</p>
                          <p className="text-white font-bold text-sm mt-0.5 mb-0">{deepDiveModalClaim.diagnosis}</p>
                        </div>
                        <div>
                          <p className="text-slate-400 m-0">Injured Anatomical Body Part:</p>
                          <p className="text-cyan-300 font-bold text-sm mt-0.5 mb-0">{deepDiveModalClaim.body_part}</p>
                        </div>
                      </div>
                    </div>

                    {/* Section: Critical Escalation Highlights (Top 2 Jumps) */}
                    <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-3">
                      <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                        <div className="flex items-center gap-2">
                          <Zap className="w-4 h-4 text-amber-400" />
                          <h4 className="text-xs font-bold uppercase tracking-wider text-white m-0">Critical Escalations & Top Inflection Jumps</h4>
                        </div>
                        <span className="text-[11px] text-slate-400">Date of Service (DOS) & Spend Impact</span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Top Jump 1 Card */}
                        {deepDiveModalClaim.primary_inflection && (
                          <div className="bg-rose-950/20 border border-rose-500/40 rounded-xl p-3.5 space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="px-2 py-0.5 rounded bg-rose-500 text-white font-black text-[10px] tracking-wider uppercase">
                                ⭐ TOP JUMP #1 (PRIMARY)
                              </span>
                              <span className="text-xs text-rose-300 font-mono font-bold">
                                Day {deepDiveModalClaim.primary_inflection.day}
                              </span>
                            </div>
                            <div className="flex items-baseline justify-between">
                              <h5 className="text-xl font-black text-rose-400 m-0">
                                ${deepDiveModalClaim.primary_inflection.amount.toLocaleString()}
                              </h5>
                              <span className="text-xs text-slate-300 font-medium">
                                DOS: {deepDiveModalClaim.primary_inflection.service_date ? new Date(deepDiveModalClaim.primary_inflection.service_date).toLocaleDateString() : 'N/A'}
                              </span>
                            </div>
                            <div className="text-xs space-y-1 pt-1 border-t border-rose-900/40">
                              <p className="text-slate-300 m-0"><strong>Category:</strong> {deepDiveModalClaim.primary_inflection.category}</p>
                              <p className="text-slate-300 m-0"><strong>Facility:</strong> {deepDiveModalClaim.primary_inflection.facility}</p>
                              <p className="text-slate-400 m-0"><strong>Physician:</strong> {deepDiveModalClaim.primary_inflection.doctor}</p>
                            </div>
                          </div>
                        )}

                        {/* Top Jump 2 Card */}
                        {deepDiveModalClaim.secondary_inflection ? (
                          <div className="bg-purple-950/20 border border-purple-500/40 rounded-xl p-3.5 space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="px-2 py-0.5 rounded bg-purple-500 text-white font-black text-[10px] tracking-wider uppercase">
                                ⚡ TOP JUMP #2 (SECONDARY)
                              </span>
                              <span className="text-xs text-purple-300 font-mono font-bold">
                                Day {deepDiveModalClaim.secondary_inflection.day}
                              </span>
                            </div>
                            <div className="flex items-baseline justify-between">
                              <h5 className="text-xl font-black text-purple-300 m-0">
                                ${deepDiveModalClaim.secondary_inflection.amount.toLocaleString()}
                              </h5>
                              <span className="text-xs text-slate-300 font-medium">
                                DOS: {deepDiveModalClaim.secondary_inflection.service_date ? new Date(deepDiveModalClaim.secondary_inflection.service_date).toLocaleDateString() : 'N/A'}
                              </span>
                            </div>
                            <div className="text-xs space-y-1 pt-1 border-t border-purple-900/40">
                              <p className="text-slate-300 m-0"><strong>Category:</strong> {deepDiveModalClaim.secondary_inflection.category}</p>
                              <p className="text-slate-300 m-0"><strong>Facility:</strong> {deepDiveModalClaim.secondary_inflection.facility}</p>
                              <p className="text-slate-400 m-0"><strong>Physician:</strong> {deepDiveModalClaim.secondary_inflection.doctor}</p>
                            </div>
                          </div>
                        ) : (
                          <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-3.5 flex items-center justify-center text-xs text-slate-500">
                            Single primary escalation observed. No secondary significant surge recorded.
                          </div>
                        )}
                      </div>

                      {/* Clinical Commentary */}
                      <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 text-xs text-slate-300 leading-relaxed">
                        <strong className="text-indigo-400 block mb-1">Clinical Escalation Analysis:</strong>
                        {deepDiveModalClaim.genai_narrative}
                      </div>
                    </div>
                  </>
                ) : null}

                {/* Chronological Treatment Timeline & Bill Ledger */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-white m-0 flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-cyan-400" />
                      Chronological Treatment Timeline & Bill Ledger ({deepDiveModalClaim.bill_rows?.length || 0} Records)
                    </h4>
                    <span className="text-xs text-slate-400 font-medium">
                      Organized strictly by Date of Service (DOS)
                    </span>
                  </div>

                  <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/80">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-slate-950 text-slate-400 border-b border-slate-800">
                          <th className="p-3">#</th>
                          <th className="p-3">Record ID</th>
                          <th className="p-3">Elapsed</th>
                          <th className="p-3">Date of Service (DOS)</th>
                          <th className="p-3">Category</th>
                          <th className="p-3">Facility / Provider</th>
                          <th className="p-3">Procedure Description</th>
                          <th className="p-3 text-right">Billed Amount</th>
                          <th className="p-3 text-right">Cumulative Spend</th>
                          <th className="p-3 text-center">Status & Jumps</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60">
                        {(deepDiveModalClaim.bill_rows || []).map((b, idx) => {
                          const isTop1 = b.is_top_jump_1;
                          const isTop2 = b.is_top_jump_2;
                          return (
                            <tr
                              key={`modal-bill-${b.record_id || idx}`}
                              className={`transition ${
                                isTop1
                                  ? 'bg-rose-950/50 hover:bg-rose-950/70 border-l-4 border-l-rose-500 font-semibold'
                                  : isTop2
                                  ? 'bg-purple-950/40 hover:bg-purple-950/60 border-l-4 border-l-purple-500 font-medium'
                                  : 'hover:bg-slate-800/40'
                              }`}
                            >
                              <td className="p-3 text-slate-500">{idx + 1}</td>
                              <td className="p-3 font-mono text-cyan-400 font-bold">{b.record_id}</td>
                              <td className="p-3 font-semibold text-slate-300">Day {b.elapsed_days}</td>
                              <td className="p-3 text-slate-300 font-medium">
                                {b.effective_service_date ? new Date(b.effective_service_date).toLocaleDateString() : b.bill_line_item_service_date}
                              </td>
                              <td className="p-3">
                                <span className="px-2 py-0.5 rounded text-[11px] font-medium" style={{ backgroundColor: `${CATEGORY_COLORS[b.bill_line_item_category] || '#64748b'}25`, color: CATEGORY_COLORS[b.bill_line_item_category] || '#cbd5e1' }}>
                                  {b.bill_line_item_category}
                                </span>
                              </td>
                              <td className="p-3 text-slate-300">
                                <span className="font-semibold text-white block">{b.facility_name}</span>
                                <span className="text-slate-500 text-[11px] block">{b.provider_name}</span>
                              </td>
                              <td className="p-3 text-slate-400 text-[11px] max-w-[180px] truncate" title={b.procedure_description}>
                                {b.procedure_description}
                              </td>
                              <td className="p-3 text-right font-mono font-bold text-white">
                                ${b.bill_line_item_build_amount.toLocaleString()}
                              </td>
                              <td className="p-3 text-right font-mono text-cyan-400 font-bold">
                                ${b.cumulative_spend.toLocaleString()}
                              </td>
                              <td className="p-3 text-center">
                                {isTop1 ? (
                                  <span className="px-2 py-0.5 rounded-full bg-rose-500/30 text-rose-300 border border-rose-500/50 text-[10px] font-black">
                                    ⭐ TOP JUMP #1
                                  </span>
                                ) : isTop2 ? (
                                  <span className="px-2 py-0.5 rounded-full bg-purple-500/30 text-purple-300 border border-purple-500/50 text-[10px] font-black">
                                    ⚡ TOP JUMP #2
                                  </span>
                                ) : (
                                  <span className="text-slate-500 text-[11px]">Routine</span>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              {/* Modal Footer */}
              <div className="px-6 py-3 border-t border-slate-800 bg-slate-950 flex items-center justify-between text-xs text-slate-400">
                <span>Job ID: <strong className="text-cyan-400 font-mono">{deepDiveModalClaim.job_id}</strong> • Total Records: {deepDiveModalClaim.bill_rows?.length || 0}</span>
                <button
                  onClick={() => setDeepDiveModalClaim(null)}
                  className="cursor-pointer px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold transition"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950/70 py-4 px-6 text-center text-xs text-slate-500 relative z-10">
        ClaimOptima™ Temporal Severity Studio • Dynamic P90 Inflection Discovery • Ready for Power BI Star-Schema Export
      </footer>
    </div>
  );
}
