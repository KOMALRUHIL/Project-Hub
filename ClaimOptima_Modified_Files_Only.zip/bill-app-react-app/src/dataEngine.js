import * as XLSX from 'xlsx';

// Standard Milestone Windows
export const MILESTONE_WINDOWS = [
  { key: 'M30', name: 'Day 0 - 30 (Acute Phase)', minD: 0, maxD: 30, evalDay: 30 },
  { key: 'M60', name: 'Day 31 - 60 (Subacute / PT)', minD: 31, maxD: 60, evalDay: 60 },
  { key: 'M90', name: 'Day 61 - 90 (Specialist / Diag)', minD: 61, maxD: 90, evalDay: 90 },
  { key: 'M180', name: 'Day 91 - 180 (Surgical / Inpatient)', minD: 91, maxD: 180, evalDay: 180 },
  { key: 'M270', name: 'Day 181 - 270 (Extended Chronic Rehab)', minD: 181, maxD: 270, evalDay: 270 },
  { key: 'M293', name: 'Day 271 - 293+ (Long-Term Resolution)', minD: 271, maxD: 999, evalDay: 293 }
];

export const CATEGORY_COLORS = {
  'Inpatient Surgery': '#ef4444', // Bright Red
  'Hospital / ER': '#2563eb', // Royal Blue
  'Inpatient / ICU': '#881337', // Deep Burgundy / Maroon
  'Diagnostic Imaging': '#9333ea', // Vivid Purple
  'Physical Therapy': '#10b981', // Emerald Green
  'Pain Management': '#f59e0b', // Amber / Gold
  'Treating Physician': '#06b6d4', // Bright Cyan
  'Chiropractic': '#ec4899', // Hot Pink
  'Discharge Care': '#3b82f6', // Sky Blue
  'Pharmacy / Rx': '#14b8a6', // Teal
  'Medical Supplies / DME': '#f97316', // Orange
  'Laboratory / Diagnostics': '#8b5cf6', // Violet
  'General Medical Treatment': '#64748b' // Slate Gray
};

export const PALETTE_COLORS = [
  '#ef4444', // Red (Inpatient Surgery)
  '#2563eb', // Royal Blue (Hospital / ER)
  '#9333ea', // Vivid Purple (Diagnostic Imaging)
  '#10b981', // Emerald Green (Physical Therapy)
  '#f59e0b', // Amber / Gold (Pain Management)
  '#06b6d4', // Cyan (Treating Physician)
  '#881337', // Deep Maroon (Inpatient / ICU)
  '#ec4899', // Hot Pink (Chiropractic)
  '#3b82f6', // Sky Blue (Discharge Care)
  '#14b8a6', // Teal (Pharmacy / Rx)
  '#f97316', // Orange (Medical Supplies / DME)
  '#8b5cf6', // Violet (Laboratory / Diagnostics)
  '#64748b', // Slate Gray (General Medical Treatment)
  '#a855f7', // Light Purple
  '#d97706', // Dark Amber
  '#059669', // Dark Emerald
  '#e11d48'  // Rose
];

export function normalizeCategoryName(rawCat) {
  if (!rawCat) return 'General Medical Treatment';
  const s = String(rawCat).trim();
  if (!s || s.toLowerCase() === 'nan' || s.toLowerCase() === 'null') return 'General Medical Treatment';
  const lower = s.toLowerCase();
  
  if (lower.includes('surg') || lower.includes('operating') || lower.includes(' or ') || lower === 'or' || lower.includes('procedure')) return 'Inpatient Surgery';
  if (lower.includes('icu') || lower.includes('intensive') || lower.includes('critical')) return 'Inpatient / ICU';
  if (lower.includes('hosp') || lower.includes('er') || lower.includes('emergency') || lower.includes('trauma') || lower.includes('acute')) return 'Hospital / ER';
  if (lower.includes('imag') || lower.includes('radiology') || lower.includes('mri') || lower.includes('ct scan') || lower.includes('x-ray') || lower.includes('xray')) return 'Diagnostic Imaging';
  if (lower.includes('pt') || lower.includes('physic') || lower.includes('rehab') || lower.includes('occupational') || lower.includes('therapy')) return 'Physical Therapy';
  if (lower.includes('pain') || lower.includes('inject') || lower.includes('epidural') || lower.includes('block')) return 'Pain Management';
  if (lower.includes('physician') || lower.includes('doctor') || lower.includes('consult') || lower.includes('clinic') || lower.includes('office') || lower.includes('evaluation') || lower.includes('treat')) return 'Treating Physician';
  if (lower.includes('chiro')) return 'Chiropractic';
  if (lower.includes('discharge') || lower.includes('post-acute') || lower.includes('home health') || lower.includes('transitional')) return 'Discharge Care';
  if (lower.includes('pharm') || lower.includes('rx') || lower.includes('drug') || lower.includes('medicat')) return 'Pharmacy / Rx';
  if (lower.includes('dme') || lower.includes('suppl') || lower.includes('equipment') || lower.includes('orthotic') || lower.includes('prosthetic')) return 'Medical Supplies / DME';
  if (lower.includes('lab') || lower.includes('pathology') || lower.includes('blood') || lower.includes('test')) return 'Laboratory / Diagnostics';
  
  return s;
}

const ALIASES = {
  job_id: ['job_id', 'job id', 'jobid', 'claim_id', 'claim id', 'claim number', 'claim_no', 'claimno'],
  record_id: ['record_id', 'record id', 'recordid', 'bill_id', 'bill id', 'line_id', 'line id'],
  tag_id: ['tag_id', 'tag id', 'tagid'],
  claim_status: ['status', 'claim_status', 'claim status', 'open_closed', 'open closed', 'claim_state', 'is_open', 'case_status', 'file_status', 'closure_status'],
  claimant_name: ['claimant_name', 'claimant name', 'claimant', 'patient_name', 'patient name', 'patient', 'injured_party', 'employee_name', 'insured_name'],
  diagnosis: ['diagnosis', 'diagnoses', 'primary_diagnosis', 'icd', 'icd10', 'icd_10', 'icd_code', 'icd_description', 'injury_type', 'clinical_diagnosis'],
  body_part: ['body_part', 'body part', 'body_part_injured', 'body part injured', 'injured_body_part', 'bodypart', 'bodyparts'],
  line_of_business: ['line_of_business', 'line of business', 'lob', 'claim_type', 'type_of_claim', 'policy_type', 'coverage'],
  procedure_description: ['procedure_description', 'procedure description', 'treatment_description', 'treatment description', 'service_description', 'cpt_description', 'line_item_description', 'description', 'notes'],
  facility_name: ['facility_name', 'facility name', 'facility', 'hospital', 'clinic', 'provider_facility', 'location'],
  provider_name: ['provider_name', 'provider name', 'doctor', 'physician', 'payee', 'rendering_provider', 'billing_provider'],
  provider_billing_state: ['provider_billing_state', 'provider billing state', 'state', 'billing_state', 'prov_state'],
  provider_billing_zip_code: ['provider_billing_zip_code', 'provider billing zip code', 'billing_zip', 'zip_code', 'zip', 'prov_zip'],
  start_date: ['start_date', 'start date', 'from_date', 'statement_from', 'service_start', 'admission_date'],
  end_date: ['end_date', 'end date', 'thru_date', 'statement_to', 'service_end', 'discharge_date'],
  bill_line_item_service_date: ['bill_line_item_service_date', 'service_date', 'service date', 'line_service_date', 'dos', 'date_of_service', 'bill_date'],
  bill_line_item_build_amount: [
    'bill_line_item_build_amount', 'bill_line_item_billed_amount', 'item_billed_amount',
    'billed_amount', 'build_amount', 'billed amount', 'line_item_amount', 'amount', 'charge', 'total_billed'
  ],
  bill_line_item_category: [
    'clinical_category', 'clinical category', 'discharge_category', 'discharge category',
    'bill_line_item_category', 'bill line item category', 'category', 'item_category',
    'treatment_type', 'treatment type', 'record_type', 'record type', 'service_category',
    'service category', 'service_type', 'service type', 'specialty', 'discipline',
    'procedure_category', 'procedure category', 'department', 'line_category', 'billing_category', 'type'
  ]
};

function parseDateRobust(val) {
  if (!val) return null;
  if (val instanceof Date && !isNaN(val)) return val;
  const s = String(val).trim();
  const parsed = new Date(s);
  if (!isNaN(parsed.getTime())) return parsed;
  const match = s.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
  if (match) {
    return new Date(parseInt(match[3]), parseInt(match[1]) - 1, parseInt(match[2]));
  }
  return null;
}

export function parseAndAnalyzeRawBills(rawRows) {
  if (!rawRows || !rawRows.length) return null;

  const firstRow = rawRows[0];
  const colKeys = Object.keys(firstRow);
  const mapping = {};

  for (const [targetKey, aliasList] of Object.entries(ALIASES)) {
    for (const key of colKeys) {
      const cleanKey = key.trim().toLowerCase().replace(/[\s-]/g, '_');
      if (aliasList.some(a => a.replace(/[\s-]/g, '_') === cleanKey || cleanKey.includes(a.replace(/[\s-]/g, '_')))) {
        mapping[targetKey] = key;
        break;
      }
    }
  }

  const hasStatusColumn = Boolean(mapping.claim_status);

  // Fallback for category column if not found directly
  let catColKey = mapping.bill_line_item_category;
  if (!catColKey) {
    catColKey = colKeys.find(k => {
      const lk = k.toLowerCase();
      return lk.includes('cat') || lk.includes('clinical') || lk.includes('discharge') || lk.includes('specialty') || lk.includes('service') || lk.includes('type') || lk.includes('treat') || lk.includes('dept');
    });
  }

  const normalized = [];
  for (let i = 0; i < rawRows.length; i++) {
    const r = rawRows[i];
    const jobId = String(r[mapping.job_id] || `JOB_${1001 + i}`).trim();
    const recId = String(r[mapping.record_id] || `REC_${i + 1}`).trim();
    const tagId = String(r[mapping.tag_id] || `TAG_${i + 1}`).trim();
    const facility = String(r[mapping.facility_name] || 'Medical Center').trim();
    const provider = String(r[mapping.provider_name] || 'Attending Physician').trim();
    const state = String(r[mapping.provider_billing_state] || 'PA').trim();
    const zip = String(r[mapping.provider_billing_zip_code] || '19104').trim();

    // Claimant info and diagnosis
    const claimantName = r[mapping.claimant_name] ? String(r[mapping.claimant_name]).trim() : `Claimant ${jobId}`;
    const diagnosis = r[mapping.diagnosis] ? String(r[mapping.diagnosis]).trim() : 'L4-S1 Lumbar Disc Herniation with Radiculopathy';
    const bodyPart = r[mapping.body_part] ? String(r[mapping.body_part]).trim() : 'Lumbar Spine';
    const lob = r[mapping.line_of_business] ? String(r[mapping.line_of_business]).trim() : 'Commercial Auto Liability';
    const procDesc = r[mapping.procedure_description] ? String(r[mapping.procedure_description]).trim() : '';

    // Status normalization ('Open' vs 'Closed')
    let rawStatus = r[mapping.claim_status];
    let normalizedStatus = 'Open';
    if (rawStatus !== undefined && rawStatus !== null && rawStatus !== '') {
      const st = String(rawStatus).toLowerCase().trim();
      if (st.includes('close') || st.includes('settle') || st.includes('resolved') || st === '0' || st === 'false' || st === 'c') {
        normalizedStatus = 'Closed';
      } else {
        normalizedStatus = 'Open';
      }
    }

    const rawCat = r[catColKey] || r['clinical_category'] || r['discharge_category'] || r['category'] || r['Category'] || r['Clinical Category'] || r['Discharge Category'] || r['specialty'] || 'General Medical Treatment';
    const cat = normalizeCategoryName(rawCat);

    const sDate = parseDateRobust(r[mapping.start_date]);
    const eDate = parseDateRobust(r[mapping.end_date]) || sDate;
    const svcDate = parseDateRobust(r[mapping.bill_line_item_service_date]) || sDate;
    const effectiveDate = svcDate || sDate;

    if (!effectiveDate) continue;

    let amt = r[mapping.bill_line_item_build_amount];
    if (typeof amt === 'string') {
      amt = parseFloat(amt.replace(/[$,]/g, '').trim()) || 0.0;
    } else {
      amt = Number(amt) || 0.0;
    }

    normalized.push({
      job_id: jobId,
      record_id: recId,
      tag_id: tagId,
      claim_status: normalizedStatus,
      claimant_name: claimantName,
      diagnosis: diagnosis,
      body_part: bodyPart,
      line_of_business: lob,
      procedure_description: procDesc || `${cat} clinical encounter`,
      facility_name: facility,
      provider_name: provider,
      provider_billing_state: state,
      provider_billing_zip_code: zip,
      start_date: sDate,
      end_date: eDate,
      bill_line_item_service_date: svcDate,
      effective_service_date: effectiveDate,
      bill_line_item_build_amount: amt,
      bill_line_item_category: cat
    });
  }

  if (!normalized.length) return null;

  // Baseline Day 0 per claim
  const claimEarliestDate = {};
  for (const row of normalized) {
    if (!claimEarliestDate[row.job_id] || row.effective_service_date < claimEarliestDate[row.job_id]) {
      claimEarliestDate[row.job_id] = row.effective_service_date;
    }
  }

  for (const row of normalized) {
    const base = claimEarliestDate[row.job_id];
    const diffMs = row.effective_service_date.getTime() - base.getTime();
    row.elapsed_days = Math.max(0, Math.floor(diffMs / (1000 * 60 * 60 * 24)));
    
    // Assign temporal phase bin
    const d = row.elapsed_days;
    if (d <= 30) row.temporal_bin = 'Days 0-30 (Acute)';
    else if (d <= 60) row.temporal_bin = 'Days 31-60 (Subacute)';
    else if (d <= 90) row.temporal_bin = 'Days 61-90 (Specialist)';
    else if (d <= 180) row.temporal_bin = 'Days 91-180 (Surgical)';
    else if (d <= 270) row.temporal_bin = 'Days 181-270 (Rehab)';
    else row.temporal_bin = 'Days 271+ (Resolution)';
  }

  normalized.sort((a, b) => {
    if (a.job_id !== b.job_id) return a.job_id.localeCompare(b.job_id);
    return a.elapsed_days - b.elapsed_days;
  });

  const claimTotals = {};
  const claimGroups = {};
  for (const row of normalized) {
    claimTotals[row.job_id] = (claimTotals[row.job_id] || 0) + row.bill_line_item_build_amount;
    if (!claimGroups[row.job_id]) claimGroups[row.job_id] = [];
    claimGroups[row.job_id].push(row);
  }

  for (const [jobId, rows] of Object.entries(claimGroups)) {
    let cum = 0;
    const tot = claimTotals[jobId] || 1;
    for (const r of rows) {
      cum += r.bill_line_item_build_amount;
      r.cumulative_spend = cum;
      r.cumulative_spend_pct = cum / tot;
    }
  }

  const allJobIds = Object.keys(claimTotals);
  const totalClaims = allJobIds.length;
  const totalMedicalSpend = Object.values(claimTotals).reduce((a, b) => a + b, 0);

  // Milestone Percentiles
  const milestoneStats = [];
  const claimSpendAtMilestone = {};

  for (const m of MILESTONE_WINDOWS) {
    claimSpendAtMilestone[m.evalDay] = {};
    const amounts = [];

    for (const jid of allJobIds) {
      const rows = claimGroups[jid] || [];
      const filtered = rows.filter(r => r.elapsed_days <= m.evalDay);
      const spend = filtered.reduce((sum, r) => sum + r.bill_line_item_build_amount, 0);
      claimSpendAtMilestone[m.evalDay][jid] = spend;
      amounts.push(spend);
    }

    amounts.sort((a, b) => a - b);
    const getP = (p) => {
      if (!amounts.length) return 0;
      const idx = (p / 100) * (amounts.length - 1);
      const low = Math.floor(idx);
      const high = Math.ceil(idx);
      if (low === high) return amounts[low];
      return amounts[low] + (amounts[high] - amounts[low]) * (idx - low);
    };

    const p25 = getP(25);
    const p50 = getP(50);
    const p75 = getP(75);
    const p90 = getP(90);
    const avg = amounts.reduce((a, b) => a + b, 0) / (amounts.length || 1);

    const prevM = milestoneStats[milestoneStats.length - 1];
    const prevP50 = prevM ? prevM.p50 : 0;
    const daysSpan = prevM ? Math.max(1, m.evalDay - prevM.evalDay) : m.evalDay;
    const velocity = Math.max(0, (p50 - prevP50) / daysSpan);

    milestoneStats.push({
      milestone_name: m.name,
      eval_day: m.evalDay,
      min_d: m.minD,
      max_d: m.maxD,
      p25,
      p50,
      p75,
      p90,
      average: avg,
      velocity_per_day: velocity
    });
  }

  // Overall Portfolio P90 Ceiling Calculation across total claim spends
  const allSpendValues = Object.values(claimTotals).sort((a, b) => a - b);
  const getOverallP = (pct) => {
    if (!allSpendValues.length) return 0;
    const idx = (pct / 100) * (allSpendValues.length - 1);
    const low = Math.floor(idx);
    const high = Math.ceil(idx);
    return allSpendValues[low] + (allSpendValues[high] - allSpendValues[low]) * (idx - low);
  };
  const finalP90 = getOverallP(90);
  const finalP75 = getOverallP(75);
  const finalP25 = getOverallP(25);

  const claimSummaries = [];
  let p90OutlierCount = 0;
  let claimSeq = 0;

  for (const jid of allJobIds) {
    claimSeq++;
    const rows = claimGroups[jid] || [];
    const totAmt = claimTotals[jid] || 0;
    const bCnt = rows.length;
    const firstDate = claimEarliestDate[jid];
    const maxDays = Math.max(...rows.map(r => r.elapsed_days), 0);

    const earlySpend = rows.filter(r => r.elapsed_days <= 30).reduce((s, r) => s + r.bill_line_item_build_amount, 0);
    const midSpend = rows.filter(r => r.elapsed_days > 30 && r.elapsed_days <= 90).reduce((s, r) => s + r.bill_line_item_build_amount, 0);
    const lateSpend = rows.filter(r => r.elapsed_days > 90).reduce((s, r) => s + r.bill_line_item_build_amount, 0);

    // Top 2 Greatest Inflection Jumps (Primary & Secondary Spikes)
    const sortedByAmt = [...rows].sort((a, b) => b.bill_line_item_build_amount - a.bill_line_item_build_amount);
    const primaryJumpRow = sortedByAmt[0] || rows[0];
    const secondaryJumpRow = (sortedByAmt[1] && sortedByAmt[1].bill_line_item_build_amount >= 1000 && Math.abs(sortedByAmt[1].elapsed_days - primaryJumpRow.elapsed_days) >= 1) ? sortedByAmt[1] : (sortedByAmt[1] || null);

    let p90Breached = false;
    let firstP90Window = 'Within Limits';
    const breachedPhases = [];

    for (const m of milestoneStats) {
      const cumAtM = claimSpendAtMilestone[m.eval_day][jid] || 0;
      if (cumAtM >= m.p90 && m.p90 > 0) {
        if (!p90Breached) {
          p90Breached = true;
          firstP90Window = `Day ${m.eval_day}`;
        }
        breachedPhases.push({
          milestone_name: m.milestone_name,
          eval_day: m.eval_day,
          spend_at_milestone: cumAtM,
          phase_p90_threshold: m.p90,
          excess_over_p90: cumAtM - m.p90
        });
      }
    }

    if (p90Breached) p90OutlierCount++;

    let severityClass = 'Low Severity (Routine)';
    let isOutlier = 0;
    if (totAmt >= finalP90 && finalP90 > 0) {
      severityClass = 'P90 Outlier (Catastrophic)';
      isOutlier = 1;
    } else if (totAmt >= finalP75) {
      severityClass = 'High Severity (Escalating)';
    } else if (totAmt >= finalP25) {
      severityClass = 'Moderate Severity';
    }

    // Flag every bill record within this claim for Top Jumps and P90 Triggers
    let foundP90Trigger = false;
    for (const r of rows) {
      r.is_primary_inflection = (r.record_id === primaryJumpRow?.record_id);
      r.is_secondary_inflection = secondaryJumpRow ? (r.record_id === secondaryJumpRow.record_id) : false;
      r.is_top_jump_1 = r.is_primary_inflection;
      r.is_top_jump_2 = r.is_secondary_inflection;
      
      if (!foundP90Trigger && (r.cumulative_spend >= finalP90 && finalP90 > 0 || isOutlier && r.is_primary_inflection)) {
        r.is_p90_breach_trigger = true;
        foundP90Trigger = true;
      } else {
        r.is_p90_breach_trigger = false;
      }
      r.is_outlier_point = (r.is_top_jump_1 && isOutlier) || r.is_p90_breach_trigger || r.is_top_jump_2;
    }

    let progression = 'Continuous Gradual Therapy';
    if (earlySpend / (totAmt || 1) >= 0.70) {
      progression = 'Acute Front-Loaded (Immediate ER/Trauma)';
    } else if (lateSpend / (totAmt || 1) >= 0.50) {
      progression = 'Late-Surge Escalation (Surgical/Chronic)';
    } else if (midSpend / (totAmt || 1) >= 0.40) {
      progression = 'Mid-Phase Intervention (Day 31-90)';
    }

    // Early Warning Risk Score: evaluates early spend & daily velocity
    const dailyVelocity = totAmt / Math.max(1, maxDays);
    let earlyRiskScore = 15;
    if (earlySpend > 10000 || dailyVelocity > 400) earlyRiskScore = 92;
    else if (earlySpend > 3500 || dailyVelocity > 150) earlyRiskScore = 65;
    else if (maxDays > 90 && lateSpend > 5000) earlyRiskScore = 78;

    // Rich GenAI Clinical Narrative Commentary embedded directly into the claim summary
    const primaryDateStr = primaryJumpRow?.effective_service_date ? new Date(primaryJumpRow.effective_service_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'N/A';
    const secondaryDateStr = secondaryJumpRow?.effective_service_date ? new Date(secondaryJumpRow.effective_service_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : null;
    
    let genAiNarrative = '';
    if (primaryJumpRow && primaryJumpRow.bill_line_item_build_amount >= 20000) {
      genAiNarrative = `Major clinical escalation identified on Date of Service ${primaryDateStr} (Elapsed Day ${primaryJumpRow.elapsed_days}) with $${primaryJumpRow.bill_line_item_build_amount.toLocaleString()} billed for ${primaryJumpRow.bill_line_item_category} at ${primaryJumpRow.facility_name} (${primaryJumpRow.provider_name}). This single surgical/hospital event represents ${Math.round((primaryJumpRow.bill_line_item_build_amount / (totAmt || 1)) * 100)}% of total claim exposure, driving immediate milestone P90 breach velocity.`;
      if (secondaryJumpRow && secondaryJumpRow.bill_line_item_build_amount >= 5000) {
        genAiNarrative += ` Secondary significant spike occurred on DOS ${secondaryDateStr} (Day ${secondaryJumpRow.elapsed_days}) with $${secondaryJumpRow.bill_line_item_build_amount.toLocaleString()} for ${secondaryJumpRow.bill_line_item_category} at ${secondaryJumpRow.facility_name}.`;
      }
    } else if (earlySpend / (totAmt || 1) >= 0.60) {
      genAiNarrative = `Acute trauma presentation with high front-loaded emergency and inpatient charges in Days 0-30 totaling $${earlySpend.toLocaleString()}. Top single charge of $${primaryJumpRow?.bill_line_item_build_amount.toLocaleString()} rendered on DOS ${primaryDateStr} at ${primaryJumpRow?.facility_name}.`;
    } else {
      genAiNarrative = `Progressive conservative management across ${bCnt} bill records totaling $${totAmt.toLocaleString()} over ${maxDays} days. Top single spend item of $${primaryJumpRow?.bill_line_item_build_amount.toLocaleString()} occurred on DOS ${primaryDateStr} (${primaryJumpRow?.bill_line_item_category}).`;
    }

    claimSummaries.push({
      job_id: jid,
      claim_index: claimSeq,
      claim_label: `Claim #${claimSeq}`,
      claim_status: rows[0]?.claim_status || 'Open',
      claimant_name: rows[0]?.claimant_name || `Claimant ${jid}`,
      diagnosis: rows[0]?.diagnosis || 'L4-S1 Lumbar Disc Herniation with Radiculopathy',
      body_part: rows[0]?.body_part || 'Lumbar Spine',
      line_of_business: rows[0]?.line_of_business || 'Commercial Auto Liability',
      billing_state: rows[0]?.provider_billing_state || 'PA',
      billing_zip: rows[0]?.provider_billing_zip_code || '19104',
      first_treatment_date: firstDate ? firstDate.toLocaleDateString() : 'N/A',
      total_treatment_span_days: maxDays,
      total_bills_count: bCnt,
      total_billed_amount: totAmt,
      early_spend_0_30d: earlySpend,
      mid_spend_31_90d: midSpend,
      late_spend_91d_plus: lateSpend,
      spend_velocity_per_day: dailyVelocity,
      inflection_point_day: `Day ${primaryJumpRow?.elapsed_days || 0}`,
      inflection_day_num: primaryJumpRow?.elapsed_days || 0,
      inflection_category: primaryJumpRow?.bill_line_item_category || 'N/A',
      inflection_facility: primaryJumpRow?.facility_name || 'N/A',
      inflection_doctor: primaryJumpRow?.provider_name || 'N/A',
      inflection_jump_amount: primaryJumpRow?.bill_line_item_build_amount || 0,
      primary_inflection: primaryJumpRow ? {
        record_id: primaryJumpRow.record_id,
        tag_id: primaryJumpRow.tag_id,
        day: primaryJumpRow.elapsed_days,
        amount: primaryJumpRow.bill_line_item_build_amount,
        category: primaryJumpRow.bill_line_item_category,
        facility: primaryJumpRow.facility_name,
        doctor: primaryJumpRow.provider_name,
        service_date: primaryJumpRow.effective_service_date,
        procedure: primaryJumpRow.procedure_description
      } : null,
      secondary_inflection: secondaryJumpRow ? {
        record_id: secondaryJumpRow.record_id,
        tag_id: secondaryJumpRow.tag_id,
        day: secondaryJumpRow.elapsed_days,
        amount: secondaryJumpRow.bill_line_item_build_amount,
        category: secondaryJumpRow.bill_line_item_category,
        facility: secondaryJumpRow.facility_name,
        doctor: secondaryJumpRow.provider_name,
        service_date: secondaryJumpRow.effective_service_date,
        procedure: secondaryJumpRow.procedure_description
      } : null,
      breached_phases: breachedPhases,
      breached_acute_phase: breachedPhases.some(p => p.eval_day === 30),
      breached_surgical_phase: breachedPhases.some(p => p.eval_day === 180),
      p90_status: p90Breached ? 'P90 BREACH' : 'Normal Range',
      is_p90_outlier: isOutlier,
      early_risk_score: earlyRiskScore,
      first_p90_breach_milestone: firstP90Window,
      severity_classification: severityClass,
      clinical_progression_pattern: progression,
      genai_narrative: genAiNarrative,
      bill_rows: rows
    });
  }

  // Enrich milestoneStats with phase breach counts across portfolio
  for (const m of milestoneStats) {
    const breaching = claimSummaries.filter(c => {
      const cum = claimSpendAtMilestone[m.eval_day][c.job_id] || 0;
      return cum >= m.p90 && m.p90 > 0;
    });
    m.phase_breach_count = breaching.length;
    m.phase_breaching_job_ids = breaching.map(c => c.job_id);
    m.phase_breach_pct = Math.round((breaching.length / (totalClaims || 1)) * 100);
  }

  claimSummaries.sort((a, b) => b.total_billed_amount - a.total_billed_amount);

  // Category Shift
  const categoryPhaseTotals = {};
  const phaseTotals = { M30: 0, M60: 0, M90: 0, M180: 0, M270: 0, M293: 0 };

  for (const row of normalized) {
    const cat = row.bill_line_item_category;
    if (!categoryPhaseTotals[cat]) {
      categoryPhaseTotals[cat] = { M30: 0, M60: 0, M90: 0, M180: 0, M270: 0, M293: 0, total: 0 };
    }
    const d = row.elapsed_days;
    const amt = row.bill_line_item_build_amount;

    categoryPhaseTotals[cat].total += amt;
    if (d <= 30) { categoryPhaseTotals[cat].M30 += amt; phaseTotals.M30 += amt; }
    else if (d <= 60) { categoryPhaseTotals[cat].M60 += amt; phaseTotals.M60 += amt; }
    else if (d <= 90) { categoryPhaseTotals[cat].M90 += amt; phaseTotals.M90 += amt; }
    else if (d <= 180) { categoryPhaseTotals[cat].M180 += amt; phaseTotals.M180 += amt; }
    else if (d <= 270) { categoryPhaseTotals[cat].M270 += amt; phaseTotals.M270 += amt; }
    else { categoryPhaseTotals[cat].M293 += amt; phaseTotals.M293 += amt; }
  }

  const categoryShiftList = Object.entries(categoryPhaseTotals).map(([cat, p]) => {
    return {
      category: cat,
      total_spend: p.total,
      early_spend: p.M30 + p.M60,
      late_spend: p.M180 + p.M270 + p.M293,
      early_share: ((p.M30 + p.M60) / (p.total || 1)) * 100,
      late_share: ((p.M180 + p.M270 + p.M293) / (p.total || 1)) * 100,
      m30: p.M30,
      m60: p.M60,
      m90: p.M90,
      m180: p.M180,
      m270: p.M270,
      m293: p.M293
    };
  }).sort((a, b) => b.total_spend - a.total_spend);

  const uniqueCategories = categoryShiftList.map(c => c.category);
  const dynamicCategoryColors = {};
  uniqueCategories.forEach((cat, idx) => {
    dynamicCategoryColors[cat] = CATEGORY_COLORS[cat] || PALETTE_COLORS[idx % PALETTE_COLORS.length];
  });

  const categoryMigrationPhases = [
    { phase: '0-30d (Acute)', ...getPhaseDistribution(categoryPhaseTotals, 'M30', phaseTotals.M30, uniqueCategories) },
    { phase: '31-60d (Subacute)', ...getPhaseDistribution(categoryPhaseTotals, 'M60', phaseTotals.M60, uniqueCategories) },
    { phase: '61-90d (Diag/Spec)', ...getPhaseDistribution(categoryPhaseTotals, 'M90', phaseTotals.M90, uniqueCategories) },
    { phase: '91-180d (Surgical)', ...getPhaseDistribution(categoryPhaseTotals, 'M180', phaseTotals.M180, uniqueCategories) },
    { phase: '181-270d (Rehab)', ...getPhaseDistribution(categoryPhaseTotals, 'M270', phaseTotals.M270, uniqueCategories) },
    { phase: '271d+ (Resolution)', ...getPhaseDistribution(categoryPhaseTotals, 'M293', phaseTotals.M293, uniqueCategories) }
  ];

  function getPhaseDistribution(totals, phaseKey, totalAmt, categoriesList) {
    const res = {};
    for (const cat of categoriesList) {
      const amt = totals[cat] ? totals[cat][phaseKey] : 0;
      res[cat] = Math.round(amt);
    }
    return res;
  }

  return {
    rawBills: normalized,
    claimSummaries,
    milestoneStats,
    claimSpendAtMilestone,
    categoryShiftList,
    categoryMigrationPhases,
    uniqueCategories,
    dynamicCategoryColors,
    hasStatusColumn,
    portfolioStats: {
      totalClaims,
      openClaimsCount: claimSummaries.filter(c => c.claim_status === 'Open').length,
      closedClaimsCount: claimSummaries.filter(c => c.claim_status === 'Closed').length,
      hasStatusColumn,
      totalMedicalSpend,
      averageClaimSpend: totalMedicalSpend / (totalClaims || 1),
      maxTreatmentDays: Math.max(...claimSummaries.map(c => c.total_treatment_span_days), 0),
      p90OutlierCount,
      finalP90Threshold: finalP90,
      p90SpendShare: (claimSummaries.filter(c => c.total_billed_amount >= finalP90).reduce((s, c) => s + c.total_billed_amount, 0) / (totalMedicalSpend || 1)) * 100
    }
  };
}

// Download Power BI Data Bundle (.xlsx and .csv files)
export function exportPowerBiModel(analysisData) {
  if (!analysisData) return;

  const wb = XLSX.utils.book_new();

  // Dim_Claims
  const dimClaims = analysisData.claimSummaries.map(c => ({
    JobID: c.job_id,
    ClaimStatus: c.claim_status,
    ClaimantName: c.claimant_name,
    Diagnosis: c.diagnosis,
    BodyPart: c.body_part,
    LineOfBusiness: c.line_of_business,
    State: c.billing_state,
    Zip: c.billing_zip,
    FirstTreatmentDate: c.first_treatment_date,
    TotalDurationDays: c.total_treatment_span_days,
    TotalBillsCount: c.total_bills_count,
    TotalBilledAmount: c.total_billed_amount,
    EarlySpend0_30d: c.early_spend_0_30d,
    MidSpend31_90d: c.mid_spend_31_90d,
    LateSpend91dPlus: c.late_spend_91d_plus,
    DailySpendVelocity: c.spend_velocity_per_day,
    InflectionDay: c.inflection_day_num,
    InflectionCategory: c.inflection_category,
    InflectionFacility: c.inflection_facility,
    InflectionDoctor: c.inflection_doctor,
    InflectionSpikeAmount: c.inflection_jump_amount,
    IsP90Outlier: c.is_p90_outlier,
    P90Status: c.p90_status,
    SeverityClassification: c.severity_classification,
    ProgressionPattern: c.clinical_progression_pattern,
    EarlyWarningRiskScore: c.early_risk_score,
    GenAiNarrative: c.genai_narrative
  }));
  const wsClaims = XLSX.utils.json_to_sheet(dimClaims);
  XLSX.utils.book_append_sheet(wb, wsClaims, 'Dim_Claims');

  // Fact_Bills
  const factBills = analysisData.rawBills.map(b => ({
    JobID: b.job_id,
    RecordID: b.record_id,
    TagID: b.tag_id,
    FacilityName: b.facility_name,
    ProviderName: b.provider_name,
    State: b.provider_billing_state,
    Zip: b.provider_billing_zip_code,
    ServiceDate_DOS: b.effective_service_date ? b.effective_service_date.toISOString().split('T')[0] : '',
    Category: b.bill_line_item_category,
    ProcedureDescription: b.procedure_description,
    BilledAmount: b.bill_line_item_build_amount,
    ElapsedDays: b.elapsed_days,
    CumulativeSpend: b.cumulative_spend,
    CumulativeSpendPct: b.cumulative_spend_pct,
    TemporalPhaseBin: b.temporal_bin,
    IsTopJump1: b.is_top_jump_1 ? 'YES' : 'NO',
    IsTopJump2: b.is_top_jump_2 ? 'YES' : 'NO'
  }));
  const wsBills = XLSX.utils.json_to_sheet(factBills);
  XLSX.utils.book_append_sheet(wb, wsBills, 'Fact_Bills');

  // Dim_Milestones
  const wsMilestones = XLSX.utils.json_to_sheet(analysisData.milestoneStats);
  XLSX.utils.book_append_sheet(wb, wsMilestones, 'Dim_Milestones');

  // Matrix_Category_Shift
  const wsCategory = XLSX.utils.json_to_sheet(analysisData.categoryShiftList);
  XLSX.utils.book_append_sheet(wb, wsCategory, 'Matrix_Category_Shift');

  XLSX.writeFile(wb, 'ClaimOptima_PowerBI_Dataset.xlsx');
}

export function generate3000ClaimsDemo() {
  const categories = ['Hospital / ER', 'Inpatient Surgery', 'Physical Therapy', 'Treating Physician', 'Diagnostic Imaging', 'Pain Management', 'Inpatient / ICU'];
  const states = ['PA', 'CA', 'TX', 'FL', 'NY', 'IL', 'OH', 'AZ', 'GA', 'WA'];
  const facilities = ['Penn Spine Institute', 'Metro Trauma Center', 'Spine & Ortho Hospital', 'Active Rehab Clinic', 'Advanced Radiology Center', 'County General ER', 'Penn Rehab Hospital', 'Precision Surgery Pavillion'];
  const doctors = ['Dr. William Sterling', 'Dr. Susan Davis', 'Dr. Sarah Jenkins', 'Dr. Marcus Vance', 'Dr. Elena Rostova', 'Dr. Kevin Patel', 'Dr. Carlos Ruiz', 'Dr. Rachel Green'];
  const claimantPool = [
    { name: 'Marcus Vance', diag: 'L4-S1 Lumbar Disc Herniation with Radiculopathy', body: 'Lumbar Spine', lob: 'Commercial Auto Liability' },
    { name: 'Elena Rostova', diag: 'Right Glenohumeral Rotator Cuff Tear & Impingement', body: 'Right Shoulder', lob: 'Workers Compensation' },
    { name: 'David Chen', diag: 'Left Knee Medial Meniscus Bucket-Handle Tear', body: 'Left Knee', lob: 'General Liability' },
    { name: 'Sarah Jenkins', diag: 'Cervical Spondylosis with C5-C6 Radiculopathy', body: 'Cervical Spine', lob: 'Commercial Auto Liability' },
    { name: 'Arthur Conan', diag: 'Distal Radius Comminuted Fracture & Soft Tissue Contusion', body: 'Right Wrist / Forearm', lob: 'Workers Compensation' },
    { name: 'Rachel Green', diag: 'Traumatic Brain Injury (Mild) & Post-Concussion Syndrome', body: 'Head / Neurological', lob: 'Commercial Auto Liability' },
    { name: 'Carlos Ruiz', diag: 'Multilevel Lumbar Facet Arthropathy & Sciatica', body: 'Lumbar Spine', lob: 'Workers Compensation' },
    { name: 'Kevin Patel', diag: 'Left Hip Labral Tear & Acetabular Impingement', body: 'Left Hip', lob: 'General Liability' }
  ];

  const rows = [];
  const baseDate = new Date(2024, 0, 15);
  let recCounter = 10000;
  let tagCounter = 50000;

  for (let i = 1; i <= 3000; i++) {
    const jobId = `CLM-${1000 + i}`;
    const state = states[(i - 1) % states.length];
    const zip = `${19100 + ((i - 1) % 800)}`;
    const claimantProfile = claimantPool[(i - 1) % claimantPool.length];
    
    // Status distribution: ~68% Open, ~32% Closed
    const claimStatus = (i % 3 === 0) ? 'Closed' : 'Open';

    let numBills = 4;
    let daysOffsets = [0, 14, 30, 60];
    let amounts = [1200, 450, 1450, 1600];
    let cats = ['Hospital / ER', 'Treating Physician', 'Physical Therapy', 'Treating Physician'];
    let procedures = [
      'Emergency Department Triage & Radiographs',
      'Initial Attending Physician Consultation',
      'Physical Therapy Evaluation & Core Strengthening',
      'Follow-up Progress Assessment & Range of Motion'
    ];

    // CLM-1001 & CLM-1008: 18 Distinct Bill Records spanning 265 days with dual surgical/ICU inflection points
    if (i === 1 || i === 8) {
      numBills = 18;
      daysOffsets = [0, 8, 14, 22, 35, 42, 49, 56, 70, 85, 88, 105, 120, 135, 155, 180, 215, 250];
      amounts = [3200, 1200, 4500, 1800, 450, 450, 450, 450, 2200, 68500, 14200, 1600, 650, 650, 650, 3800, 2400, 1800];
      cats = [
        'Hospital / ER', 'Treating Physician', 'Diagnostic Imaging', 'Treating Physician',
        'Physical Therapy', 'Physical Therapy', 'Physical Therapy', 'Physical Therapy',
        'Pain Management', 'Inpatient Surgery', 'Inpatient / ICU', 'Treating Physician',
        'Physical Therapy', 'Physical Therapy', 'Physical Therapy', 'Pain Management',
        'Physical Therapy', 'Treating Physician'
      ];
      procedures = [
        'Emergency Room Trauma Triage & Lumbosacral X-rays',
        'Initial Orthopedic Consultation & Pain Assessment',
        'MRI Lumbar Spine 3T (L4-S1 Herniation Confirmed)',
        'Neurosurgery Follow-up & Conservative Care Plan',
        'Physical Therapy Initial Session (Gait & Core)',
        'Physical Therapy Session 2 (Lumbar Stabilization)',
        'Physical Therapy Session 3 (Flexibility & ROM)',
        'Physical Therapy Session 4 (Therapeutic Exercise)',
        'Fluoroscopy-Guided L5-S1 Epidural Steroid Injection',
        'L4-S1 Transforaminal Lumbar Interbody Fusion (TLIF) Surgery',
        'ICU Surgical Recovery & Post-Operative Monitoring',
        'Post-Surgical Attending Physician Progress Evaluation',
        'Post-Operative Physical Rehabilitation Session 1',
        'Post-Operative Physical Rehabilitation Session 2',
        'Post-Operative Physical Rehabilitation Session 3',
        'Bilateral Lumbar Facet Radiofrequency Ablation',
        'Work-Hardening Conditioning & Functional Capacity',
        'Final Medical Maximum Improvement (MMI) Evaluation'
      ];
    } else if (i % 20 === 0) {
      // 14-bill Catastrophic Outlier
      numBills = 14;
      daysOffsets = [0, 5, 12, 28, 45, 60, 75, 92, 95, 120, 150, 180, 210, 240];
      amounts = [4500, 1800, 3200, 1200, 450, 450, 2800, 72000, 16500, 1800, 650, 650, 3200, 1900];
      cats = [
        'Hospital / ER', 'Diagnostic Imaging', 'Treating Physician', 'Physical Therapy',
        'Physical Therapy', 'Physical Therapy', 'Pain Management', 'Inpatient Surgery',
        'Inpatient / ICU', 'Treating Physician', 'Physical Therapy', 'Physical Therapy',
        'Pain Management', 'Treating Physician'
      ];
      procedures = [
        'Level 1 Trauma Triage & Computed Tomography',
        'Complete Musculoskeletal MRI Series',
        'Specialist Evaluation & Conservative Plan',
        'Targeted Physical Therapy Sessions',
        'Manual Therapy & Joint Mobilization',
        'Core Rehabilitation Protocol',
        'Trigger Point Injections & Nerve Block',
        'Complex Spinal Decompression & Instrumented Fusion',
        'ICU Critical Care Monitoring & Hemodynamic Support',
        'Specialist Post-Op Hospital Rounding',
        'Rehabilitation & Functional Mobility Training',
        'Subacute Physical Conditioning',
        'Spinal Cord Stimulation Trial',
        'Comprehensive Impairment Rating'
      ];
    } else if (i % 7 === 0) {
      // 8-bill Acute ER Outlier
      numBills = 8;
      daysOffsets = [0, 0, 14, 45, 90, 150, 220, 290];
      amounts = [78500, 14200, 5800, 3400, 2800, 2400, 2100, 1900];
      cats = [
        'Hospital / ER', 'Inpatient Surgery', 'Inpatient / ICU', 'Treating Physician',
        'Physical Therapy', 'Treating Physician', 'Treating Physician', 'Treating Physician'
      ];
      procedures = [
        'Acute Emergency Resuscitation & Emergency Surgery Prep',
        'Urgent Open Reduction & Internal Fixation',
        'Intensive Care Unit Critical Care Services',
        'Attending Trauma Surgeon Follow-up',
        'Outpatient Physical Therapy Course',
        'Clinical Progress Evaluation',
        'Orthopedic Follow-up & Hardware Assessment',
        'Final Case Review & Functional Release'
      ];
    } else if (i % 4 === 0) {
      // 7-bill Mid-Phase Surgical Claim
      numBills = 7;
      daysOffsets = [0, 12, 35, 58, 85, 185, 280];
      amounts = [1850, 650, 2200, 42000, 4800, 6200, 3200];
      cats = [
        'Hospital / ER', 'Treating Physician', 'Diagnostic Imaging', 'Inpatient Surgery',
        'Physical Therapy', 'Pain Management', 'Physical Therapy'
      ];
      procedures = [
        'Urgent Care Initial Evaluation & Splinting',
        'Primary Care Physician Review',
        'High-Resolution MRI & Contrast Study',
        'Arthroscopic Surgical Reconstruction',
        'Post-Surgical Range of Motion PT',
        'Interventional Pain Management & Injection',
        'Functional Restoration Therapy'
      ];
    } else if (i % 2 === 0) {
      // 6-bill Progressive Treatment
      numBills = 6;
      daysOffsets = [0, 10, 25, 45, 75, 110];
      amounts = [2400, 850, 450, 450, 1800, 1200];
      cats = ['Hospital / ER', 'Treating Physician', 'Physical Therapy', 'Physical Therapy', 'Diagnostic Imaging', 'Treating Physician'];
      procedures = [
        'Emergency Clinic Evaluation & Radiography',
        'Attending Physician Physical Exam',
        'Physical Therapy Initial Session',
        'Physical Therapy Continued Rehab',
        'Follow-up Diagnostic Radiographs',
        'Physician Final Clearance Assessment'
      ];
    }

    for (let b = 0; b < numBills; b++) {
      recCounter++;
      tagCounter++;
      const dOff = daysOffsets[b] || 0;
      const d = new Date(baseDate.getTime() + dOff * 24 * 60 * 60 * 1000);
      const dateStr = `${d.getMonth() + 1}/${d.getDate()}/${d.getFullYear()} 12:00:00 AM`;

      rows.push({
        job_id: jobId,
        record_id: `REC-${recCounter}`,
        tag_id: `TAG-${tagCounter}`,
        claim_status: claimStatus,
        claimant_name: claimantProfile.name,
        diagnosis: claimantProfile.diag,
        body_part: claimantProfile.body,
        line_of_business: claimantProfile.lob,
        procedure_description: procedures[b] || `${cats[b] || 'Treating Physician'} Procedure`,
        facility_name: facilities[(i + b) % facilities.length],
        provider_name: doctors[(i + b) % doctors.length],
        provider_billing_state: state,
        provider_billing_zip_code: zip,
        start_date: dateStr,
        end_date: dateStr,
        bill_line_item_service_date: dateStr,
        bill_line_item_build_amount: amounts[b] || 500,
        bill_line_item_category: cats[b] || 'Treating Physician'
      });
    }
  }

  return rows;
}
