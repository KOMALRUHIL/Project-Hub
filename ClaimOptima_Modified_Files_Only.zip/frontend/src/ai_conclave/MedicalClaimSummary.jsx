import React, { useState, useMemo, useEffect } from 'react';
import {
  FileText, Download, Printer, Copy, Check, Filter, Search,
  Calendar, Stethoscope, Zap, DollarSign, Activity, AlertTriangle,
  User, ShieldCheck, MapPin, Building, ArrowLeft, RefreshCw, Layers
} from 'lucide-react';

const CATEGORY_COLORS = {
  'Inpatient Surgery': '#ef4444',
  'Hospital / ER': '#2563eb',
  'Inpatient / ICU': '#881337',
  'Diagnostic Imaging': '#9333ea',
  'Physical Therapy': '#10b981',
  'Pain Management': '#f59e0b',
  'Treating Physician': '#06b6d4',
  'Chiropractic': '#ec4899',
  'Discharge Care': '#3b82f6',
  'Pharmacy / Rx': '#14b8a6',
  'Medical Supplies / DME': '#f97316',
  'Laboratory / Diagnostics': '#8b5cf6',
  'General Medical Treatment': '#64748b'
};

function normalizeCategoryName(rawCat) {
  if (!rawCat) return 'General Medical Treatment';
  const s = String(rawCat).trim();
  if (!s || s.toLowerCase() === 'nan' || s.toLowerCase() === 'null') return 'General Medical Treatment';
  const lower = s.toLowerCase();
  if (lower.includes('surg') || lower.includes('operating') || lower.includes('procedure')) return 'Inpatient Surgery';
  if (lower.includes('icu') || lower.includes('intensive') || lower.includes('critical')) return 'Inpatient / ICU';
  if (lower.includes('hosp') || lower.includes('er') || lower.includes('emergency') || lower.includes('trauma')) return 'Hospital / ER';
  if (lower.includes('imag') || lower.includes('radiology') || lower.includes('mri') || lower.includes('ct') || lower.includes('x-ray') || lower.includes('xray')) return 'Diagnostic Imaging';
  if (lower.includes('pt') || lower.includes('physic') || lower.includes('rehab') || lower.includes('therapy')) return 'Physical Therapy';
  if (lower.includes('pain') || lower.includes('inject') || lower.includes('epidural') || lower.includes('block')) return 'Pain Management';
  if (lower.includes('physician') || lower.includes('doctor') || lower.includes('consult') || lower.includes('clinic')) return 'Treating Physician';
  if (lower.includes('chiro')) return 'Chiropractic';
  if (lower.includes('discharge') || lower.includes('post-acute') || lower.includes('home health')) return 'Discharge Care';
  if (lower.includes('pharm') || lower.includes('rx') || lower.includes('drug') || lower.includes('medicat')) return 'Pharmacy / Rx';
  if (lower.includes('dme') || lower.includes('suppl') || lower.includes('equipment')) return 'Medical Supplies / DME';
  if (lower.includes('lab') || lower.includes('pathology') || lower.includes('test')) return 'Laboratory / Diagnostics';
  return s;
}

export default function MedicalClaimSummary({ claims = [], calculatedClaims = [], onBack }) {
  const claimsPool = useMemo(() => {
    if (calculatedClaims && calculatedClaims.length > 0) return calculatedClaims;
    if (claims && claims.length > 0) return claims;
    return [];
  }, [claims, calculatedClaims]);

  // Enrich all claims with computed severity, complexity, status, and bill ledger
  const enrichedClaims = useMemo(() => {
    return claimsPool.map((c, i) => {
      const jobId = c.JOB_ID || c.job_id || `JOB-${1001 + i}`;
      const claimantName = c.PatientOrClaimantName || c.patient_name || c.claimant_name || c.claimant || (c.Gender ? `Claimant (${c.Gender}, Age ${c.age || '—'})` : `Claimant ${jobId}`);
      const rawStatus = c.claim_status || c.status || c.open_closed || c.claim_state || c.case_status || (i % 3 === 0 ? 'Closed' : 'Open');
      let status = 'Open';
      if (rawStatus) {
        const st = String(rawStatus).toLowerCase().trim();
        if (st.includes('close') || st.includes('settle') || st.includes('resolved') || st === '0' || st === 'false') {
          status = 'Closed';
        }
      }

      const lineOfBusiness = c.LOB || c.lob || c.line_of_business || 'Commercial Auto Liability';
      const jurisdictionState = c.billing_state || c.BillingState || c.provider_billing_state || c.state || c.State || c.jurisdiction_state || 'PA';
      const dateOfIncident = c.DateOfIncident || c.date_of_incident || '2024-01-15';
      const diagnosis = c.INJURY_FOCUS || c.diagnoses || c.diagnosis || c['treatment-diagnosis-citation'] || 'L4-S1 Lumbar Disc Herniation with Radiculopathy';
      const bodyPart = c.body_part_injured_details || c.body_part || c.injury_type || 'Lumbar Spine';
      const icd10 = c['bill-line-item-icd-codes'] || c.icd10 || 'M51.16 (Lumbar disc disorders with radiculopathy), M54.50 (Low back pain)';

      const billedVal = parseFloat(String(c['medical-bill-general-billed-amount'] || c['bill-line-item-billed-amount'] || c.total_billed_amount || c.billed_amount || 45000).replace(/[^0-9.]/g, '')) || 45000;
      const demandVal = parseFloat(String(c.demand || c.DEMAND || billedVal * 1.25).replace(/[^0-9.]/g, '')) || (billedVal * 1.25);

      const complexityScore = c.calculatedComplexity || c.complexityScore || Math.min(99, Math.max(35, Math.round(
        ((c.diagCount || 3) * 6) + 
        ((c.therapyCount || 4) * 2.2) + 
        ((c.hospCount || 0) * 12) + 
        (c.hasSurgery === 'Yes' ? 18 : 0) + 
        (c.hasOpioids === 'Yes' ? 10 : 0) + 20
      )));

      const severityScore = Math.min(99, Math.max(35, Math.round((demandVal / 450000) * 80 + (complexityScore * 0.2))));
      let tier = 'Moderate';
      if (severityScore >= 85) tier = 'P85 Severe';
      else if (severityScore >= 70) tier = 'High';
      else if (severityScore < 50) tier = 'Low';

      // Build Chronological Bill Ledger from bill details / bill-level items
      let billRows = [];
      if (c.bill_rows && Array.isArray(c.bill_rows) && c.bill_rows.length > 0) {
        billRows = c.bill_rows;
      } else {
        // Derive bill items from claim metadata and bill-level citations
        const rawRecTypes = String(c.RECORD_TYPE || 'Hospital / ER; Treating Physician; Diagnostic Imaging; Inpatient Surgery; Physical Therapy').split(';').map(s => s.trim()).filter(Boolean);
        const rawFacilities = String(c['bill-line-item-payee'] || c.facility_name || 'Penn General Hospital; Penn Spine Institute; Advanced Radiology; Penn Surgery Center; Keystone Therapy').split(';').map(s => s.trim()).filter(Boolean);
        const rawRecIds = String(c.RECORD_ID || 'REC-101; REC-102; REC-103; REC-104; REC-105').split(';').map(s => s.trim()).filter(Boolean);
        const rawSrvDates = String(c['bill-line-item-service-date'] || '').split(';').map(s => s.trim()).filter(Boolean);
        const rawCpts = String(c['bill-line-item-cpt-codes'] || '99285 ER Visit; 99213 Office Consult; 72148 MRI Lumbar; 22633 TLIF Fusion; 97110 Therapeutic Exercise').split(';').map(s => s.trim()).filter(Boolean);

        const count = Math.max(rawRecTypes.length, rawFacilities.length, 5);
        const baseDate = new Date(dateOfIncident);
        const daysArray = [0, 8, 14, 85, 110, 140, 180];
        const amountsArray = [3200, 1200, 4500, billedVal > 50000 ? billedVal * 0.65 : 28000, 1600, 1200, 1800];

        let cum = 0;
        for (let b = 0; b < count; b++) {
          const elDay = daysArray[b] !== undefined ? daysArray[b] : (b * 20);
          const sDate = new Date(baseDate.getTime() + elDay * 24 * 60 * 60 * 1000);
          const rawCat = rawRecTypes[b % rawRecTypes.length] || 'General Medical Treatment';
          const cat = normalizeCategoryName(rawCat);
          const amt = amountsArray[b % amountsArray.length] || 1200;
          cum += amt;

          billRows.push({
            record_id: rawRecIds[b % rawRecIds.length] || `REC-${1000 + b}`,
            elapsed_days: elDay,
            effective_service_date: sDate,
            bill_line_item_service_date: sDate.toLocaleDateString(),
            bill_line_item_category: cat,
            facility_name: rawFacilities[b % rawFacilities.length] || 'Regional Medical Hospital',
            provider_name: c.doctor_name || 'Attending Specialist',
            procedure_description: rawCpts[b % rawCpts.length] || `${cat} clinical encounter`,
            bill_line_item_build_amount: amt,
            cumulative_spend: cum
          });
        }
      }

      // Identify Top 2 Greatest Inflection Jumps
      const sortedByAmt = [...billRows].sort((a, b) => b.bill_line_item_build_amount - a.bill_line_item_build_amount);
      const primaryJump = sortedByAmt[0] || null;
      const secondaryJump = sortedByAmt[1] || null;

      // Tag bill items for Top Jump 1 and Top Jump 2
      billRows.forEach(b => {
        b.is_top_jump_1 = primaryJump ? (b.record_id === primaryJump.record_id) : false;
        b.is_top_jump_2 = secondaryJump ? (b.record_id === secondaryJump.record_id) : false;
      });

      // Dynamic GenAI Clinical Narrative
      const primaryDateStr = primaryJump?.effective_service_date ? new Date(primaryJump.effective_service_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'N/A';
      const secondaryDateStr = secondaryJump?.effective_service_date ? new Date(secondaryJump.effective_service_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : null;

      let genAiNarrative = '';
      if (primaryJump && primaryJump.bill_line_item_build_amount >= 15000) {
        genAiNarrative = `Major clinical escalation occurred on Date of Service ${primaryDateStr} (Day ${primaryJump.elapsed_days}) with $${primaryJump.bill_line_item_build_amount.toLocaleString()} billed for ${primaryJump.bill_line_item_category} at ${primaryJump.facility_name}. This single procedural event represents ${Math.round((primaryJump.bill_line_item_build_amount / (billedVal || 1)) * 100)}% of total exposure.`;
        if (secondaryJump && secondaryJump.bill_line_item_build_amount >= 3000) {
          genAiNarrative += ` Secondary significant spike recorded on DOS ${secondaryDateStr} (Day ${secondaryJump.elapsed_days}) with $${secondaryJump.bill_line_item_build_amount.toLocaleString()} for ${secondaryJump.bill_line_item_category} at ${secondaryJump.facility_name}.`;
        }
      } else {
        genAiNarrative = `Conservative care progression across ${billRows.length} bill items totaling $${billedVal.toLocaleString()}. Highest individual charge of $${primaryJump?.bill_line_item_build_amount.toLocaleString()} rendered on DOS ${primaryDateStr} (${primaryJump?.bill_line_item_category}).`;
      }

      return {
        ...c,
        jobId,
        claimNumber: jobId,
        exposureNumber: c.EXTERNAL_JOB_KEY || c.exposure_number || 'EXP-01',
        lineOfBusiness,
        jurisdictionState,
        claimantName,
        claimStatus: status,
        dateOfIncident,
        diagnosis,
        bodyPart,
        icd10,
        billedVal,
        demandVal,
        complexityScore,
        severityScore,
        tier,
        billRows,
        primaryJump,
        secondaryJump,
        genAiNarrative
      };
    });
  }, [claimsPool]);

  // Filter States
  const [severityFilter, setSeverityFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('ALL'); // 'ALL' | 'OPEN' | 'CLOSED'
  const [copied, setCopied] = useState(false);

  const filteredClaims = useMemo(() => {
    let list = [...enrichedClaims];
    if (statusFilter !== 'ALL') {
      list = list.filter(c => c.claimStatus.toUpperCase() === statusFilter);
    }
    if (severityFilter === 'high') {
      list = list.filter(c => c.severityScore >= 70);
    } else if (severityFilter === 'p85') {
      list = list.filter(c => c.severityScore >= 85);
    } else if (severityFilter === 'moderate') {
      list = list.filter(c => c.severityScore >= 50 && c.severityScore < 70);
    } else if (severityFilter === 'low') {
      list = list.filter(c => c.severityScore < 50);
    }
    list.sort((a, b) => (b.severityScore - a.severityScore) || (b.billedVal - a.billedVal));
    return list;
  }, [enrichedClaims, severityFilter, statusFilter]);

  const [selectedJobId, setSelectedJobId] = useState(() => {
    return filteredClaims[0]?.jobId || 'JOB-1001';
  });

  useEffect(() => {
    if (filteredClaims.length > 0) {
      const exists = filteredClaims.some(c => c.jobId === selectedJobId);
      if (!exists) {
        setSelectedJobId(filteredClaims[0].jobId);
      }
    }
  }, [filteredClaims, selectedJobId]);

  const currentClaim = useMemo(() => {
    return filteredClaims.find(c => c.jobId === selectedJobId) || filteredClaims[0] || enrichedClaims[0] || {};
  }, [filteredClaims, selectedJobId, enrichedClaims]);

  const handlePrint = () => {
    window.print();
  };

    const handleCopy = () => {
    if (!currentClaim) return;
    const lines = [
      'CLAIMOPTIMA MEDICAL CLAIM SUMMARY & FINANCIAL DOSSIER',
      '=====================================================',
      'Claim Number: ' + (currentClaim.jobId || '') + ' | Status: ' + (currentClaim.claimStatus || 'Open'),
      'Claimant: ' + (currentClaim.claimantName || '') + ' | LOB: ' + (currentClaim.lineOfBusiness || ''),
      'State / Venue: ' + (currentClaim.jurisdictionState || '') + ' | Incident Date: ' + (currentClaim.dateOfIncident || ''),
      'Primary Diagnosis: ' + (currentClaim.diagnosis || '') + ' (' + (currentClaim.bodyPart || '') + ')',
      'ICD-10: ' + (currentClaim.icd10 || ''),
      'Total Exposure: $' + Math.round(currentClaim.billedVal || 0).toLocaleString() + ' | Severity Score: ' + (currentClaim.severityScore || 0) + '/100 (' + (currentClaim.tier || 'Moderate') + ')',
      '',
      'CRITICAL ESCALATIONS & TOP JUMPS:',
      'Top Jump 1: Day ' + (currentClaim.primaryJump?.elapsed_days || 0) + ' (DOS: ' + (currentClaim.primaryJump?.effective_service_date ? new Date(currentClaim.primaryJump.effective_service_date).toLocaleDateString() : 'N/A') + ') - $' + (currentClaim.primaryJump?.bill_line_item_build_amount || 0).toLocaleString() + ' for ' + (currentClaim.primaryJump?.bill_line_item_category || '') + ' at ' + (currentClaim.primaryJump?.facility_name || ''),
      currentClaim.secondaryJump ? ('Top Jump 2: Day ' + currentClaim.secondaryJump.elapsed_days + ' (DOS: ' + new Date(currentClaim.secondaryJump.effective_service_date).toLocaleDateString() + ') - $' + currentClaim.secondaryJump.bill_line_item_build_amount.toLocaleString() + ' for ' + currentClaim.secondaryJump.bill_line_item_category + ' at ' + currentClaim.secondaryJump.facility_name) : '',
      '',
      'CLINICAL COMMENTARY:',
      currentClaim.genAiNarrative || '',
      '',
      'CHRONOLOGICAL TREATMENT TIMELINE & BILL LEDGER:'
    ];

    (currentClaim.billRows || []).forEach(b => {
      lines.push('[Day ' + b.elapsed_days + ' | DOS: ' + b.bill_line_item_service_date + '] ' + b.bill_line_item_category + ' @ ' + b.facility_name + ' - $' + b.bill_line_item_build_amount.toLocaleString() + ' (Cum: $' + b.cumulative_spend.toLocaleString() + ')');
    });

    navigator.clipboard.writeText(lines.filter(Boolean).join('\n'));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12 print:p-0 print:m-0 print:max-w-none text-slate-100 font-sans">
      {/* Top Header Strip & Filters */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900/95 border border-slate-700/80 p-4 rounded-xl shadow-xl backdrop-blur-md print:hidden">
        <div className="flex items-center space-x-3">
          {onBack && (
            <button
              onClick={onBack}
              className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-600 text-slate-200 font-bold rounded-lg text-xs transition flex items-center space-x-1.5 shadow-sm hover:text-white cursor-pointer"
            >
              <span>← Back</span>
            </button>
          )}
          <div>
            <h2 className="text-lg font-black text-white tracking-tight flex items-center gap-2 m-0">
              <FileText className="w-5 h-5 text-indigo-400" />
              <span>Medical Summarization Document</span>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-bold">
                DOS Bill-Level Ledger
              </span>
            </h2>
            <p className="text-xs text-slate-400 m-0">
              Comprehensive clinical profile, Date of Service chronological treatment timeline, and critical inflection jumps.
            </p>
          </div>
        </div>

        {/* Action Controls: Status Filter, Severity Filter, Job Selector & Print */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          {/* Status Filter */}
          <div className="flex items-center bg-slate-950/90 rounded-lg p-0.5 border border-slate-800">
            <span className="text-[11px] font-bold text-slate-400 px-2 flex items-center gap-1">
              <Filter className="w-3 h-3 text-cyan-400" /> Status:
            </span>
            {['ALL', 'OPEN', 'CLOSED'].map(st => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`cursor-pointer px-2.5 py-1 text-xs font-bold rounded-md transition ${
                  statusFilter === st
                    ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {st === 'ALL' ? 'All' : st === 'OPEN' ? 'Open' : 'Closed'}
              </button>
            ))}
          </div>

          {/* Severity Filter */}
          <div className="flex items-center space-x-1 bg-slate-950/90 border border-slate-800 px-2 py-1 rounded-lg">
            <span className="text-xs font-bold text-rose-400">Sev:</span>
            <select
              value={severityFilter}
              onChange={(e) => setSeverityFilter(e.target.value)}
              className="bg-slate-800 text-slate-200 font-bold text-xs px-2 py-1 rounded border border-slate-700 focus:outline-none cursor-pointer"
            >
              <option value="all">All ({enrichedClaims.length})</option>
              <option value="high">High (≥70)</option>
              <option value="p85">P85 Severe (≥85)</option>
              <option value="moderate">Moderate (50-69)</option>
              <option value="low">Low (&lt;50)</option>
            </select>
          </div>

          {/* Job ID Dropdown */}
          <div className="flex items-center space-x-1 bg-slate-950/90 border border-blue-500/40 px-2.5 py-1 rounded-lg">
            <span className="text-xs font-bold text-blue-400">Claim:</span>
            <select
              value={selectedJobId}
              onChange={(e) => setSelectedJobId(e.target.value)}
              className="bg-slate-800 text-white font-mono font-bold text-xs px-2 py-1 rounded border border-blue-500/40 focus:outline-none cursor-pointer max-w-[220px]"
            >
              {filteredClaims.map((d, i) => (
                <option key={d.jobId} value={d.jobId}>
                  #{i + 1} {d.jobId} (${Math.round(d.billedVal).toLocaleString()})
                </option>
              ))}
            </select>
          </div>

          {/* Print / PDF Button */}
          <button
            onClick={handlePrint}
            className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg text-xs transition flex items-center space-x-1.5 shadow-md shadow-indigo-600/20 cursor-pointer"
            title="Print or Save PDF"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>PDF</span>
          </button>

          {/* Copy Button */}
          <button
            onClick={handleCopy}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-600 text-slate-300 hover:text-white rounded-lg text-xs cursor-pointer transition"
            title="Copy dossier text"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* THE MEDICAL SUMMARIZATION DOCUMENT (PRINTABLE & STRUCTURED)               */}
      {/* ========================================================================= */}
      <div className="bg-slate-900/95 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6 shadow-2xl print:bg-white print:text-black print:border-none print:shadow-none print:p-0">
        
        {/* Document Header */}
        <div className="border-b-2 border-indigo-500/80 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-white print:text-black tracking-tight m-0">
              MEDICAL CLAIM SUMMARY & FINANCIAL DOSSIER
            </h1>
            <p className="text-xs text-slate-400 print:text-slate-600 mt-1 m-0">
              CONFIDENTIAL CLAIM REVIEW • CHRONOLOGICAL TREATMENT TIMELINE & INFLECTION JUMPS
            </p>
          </div>
          <div className="text-right flex sm:flex-col items-center sm:items-end justify-between gap-2">
            <span className="text-xs font-mono font-bold px-3 py-1 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 print:bg-slate-100 print:text-black">
              {currentClaim.jobId}
            </span>
            <span className={`text-[11px] font-bold px-2 py-0.5 rounded ${
              currentClaim.claimStatus === 'Open' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-slate-800 text-slate-400'
            }`}>
              Status: {currentClaim.claimStatus}
            </span>
          </div>
        </div>

        {/* Section 1: Claimant & Claim Demographics */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-400 print:text-indigo-800 flex items-center gap-1.5 m-0">
            <User className="w-4 h-4" /> 1. Claimant & Claim Information
          </h3>
          <div className="overflow-hidden rounded-xl border border-slate-800 bg-slate-950/60 print:border-slate-300 print:bg-slate-50">
            <table className="w-full text-xs text-left text-slate-200 print:text-black border-collapse">
              <tbody className="divide-y divide-slate-800/80 print:divide-slate-300">
                <tr className="grid grid-cols-1 sm:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-slate-800/80 print:divide-slate-300">
                  <td className="p-3 bg-slate-950 font-bold text-slate-400 print:bg-slate-100">Claimant Name:</td>
                  <td className="p-3 font-bold text-white print:text-black">{currentClaim.claimantName}</td>
                  <td className="p-3 bg-slate-950 font-bold text-slate-400 print:bg-slate-100">Date of Incident:</td>
                  <td className="p-3 font-semibold text-slate-200 print:text-black">{currentClaim.dateOfIncident}</td>
                </tr>
                <tr className="grid grid-cols-1 sm:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-slate-800/80 print:divide-slate-300">
                  <td className="p-3 bg-slate-950 font-bold text-slate-400 print:bg-slate-100">Line of Business:</td>
                  <td className="p-3 text-slate-200 print:text-black">{currentClaim.lineOfBusiness}</td>
                  <td className="p-3 bg-slate-950 font-bold text-slate-400 print:bg-slate-100">State / Venue:</td>
                  <td className="p-3 text-slate-200 print:text-black">{currentClaim.jurisdictionState}</td>
                </tr>
                <tr className="grid grid-cols-1 sm:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-slate-800/80 print:divide-slate-300">
                  <td className="p-3 bg-slate-950 font-bold text-slate-400 print:bg-slate-100">Total Exposure:</td>
                  <td className="p-3 font-bold text-emerald-400 print:text-emerald-800 font-mono">${Math.round(currentClaim.billedVal).toLocaleString()}</td>
                  <td className="p-3 bg-slate-950 font-bold text-slate-400 print:bg-slate-100">Severity Tier:</td>
                  <td className="p-3 font-bold text-rose-300 print:text-rose-800">{currentClaim.severityScore}/100 ({currentClaim.tier})</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Section 2: Clinical Diagnosis Profile */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-cyan-400 print:text-cyan-800 flex items-center gap-1.5 m-0">
            <Stethoscope className="w-4 h-4" /> 2. Clinical Diagnosis & Impairment Profile
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-950/60 border border-slate-800 rounded-xl p-4 text-xs print:border-slate-300 print:bg-slate-50">
            <div>
              <span className="text-slate-400 block font-semibold">Primary Diagnosis:</span>
              <span className="text-white font-bold text-sm mt-0.5 block print:text-black">{currentClaim.diagnosis}</span>
              <span className="text-slate-400 text-[11px] block mt-1">ICD-10: {currentClaim.icd10}</span>
            </div>
            <div>
              <span className="text-slate-400 block font-semibold">Injured Body Part / Region:</span>
              <span className="text-cyan-300 font-bold text-sm mt-0.5 block print:text-cyan-800">{currentClaim.bodyPart}</span>
              <span className="text-slate-400 text-[11px] block mt-1">Target Treatment Span: {currentClaim.billRows?.length || 0} Records</span>
            </div>
          </div>
        </div>

        {/* Section 3: Critical Escalations & Top 2 Greatest Inflection Jumps */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-amber-400 print:text-amber-800 flex items-center gap-1.5 m-0">
              <Zap className="w-4 h-4" /> 3. Critical Escalations & Top Inflection Jumps
            </h3>
            <span className="text-[11px] text-slate-400">Date of Service (DOS) & Spend Acceleration</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Top Jump 1 Card */}
            {currentClaim.primaryJump && (
              <div className="bg-rose-950/20 border border-rose-500/40 rounded-xl p-4 space-y-2 print:border-rose-300 print:bg-rose-50">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-0.5 rounded bg-rose-500 text-white font-black text-[10px] uppercase">
                    ⭐ TOP JUMP #1 (PRIMARY)
                  </span>
                  <span className="text-xs text-rose-300 print:text-rose-800 font-mono font-bold">
                    Day {currentClaim.primaryJump.elapsed_days}
                  </span>
                </div>
                <div className="flex items-baseline justify-between">
                  <h4 className="text-2xl font-black text-rose-400 print:text-rose-800 m-0">
                    ${currentClaim.primaryJump.bill_line_item_build_amount.toLocaleString()}
                  </h4>
                  <span className="text-xs text-slate-300 print:text-slate-700 font-medium">
                    DOS: {currentClaim.primaryJump.effective_service_date ? new Date(currentClaim.primaryJump.effective_service_date).toLocaleDateString() : 'N/A'}
                  </span>
                </div>
                <div className="text-xs space-y-0.5 pt-1 border-t border-rose-900/40 print:border-rose-200">
                  <p className="text-slate-300 print:text-black m-0"><strong>Category:</strong> {currentClaim.primaryJump.bill_line_item_category}</p>
                  <p className="text-slate-300 print:text-black m-0"><strong>Facility:</strong> {currentClaim.primaryJump.facility_name}</p>
                  <p className="text-slate-400 print:text-slate-600 m-0"><strong>Provider:</strong> {currentClaim.primaryJump.provider_name}</p>
                </div>
              </div>
            )}

            {/* Top Jump 2 Card */}
            {currentClaim.secondaryJump ? (
              <div className="bg-purple-950/20 border border-purple-500/40 rounded-xl p-4 space-y-2 print:border-purple-300 print:bg-purple-50">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-0.5 rounded bg-purple-500 text-white font-black text-[10px] uppercase">
                    ⚡ TOP JUMP #2 (SECONDARY)
                  </span>
                  <span className="text-xs text-purple-300 print:text-purple-800 font-mono font-bold">
                    Day {currentClaim.secondaryJump.elapsed_days}
                  </span>
                </div>
                <div className="flex items-baseline justify-between">
                  <h4 className="text-2xl font-black text-purple-300 print:text-purple-800 m-0">
                    ${currentClaim.secondaryJump.bill_line_item_build_amount.toLocaleString()}
                  </h4>
                  <span className="text-xs text-slate-300 print:text-slate-700 font-medium">
                    DOS: {currentClaim.secondaryJump.effective_service_date ? new Date(currentClaim.secondaryJump.effective_service_date).toLocaleDateString() : 'N/A'}
                  </span>
                </div>
                <div className="text-xs space-y-0.5 pt-1 border-t border-purple-900/40 print:border-purple-200">
                  <p className="text-slate-300 print:text-black m-0"><strong>Category:</strong> {currentClaim.secondaryJump.bill_line_item_category}</p>
                  <p className="text-slate-300 print:text-black m-0"><strong>Facility:</strong> {currentClaim.secondaryJump.facility_name}</p>
                  <p className="text-slate-400 print:text-slate-600 m-0"><strong>Provider:</strong> {currentClaim.secondaryJump.provider_name}</p>
                </div>
              </div>
            ) : (
              <div className="bg-slate-950/40 border border-slate-800 rounded-xl p-4 flex items-center justify-center text-xs text-slate-500">
                Single primary escalation observed.
              </div>
            )}
          </div>

          {/* Embedded GenAI Clinical Commentary */}
          <div className="p-3.5 bg-slate-950/80 rounded-xl border border-slate-800 text-xs text-slate-300 leading-relaxed print:bg-slate-50 print:border-slate-300 print:text-black">
            <strong className="text-indigo-400 print:text-indigo-800 block mb-1">Clinical Escalation Commentary:</strong>
            {currentClaim.genAiNarrative}
          </div>
        </div>

        {/* Section 4: Chronological Medical Treatment Timeline & Bill Ledger */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-400 print:text-emerald-800 flex items-center gap-1.5 m-0">
              <Calendar className="w-4 h-4" /> 4. Chronological Medical Treatment Timeline & Bill Ledger ({currentClaim.billRows?.length || 0} Records)
            </h3>
            <span className="text-xs text-slate-400">
              Organized by Date of Service (DOS)
            </span>
          </div>

          <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/80 print:border-slate-300 print:bg-white">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-950 text-slate-400 border-b border-slate-800 print:bg-slate-100 print:text-slate-700">
                  <th className="p-3">#</th>
                  <th className="p-3">Record ID</th>
                  <th className="p-3">Elapsed</th>
                  <th className="p-3">Date of Service (DOS)</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">Facility / Provider</th>
                  <th className="p-3">Procedure Description</th>
                  <th className="p-3 text-right">Billed Amount</th>
                  <th className="p-3 text-right">Cumulative Spend</th>
                  <th className="p-3 text-center">Status & Jumps</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 print:divide-slate-300">
                {(currentClaim.billRows || []).map((b, idx) => {
                  const isTop1 = b.is_top_jump_1;
                  const isTop2 = b.is_top_jump_2;
                  return (
                    <tr
                      key={`bill-${b.record_id || idx}`}
                      className={`transition ${
                        isTop1
                          ? 'bg-rose-950/50 print:bg-rose-100 border-l-4 border-l-rose-500 font-semibold'
                          : isTop2
                          ? 'bg-purple-950/40 print:bg-purple-100 border-l-4 border-l-purple-500 font-medium'
                          : 'hover:bg-slate-800/40 print:hover:bg-slate-50'
                      }`}
                    >
                      <td className="p-3 text-slate-500 print:text-slate-600">{idx + 1}</td>
                      <td className="p-3 font-mono text-cyan-400 print:text-cyan-800 font-bold">{b.record_id}</td>
                      <td className="p-3 font-semibold text-slate-300 print:text-slate-700">Day {b.elapsed_days}</td>
                      <td className="p-3 text-slate-300 print:text-black font-medium">
                        {b.effective_service_date ? new Date(b.effective_service_date).toLocaleDateString() : b.bill_line_item_service_date}
                      </td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 rounded text-[11px] font-medium" style={{ backgroundColor: `${CATEGORY_COLORS[b.bill_line_item_category] || '#64748b'}25`, color: CATEGORY_COLORS[b.bill_line_item_category] || '#cbd5e1' }}>
                          {b.bill_line_item_category}
                        </span>
                      </td>
                      <td className="p-3 text-slate-300 print:text-black">
                        <span className="font-semibold text-white print:text-black block">{b.facility_name}</span>
                        <span className="text-slate-500 print:text-slate-600 text-[11px] block">{b.provider_name}</span>
                      </td>
                      <td className="p-3 text-slate-400 print:text-slate-700 text-[11px] max-w-[180px] truncate" title={b.procedure_description}>
                        {b.procedure_description}
                      </td>
                      <td className="p-3 text-right font-mono font-bold text-white print:text-black">
                        ${b.bill_line_item_build_amount.toLocaleString()}
                      </td>
                      <td className="p-3 text-right font-mono text-cyan-400 print:text-cyan-800 font-bold">
                        ${b.cumulative_spend.toLocaleString()}
                      </td>
                      <td className="p-3 text-center">
                        {isTop1 ? (
                          <span className="px-2 py-0.5 rounded-full bg-rose-500/30 text-rose-300 border border-rose-500/50 text-[10px] font-black print:bg-rose-200 print:text-rose-900">
                            ⭐ TOP JUMP #1
                          </span>
                        ) : isTop2 ? (
                          <span className="px-2 py-0.5 rounded-full bg-purple-500/30 text-purple-300 border border-purple-500/50 text-[10px] font-black print:bg-purple-200 print:text-purple-900">
                            ⚡ TOP JUMP #2
                          </span>
                        ) : (
                          <span className="text-slate-500 print:text-slate-600 text-[11px]">Routine</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  );
}
