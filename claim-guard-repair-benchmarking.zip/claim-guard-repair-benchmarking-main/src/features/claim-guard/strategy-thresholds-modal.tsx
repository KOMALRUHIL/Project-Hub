﻿import { useEffect, useState } from "react"
import {
  Edit2Icon,
  PlusIcon,
  RotateCcwIcon,
  SlidersHorizontalIcon,
  Trash2Icon,
  XIcon,
} from "lucide-react"
import { toast } from "sonner"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Textarea } from "@/components/ui/textarea"

import { money } from "./benchmark-analysis-rows"
import {
  createStrategyThreshold,
  deleteStrategyThreshold,
  fetchStrategyThresholds,
  updateStrategyThreshold,
  type StrategyThresholdItem,
} from "./benchmark-api"
import { documentApiErrorMessage } from "./document-api"

function extractSuggestedKeywords(title: string): string[] {
  const matches = title.toLowerCase().match(/[a-z0-9]+/g) || []
  return Array.from(new Set(matches.filter((w) => w.length >= 3)))
}

export function InsuredStatutoryThresholdsDialog({
  open,
  onOpenChange,
  caseReference,
  onThresholdsChanged,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  caseReference: string
  onThresholdsChanged?: () => void
}) {
  const [thresholds, setThresholds] = useState<StrategyThresholdItem[]>([])
  const [loading, setLoading] = useState(false)
  const [editingThreshold, setEditingThreshold] = useState<StrategyThresholdItem | null>(null)
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [formMode, setFormMode] = useState<"create" | "edit">("create")

  // Form states
  const [itemName, setItemName] = useState("")
  const [maxAmount, setMaxAmount] = useState("")
  const [description, setDescription] = useState("")
  const [keywords, setKeywords] = useState<string[]>([])
  const [customKeywordInput, setCustomKeywordInput] = useState("")
  const [saving, setSaving] = useState(false)
  const [hasManuallyEditedKeywords, setHasManuallyEditedKeywords] = useState(false)

  const loadThresholds = async () => {
    if (!caseReference) return
    setLoading(true)
    try {
      const res = await fetchStrategyThresholds(caseReference)
      setThresholds(res.thresholds || [])
    } catch {
      // Fallback silently if case is fresh
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (open) {
      loadThresholds()
    }
  }, [open, caseReference])

  const handleOpenCreate = () => {
    setFormMode("create")
    setEditingThreshold(null)
    setItemName("")
    setMaxAmount("")
    setDescription("")
    setKeywords([])
    setCustomKeywordInput("")
    setHasManuallyEditedKeywords(false)
    setIsFormOpen(true)
  }

  const handleOpenEdit = (t: StrategyThresholdItem) => {
    setFormMode("edit")
    setEditingThreshold(t)
    setItemName(t.item_name)
    setMaxAmount(t.max_amount_net)
    setDescription(t.description)
    setKeywords([...(t.keywords || [])])
    setCustomKeywordInput("")
    setHasManuallyEditedKeywords(true)
    setIsFormOpen(true)
  }

  const handleItemNameChange = (val: string) => {
    setItemName(val)
    if (formMode === "create" && !hasManuallyEditedKeywords) {
      setKeywords(extractSuggestedKeywords(val))
    }
  }

  const handleAddCustomKeyword = () => {
    const trimmed = customKeywordInput.trim().toLowerCase()
    if (!trimmed) return
    if (!keywords.includes(trimmed)) {
      setKeywords([...keywords, trimmed])
      setHasManuallyEditedKeywords(true)
    }
    setCustomKeywordInput("")
  }

  const handleRemoveKeyword = (kwToRemove: string) => {
    setKeywords(keywords.filter((kw) => kw !== kwToRemove))
    setHasManuallyEditedKeywords(true)
  }

  const handleResetKeywords = () => {
    const autoKws = extractSuggestedKeywords(itemName)
    setKeywords(autoKws)
    setHasManuallyEditedKeywords(false)
  }

  const handleDelete = async (thresholdId: string, name: string) => {
    try {
      await deleteStrategyThreshold(caseReference, thresholdId)
      toast.success(`Removed statutory threshold for "${name}"`)
      loadThresholds()
      onThresholdsChanged?.()
    } catch (err) {
      toast.error("Failed to delete threshold", {
        description: documentApiErrorMessage(err),
      })
    }
  }

  const handleSaveForm = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!itemName.trim() || !maxAmount.trim()) {
      toast.error("Please provide both the item name and maximum allowed amount.")
      return
    }
    const num = parseFloat(maxAmount)
    if (isNaN(num) || num < 0) {
      toast.error("Please enter a valid non-negative number for the amount.")
      return
    }

    setSaving(true)
    try {
      if (formMode === "edit" && editingThreshold) {
        await updateStrategyThreshold(caseReference, editingThreshold.id, {
          item_name: itemName.trim(),
          max_amount_net: num.toFixed(2),
          description: description.trim(),
          keywords: keywords.length ? keywords : undefined,
        })
        toast.success(`Updated threshold for "${itemName.trim()}"`)
      } else {
        await createStrategyThreshold(caseReference, {
          item_name: itemName.trim(),
          max_amount_net: num.toFixed(2),
          description: description.trim(),
          keywords: keywords.length ? keywords : undefined,
        })
        toast.success(`Added new policy threshold for "${itemName.trim()}"`)
      }
      setIsFormOpen(false)
      loadThresholds()
      onThresholdsChanged?.()
    } catch (err) {
      toast.error(
        formMode === "edit" ? "Failed to update threshold" : "Failed to create threshold",
        { description: documentApiErrorMessage(err) }
      )
    } finally {
      setSaving(false)
    }
  }

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-4xl max-h-[90dvh] overflow-y-auto">
          <DialogHeader className="pb-2 border-b">
            <div className="flex flex-wrap items-center justify-between gap-3 pr-6">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-primary/10 text-primary">
                  <SlidersHorizontalIcon className="size-5" />
                </div>
                <div>
                  <DialogTitle className="text-lg font-bold">
                    Insured & Statutory Policy Thresholds
                  </DialogTitle>
                  <DialogDescription className="text-xs">
                    Insurer-mandated policy caps, statutory limits, and allowable fee thresholds. Matching invoice line items are benchmarked and capped against these rules.
                  </DialogDescription>
                </div>
              </div>
              <Button size="sm" onClick={handleOpenCreate} className="gap-1.5 shrink-0">
                <PlusIcon className="size-4" />
                Add New Threshold
              </Button>
            </div>
          </DialogHeader>

          <div className="py-2 space-y-4">
            <div className="flex items-center justify-between text-xs text-muted-foreground px-1">
              <span>
                Active Rules: <strong className="text-foreground">{thresholds.length}</strong>
              </span>
              <span>All matched items generate automatic challenge recommendations.</span>
            </div>

            {loading ? (
              <p className="text-xs text-muted-foreground py-6 text-center">
                Loading insured & statutory policy rules…
              </p>
            ) : thresholds.length === 0 ? (
              <div className="rounded-lg border border-dashed p-8 text-center space-y-3">
                <p className="text-sm font-medium">No statutory policy thresholds configured</p>
                <p className="text-xs text-muted-foreground max-w-md mx-auto">
                  Add custom policy thresholds to enforce maximum billing caps on labour rates, environmental fees, cleaning charges, or administrative costs.
                </p>
                <Button size="sm" variant="outline" onClick={handleOpenCreate} className="gap-1.5">
                  <PlusIcon className="size-4" />
                  Add First Threshold
                </Button>
              </div>
            ) : (
              <div className="rounded-md border overflow-hidden bg-background">
                <Table className="text-xs">
                  <TableHeader>
                    <TableRow className="bg-muted/40">
                      <TableHead className="w-[26%] font-semibold">Repair Item / Policy Target</TableHead>
                      <TableHead className="w-[12%] text-right font-semibold">Max Cap (£)</TableHead>
                      <TableHead className="w-[30%] font-semibold">Policy Description & Scope</TableHead>
                      <TableHead className="w-[20%] font-semibold">Keywords Matched</TableHead>
                      <TableHead className="w-[12%] text-right font-semibold">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {thresholds.map((t) => (
                      <TableRow key={t.id} className="hover:bg-muted/30">
                        <TableCell className="font-medium text-foreground">
                          {t.item_name}
                        </TableCell>
                        <TableCell className="text-right font-bold tabular-nums text-primary">
                          {money(t.max_amount_net)}
                        </TableCell>
                        <TableCell className="text-muted-foreground text-[11px] leading-relaxed">
                          {t.description || "—"}
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1 max-h-16 overflow-y-auto">
                            {t.keywords && t.keywords.length > 0 ? (
                              t.keywords.map((kw) => (
                                <Badge
                                  key={kw}
                                  variant="secondary"
                                  className="text-[10px] px-1.5 py-0 font-normal"
                                >
                                  {kw}
                                </Badge>
                              ))
                            ) : (
                              <span className="text-muted-foreground text-[11px]">Auto-derived</span>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1 justify-end">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 px-2 text-xs text-foreground hover:bg-muted"
                              onClick={() => handleOpenEdit(t)}
                              title="Edit this rule"
                            >
                              <Edit2Icon className="size-3.5 mr-1 text-muted-foreground" />
                              Edit
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 px-2 text-xs text-destructive hover:text-destructive hover:bg-destructive/10"
                              onClick={() => handleDelete(t.id, t.item_name)}
                              title="Delete this rule"
                            >
                              <Trash2Icon className="size-3.5 mr-1" />
                              Delete
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Add / Edit Sub-Dialog Form */}
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {formMode === "edit" ? "Edit Policy Threshold" : "Add Insured & Statutory Policy Threshold"}
            </DialogTitle>
            <DialogDescription className="text-xs">
              Set maximum allowable net amounts (£) and keyword match patterns for automated benchmarking.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSaveForm} className="flex flex-col gap-3.5 py-2">
            <label className="flex flex-col gap-1 text-xs font-semibold text-foreground">
              Repair Item / Policy Target *
              <Input
                placeholder="e.g. Environmental Investment and Sustainable Charge"
                value={itemName}
                onChange={(e) => handleItemNameChange(e.target.value)}
                required
                className="text-xs"
              />
            </label>

            <label className="flex flex-col gap-1 text-xs font-semibold text-foreground">
              Maximum Allowed Net Amount (£) *
              <Input
                type="number"
                step="0.01"
                min="0"
                placeholder="20.00"
                value={maxAmount}
                onChange={(e) => setMaxAmount(e.target.value)}
                required
                className="text-xs font-semibold"
              />
              <span className="text-[11px] font-normal text-muted-foreground">
                Invoiced charges exceeding this net cap will trigger a challenge.
              </span>
            </label>

            <label className="flex flex-col gap-1 text-xs font-semibold text-foreground">
              Policy Description & Rationale
              <Textarea
                placeholder="e.g. Insurer maximum policy cap of £20.00 for environmental and EPA charges."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="h-16 resize-none text-xs"
              />
            </label>

            {/* Keywords Matched Section */}
            <div className="flex flex-col gap-1.5 pt-1 border-t">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-foreground">Keywords Matched</span>
                {itemName && (
                  <button
                    type="button"
                    onClick={handleResetKeywords}
                    className="inline-flex items-center gap-1 text-[11px] text-primary hover:underline"
                  >
                    <RotateCcwIcon className="size-3" />
                    Auto-suggest from title
                  </button>
                )}
              </div>
              <p className="text-[11px] text-muted-foreground">
                Invoice lines containing any of these keywords will match this policy threshold cap.
              </p>

              {/* Keyword chips */}
              <div className="flex flex-wrap gap-1.5 min-h-8 p-2 rounded-md border bg-muted/20">
                {keywords.length === 0 ? (
                  <span className="text-[11px] text-muted-foreground italic">
                    No keywords added yet. Type an item name or add keywords below.
                  </span>
                ) : (
                  keywords.map((kw) => (
                    <span
                      key={kw}
                      className="inline-flex items-center gap-1 rounded bg-background border px-2 py-0.5 text-xs text-foreground font-medium shadow-xs"
                    >
                      {kw}
                      <button
                        type="button"
                        onClick={() => handleRemoveKeyword(kw)}
                        className="text-muted-foreground hover:text-destructive focus:outline-none"
                        title={`Remove "${kw}"`}
                      >
                        <XIcon className="size-3" />
                      </button>
                    </span>
                  ))
                )}
              </div>

              {/* Add custom keyword input */}
              <div className="flex items-center gap-2 mt-1">
                <Input
                  placeholder="Type new keyword and press Add..."
                  value={customKeywordInput}
                  onChange={(e) => setCustomKeywordInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault()
                      handleAddCustomKeyword()
                    }
                  }}
                  className="h-8 text-xs flex-1"
                />
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  onClick={handleAddCustomKeyword}
                  className="h-8 px-3 text-xs shrink-0"
                >
                  + Add
                </Button>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t mt-1">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setIsFormOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" size="sm" disabled={saving}>
                {saving
                  ? "Saving…"
                  : formMode === "edit"
                  ? "Save Changes"
                  : "Add Threshold"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </>
  )
}
