import { useEffect, useMemo, useState } from "react"
import {
  Edit2Icon,
  PlusIcon,
  RotateCcwIcon,
  SearchIcon,
  SlidersHorizontalIcon,
  Trash2Icon,
  XIcon,
} from "lucide-react"
import { toast } from "sonner"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Textarea } from "@/components/ui/textarea"

import { money } from "./benchmark-analysis-rows"
import {
  createStrategyThreshold,
  deleteStrategyThreshold,
  fetchStrategyThresholds,
  updateStrategyThreshold,
  type StrategyThresholdItem,
} from "./benchmark-api"
import { documentApiErrorMessage } from "./document-api"
import { ScreenHeading } from "./shared"

function extractSuggestedKeywords(title: string): string[] {
  const matches = title.toLowerCase().match(/[a-z0-9]+/g) || []
  return Array.from(new Set(matches.filter((w) => w.length >= 3)))
}

export function InsurerStatutoryThresholdsScreen({
  caseReference,
  onThresholdsChanged,
}: {
  caseReference: string
  onThresholdsChanged?: () => void
}) {
  const [thresholds, setThresholds] = useState<StrategyThresholdItem[]>([])
  const [loading, setLoading] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")

  // Form dialog state
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [formMode, setFormMode] = useState<"create" | "edit">("create")
  const [editingThreshold, setEditingThreshold] =
    useState<StrategyThresholdItem | null>(null)

  // Form inputs
  const [itemName, setItemName] = useState("")
  const [maxAmount, setMaxAmount] = useState("")
  const [description, setDescription] = useState("")
  const [keywords, setKeywords] = useState<string[]>([])
  const [customKeywordInput, setCustomKeywordInput] = useState("")
  const [saving, setSaving] = useState(false)
  const [hasManuallyEditedKeywords, setHasManuallyEditedKeywords] = useState(false)

  const loadThresholds = async () => {
    if (!caseReference) return
    setLoading(true)
    try {
      const res = await fetchStrategyThresholds(caseReference)
      setThresholds(res.thresholds || [])
    } catch (err) {
      toast.error("Could not load statutory policy thresholds", {
        description: documentApiErrorMessage(err),
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadThresholds()
  }, [caseReference])

  const handleOpenCreate = () => {
    setFormMode("create")
    setEditingThreshold(null)
    setItemName("")
    setMaxAmount("")
    setDescription("")
    setKeywords([])
    setCustomKeywordInput("")
    setHasManuallyEditedKeywords(false)
    setIsFormOpen(true)
  }

  const handleOpenEdit = (t: StrategyThresholdItem) => {
    setFormMode("edit")
    setEditingThreshold(t)
    setItemName(t.item_name)
    setMaxAmount(t.max_amount_net)
    setDescription(t.description)
    setKeywords([...(t.keywords || [])])
    setCustomKeywordInput("")
    setHasManuallyEditedKeywords(true)
    setIsFormOpen(true)
  }

  const handleItemNameChange = (val: string) => {
    setItemName(val)
    if (formMode === "create" && !hasManuallyEditedKeywords) {
      setKeywords(extractSuggestedKeywords(val))
    }
  }

  const handleAddCustomKeyword = () => {
    const trimmed = customKeywordInput.trim().toLowerCase()
    if (!trimmed) return
    if (!keywords.includes(trimmed)) {
      setKeywords([...keywords, trimmed])
      setHasManuallyEditedKeywords(true)
    }
    setCustomKeywordInput("")
  }

  const handleRemoveKeyword = (kwToRemove: string) => {
    setKeywords(keywords.filter((kw) => kw !== kwToRemove))
    setHasManuallyEditedKeywords(true)
  }

  const handleResetKeywords = () => {
    const autoKws = extractSuggestedKeywords(itemName)
    setKeywords(autoKws)
    setHasManuallyEditedKeywords(false)
  }

  const handleDelete = async (thresholdId: string, name: string) => {
    try {
      await deleteStrategyThreshold(caseReference, thresholdId)
      toast.success(`Removed statutory policy threshold for "${name}"`)
      loadThresholds()
      onThresholdsChanged?.()
    } catch (err) {
      toast.error("Failed to delete threshold", {
        description: documentApiErrorMessage(err),
      })
    }
  }

  const handleSaveForm = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!itemName.trim() || !maxAmount.trim()) {
      toast.error("Please provide both the target item name and maximum net amount.")
      return
    }
    const num = parseFloat(maxAmount)
    if (isNaN(num) || num < 0) {
      toast.error("Please enter a valid non-negative number for the amount.")
      return
    }

    setSaving(true)
    try {
      if (formMode === "edit" && editingThreshold) {
        await updateStrategyThreshold(caseReference, editingThreshold.id, {
          item_name: itemName.trim(),
          max_amount_net: num.toFixed(2),
          description: description.trim(),
          keywords: keywords.length ? keywords : undefined,
        })
        toast.success(`Updated policy threshold for "${itemName.trim()}"`)
      } else {
        await createStrategyThreshold(caseReference, {
          item_name: itemName.trim(),
          max_amount_net: num.toFixed(2),
          description: description.trim(),
          keywords: keywords.length ? keywords : undefined,
        })
        toast.success(`Added new policy threshold for "${itemName.trim()}"`)
      }
      setIsFormOpen(false)
      loadThresholds()
      onThresholdsChanged?.()
    } catch (err) {
      toast.error(
        formMode === "edit"
          ? "Failed to update threshold"
          : "Failed to create threshold",
        { description: documentApiErrorMessage(err) }
      )
    } finally {
      setSaving(false)
    }
  }

  const filteredThresholds = useMemo(() => {
    const q = searchQuery.trim().toLowerCase()
    if (!q) return thresholds
    return thresholds.filter(
      (t) =>
        t.item_name.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        t.keywords?.some((k) => k.toLowerCase().includes(q))
    )
  }, [thresholds, searchQuery])

  // Summary KPI Calculations
  const stats = useMemo(() => {
    if (thresholds.length === 0) {
      return { total: 0, avgCap: 0, maxCap: 0, keywordCount: 0 }
    }
    const amounts = thresholds
      .map((t) => parseFloat(t.max_amount_net))
      .filter((n) => !isNaN(n))
    const total = thresholds.length
    const sum = amounts.reduce((acc, curr) => acc + curr, 0)
    const avgCap = amounts.length ? sum / amounts.length : 0
    const maxCap = amounts.length ? Math.max(...amounts) : 0
    const keywordCount = thresholds.reduce(
      (acc, t) => acc + (t.keywords?.length || 0),
      0
    )
    return { total, avgCap, maxCap, keywordCount }
  }, [thresholds])

  return (
    <div className="flex flex-col gap-6">
      <ScreenHeading
        title="Insurer Statutory Threshold"
        description="Configure insurer policy caps, statutory limits, and keyword rules. Invoice line items matching these target items or keywords are automatically benchmarked against these caps during comparison."
        action={
          <Button onClick={handleOpenCreate} className="gap-1.5 shadow-xs">
            <PlusIcon className="size-4" />
            Add New Threshold
          </Button>
        }
      />

      {/* KPI Cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="shadow-xs">
          <CardHeader className="pb-2">
            <CardDescription className="text-xs">Active Policy Rules</CardDescription>
            <CardTitle className="text-2xl font-bold">{stats.total}</CardTitle>
          </CardHeader>
          <CardContent className="text-xs text-muted-foreground">
            Enforced across all benchmark runs
          </CardContent>
        </Card>

        <Card className="shadow-xs">
          <CardHeader className="pb-2">
            <CardDescription className="text-xs">Average Policy Cap</CardDescription>
            <CardTitle className="text-2xl font-bold text-primary">
              {money(stats.avgCap)}
            </CardTitle>
          </CardHeader>
          <CardContent className="text-xs text-muted-foreground">
            Mean allowable net charge
          </CardContent>
        </Card>

        <Card className="shadow-xs">
          <CardHeader className="pb-2">
            <CardDescription className="text-xs">Maximum Rule Cap</CardDescription>
            <CardTitle className="text-2xl font-bold">
              {money(stats.maxCap)}
            </CardTitle>
          </CardHeader>
          <CardContent className="text-xs text-muted-foreground">
            Highest individual fee cap
          </CardContent>
        </Card>

        <Card className="shadow-xs">
          <CardHeader className="pb-2">
            <CardDescription className="text-xs">Keywords Configured</CardDescription>
            <CardTitle className="text-2xl font-bold">
              {stats.keywordCount}
            </CardTitle>
          </CardHeader>
          <CardContent className="text-xs text-muted-foreground">
            Auto-match token coverage
          </CardContent>
        </Card>
      </div>

      {/* Table Card */}
      <Card className="shadow-xs">
        <CardHeader className="pb-3 border-b">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <CardTitle className="text-base font-semibold">
                Policy Rules & Statutory Caps
              </CardTitle>
              <CardDescription className="text-xs mt-0.5">
                Every configured rule below is checked against the uploaded invoice lines.
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative">
                <SearchIcon className="absolute left-2.5 top-2.5 size-4 text-muted-foreground" />
                <Input
                  placeholder="Filter thresholds or keywords…"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="h-9 w-64 pl-8 text-xs"
                />
              </div>
              {searchQuery && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSearchQuery("")}
                  className="h-9 px-2 text-xs"
                >
                  Clear
                </Button>
              )}
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-0">
          {loading ? (
            <div className="py-12 text-center text-sm text-muted-foreground">
              Loading insurer statutory policy thresholds…
            </div>
          ) : filteredThresholds.length === 0 ? (
            <div className="py-12 text-center space-y-3 px-4">
              <div className="inline-flex size-12 items-center justify-center rounded-full bg-muted">
                <SlidersHorizontalIcon className="size-6 text-muted-foreground" />
              </div>
              <p className="text-sm font-medium">
                {searchQuery
                  ? "No matching policy thresholds found"
                  : "No statutory thresholds configured"}
              </p>
              <p className="text-xs text-muted-foreground max-w-md mx-auto">
                {searchQuery
                  ? `No rules match the query "${searchQuery}". Try clearing the search filter.`
                  : "Add insurer policy rules to cap allowable fees on environmental charges, cleaning, storage, or statutory caps."}
              </p>
              {!searchQuery && (
                <Button
                  size="sm"
                  onClick={handleOpenCreate}
                  className="gap-1.5 mt-2"
                >
                  <PlusIcon className="size-4" />
                  Add First Threshold
                </Button>
              )}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/30">
                  <TableHead className="w-[24%] font-semibold">
                    Repair Item / Policy Target
                  </TableHead>
                  <TableHead className="w-[12%] text-right font-semibold">
                    Max Cap (£)
                  </TableHead>
                  <TableHead className="w-[32%] font-semibold">
                    Policy Description & Scope
                  </TableHead>
                  <TableHead className="w-[20%] font-semibold">
                    Keywords Matched
                  </TableHead>
                  <TableHead className="w-[12%] text-right font-semibold">
                    Actions
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredThresholds.map((t) => (
                  <TableRow key={t.id} className="hover:bg-muted/20">
                    <TableCell className="font-medium text-foreground align-top py-3">
                      {t.item_name}
                    </TableCell>
                    <TableCell className="text-right font-bold tabular-nums text-primary align-top py-3">
                      {money(t.max_amount_net)}
                    </TableCell>
                    <TableCell className="text-muted-foreground text-xs leading-relaxed align-top py-3">
                      {t.description || "—"}
                    </TableCell>
                    <TableCell className="align-top py-3">
                      <div className="flex flex-wrap gap-1 max-h-24 overflow-y-auto">
                        {t.keywords && t.keywords.length > 0 ? (
                          t.keywords.map((kw) => (
                            <Badge
                              key={kw}
                              variant="secondary"
                              className="text-[10px] px-1.5 py-0 font-normal"
                            >
                              {kw}
                            </Badge>
                          ))
                        ) : (
                          <span className="text-muted-foreground text-[11px] italic">
                            Auto-derived from title
                          </span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right align-top py-3 whitespace-nowrap">
                      <div className="inline-flex items-center gap-1 justify-end">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 px-2.5 text-xs text-foreground hover:bg-muted"
                          onClick={() => handleOpenEdit(t)}
                          title="Edit this rule"
                        >
                          <Edit2Icon className="size-3.5 mr-1 text-muted-foreground" />
                          Edit
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 px-2.5 text-xs text-destructive hover:text-destructive hover:bg-destructive/10"
                          onClick={() => handleDelete(t.id, t.item_name)}
                          title="Delete this rule"
                        >
                          <Trash2Icon className="size-3.5 mr-1" />
                          Delete
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Add / Edit Form Modal */}
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {formMode === "edit"
                ? "Edit Policy Threshold"
                : "Add Insurer Statutory Threshold"}
            </DialogTitle>
            <DialogDescription className="text-xs">
              Set maximum allowable net amounts (£) and keyword match patterns for automated benchmarking.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSaveForm} className="flex flex-col gap-4 py-2">
            <label className="flex flex-col gap-1 text-xs font-semibold text-foreground">
              Repair Item / Policy Target *
              <Input
                placeholder="e.g. Environmental Investment and Sustainable Charge"
                value={itemName}
                onChange={(e) => handleItemNameChange(e.target.value)}
                required
                className="text-xs"
              />
            </label>

            <label className="flex flex-col gap-1 text-xs font-semibold text-foreground">
              Maximum Allowed Net Amount (£) *
              <Input
                type="number"
                step="0.01"
                min="0"
                placeholder="20.00"
                value={maxAmount}
                onChange={(e) => setMaxAmount(e.target.value)}
                required
                className="text-xs font-semibold"
              />
              <span className="text-[11px] font-normal text-muted-foreground">
                Invoiced charges exceeding this net cap will trigger a challenge.
              </span>
            </label>

            <label className="flex flex-col gap-1 text-xs font-semibold text-foreground">
              Policy Description & Scope
              <Textarea
                placeholder="e.g. Insurer maximum policy cap of £20.00 for environmental and EPA charges."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="h-16 resize-none text-xs"
              />
            </label>

            {/* Keywords Matched Section */}
            <div className="flex flex-col gap-1.5 pt-2 border-t">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-foreground">
                  Keywords Matched
                </span>
                {itemName && (
                  <button
                    type="button"
                    onClick={handleResetKeywords}
                    className="inline-flex items-center gap-1 text-[11px] text-primary hover:underline"
                  >
                    <RotateCcwIcon className="size-3" />
                    Auto-suggest from title
                  </button>
                )}
              </div>
              <p className="text-[11px] text-muted-foreground">
                Invoice lines containing any of these keywords will match this policy cap.
              </p>

              {/* Keyword chips */}
              <div className="flex flex-wrap gap-1.5 min-h-10 p-2 rounded-md border bg-muted/20">
                {keywords.length === 0 ? (
                  <span className="text-[11px] text-muted-foreground italic">
                    No keywords added yet. Type an item name or add custom keywords below.
                  </span>
                ) : (
                  keywords.map((kw) => (
                    <span
                      key={kw}
                      className="inline-flex items-center gap-1 rounded bg-background border px-2 py-0.5 text-xs text-foreground font-medium shadow-xs"
                    >
                      {kw}
                      <button
                        type="button"
                        onClick={() => handleRemoveKeyword(kw)}
                        className="text-muted-foreground hover:text-destructive focus:outline-none"
                        title={`Remove "${kw}"`}
                      >
                        <XIcon className="size-3" />
                      </button>
                    </span>
                  ))
                )}
              </div>

              {/* Add custom keyword input */}
              <div className="flex items-center gap-2 mt-1">
                <Input
                  placeholder="Type new keyword and press Add..."
                  value={customKeywordInput}
                  onChange={(e) => setCustomKeywordInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault()
                      handleAddCustomKeyword()
                    }
                  }}
                  className="h-8 text-xs flex-1"
                />
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  onClick={handleAddCustomKeyword}
                  className="h-8 px-3 text-xs shrink-0"
                >
                  + Add
                </Button>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t mt-1">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setIsFormOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" size="sm" disabled={saving}>
                {saving
                  ? "Saving…"
                  : formMode === "edit"
                  ? "Save Changes"
                  : "Add Threshold"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
