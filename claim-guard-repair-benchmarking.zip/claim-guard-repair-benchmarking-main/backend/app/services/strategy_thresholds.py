"""Insurer policy strategy thresholds for repair items and fee caps."""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field
from decimal import Decimal
from typing import Any
from uuid import uuid4


@dataclass
class StrategyThreshold:
    id: str
    item_name: str
    max_amount_net: Decimal
    description: str
    keywords: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "item_name": self.item_name,
            "max_amount_net": f"{self.max_amount_net:.2f}",
            "description": self.description,
            "keywords": self.keywords,
        }


# Default client-seeded strategy thresholds
_ACTIVE_THRESHOLDS: list[StrategyThreshold] = [
    StrategyThreshold(
        id="strat-env",
        item_name="Environmental Investment and Sustainable Charge",
        max_amount_net=Decimal("20.00"),
        description="Caps environmental/sustainability/EPA charges to £20.00 max.",
        keywords=["environmental", "sustainable", "sustainability", "waste", "epa", "green charge"],
    ),
    StrategyThreshold(
        id="strat-labour",
        item_name="Body Shop Labour Rate",
        max_amount_net=Decimal("70.00"),
        description="Hourly bodyshop labour rate cap of £70.00/hour.",
        keywords=["labour rate", "bodyshop labour", "hourly rate", "hourly labour"],
    ),
    StrategyThreshold(
        id="strat-clean-combo",
        item_name="Pre-Clean + Post-Clean Charge",
        max_amount_net=Decimal("50.00"),
        description="Combined pre-repair and post-repair cleaning/valeting cap of £50.00.",
        keywords=["pre clean post clean", "pre-clean + post-clean", "pre & post clean", "clean pre post", "pre/post clean", "valet combo"],
    ),
    StrategyThreshold(
        id="strat-engineer-fee",
        item_name="Engineer Fees",
        max_amount_net=Decimal("0.00"),
        description="Engineer/assessing/estimating fees cannot be billed on repair invoices (£0.00 max).",
        keywords=["engineer fee", "assessing fee", "estimating fee", "estimate fee", "engineer report"],
    ),
    StrategyThreshold(
        id="strat-pre-clean",
        item_name="Pre-Repair Cleaning Charge",
        max_amount_net=Decimal("10.00"),
        description="Pre-repair cleaning/wash inspection charge cap of £10.00.",
        keywords=["pre repair clean", "pre-repair clean", "pre repair cleaning", "pre-clean", "pre wash", "pre-repair cleaning charge"],
    ),
]


def list_strategy_thresholds() -> list[StrategyThreshold]:
    return list(_ACTIVE_THRESHOLDS)


def add_strategy_threshold(
    item_name: str,
    max_amount_net: Decimal,
    description: str = "",
    keywords: list[str] | None = None,
) -> StrategyThreshold:
    if keywords is not None and len(keywords) > 0:
        kws = [k.strip().lower() for k in keywords if k.strip()]
    else:
        kws = [w.lower() for w in re.findall(r"[A-Za-z0-9]+", item_name) if len(w) > 2]
    threshold = StrategyThreshold(
        id=f"strat-{uuid4().hex[:8]}",
        item_name=item_name.strip(),
        max_amount_net=max_amount_net,
        description=description.strip() or f"Insurer policy cap of £{max_amount_net:.2f} for {item_name.strip()}.",
        keywords=kws,
    )
    _ACTIVE_THRESHOLDS.append(threshold)
    return threshold


def update_strategy_threshold(
    threshold_id: str,
    item_name: str,
    max_amount_net: Decimal,
    description: str = "",
    keywords: list[str] | None = None,
) -> StrategyThreshold | None:
    for t in _ACTIVE_THRESHOLDS:
        if t.id == threshold_id:
            t.item_name = item_name.strip()
            t.max_amount_net = max_amount_net
            t.description = description.strip() or f"Insurer policy cap of £{max_amount_net:.2f} for {item_name.strip()}."
            if keywords is not None and len(keywords) > 0:
                t.keywords = [k.strip().lower() for k in keywords if k.strip()]
            else:
                words = [w.lower() for w in re.findall(r"[A-Za-z0-9]+", item_name) if len(w) > 2]
                t.keywords = words
            return t
    return None


def remove_strategy_threshold(threshold_id: str) -> bool:
    global _ACTIVE_THRESHOLDS
    initial_len = len(_ACTIVE_THRESHOLDS)
    _ACTIVE_THRESHOLDS = [t for t in _ACTIVE_THRESHOLDS if t.id != threshold_id]
    return len(_ACTIVE_THRESHOLDS) < initial_len


def match_strategy_threshold(
    description: str,
    repair_item: str | None = None,
    thresholds: list[StrategyThreshold] | None = None,
) -> StrategyThreshold | None:
    active = thresholds or _ACTIVE_THRESHOLDS
    combined = f"{description} {repair_item or ''}".lower()
    desc_clean = re.sub(r"[^a-z0-9]+", " ", combined).strip()

    for threshold in active:
        target_clean = re.sub(r"[^a-z0-9]+", " ", threshold.item_name.lower()).strip()
        if target_clean in desc_clean or desc_clean in target_clean:
            return threshold
        for keyword in threshold.keywords:
            kw_clean = re.sub(r"[^a-z0-9]+", " ", keyword.lower()).strip()
            if kw_clean and (f" {kw_clean} " in f" {desc_clean} " or desc_clean.startswith(kw_clean) or desc_clean.endswith(kw_clean)):
                return threshold
    return None
