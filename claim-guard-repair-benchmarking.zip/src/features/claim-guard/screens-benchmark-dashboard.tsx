import { useEffect, useMemo, useRef, useState } from "react"
import {
  ArrowDownIcon,
  ArrowUpDownIcon,
  ArrowUpIcon,
  DatabaseIcon,
  EyeIcon,
  Share2Icon,
} from "lucide-react"

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import type {
  BenchmarkDashboardPayload,
  BenchmarkExceptionPayload,
  BenchmarkObservationPayload,
} from "@/lib/api"
import { fetchBenchmarkDashboard, fetchBenchmarkObservations } from "@/lib/api"

import { DataCard, MINIMUM_CHALLENGE_AMOUNT, ScreenHeading } from "./shared"
import type { ClaimWorkspace } from "./types"

const emptyDashboard: BenchmarkDashboardPayload = {
  summary: {
    averageRepairCost: null,
    averageLabourRate: null,
    mostObservedItem: null,
    observationCount: 0,
    mostExpensiveRepairCategory: null,
    mostExpensiveRepairAverage: null,
  },
  vehicleCategories: [],
  benchmarks: [],
  repairerTrends: [],
  filterOptions: { vehicleClasses: [], repairItems: [] },
  appliedFilters: {
    vehicleClass: null,
    ontologyItemId: null,
    dateFrom: null,
    dateTo: null,
    minimumCount: 1,
    challengeThresholdPct: 10,
    minimumChallengeAmount: MINIMUM_CHALLENGE_AMOUNT,
  },
  dataQuality: {
    invoiceObservationCount: 0,
    validCostCount: 0,
    invalidOrMissingCostCount: 0,
    classifiedCount: 0,
    unclassifiedCount: 0,
    classifiedCoveragePct: 0,
    latestObservationDate: null,
  },
  definitions: {
    cost: "Invoice net line total, excluding estimates and credit notes.",
    labour: "Explicit labour rate, or an hourly labour line where available.",
    challengeGate:
      "A P90 exception must exceed the selected percentage threshold and the £5.00 minimum positive variance.",
    coverageNote: "No uploaded invoice observations are available yet.",
    officialClasses: {},
  },
}

function money(value: number | null, suffix = "") {
  return value === null
    ? "—"
    : `£${value.toLocaleString("en-GB", { maximumFractionDigits: 0 })}${suffix}`
}

function preciseMoney(value: number) {
  return `£${value.toLocaleString("en-GB", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`
}

function signedMoney(value: number) {
  if (value === 0) return preciseMoney(0)
  return `${value > 0 ? "+" : "−"}${preciseMoney(Math.abs(value))}`
}

type BenchmarkSortKey =
  | "item"
  | "vehicleClass"
  | "invoiceCount"
  | "min"
  | "max"
  | "median"
  | "p90"
  | "exceptionInvoiceCount"
  | "totalChallenge"

type BenchmarkRow = BenchmarkDashboardPayload["benchmarks"][number]

function totalChallengeAmount(item: BenchmarkRow) {
  const total = item.exceptions.reduce((sum, row) => sum + row.difference, 0)
  return Math.round(total * 100) / 100
}

function benchmarkSortValue(item: BenchmarkRow, key: BenchmarkSortKey) {
  switch (key) {
    case "item":
      return item.item
    case "vehicleClass":
      return item.vehicleClass
    case "invoiceCount":
      return item.invoiceCount
    case "min":
      return item.statistics.min ?? Number.NEGATIVE_INFINITY
    case "max":
      return item.statistics.max ?? Number.NEGATIVE_INFINITY
    case "median":
      return item.statistics.median ?? Number.NEGATIVE_INFINITY
    case "p90":
      return item.statistics.p90 ?? Number.NEGATIVE_INFINITY
    case "exceptionInvoiceCount":
      return item.exceptionInvoiceCount
    case "totalChallenge":
      return totalChallengeAmount(item)
  }
}

export function BenchmarkDashboardScreen({
  workspace,
  challengeThreshold,
  onChallengeThresholdChange,
  thresholdApplying = false,
  onOpenKnowledgeGraph,
  sourceGroup,
}: {
  workspace: ClaimWorkspace
  challengeThreshold: number
  onChallengeThresholdChange: (value: number) => void
  thresholdApplying?: boolean
  onOpenKnowledgeGraph: () => void
  sourceGroup: "in_house" | "historical_claim"
}) {
  // Starts genuinely empty: until the live fetch resolves the screen shows no
  // numbers rather than placeholder ones.
  const [dashboard, setDashboard] =
    useState<BenchmarkDashboardPayload>(emptyDashboard)
  const [loadError, setLoadError] = useState<string | null>(null)
  const [vehicleClass, setVehicleClass] = useState("all")
  const [repairItem, setRepairItem] = useState("all")
  const [minimumCount, setMinimumCount] = useState("1")
  const [sortKey, setSortKey] = useState<BenchmarkSortKey>("item")
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc")
  const [sourceRows, setSourceRows] = useState<BenchmarkObservationPayload[]>(
    []
  )
  const [exceptionRows, setExceptionRows] = useState<
    BenchmarkExceptionPayload[]
  >([])
  const [evidenceMode, setEvidenceMode] = useState<"sources" | "exceptions">(
    "sources"
  )
  const [sourceTitle, setSourceTitle] = useState<string | null>(null)
  const [sourceLoading, setSourceLoading] = useState(false)
  const sourcePanelRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    let cancelled = false
    void fetchBenchmarkDashboard({
      caseReference: workspace.claim.id,
      vehicleClass: vehicleClass === "all" ? undefined : vehicleClass,
      ontologyItemId: repairItem === "all" ? undefined : repairItem,
      minimumCount: Number(minimumCount),
      challengeThresholdPct: challengeThreshold,
      sourceGroup,
    })
      .then((result) => {
        if (cancelled) return
        setDashboard(result)
        setLoadError(null)
      })
      .catch(() => {
        if (cancelled) return
        setDashboard(emptyDashboard)
        setLoadError(
          "Live benchmark data could not be loaded. No pilot or static prices are being shown."
        )
      })
    return () => {
      cancelled = true
    }
  }, [
    challengeThreshold,
    minimumCount,
    repairItem,
    sourceGroup,
    vehicleClass,
    workspace.claim.id,
  ])

  const selectedInvoiceBenchmarks = workspace.lines.filter(
    (line) => line.p90Benchmark
  )
  const challengedLineCount = dashboard.benchmarks.reduce(
    (total, item) => total + item.exceptionCount,
    0
  )
  const sortedBenchmarks = useMemo(
    () =>
      [...dashboard.benchmarks].sort((left, right) => {
        const leftValue = benchmarkSortValue(left, sortKey)
        const rightValue = benchmarkSortValue(right, sortKey)
        const comparison =
          typeof leftValue === "string" && typeof rightValue === "string"
            ? leftValue.localeCompare(rightValue, "en-GB", {
                sensitivity: "base",
              })
            : Number(leftValue) - Number(rightValue)
        if (comparison !== 0)
          return sortDirection === "asc" ? comparison : -comparison
        return left.item.localeCompare(right.item, "en-GB", {
          sensitivity: "base",
        })
      }),
    [dashboard.benchmarks, sortDirection, sortKey]
  )

  function changeSort(key: BenchmarkSortKey) {
    if (sortKey === key) {
      setSortDirection((current) => (current === "asc" ? "desc" : "asc"))
      return
    }
    setSortKey(key)
    setSortDirection(key === "item" || key === "vehicleClass" ? "asc" : "desc")
  }

  function sortHeader(
    label: string,
    key: BenchmarkSortKey,
    alignment: "left" | "right" = "right"
  ) {
    const active = sortKey === key
    const SortIcon = active
      ? sortDirection === "asc"
        ? ArrowUpIcon
        : ArrowDownIcon
      : ArrowUpDownIcon
    return (
      <Button
        type="button"
        variant="ghost"
        size="sm"
        className={`h-auto w-full gap-1 px-0 py-0 text-xs font-medium hover:bg-transparent ${
          alignment === "right" ? "justify-end" : "justify-start"
        } ${active ? "text-foreground" : "text-muted-foreground"}`}
        onClick={() => changeSort(key)}
        aria-label={`Sort by ${label}, ${
          active
            ? sortDirection === "asc"
              ? "ascending"
              : "descending"
            : "not selected"
        }`}
      >
        {label}
        <SortIcon className="size-3.5" aria-hidden />
      </Button>
    )
  }

  function revealEvidencePanel() {
    window.requestAnimationFrame(() => {
      window.requestAnimationFrame(() => {
        sourcePanelRef.current?.scrollIntoView({
          behavior: "smooth",
          block: "start",
        })
      })
    })
  }

  function showSources(item: BenchmarkDashboardPayload["benchmarks"][number]) {
    setSourceTitle(`${item.item} · ${item.vehicleClass}`)
    setEvidenceMode("sources")
    setSourceRows([])
    setExceptionRows([])
    setSourceLoading(true)
    revealEvidencePanel()
    if (item.sourceObservations) {
      setSourceRows(item.sourceObservations)
      setSourceLoading(false)
      return
    }
    void fetchBenchmarkObservations(
      item.ontologyItemId,
      item.vehicleClass,
      sourceGroup
    )
      .then((result) => {
        setSourceRows(result.observations)
        setLoadError(null)
      })
      .catch(() => setLoadError("The source observations could not be loaded."))
      .finally(() => setSourceLoading(false))
  }

  function showExceptions(
    item: BenchmarkDashboardPayload["benchmarks"][number]
  ) {
    setSourceTitle(`${item.item} · ${item.vehicleClass}`)
    setEvidenceMode("exceptions")
    setSourceRows([])
    setExceptionRows(item.exceptions)
    setSourceLoading(false)
    revealEvidencePanel()
  }

  return (
    <div className="flex flex-col gap-6">
      <ScreenHeading
        title={
          sourceGroup === "in_house"
            ? "In-house Benchmark"
            : "Repair Price Benchmarking"
        }
        description={
          sourceGroup === "in_house"
            ? "Review prices from client-provided in-house repair invoices uploaded in Benchmark data setup."
            : "Review prices extracted from uploaded repair invoices, kept separate from in-house and external evidence."
        }
        action={
          <div className="flex flex-wrap gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={onOpenKnowledgeGraph}
            >
              <Share2Icon aria-hidden />
              Open knowledge graph
            </Button>
          </div>
        }
      />

      <Card>
        <CardContent className="grid gap-4 p-5 md:grid-cols-2 xl:grid-cols-4">
          <label className="grid gap-2 text-sm font-medium">
            {sourceGroup === "in_house"
              ? "Vehicle make & model"
              : "Vehicle category"}
            <Select value={vehicleClass} onValueChange={setVehicleClass}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectItem value="all">
                    {sourceGroup === "in_house"
                      ? "All makes and models"
                      : "All vehicle categories"}
                  </SelectItem>
                  {dashboard.filterOptions.vehicleClasses.map((item) => (
                    <SelectItem key={item} value={item}>
                      {item}
                    </SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
          </label>
          <label className="grid gap-2 text-sm font-medium">
            Repair item
            <Select value={repairItem} onValueChange={setRepairItem}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectItem value="all">All repair items</SelectItem>
                  {dashboard.filterOptions.repairItems.map((item) => (
                    <SelectItem key={item.id} value={item.id}>
                      {item.name}
                    </SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
          </label>
          <label className="grid gap-2 text-sm font-medium">
            Minimum sample
            <Select value={minimumCount} onValueChange={setMinimumCount}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectItem value="1">
                    1+ {sourceGroup === "in_house" ? "samples" : "observations"}
                  </SelectItem>
                  <SelectItem value="3">
                    3+ {sourceGroup === "in_house" ? "samples" : "observations"}
                  </SelectItem>
                  <SelectItem value="10">
                    10+{" "}
                    {sourceGroup === "in_house" ? "samples" : "observations"}
                  </SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          </label>
          <label className="grid gap-2 text-sm font-medium">
            P90 alert threshold
            <Select
              value={String(challengeThreshold)}
              disabled={thresholdApplying}
              onValueChange={(value) =>
                onChallengeThresholdChange(Number(value))
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectItem value="5">More than 5% above P90</SelectItem>
                  <SelectItem value="10">More than 10% above P90</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
            {thresholdApplying ? (
              <span className="text-xs font-normal text-muted-foreground">
                Applying threshold…
              </span>
            ) : null}
          </label>
        </CardContent>
      </Card>

      <div className="grid gap-4 sm:grid-cols-3" aria-label="Benchmark totals">
        {(sourceGroup === "in_house"
          ? [
              ["Invoice observations", dashboard.summary.observationCount],
              ["Benchmark groups", dashboard.benchmarks.length],
              ["Challenged lines", challengedLineCount],
            ]
          : [
              ["Invoice observations", dashboard.summary.observationCount],
              ["Benchmark groups", dashboard.benchmarks.length],
              ["Challenged lines", challengedLineCount],
            ]
        ).map(([label, value]) => (
          <Card key={label}>
            <CardContent className="p-5">
              <p className="text-sm text-muted-foreground">{label}</p>
              <p className="mt-2 text-3xl font-semibold tabular-nums">
                {value}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      {loadError ? (
        <Alert variant="destructive">
          <DatabaseIcon />
          <AlertTitle>Benchmark service unavailable</AlertTitle>
          <AlertDescription>{loadError}</AlertDescription>
        </Alert>
      ) : null}

      <DataCard
        title={
          sourceGroup === "in_house"
            ? "In-house repair benchmark summary"
            : "Historical claims benchmark summary"
        }
        description={
          sourceGroup === "in_house"
            ? "Only client-provided in-house invoices are included. Source rows remain available for each repair item."
            : `Only uploaded historical-claim invoice observations are included here. Red counts require both more than ${challengeThreshold}% above P90 and at least ${preciseMoney(MINIMUM_CHALLENGE_AMOUNT)} difference.`
        }
        action={<Badge variant="outline">P90 · interpolated</Badge>}
      >
        <div className="overflow-x-auto">
          <table className="w-full min-w-[1120px] text-left text-sm">
            <thead className="border-b bg-muted/50 text-xs text-muted-foreground">
              <tr>
                <th className="px-3 py-3">
                  {sortHeader("Repair item", "item", "left")}
                </th>
                <th className="px-3 py-3">
                  {sortHeader(
                    sourceGroup === "in_house"
                      ? "Vehicle make & model"
                      : "Vehicle category",
                    "vehicleClass",
                    "left"
                  )}
                </th>
                <th className="px-3 py-3 text-right">
                  {sortHeader(
                    sourceGroup === "in_house" ? "Samples" : "Invoices",
                    "invoiceCount"
                  )}
                </th>
                <th className="px-3 py-3 text-right">
                  {sortHeader("Min", "min")}
                </th>
                <th className="px-3 py-3 text-right">
                  {sortHeader("Max", "max")}
                </th>
                <th className="px-3 py-3 text-right">
                  {sortHeader("Median", "median")}
                </th>
                <th className="bg-primary/5 px-3 py-3 text-right font-semibold text-foreground">
                  {sortHeader("P90", "p90")}
                </th>
                {sourceGroup !== "in_house" ? (
                  <>
                    <th className="bg-primary/5 px-3 py-3 text-right font-semibold text-foreground">
                      {sortHeader(
                        "Challenged invoices",
                        "exceptionInvoiceCount"
                      )}
                    </th>
                    <th className="bg-destructive/5 px-3 py-3 text-right font-semibold text-foreground">
                      {sortHeader("Total challenge", "totalChallenge")}
                    </th>
                  </>
                ) : null}
                <th className="px-3 py-3 text-right font-medium">
                  {sourceGroup === "in_house"
                    ? "Invoices used"
                    : "Invoices used"}
                </th>
              </tr>
            </thead>
            <tbody>
              {sortedBenchmarks.length ? (
                sortedBenchmarks.map((item) => (
                  <tr
                    key={`${item.ontologyItemId}-${item.vehicleClass}`}
                    className="border-b last:border-0"
                  >
                    <td className="px-3 py-3 font-medium">
                      <div>{item.item}</div>
                      <details className="mt-1 text-xs font-normal text-muted-foreground">
                        <summary className="cursor-pointer select-none hover:text-foreground">
                          More statistics
                        </summary>
                        <div className="mt-2 grid min-w-[250px] grid-cols-2 gap-x-4 gap-y-1 rounded-md border bg-muted/30 p-2">
                          <span>Mean</span>
                          <span className="text-right tabular-nums">
                            {money(item.statistics.mean)}
                          </span>
                          <span>Mode</span>
                          <span className="text-right tabular-nums">
                            {money(item.statistics.mode)}
                          </span>
                          <span>Observations</span>
                          <span className="text-right tabular-nums">
                            {item.statistics.count}
                          </span>
                          <span>Labour mean</span>
                          <span className="text-right tabular-nums">
                            {money(item.labourStatistics.mean)}
                          </span>
                          <span>Labour median</span>
                          <span className="text-right tabular-nums">
                            {money(item.labourStatistics.median)}
                          </span>
                          <span>Labour observations</span>
                          <span className="text-right tabular-nums">
                            {item.labourStatistics.count}
                          </span>
                        </div>
                      </details>
                    </td>
                    <td className="px-3 py-3 text-muted-foreground">
                      {item.vehicleClass}
                    </td>
                    <td className="px-3 py-3 text-right tabular-nums">
                      {item.invoiceCount}
                    </td>
                    <td className="px-3 py-3 text-right tabular-nums">
                      {money(item.statistics.min)}
                    </td>
                    <td className="px-3 py-3 text-right tabular-nums">
                      {money(item.statistics.max)}
                    </td>
                    <td className="px-3 py-3 text-right tabular-nums">
                      {money(item.statistics.median)}
                    </td>
                    <td className="bg-primary/5 px-3 py-3 text-right font-semibold tabular-nums">
                      {money(item.statistics.p90 ?? null)}
                    </td>
                    {sourceGroup !== "in_house" ? (
                      <td className="bg-primary/5 px-3 py-3 text-right">
                        {item.exceptionInvoiceCount > 0 ? (
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            className="h-auto border-destructive/40 py-1 text-destructive hover:text-destructive"
                            onClick={() => showExceptions(item)}
                          >
                            <EyeIcon aria-hidden />
                            {item.exceptionInvoiceCount} invoice
                            {item.exceptionInvoiceCount === 1 ? "" : "s"} ·{" "}
                            {item.exceptionCount} line
                            {item.exceptionCount === 1 ? "" : "s"}
                          </Button>
                        ) : (
                          <Badge variant="outline">0</Badge>
                        )}
                      </td>
                    ) : null}
                    {sourceGroup !== "in_house" ? (
                      <td
                        className={`bg-destructive/5 px-3 py-3 text-right font-semibold tabular-nums ${
                          item.exceptionCount > 0
                            ? "text-destructive"
                            : "text-muted-foreground"
                        }`}
                      >
                        {preciseMoney(totalChallengeAmount(item))}
                      </td>
                    ) : null}
                    <td className="px-3 py-3 text-right">
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        onClick={() => showSources(item)}
                      >
                        <EyeIcon aria-hidden />
                        View {item.invoiceCount}{" "}
                        {sourceGroup === "in_house" ? "rows" : ""}
                      </Button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td
                    colSpan={sourceGroup === "in_house" ? 8 : 10}
                    className="px-3 py-8 text-center text-muted-foreground"
                  >
                    No benchmark observations yet. Values remain at zero until
                    uploaded invoice lines are mapped and compared.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </DataCard>

      {sourceTitle ? (
        <div ref={sourcePanelRef} aria-live="polite">
          <DataCard
            title={
              evidenceMode === "exceptions"
                ? "Above-threshold invoices"
                : "Source observations"
            }
            description={
              evidenceMode === "exceptions"
                ? `${sourceTitle}. Each row was compared with other selected reference invoices and exceeded both challenge gates.`
                : `${sourceTitle}. These invoice rows are the evidence behind the selected benchmark.`
            }
          >
            {evidenceMode === "exceptions" ? (
              exceptionRows.length ? (
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[760px] text-left text-sm">
                    <thead className="border-b bg-muted/50 text-xs text-muted-foreground">
                      <tr>
                        <th className="px-3 py-3 font-medium">Invoice</th>
                        <th className="px-3 py-3 font-medium">Repairer</th>
                        <th className="px-3 py-3 font-medium">
                          Original description
                        </th>
                        <th className="px-3 py-3 text-right font-medium">
                          Charged
                        </th>
                        <th className="px-3 py-3 text-right font-medium">
                          Earlier P90
                        </th>
                        <th className="px-3 py-3 text-right font-medium">
                          Difference
                        </th>
                        <th className="px-3 py-3 text-right font-medium">
                          Above P90
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {exceptionRows.map((row) => (
                        <tr
                          key={row.observationId}
                          className="border-b last:border-0"
                        >
                          <td className="px-3 py-3 font-medium">
                            {row.invoiceNumber}
                          </td>
                          <td className="px-3 py-3 text-muted-foreground">
                            {row.repairer}
                          </td>
                          <td className="px-3 py-3 text-muted-foreground">
                            {row.description ?? "—"}
                          </td>
                          <td className="px-3 py-3 text-right tabular-nums">
                            {preciseMoney(row.amount)}
                          </td>
                          <td className="px-3 py-3 text-right tabular-nums">
                            {preciseMoney(row.p90)}
                          </td>
                          <td className="px-3 py-3 text-right font-medium text-destructive tabular-nums">
                            +{preciseMoney(row.difference)}
                          </td>
                          <td className="px-3 py-3 text-right font-medium text-destructive tabular-nums">
                            +{row.percentageAboveP90.toFixed(1)}%
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">
                  No invoices exceed the selected threshold for this benchmark.
                </p>
              )
            ) : sourceLoading ? (
              <p className="text-sm text-muted-foreground">
                Loading source observations…
              </p>
            ) : sourceRows.length ? (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[720px] text-left text-sm">
                  <thead className="border-b bg-muted/50 text-xs text-muted-foreground">
                    <tr>
                      <th className="px-3 py-3 font-medium">Invoice date</th>
                      <th className="px-3 py-3 font-medium">
                        Source reference
                      </th>
                      <th className="px-3 py-3 font-medium">Source group</th>
                      <th className="px-3 py-3 font-medium">
                        Original description
                      </th>
                      <th className="px-3 py-3 font-medium">Repairer</th>
                      <th className="px-3 py-3 font-medium">Vehicle</th>
                      <th className="px-3 py-3 text-right font-medium">
                        Net amount
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {sourceRows.map((row) => (
                      <tr key={row.id} className="border-b last:border-0">
                        <td className="px-3 py-3">{row.invoiceDate ?? "—"}</td>
                        <td className="px-3 py-3 font-medium">
                          {row.sourceRecordId ?? "—"}
                        </td>
                        <td className="px-3 py-3 text-muted-foreground">
                          {row.sourceGroup === "historical_claim"
                            ? "Previous claim"
                            : row.sourceGroup === "in_house"
                              ? "In-house repair data"
                              : row.sourceGroup || "—"}
                        </td>
                        <td className="px-3 py-3 text-muted-foreground">
                          {row.rawDescription ?? "—"}
                        </td>
                        <td className="px-3 py-3 text-muted-foreground">
                          {row.repairer}
                        </td>
                        <td className="px-3 py-3 text-muted-foreground">
                          {[row.vehicleMake, row.vehicleModel]
                            .filter(Boolean)
                            .join(" ") || row.vehicleClass}
                        </td>
                        <td className="px-3 py-3 text-right tabular-nums">
                          {money(row.amount)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">
                No valid source observations match this benchmark.
              </p>
            )}
          </DataCard>
        </div>
      ) : null}

      {dashboard.summary.observationCount > 0 &&
      selectedInvoiceBenchmarks.length > 0 ? (
        <DataCard
          title={`Selected invoice · ${workspace.invoice.number}`}
          description={`Operational comparison: the selected invoice is excluded from its own P90. A challenge requires both more than ${challengeThreshold}% above P90 and at least ${preciseMoney(MINIMUM_CHALLENGE_AMOUNT)} difference.`}
          action={<Badge variant="outline">Current invoice excluded</Badge>}
        >
          {selectedInvoiceBenchmarks.length ? (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[780px] text-left text-sm">
                <thead className="border-b bg-muted/50 text-xs text-muted-foreground">
                  <tr>
                    <th className="px-3 py-3 font-medium">Line item</th>
                    <th className="px-3 py-3 font-medium">Standard category</th>
                    <th className="px-3 py-3 text-right font-medium">
                      Current
                    </th>
                    <th className="px-3 py-3 text-right font-medium">P90</th>
                    <th className="px-3 py-3 text-right font-medium">
                      Difference
                    </th>
                    <th className="px-3 py-3 font-medium">Decision</th>
                    <th className="px-3 py-3 text-right font-medium">
                      Evidence
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {selectedInvoiceBenchmarks.map((line) => {
                    const benchmark = line.p90Benchmark!
                    // The operational status comes only from the server's
                    // comparisonStatus (see backend price_decision.py) — never
                    // recomputed client-side, so this table can't disagree
                    // with Review findings or the line evidence sheet.
                    const exceedsThreshold =
                      line.comparisonStatus === "CHALLENGE"
                    return (
                      <tr
                        key={line.id}
                        className="border-b align-top last:border-0"
                      >
                        <td className="px-3 py-3 font-medium">
                          {line.description}
                        </td>
                        <td className="px-3 py-3 text-muted-foreground">
                          {benchmark.category}
                        </td>
                        <td className="px-3 py-3 text-right tabular-nums">
                          {preciseMoney(benchmark.currentPrice)}
                        </td>
                        <td className="px-3 py-3 text-right font-semibold tabular-nums">
                          {preciseMoney(benchmark.p90)}
                        </td>
                        <td
                          className={`px-3 py-3 text-right tabular-nums ${
                            exceedsThreshold
                              ? "text-destructive"
                              : "text-success"
                          }`}
                        >
                          {signedMoney(benchmark.difference)}
                        </td>
                        <td className="px-3 py-3">
                          <Badge
                            variant={
                              exceedsThreshold ? "destructive" : "secondary"
                            }
                          >
                            {exceedsThreshold
                              ? "Challenge"
                              : "Within threshold"}
                          </Badge>
                        </td>
                        <td className="px-3 py-3 text-right">
                          <details className="group inline-block text-left">
                            <summary className="cursor-pointer list-none rounded-md border px-3 py-1.5 text-xs font-medium">
                              View {benchmark.historicalCount} prices
                            </summary>
                            <div className="mt-2 min-w-[340px] rounded-lg border bg-card p-3 shadow-sm">
                              <p className="mb-2 text-xs text-muted-foreground">
                                {benchmark.method}. Current invoice excluded.
                              </p>
                              <table className="w-full text-xs">
                                <thead className="text-muted-foreground">
                                  <tr>
                                    <th className="py-1 text-left font-medium">
                                      Invoice
                                    </th>
                                    <th className="py-1 text-left font-medium">
                                      Description
                                    </th>
                                    <th className="py-1 text-right font-medium">
                                      Price
                                    </th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {benchmark.observations.map((observation) => (
                                    <tr
                                      key={observation.lineId}
                                      className="border-t"
                                    >
                                      <td className="py-1.5 pr-2 font-medium">
                                        {observation.invoiceNumber}
                                      </td>
                                      <td className="py-1.5 pr-2 text-muted-foreground">
                                        {observation.description}
                                      </td>
                                      <td className="py-1.5 text-right tabular-nums">
                                        {preciseMoney(observation.price)}
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          </details>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          ) : null}
        </DataCard>
      ) : (
        <DataCard
          title="Invoice comparison"
          description="Upload client reference invoices and a fresh repair invoice to compare prices. Comparisons appear when sufficient matching evidence is available."
        >
          <p className="p-4 text-sm text-muted-foreground">
            No invoice comparison available yet.
          </p>
        </DataCard>
      )}

      <p className="border-t pt-4 text-xs text-muted-foreground">
        Aggregate statistics use client reference invoices. Each invoice is
        excluded from its own comparison; live invoices remain outside the
        reference dataset.
        {loadError ? ` ${loadError}` : ""}
      </p>
    </div>
  )
}
