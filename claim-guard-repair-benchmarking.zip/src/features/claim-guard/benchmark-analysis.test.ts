import { createElement } from "react"
import { renderToStaticMarkup } from "react-dom/server"
import { describe, expect, it } from "vitest"

import { TooltipProvider } from "@/components/ui/tooltip"
import {
  benchmarkAnalysis,
  analysisLines,
  templateDraft,
} from "./benchmark-fixtures"
import {
  benchmarkCellState,
  challengePriceTotal,
  challengeSummary,
  documentOrder,
  generatedByLabel,
  mailtoHref,
  sortByChallengeLevel,
} from "./benchmark-analysis-rows"
import type { BenchmarkAnalysisPayload } from "./benchmark-api"
import {
  BenchmarkAnalysisView,
  ChallengeEmailDraftView,
} from "./screens-benchmark-analysis"

function render(
  analysis: BenchmarkAnalysisPayload = benchmarkAnalysis,
  extra: Record<string, unknown> = {}
) {
  return renderToStaticMarkup(
    createElement(
      TooltipProvider,
      null,
      createElement(BenchmarkAnalysisView, {
        analysis,
        onSelectInvoice: () => {},
        onDraftEmail: () => {},
        drafting: false,
        ...extra,
      })
    )
  )
}

/** Line ids in the order the table rows render them. */
function renderedLineOrder(html: string) {
  return [...html.matchAll(/data-line-id="([^"]+)"/g)].map((match) => match[1])
}

describe("line order: from the invoice first, then from the engineer assessment", () => {
  it("puts every invoice line before every assessment line, keeping each document's own order", () => {
    expect(documentOrder(analysisLines).map((line) => line.line_id)).toEqual([
      "inv-low",
      "inv-medium",
      "inv-high",
      "ea-1",
      "ea-medium",
      "ea-none",
    ])
  })

  it("renders the table in that order by default", () => {
    expect(renderedLineOrder(render())).toEqual([
      "inv-low",
      "inv-medium",
      "inv-high",
      "ea-1",
      "ea-medium",
      "ea-none",
    ])
  })

  it("shows where each row came from", () => {
    const html = render()
    const rowOf = (id: string) => {
      const start = html.indexOf(`data-line-id="${id}"`)
      return html.slice(start, html.indexOf("</tr>", start))
    }

    expect(rowOf("inv-high")).toContain("Invoice")
    expect(rowOf("ea-medium")).toContain("Engineer assessment")
  })
})

describe("sort by challenge level", () => {
  it("orders high, medium, low, none, then by challenge amount", () => {
    expect(sortByChallengeLevel(analysisLines).map((line) => line.line_id)).toEqual([
      "inv-high",
      "inv-medium", // medium, £40.00
      "ea-medium", // medium, £26.20
      "inv-low",
      "ea-1", // none: document order within the level
      "ea-none",
    ])
  })

  it("renders the sorted order when asked to", () => {
    expect(renderedLineOrder(render(benchmarkAnalysis, { initialSort: "level" }))).toEqual([
      "inv-high",
      "inv-medium",
      "ea-medium",
      "inv-low",
      "ea-1",
      "ea-none",
    ])
  })
})

describe("red where a benchmark is violated, amber for Low", () => {
  it("classifies each benchmark cell", () => {
    const [ea1, low, medium, high, eaMedium] = analysisLines

    expect(benchmarkCellState(high.benchmarks.third_party)).toBe("violated")
    expect(benchmarkCellState(high.benchmarks.aviva_dlg)).toBe("violated")
    expect(benchmarkCellState(medium.benchmarks.aviva_dlg)).toBe("within")
    expect(benchmarkCellState(low.benchmarks.third_party)).toBe("above")
    expect(benchmarkCellState(low.benchmarks.aviva_dlg)).toBe("above")
    expect(benchmarkCellState(eaMedium.benchmarks.third_party)).toBe("within")
    expect(benchmarkCellState(ea1.benchmarks.third_party)).toBe("within")
  })

  it("draws a violated cell red, and only a violated cell", () => {
    const html = render()
    const red = [...html.matchAll(/<td[^>]*data-benchmark-state="violated"[^>]*>/g)]

    // high: both; medium: third party; ea-medium: In-house.
    expect(red).toHaveLength(4)
    for (const match of red) expect(match[0]).toContain("text-destructive")
    const notRed = [
      ...html.matchAll(/<td[^>]*data-benchmark-state="(within|above|no-data)"[^>]*>/g),
    ]
    for (const match of notRed) expect(match[0]).not.toContain("text-destructive")
  })

  it("draws a Low line amber, and does not draw it red", () => {
    const html = render()
    const lowRow = html.match(/<tr[^>]*data-line-id="inv-low"[^>]*>/)?.[0] ?? ""

    expect(lowRow).toContain('data-level="low"')
    expect(lowRow).toContain("bg-amber")
    expect(lowRow).not.toContain("destructive")
  })
})

describe("an unavailable benchmark reads No data, never £0.00", () => {
  it("prints No data in every cell with no benchmark", () => {
    const html = render()
    const noData = [
      ...html.matchAll(/<td[^>]*data-benchmark-state="no-data"[^>]*>(.*?)<\/td>/g),
    ]

    // With all 4 benchmark sources rendered, unpopulated cells render No data
    expect(noData.length).toBeGreaterThan(0)
    for (const match of noData) {
      expect(match[1]).toContain("No data")
      expect(match[1]).not.toContain("£0.00")
    }
  })

  it("prints n beside every P90 that exists", () => {
    const html = render()
    const cells = [
      ...html.matchAll(
        /<td[^>]*data-benchmark-state="(within|above|violated)"[^>]*>(.*?)<\/td>/g
      ),
    ]

    expect(cells.length).toBe(10)
    for (const match of cells) expect(match[2]).toMatch(/n = \d+/)
  })
})

describe("the total challenge amount counts High and Medium only", () => {
  it("sums the challenge amounts of high and medium lines, never low", () => {
    const summary = challengeSummary(analysisLines)

    expect(summary.total).toBeCloseTo(234.95, 2)
    expect(summary.counts).toEqual({ high: 1, medium: 2, low: 1 })
    expect(summary.challengeCount).toBe(3)
  })

  it("leaves a Low line out even if the server puts an amount on it", () => {
    // The contract sends "0.00" for Low, but the rule belongs to this screen:
    // a Low line's distance above P90 is never a challenge amount.
    const lines = analysisLines.map((line) =>
      line.line_id === "inv-low"
        ? { ...line, challenge: { ...line.challenge, challenge_amount: "47.73" } }
        : line
    )

    expect(challengeSummary(lines).total).toBeCloseTo(234.95, 2)
  })

  it("puts the total and the count per level at the top of the screen", () => {
    const html = render()
    const table = html.indexOf('data-testid="analysis-table"')
    const total = html.indexOf("£234.95")

    expect(total).toBeGreaterThan(-1)
    expect(total).toBeLessThan(table)
    expect(html).toContain("Total challenge amount")
    const text = html.replaceAll("<!-- -->", "")
    expect(text).toContain("1 high")
    expect(text).toContain("2 medium")
    expect(text).toContain("1 low")
  })

  it("does not count a Low line's distance above P90", () => {
    const html = render()
    const lowRow = html.slice(
      html.indexOf('data-line-id="inv-low"'),
      html.indexOf("</tr>", html.indexOf('data-line-id="inv-low"'))
    )

    expect(lowRow).toContain("£47.73 above P90")
    expect(lowRow).toContain("not counted")
  })
})

describe("P90 challenge reductions and justified amounts", () => {
  it("shows the challenge reduction and justified amount together", () => {
    const html = render()
    const row = (id: string) => {
      const start = html.indexOf(`data-line-id="${id}"`)
      return html.slice(start, html.indexOf("</tr>", start))
    }

    expect(html).toContain("Challenge amount")
    expect(row("inv-high")).toContain("Save £168.75")
    expect(row("inv-high")).toContain("Justified £431.25")
    expect(row("inv-medium")).toContain("Save £40.00")
    expect(row("inv-medium")).toContain("Justified £260.00")
    expect(row("ea-medium")).toContain("Save £26.20")
    expect(row("ea-medium")).toContain("Justified £233.80")
    expect(row("inv-low")).toContain("£47.73 above P90")
    expect(row("ea-none")).toContain("—")
  })

  it("adds proposed prices for challenged lines without changing the reduction total", () => {
    expect(challengePriceTotal(analysisLines)).toBe(925.05)
    expect(challengeSummary(analysisLines).total).toBe(234.95)
    const html = render()
    const summary = html.slice(0, html.indexOf('data-testid="analysis-table"'))
    expect(summary).toContain("50/50 challenge price total")
    expect(summary).toContain("£925.05")
    expect(summary).toContain("excludes unchanged lines")
    expect(summary).toContain("£234.95")
  })

  it("does not invent a price or show a partial total when a proposed price is missing", () => {
    const lines = analysisLines.map((line) => line.line_id === "inv-high"
      ? { ...line, challenge: { ...line.challenge, justified_amount: null } }
      : line)
    expect(challengePriceTotal(lines)).toBeNull()
    expect(challengePriceTotal([])).toBeNull()
    expect(challengePriceTotal(analysisLines.filter((line) => line.challenge.level === "low"))).toBeNull()
  })
})

describe("the invoice header", () => {
  it("names the invoice, vehicle, category and its source, and the paired engineer assessment", () => {
    const html = render()

    expect(html).toContain("LIVE-77")
    expect(html).toContain("SKODA KAROQ")
    expect(html).toContain("A30DRY")
    expect(html).toContain("SUV")
    expect(html).toContain("From the lookup")
    expect(html).toContain("D7576879")
  })

  it("offers a selector when there is more than one live invoice", () => {
    const html = render()

    expect(html).toContain('aria-label="New invoice to analyse"')
    expect(html).toContain("LIVE-78")
  })

  it("offers no selector for a single live invoice", () => {
    const html = render({
      ...benchmarkAnalysis,
      live_invoices: benchmarkAnalysis.live_invoices.slice(0, 1),
    })

    expect(html).not.toContain('aria-label="New invoice to analyse"')
  })

  it("marks an Unknown category as unknown", () => {
    const html = render({
      ...benchmarkAnalysis,
      invoice: {
        ...benchmarkAnalysis.invoice,
        vehicle_category: "Unknown",
        vehicle_category_source: "unknown",
      },
    })

    expect(html).toContain('data-category-unknown="true"')
    expect(html).toContain("Unknown category")
  })
})

describe("challenge actions and draft email workflow", () => {
  it("offers a Challenge button on each challengeable line", () => {
    const html = render()
    const row = (id: string) => {
      const start = html.indexOf(`data-line-id="${id}"`)
      return html.slice(start, html.indexOf("</tr>", start))
    }

    expect(row("inv-high")).toContain("Challenge")
    expect(row("inv-medium")).toContain("Challenge")
    expect(row("ea-medium")).toContain("Challenge")
    expect(row("inv-low")).toContain("Review")
    expect(row("ea-none")).toContain("—")
  })

  it("keeps Draft email disabled until something is selected", () => {
    const html = render()
    const button = html.match(/<button[^>]*>[^<]*Draft email/)?.[0] ?? ""

    expect(button).toContain('disabled=""')
  })

  it("enables Draft email once a challenge is selected", () => {
    const html = render(benchmarkAnalysis, { initialSelected: ["inv-high"] })
    const button = html.match(/<button[^>]*>[^<]*Draft email/)?.[0] ?? ""

    expect(button).toContain("Draft email")
    expect(button).not.toContain('disabled=""')
  })
})

describe("show evidence pop-up triggers per line for benchmarks", () => {
  it("offers interactive popup triggers on every benchmark cell with data", () => {
    const html = render()

    expect(html).toContain('title="Click to open historical benchmark evidence popup"')
  })
})

describe("the email draft says it is a draft, and never that it was sent", () => {
  function renderDraft(draft = templateDraft) {
    return renderToStaticMarkup(
      createElement(ChallengeEmailDraftView, {
        draft,
        onCopy: () => {},
      })
    )
  }

  it("carries the subject and the body", () => {
    const html = renderDraft()

    expect(html).toContain("Invoice LIVE-77: 2 line items challenged")
    expect(html).toContain("FRONT BUMPER: billed £600.00, justified £431.25.")
  })

  it("says plainly that nothing has been sent", () => {
    const html = renderDraft()

    expect(html).toContain("This is a draft. Nothing has been sent.")
    expect(html).not.toMatch(/\b(email|message) (was |has been )?sent\b/i)
    expect(html).not.toMatch(/\bsent to\b/i)
    expect(html).not.toMatch(/>\s*Send\s*</)
  })

  it("offers Copy and Open in email app, and nothing that sends", () => {
    const html = renderDraft()

    expect(html).toContain("Copy")
    expect(html).toContain("Open in email app")
    expect(html).toContain('href="mailto:')
  })

  it("says honestly who wrote it", () => {
    expect(renderDraft()).toContain("Written from a template")
    expect(renderDraft({ ...templateDraft, generated_by: "ai" })).toContain(
      "AI-written; every figure checked against the analysis"
    )
    expect(generatedByLabel("template")).toBe("Written from a template")
  })

  it("builds a mailto link with the subject and body encoded", () => {
    const href = mailtoHref("Invoice 1 & 2", "Line one\nLine two")

    expect(href).toBe("mailto:?subject=Invoice%201%20%26%202&body=Line%20one%0ALine%20two")
  })
})

describe("the rolled-up totals' breakdown is here now", () => {
  it("mounts SectionBreakdownDetail on the analysis screen", () => {
    const html = render()

    expect(html).toContain("Engineer assessment breakdown")
    expect(html).toContain("Total Parts")
    expect(html).toContain("HEADLAMP")
    expect(html).toContain("Matches engineer assessment")
  })

  it("says so when there is no rolled-up total to break down", () => {
    const html = render({ ...benchmarkAnalysis, section_breakdowns: [] })

    expect(html).not.toContain("Engineer assessment breakdown")
    expect(html).toContain("prints no rolled-up totals")
  })
})

it("explains why no challenge rows exist and orders new invoice price before benchmarks", () => {
  const html = render({ ...benchmarkAnalysis, lines: [] })
  expect(html).toContain("No item prices are available to compare")
  expect(html.indexOf("Item price")).toBeLessThan(html.indexOf("Third-party P90 (n)"))
  expect(html.indexOf("Third-party P90 (n)")).toBeLessThan(html.indexOf("In-house P90 (n)"))
  expect(html.indexOf("In-house P90 (n)")).toBeLessThan(html.indexOf("Previous live P90 (n)"))
})

