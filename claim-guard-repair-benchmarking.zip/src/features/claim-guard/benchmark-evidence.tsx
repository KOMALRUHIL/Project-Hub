import { CircleHelpIcon, ExternalLinkIcon, EyeIcon, FileTextIcon } from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"

import { categorySourceLabel, isUnknownCategory, money } from "./benchmark-analysis-rows"
import { cn } from "@/lib/utils"
import type {
  AnalysisLine,
  BenchmarkEvidenceRow,
  BenchmarkSource,
  LineOrigin,
  VehicleCategorySource,
} from "./benchmark-api"

export type { BenchmarkEvidenceRow }

/** Which document a row was read from. Every benchmark and analysis row
 * shows it, because the two documents combine on these screens and the
 * reader has to be able to tell which one a figure came from. */
export function OriginBadge({ origin }: { origin: LineOrigin }) {
  return origin === "invoice" ? (
    <Badge variant="outline">Invoice</Badge>
  ) : (
    <Badge
      variant="outline"
      className="border-sky-300 text-sky-700 dark:border-sky-900 dark:text-sky-300"
    >
      Engineer assessment
    </Badge>
  )
}

/** A vehicle category and where it came from. `Unknown` is drawn as an
 * unknown -- dashed, with a question mark and the reason -- so it can never
 * be read as a vehicle class like SUV or Hatchback. */
export function VehicleCategoryBadge({
  category,
  source,
  showSource = true,
}: {
  category: string
  source?: VehicleCategorySource | null
  showSource?: boolean
}) {
  if (isUnknownCategory(category, source)) {
    return (
      <span
        data-category-unknown="true"
        className="inline-flex flex-wrap items-center gap-1.5"
      >
        <Badge
          variant="outline"
          className="gap-1 border-dashed border-amber-400 text-amber-700 dark:text-amber-300"
        >
          <CircleHelpIcon aria-hidden />
          Unknown category
        </Badge>
        {showSource ? (
          <span className="text-xs text-muted-foreground">
            make and model not recognised
          </span>
        ) : null}
      </span>
    )
  }
  return (
    <span className="inline-flex flex-wrap items-center gap-1.5">
      <Badge variant="secondary">{category}</Badge>
      {showSource && source ? (
        <span className="text-xs text-muted-foreground">
          {categorySourceLabel(source)}
        </span>
      ) : null}
    </span>
  )
}

/** The contributing rows behind one P90, with clear narrative and Show Invoice action. */
export function EvidenceTable({
  rows,
  onShowInvoice,
  repairItem,
  p90,
  currentPrice,
  differencePct,
}: {
  rows: BenchmarkEvidenceRow[]
  onShowInvoice?: (row: BenchmarkEvidenceRow) => void
  repairItem?: string | null
  p90?: string | number | null
  currentPrice?: string | number | null
  differencePct?: string | number | null
}) {
  if (!rows.length)
    return (
      <p className="text-sm text-muted-foreground">
        No contributing rows: this source holds no observation for this repair
        item in this vehicle category.
      </p>
    )

  return (
    <div className="space-y-3">
      {p90 != null && currentPrice != null && (
        <div className="rounded-md border bg-card/60 p-2.5 text-xs text-muted-foreground">
          <p>
            <span className="font-semibold text-foreground">Evidence breakdown: </span>
            This repair item ({repairItem || "item"}) has <span className="font-semibold text-foreground">{rows.length}</span> historical observation(s) yielding a benchmark P90 of <span className="font-semibold text-foreground">{money(p90)}</span>.
            {differencePct != null && Number(differencePct) > 0 ? (
              <span> The new invoice charges <span className="font-semibold text-destructive">{money(currentPrice)}</span> (+{differencePct}% above benchmark).</span>
            ) : null}
          </p>
        </div>
      )}

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Invoice</TableHead>
            <TableHead>Vehicle</TableHead>
            <TableHead>Registration</TableHead>
            <TableHead>Description</TableHead>
            <TableHead>From</TableHead>
            <TableHead className="text-right">Historical Amount</TableHead>
            <TableHead className="text-right">Action</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={`${row.invoice_id}:${row.source_line_id}`}>
              <TableCell>
                <span className="font-medium">
                  {row.invoice_number ?? "Not printed"}
                </span>
                {row.document_filename ? (
                  <span className="block text-xs text-muted-foreground">
                    {row.document_filename}
                  </span>
                ) : null}
              </TableCell>
              <TableCell>
                {[row.vehicle_make, row.vehicle_model].filter(Boolean).join(" ") ||
                  "—"}
              </TableCell>
              <TableCell>{row.registration ?? "—"}</TableCell>
              <TableCell>{row.description}</TableCell>
              <TableCell>
                <OriginBadge origin={row.origin} />
              </TableCell>
              <TableCell className="text-right tabular-nums font-medium">
                {money(row.amount)}
              </TableCell>
              <TableCell className="text-right">
                <Button
                  size="sm"
                  variant="outline"
                  className="h-7 text-xs gap-1.5"
                  onClick={() => onShowInvoice?.(row)}
                  aria-label={`Show invoice ${row.invoice_number || row.document_filename || "document"}`}
                >
                  <EyeIcon className="size-3.5" />
                  Show invoice
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

/** Modal dialog for inspecting the full historical invoice and its original document. */
export function InvoiceDocumentPreviewDialog({
  evidenceRow,
  open,
  onOpenChange,
  onSelectInvoice,
}: {
  evidenceRow: BenchmarkEvidenceRow | null
  open: boolean
  onOpenChange: (open: boolean) => void
  onSelectInvoice?: (invoiceId: string) => void
}) {
  if (!evidenceRow) return null

  const originalDocUrl = evidenceRow.document_id
    ? `/api/v1/documents/${encodeURIComponent(evidenceRow.document_id)}/original`
    : null

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <FileTextIcon className="size-5 text-primary" />
            <DialogTitle>
              Invoice Evidence: {evidenceRow.invoice_number || "Document"}
            </DialogTitle>
          </div>
          <DialogDescription>
            Historical evidence record contributing to the benchmark P90.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div className="grid grid-cols-2 gap-3 rounded-lg border bg-muted/40 p-3 text-sm sm:grid-cols-3">
            <div>
              <p className="text-xs text-muted-foreground">Invoice Number</p>
              <p className="font-semibold">{evidenceRow.invoice_number || "Not printed"}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Document File</p>
              <p className="font-semibold truncate">{evidenceRow.document_filename || "—"}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Source Origin</p>
              <div className="mt-0.5">
                <OriginBadge origin={evidenceRow.origin} />
              </div>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Vehicle</p>
              <p className="font-semibold">
                {[evidenceRow.vehicle_make, evidenceRow.vehicle_model].filter(Boolean).join(" ") || "—"}
              </p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Registration</p>
              <p className="font-semibold">{evidenceRow.registration || "—"}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Historical Amount Billed</p>
              <p className="font-semibold text-primary">{money(evidenceRow.amount)}</p>
            </div>
          </div>

          <div className="rounded-lg border p-3">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">
              Item Billed on this Historical Invoice
            </h4>
            <div className="flex items-center justify-between rounded bg-muted/20 p-2.5">
              <div>
                <p className="font-medium text-sm">{evidenceRow.description}</p>
                {evidenceRow.assessment_number ? (
                  <p className="text-xs text-muted-foreground">
                    Assessment #{evidenceRow.assessment_number}
                  </p>
                ) : null}
              </div>
              <span className="text-base font-bold text-foreground">
                {money(evidenceRow.amount)}
              </span>
            </div>
          </div>
        </div>

        <DialogFooter className="flex flex-wrap items-center justify-between gap-2 sm:justify-between">
          <div className="flex items-center gap-2">
            {originalDocUrl ? (
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5"
                onClick={() => window.open(originalDocUrl, "_blank", "noopener,noreferrer")}
              >
                <ExternalLinkIcon className="size-3.5" />
                Open original PDF
              </Button>
            ) : null}
            {onSelectInvoice && evidenceRow.invoice_id ? (
              <Button
                variant="secondary"
                size="sm"
                onClick={() => {
                  onOpenChange(false)
                  onSelectInvoice(evidenceRow.invoice_id)
                }}
              >
                Inspect in intake workflow
              </Button>
            ) : null}
          </div>
          <Button variant="ghost" size="sm" onClick={() => onOpenChange(false)}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

/** Modal pop-up window showing the specific historical evidence and observations for a clicked benchmark source */
export function SourceEvidenceModal({
  line,
  source,
  open,
  onOpenChange,
  onShowInvoice,
}: {
  line: AnalysisLine | null
  source: BenchmarkSource | null
  open: boolean
  onOpenChange: (open: boolean) => void
  onShowInvoice: (row: BenchmarkEvidenceRow) => void
}) {
  if (!line || !source) return null

  const benchmark = line.benchmarks[source]
  const sourceName =
    source === "third_party"
      ? "Insurer Third Party Invoices"
      : source === "aviva_dlg"
        ? "In-House Benchmark Invoices"
        : source === "new_invoices"
          ? "Previous Live Invoices"
          : "Insurer Strategy Policy Threshold"

  const evidenceRows = benchmark?.evidence || []
  const hasData = benchmark && benchmark.available && benchmark.p90 != null
  const diffPct = benchmark?.difference_pct ? Number(benchmark.difference_pct) : 0
  const isViolated = benchmark?.violated || benchmark?.above_p90

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90dvh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between gap-2">
            <DialogTitle className="text-lg font-bold flex items-center gap-2">
              <FileTextIcon className="size-5 text-primary" />
              {sourceName} Evidence
            </DialogTitle>
            {isViolated && diffPct > 0 ? (
              <Badge variant="destructive" className="text-xs">
                +{diffPct}% over benchmark
              </Badge>
            ) : null}
          </div>
          <DialogDescription>
            Historical evidence and price observations for <span className="font-semibold text-foreground">{line.description}</span> from {sourceName}.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* Top Summary Cards */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 rounded-lg border bg-muted/30 p-3 text-sm">
            <div>
              <p className="text-xs text-muted-foreground">New Invoice Price</p>
              <p className="font-bold text-base text-foreground">{money(line.amount)}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Benchmark P90</p>
              <p className="font-bold text-base text-primary">
                {hasData ? money(benchmark.p90) : "No data"}
              </p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Observations (n)</p>
              <p className="font-semibold">{benchmark?.observations ?? 0} historical records</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Variance</p>
              <p
                className={cn(
                  "font-semibold",
                  isViolated ? "text-destructive" : "text-emerald-600 dark:text-emerald-400"
                )}
              >
                {diffPct > 0 ? `+${diffPct}% above` : diffPct < 0 ? `${diffPct}% below` : "Within benchmark"}
              </p>
            </div>
          </div>

          {/* Narrative Explanation */}
          <div className="rounded-lg border bg-card p-3 text-sm">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1">
              Benchmark Calculation Rationale
            </h4>
            <p className="text-xs leading-relaxed text-muted-foreground">
              {source === "strategy_threshold" ? (
                <>
                  Under the insurer&apos;s strategy policy, <span className="font-medium text-foreground">{line.description}</span> has a policy cap of <span className="font-semibold text-foreground">{money(benchmark?.p90)}</span>. The new invoice price of <span className="font-semibold text-destructive">{money(line.amount)}</span> exceeds the allowable threshold.
                </>
              ) : hasData ? (
                <>
                  This item was matched against <span className="font-semibold text-foreground">{benchmark.observations}</span> historical invoice observation(s) in this vehicle category. The 90th percentile benchmark (P90) is <span className="font-semibold text-foreground">{money(benchmark.p90)}</span>. The new invoice charges <span className="font-semibold text-destructive">{money(line.amount)}</span>, representing an increase of <span className="font-semibold text-destructive">{diffPct}%</span>.
                </>
              ) : (
                <>
                  No previous invoice observations were found in this source database for this item and vehicle category.
                </>
              )}
            </p>
          </div>

          {/* Historical Evidence Invoices Table */}
          <div className="space-y-2">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Contributing Historical Invoices ({evidenceRows.length})
            </h4>
            {evidenceRows.length > 0 ? (
              <EvidenceTable
                rows={evidenceRows}
                onShowInvoice={onShowInvoice}
                repairItem={line.repair_item || line.description}
                p90={benchmark?.p90}
                currentPrice={line.amount}
                differencePct={benchmark?.difference_pct}
              />
            ) : (
              <p className="text-xs text-muted-foreground py-4 text-center">
                No individual invoice rows available for this source.
              </p>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

