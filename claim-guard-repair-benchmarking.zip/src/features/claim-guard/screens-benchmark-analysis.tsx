import { Fragment, useEffect, useState } from "react"
import {
  AlertCircleIcon,
  ChevronDownIcon,
  ChevronRightIcon,
  MailIcon,
} from "lucide-react"
import { toast } from "sonner"

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Textarea } from "@/components/ui/textarea"
import { cn } from "@/lib/utils"

import {
  benchmarkCellState,
  challengePriceTotal,
  challengeSummary,
  documentOrder,
  generatedByLabel,
  isChallenge,
  lowLineDistance,
  mailtoHref,
  money,
  observationsLabel,
  sortByChallengeLevel,
  toNumber,
} from "./benchmark-analysis-rows"
import {
  BENCHMARK_SOURCES,
  createStrategyThreshold,
  deleteStrategyThreshold,
  draftChallengeEmail,
  fetchBenchmarkAnalysis,
  fetchStrategyThresholds,
  type AnalysisBenchmark,
  type AnalysisLine,
  type BenchmarkAnalysisPayload,
  type BenchmarkSource,
  type ChallengeEmailDraft,
  type ChallengeLevel,
  type ChallengeLineAdjustmentInput,
  type StrategyThresholdItem,
} from "./benchmark-api"
import {
  EvidenceTable,
  InvoiceDocumentPreviewDialog,
  OriginBadge,
  VehicleCategoryBadge,
} from "./benchmark-evidence"
import { documentApiErrorMessage } from "./document-api"
import { SectionBreakdownDetail } from "./extracts-section"
import { Metric, ScreenHeading } from "./shared"

const SOURCES: BenchmarkSource[] = ["third_party", "aviva_dlg", "new_invoices", "strategy_threshold"]

export type AnalysisSort = "document" | "level"

const LEVEL_LABELS: Record<ChallengeLevel, string> = {
  high: "High",
  medium: "Medium",
  low: "Low",
}

function LevelBadge({ level }: { level: ChallengeLevel | null }) {
  if (!level) return <span className="text-muted-foreground">—</span>
  if (level === "low")
    return (
      <Badge
        variant="outline"
        className="border-amber-400 text-amber-800 dark:text-amber-300"
      >
        Low
      </Badge>
    )
  return <Badge variant="destructive">{LEVEL_LABELS[level]}</Badge>
}

/** One benchmark's cell. Red when the line violates it, amber when the line
 * is above it but inside the rule, and "No data" -- never £0.00 -- when the
 * source holds nothing for this repair item in this category. `n` sits
 * beside every P90. Clickable to open evidence details when data exists. */
function BenchmarkCell({
  benchmark,
  onClick,
}: {
  benchmark: AnalysisBenchmark
  onClick?: () => void
}) {
  const state = benchmarkCellState(benchmark)
  const isInteractive = state !== "no-data" && Boolean(onClick)
  return (
    <TableCell
      data-benchmark-state={state}
      onClick={isInteractive ? onClick : undefined}
      className={cn(
        "text-right tabular-nums",
        isInteractive && "cursor-pointer hover:underline transition-colors",
        state === "violated" && "bg-destructive/10 font-medium text-destructive",
        state === "above" &&
          "bg-amber-50 text-amber-800 dark:bg-amber-950/30 dark:text-amber-300"
      )}
      title={isInteractive ? "Click to view historical benchmark observations" : undefined}
    >
      {state === "no-data" ? (
        <span className="text-muted-foreground">No data</span>
      ) : (
        <>
          <span>{money(benchmark.p90)}</span>{" "}
          <span className="text-xs opacity-80">
            {observationsLabel(benchmark.observations)}
          </span>
          {toNumber(benchmark.difference_pct) != null &&
          (state === "violated" || state === "above") ? (
            <span className="block text-xs font-semibold">
              +{benchmark.difference_pct}% over
            </span>
          ) : null}
        </>
      )}
    </TableCell>
  )
}

function ChallengeAmountCell({
  line,
  approved,
  onReviewChallenge,
}: {
  line: AnalysisLine
  approved?: { amount: string; note: string }
  onReviewChallenge?: () => void
}) {
  if (isChallenge(line) || approved) {
    const effectiveAmount = approved?.amount ?? line.challenge.challenge_amount
    return (
      <TableCell className="text-right tabular-nums">
        <div className="flex flex-col items-end gap-1">
          <div className="flex items-center gap-1.5">
            {approved && (
              <Badge
                variant="outline"
                className="border-emerald-500 bg-emerald-50 text-[10px] text-emerald-800 py-0 px-1 dark:bg-emerald-950/40 dark:text-emerald-300"
              >
                Approved
              </Badge>
            )}
            <span className="font-semibold text-destructive">
              {money(effectiveAmount)}
            </span>
          </div>
          {onReviewChallenge && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="h-6 px-1.5 text-xs text-primary hover:underline"
              onClick={onReviewChallenge}
            >
              {approved ? "Edit challenge" : "Review & approve"}
            </Button>
          )}
        </div>
      </TableCell>
    )
  }
  if (line.challenge.level === "low") {
    const distance = lowLineDistance(line)
    return (
      <TableCell className="text-right text-xs text-amber-800 tabular-nums dark:text-amber-300">
        <div className="flex flex-col items-end gap-1">
          <span>{distance != null ? `${money(distance)} above P90` : "Above P90"} · not counted</span>
          {onReviewChallenge && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="h-6 px-1.5 text-xs text-muted-foreground hover:text-foreground"
              onClick={onReviewChallenge}
            >
              Challenge anyway
            </Button>
          )}
        </div>
      </TableCell>
    )
  }
  return (
    <TableCell className="text-right text-muted-foreground">—</TableCell>
  )
}

/** Interactive dialog to review, edit, and approve a benchmark challenge */
export function ChallengeApprovalDialog({
  line,
  open,
  onOpenChange,
  onApprove,
  existingApproval,
}: {
  line: AnalysisLine | null
  open: boolean
  onOpenChange: (open: boolean) => void
  onApprove: (lineId: string, amount: string, note: string) => void
  existingApproval?: { amount: string; note: string }
}) {
  if (!line) return null
  const defaultAmount = existingApproval?.amount ?? (line.challenge.challenge_amount !== "0.00" ? line.challenge.challenge_amount : "") ?? ""
  const defaultNote = existingApproval?.note ?? ""
  const [challengeAmount, setChallengeAmount] = useState(defaultAmount)
  const [note, setNote] = useState(defaultNote)

  useEffect(() => {
    if (line) {
      setChallengeAmount(
        existingApproval?.amount ?? (line.challenge.challenge_amount !== "0.00" ? line.challenge.challenge_amount : "") ?? ""
      )
      setNote(existingApproval?.note ?? "")
    }
  }, [line, existingApproval])

  const linePrice = parseFloat(line.amount || "0")
  const numChallenge = parseFloat(challengeAmount || "0")
  const netJustified = isNaN(linePrice) || isNaN(numChallenge) ? 0 : Math.max(0, linePrice - numChallenge)

  const handleApprove = (e: React.FormEvent) => {
    e.preventDefault()
    const parsed = parseFloat(challengeAmount)
    if (isNaN(parsed) || parsed <= 0) {
      toast.error("Please enter a valid challenge reduction amount greater than £0.00.")
      return
    }
    if (parsed > linePrice) {
      toast.error("Challenge reduction amount cannot exceed the total invoiced item price.")
      return
    }
    onApprove(line.line_id, parsed.toFixed(2), note.trim())
    toast.success(`Challenge approved for ${line.description}`, {
      description: `Reduction of ${money(parsed.toFixed(2))} confirmed. Selected for challenge email draft.`,
    })
    onOpenChange(false)
  }

  const handleResetToSystem = () => {
    setChallengeAmount(line.challenge.challenge_amount || "0.00")
    setNote("")
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90dvh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <DialogTitle>Review & Approve Challenge</DialogTitle>
            <LevelBadge level={line.challenge.level} />
          </div>
          <DialogDescription>
            Verify the benchmark violation, accept the calculated reduction, or edit the challenge amount before drafting the challenge email.
          </DialogDescription>
        </DialogHeader>

        <div className="rounded-lg border bg-muted/30 p-3 space-y-2 text-sm">
          <div className="flex justify-between font-medium">
            <span>Item: {line.description}</span>
            <OriginBadge origin={line.origin} />
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground pt-1">
            <div>
              <span className="font-semibold text-foreground">Invoiced Item Price:</span>{" "}
              {money(line.amount)}
            </div>
            <div>
              <span className="font-semibold text-foreground">Blended Benchmark Price:</span>{" "}
              {money(line.challenge.justified_amount)}
            </div>
          </div>
          <div className="text-xs text-muted-foreground pt-1">
            <span className="font-semibold text-foreground">Benchmark Evidence & Rule:</span>
            <p className="mt-0.5">{line.challenge.reason}</p>
          </div>
        </div>

        <form onSubmit={handleApprove} className="space-y-4 pt-2">
          <div className="space-y-1.5">
            <div className="flex justify-between items-center text-sm font-medium">
              <label htmlFor="challenge-amount">Challenge Reduction Amount (£) *</label>
              {line.challenge.challenge_amount !== "0.00" ? (
                <button
                  type="button"
                  onClick={handleResetToSystem}
                  className="text-xs text-primary hover:underline"
                >
                  Reset to system ({money(line.challenge.challenge_amount)})
                </button>
              ) : null}
            </div>
            <Input
              id="challenge-amount"
              type="number"
              step="0.01"
              min="0.01"
              max={line.amount}
              value={challengeAmount}
              onChange={(e) => setChallengeAmount(e.target.value)}
              required
              className="text-base font-semibold"
            />
            <p className="text-xs text-muted-foreground">
              Adjusted proposed justified price:{" "}
              <span className="font-semibold text-foreground">{money(netJustified.toFixed(2))}</span>
            </p>
          </div>

          <div className="space-y-1.5">
            <label htmlFor="challenge-note" className="text-sm font-medium">
              Handler Rationale / Email Note (Optional)
            </label>
            <Textarea
              id="challenge-note"
              placeholder="e.g. Capped per regional rate agreement; excess labour units disallowed."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="h-20 resize-none text-xs"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">
              Approve Challenge
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}

/** The analysis itself, rendered from a payload so it can be tested without
 * a network. The `initial*` props seed the local state for the same reason:
 * a server render has no pointer to click the sort, a checkbox or a toggle. */
export function BenchmarkAnalysisView({
  analysis,
  caseReference,
  onThresholdsChanged,
  onSelectInvoice,
  onDraftEmail,
  drafting,
  initialSort = "document",
  initialSelected = [],
  initialEvidenceOpen = [],
}: {
  analysis: BenchmarkAnalysisPayload
  caseReference?: string
  onThresholdsChanged?: () => void
  onSelectInvoice: (invoiceId: string) => void
  onDraftEmail: (lineIds: string[], adjustments?: ChallengeLineAdjustmentInput[]) => void
  drafting: boolean
  initialSort?: AnalysisSort
  initialSelected?: string[]
  initialEvidenceOpen?: string[]
}) {
  const [sort, setSort] = useState<AnalysisSort>(initialSort)
  const [selected, setSelected] = useState<Set<string>>(
    () => new Set(initialSelected)
  )
  const [evidenceOpen, setEvidenceOpen] = useState<Set<string>>(
    () => new Set(initialEvidenceOpen)
  )
  const [inspectingRow, setInspectingRow] = useState<BenchmarkEvidenceRow | null>(
    null
  )
  const [approvingLine, setApprovingLine] = useState<AnalysisLine | null>(null)
  const [approvedChallenges, setApprovedChallenges] = useState<
    Map<string, { amount: string; note: string }>
  >(new Map())

  const { invoice } = analysis
  const lines =
    sort === "level"
      ? sortByChallengeLevel(analysis.lines)
      : documentOrder(analysis.lines)
  const summary = challengeSummary(analysis.lines)
  const challengeLines = lines.filter((l) => isChallenge(l) || approvedChallenges.has(l.line_id))
  const selectedIds = lines
    .filter(
      (line) => selected.has(line.line_id) && (isChallenge(line) || approvedChallenges.has(line.line_id))
    )
    .map((line) => line.line_id)
  const selectedTotal = lines
    .filter((line) => selected.has(line.line_id) && (isChallenge(line) || approvedChallenges.has(line.line_id)))
    .reduce((total, line) => {
      const approved = approvedChallenges.get(line.line_id)
      const amt = approved ? toNumber(approved.amount) : toNumber(line.challenge.challenge_amount)
      return total + (amt ?? 0)
    }, 0)

  function handleApproveChallenge(lineId: string, amount: string, note: string) {
    setApprovedChallenges((prev) => {
      const next = new Map(prev)
      next.set(lineId, { amount, note })
      return next
    })
    setSelected((prev) => {
      const next = new Set(prev)
      next.add(lineId)
      return next
    })
  }

  const handleDraftClick = () => {
    const adjustments: ChallengeLineAdjustmentInput[] = selectedIds.map((id) => ({
      line_id: id,
      adjusted_challenge_amount: approvedChallenges.get(id)?.amount,
      note: approvedChallenges.get(id)?.note,
    }))
    onDraftEmail(selectedIds, adjustments)
  }

  function toggleIn(
    setter: typeof setSelected,
    id: string,
    on?: boolean
  ) {
    setter((current) => {
      const next = new Set(current)
      if (on ?? !next.has(id)) next.add(id)
      else next.delete(id)
      return next
    })
  }

  const vehicle =
    [invoice.vehicle_make, invoice.vehicle_model].filter(Boolean).join(" ") ||
    "Not printed"

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <CardTitle>
                Invoice {invoice.invoice_number ?? "number not printed"}
              </CardTitle>
              <CardDescription>
                Every line of this invoice, then every line of its engineer
                assessment, against the third-party P90 and the In-house P90
                for its vehicle category. The two reference P90s stay separate;
                their 50/50 average supplies the challenge price.
              </CardDescription>
            </div>
            {analysis.live_invoices.length > 1 ? (
              <select
                className="h-9 min-w-56 rounded-md border bg-background px-3 text-sm"
                aria-label="New invoice to analyse"
                value={invoice.id}
                onChange={(event) => onSelectInvoice(event.target.value)}
              >
                {analysis.live_invoices.map((option) => (
                  <option key={option.id} value={option.id}>
                    {[option.invoice_number ?? "Number not printed", option.registration]
                      .filter(Boolean)
                      .join(" · ")}
                  </option>
                ))}
              </select>
            ) : null}
          </div>
        </CardHeader>
        <CardContent>
          <dl className="grid gap-4 text-sm sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <dt className="text-xs text-muted-foreground">Vehicle</dt>
              <dd className="font-medium">{vehicle}</dd>
              <dd className="text-muted-foreground">
                {invoice.registration ?? "Registration not printed"}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-muted-foreground">Vehicle category</dt>
              <dd className="mt-1">
                <VehicleCategoryBadge
                  category={invoice.vehicle_category}
                  source={invoice.vehicle_category_source}
                />
              </dd>
            </div>
            <div>
              <dt className="text-xs text-muted-foreground">
                Paired engineer assessment
              </dt>
              <dd className="font-medium">
                {invoice.paired_assessment_number ?? (
                  <span className="font-normal text-muted-foreground">
                    No engineer assessment paired
                  </span>
                )}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-muted-foreground">Valuation rule</dt>
              <dd className="text-muted-foreground">
                Challenge when over the 50/50 price by more than {analysis.threshold_pct}%
                and by at least {money(analysis.minimum_challenge_amount)}.
              </dd>
            </div>
          </dl>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Metric
            label="50/50 challenge price total"
            value={money(challengePriceTotal(analysis.lines))}
            hint="Sum of proposed prices for this invoice's High and Medium lines only; excludes unchanged lines."
          />
          <Metric
            label="Total challenge amount"
            value={money(summary.total)}
            hint="Reduction requested on High and Medium lines only. Low lines are shown, never counted."
            emphasis={summary.total > 0}
          />
          <div className="min-w-0 px-1 py-1">
            <p className="text-xs font-medium text-muted-foreground">
              Challenges by level
            </p>
            <p className="mt-2 flex flex-wrap items-center gap-2 text-sm">
              <Badge variant="destructive">{summary.counts.high} high</Badge>
              <Badge variant="destructive">{summary.counts.medium} medium</Badge>
              <Badge
                variant="outline"
                className="border-amber-400 text-amber-800 dark:text-amber-300"
              >
                {summary.counts.low} low
              </Badge>
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              High: both benchmarks violated. Medium: one. Both require the invoice
              price to exceed the 50/50 price by the valuation rule. Low: not challenged.
            </p>
          </div>
          <Metric
            label="Selected for the email"
            value={money(selectedTotal)}
            hint={`${selectedIds.length} of ${challengeLines.length} challenges selected`}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <CardTitle>Line items against both benchmarks</CardTitle>
              <CardDescription>
                Red where a benchmark is violated, amber for a Low line. Select
                the challenges to pursue, then draft the email.
                {" "}Challenge price is 50% Third-party P90 + 50% In-house P90. Both
                benchmarks are required. Challenge amount is the reduction from
                the new invoice item price, subject to the valuation rule.
              </CardDescription>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="inline-flex rounded-md border p-0.5" role="group" aria-label="Order">
                <Button
                  size="sm"
                  variant={sort === "document" ? "secondary" : "ghost"}
                  aria-pressed={sort === "document"}
                  onClick={() => setSort("document")}
                >
                  As on the documents
                </Button>
                <Button
                  size="sm"
                  variant={sort === "level" ? "secondary" : "ghost"}
                  aria-pressed={sort === "level"}
                  onClick={() => setSort("level")}
                >
                  By challenge level
                </Button>
              </div>
              <Button
                size="sm"
                variant="outline"
                disabled={!challengeLines.length}
                onClick={() =>
                  setSelected(
                    selectedIds.length === challengeLines.length
                      ? new Set()
                      : new Set(challengeLines.map((line) => line.line_id))
                  )
                }
              >
                {challengeLines.length &&
                selectedIds.length === challengeLines.length
                  ? "Clear selection"
                  : "Select all challenges"}
              </Button>
              <Button
                size="sm"
                disabled={!selectedIds.length || drafting}
                onClick={handleDraftClick}
              >
                {drafting ? "Drafting…" : "Draft email"}
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div data-testid="analysis-table" className="rounded-lg border">
            <Table className="min-w-[860px] table-fixed [&_th]:h-auto [&_th]:py-3 [&_th]:whitespace-normal">
              <TableHeader>
                <TableRow>
                  <TableHead className="w-8">
                    <span className="sr-only">Evidence</span>
                  </TableHead>
                  <TableHead className="w-1/5">Description</TableHead>
                  <TableHead className="text-right">
                    Third-party P90 (n)
                  </TableHead>
                  <TableHead className="text-right">In-house P90 (n)</TableHead>
                  <TableHead className="text-right">Previous live P90 (n)</TableHead>
                  <TableHead className="text-right">Strategy threshold</TableHead>
                  <TableHead className="text-right">New invoice item price</TableHead>
                  <TableHead>Challenge level</TableHead>
                  <TableHead className="text-right">Challenge price (blended P90)</TableHead>
                  <TableHead className="text-right">Challenge amount</TableHead>
                  <TableHead className="w-12">Select</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {lines.length === 0 && (
                  <TableRow><TableCell colSpan={11} className="whitespace-normal py-8 text-center text-muted-foreground">
                    No item prices are available to compare. Review this invoice in Document intelligence.
                    If it contains section totals, pair its engineer assessment and check that detailed rows
                    were extracted and the section totals agree.
                  </TableCell></TableRow>
                )}
                {lines.map((line) => {
                  const open = evidenceOpen.has(line.line_id)
                  const detailId = `analysis-evidence-${line.line_id}`
                  return (
                    <Fragment key={line.line_id}>
                      <TableRow
                        data-line-id={line.line_id}
                        data-level={line.challenge.level ?? "none"}
                        className={cn(
                          line.challenge.level === "low" &&
                            "bg-amber-50/60 dark:bg-amber-950/20"
                        )}
                      >
                        <TableCell>
                          <button
                            type="button"
                            onClick={() =>
                              toggleIn(setEvidenceOpen, line.line_id)
                            }
                            aria-expanded={open}
                            aria-controls={detailId}
                            aria-label={`${open ? "Hide" : "Show"} evidence for ${line.description}`}
                            className="text-muted-foreground transition-colors hover:text-foreground"
                          >
                            {open ? (
                              <ChevronDownIcon className="size-4" />
                            ) : (
                              <ChevronRightIcon className="size-4" />
                            )}
                          </button>
                        </TableCell>
                        <TableCell className="whitespace-normal [overflow-wrap:anywhere]">
                          <span className="font-medium">{line.description}</span>
                          <span className="mt-1 flex flex-wrap items-center gap-1.5">
                            <OriginBadge origin={line.origin} />
                            {line.repair_item ? (
                              <span className="text-xs text-muted-foreground">
                                {line.repair_item}
                              </span>
                            ) : null}
                          </span>
                        </TableCell>
                        <BenchmarkCell
                          benchmark={line.benchmarks.third_party}
                          onClick={() => toggleIn(setEvidenceOpen, line.line_id, true)}
                        />
                        <BenchmarkCell
                          benchmark={line.benchmarks.aviva_dlg}
                          onClick={() => toggleIn(setEvidenceOpen, line.line_id, true)}
                        />
                        <BenchmarkCell
                          benchmark={
                            line.benchmarks.new_invoices ?? {
                              available: false,
                              p90: null,
                              observations: 0,
                              above_p90: false,
                              violated: false,
                              difference: null,
                              difference_pct: null,
                              evidence: [],
                            }
                          }
                          onClick={() => toggleIn(setEvidenceOpen, line.line_id, true)}
                        />
                        <BenchmarkCell
                          benchmark={
                            line.benchmarks.strategy_threshold ?? {
                              available: false,
                              p90: null,
                              observations: 0,
                              above_p90: false,
                              violated: false,
                              difference: null,
                              difference_pct: null,
                              evidence: [],
                            }
                          }
                          onClick={() => toggleIn(setEvidenceOpen, line.line_id, true)}
                        />
                        <TableCell className="text-right tabular-nums">{money(line.amount)}</TableCell>
                        <TableCell>
                          <LevelBadge level={line.challenge.level} />
                        </TableCell>
                        <TableCell data-challenge-price className="text-right font-medium tabular-nums">
                          {money(
                            approvedChallenges.has(line.line_id)
                              ? String(
                                  Math.max(
                                    0,
                                    (toNumber(line.amount) ?? 0) -
                                      (toNumber(approvedChallenges.get(line.line_id)?.amount) ?? 0)
                                  ).toFixed(2)
                                )
                              : isChallenge(line)
                                ? line.challenge.justified_amount
                                : null
                          )}
                        </TableCell>
                        <ChallengeAmountCell
                          line={line}
                          approved={approvedChallenges.get(line.line_id)}
                          onReviewChallenge={() => setApprovingLine(line)}
                        />
                        <TableCell>
                          {isChallenge(line) || approvedChallenges.has(line.line_id) ? (
                            <Checkbox
                              checked={selected.has(line.line_id)}
                              onCheckedChange={(checked) =>
                                toggleIn(setSelected, line.line_id, checked === true)
                              }
                              aria-label={`Select ${line.description} for the challenge email`}
                            />
                          ) : null}
                        </TableCell>
                      </TableRow>
                      {open ? (
                        <TableRow id={detailId}>
                          <TableCell colSpan={11} className="bg-muted/30 p-3">
                            <p className="mb-3 text-sm">{line.challenge.reason}</p>
                            <div className="grid gap-4 xl:grid-cols-2">
                              {SOURCES.map((source) => (
                                line.benchmarks[source] ? (
                                  <div key={source} className="min-w-0">
                                    <h4 className="mb-2 text-sm font-semibold">
                                      {BENCHMARK_SOURCES[source]?.label || source} evidence
                                    </h4>
                                    <EvidenceTable
                                      rows={line.benchmarks[source].evidence || []}
                                      onShowInvoice={(row) => setInspectingRow(row)}
                                      repairItem={line.repair_item || line.description}
                                      p90={line.benchmarks[source]?.p90}
                                      currentPrice={line.amount}
                                      differencePct={line.benchmarks[source]?.difference_pct}
                                    />
                                  </div>
                                ) : null
                              ))}
                            </div>
                          </TableCell>
                        </TableRow>
                      ) : null}
                    </Fragment>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* "Now we are able to combine them when we do the analysis." The
          split was taken out of the extract tables on 17 Sep and moved here:
          how each rolled-up invoice total breaks down into the engineer
          assessment rows that the lines above were benchmarked on. */}
      <Card>
        <CardHeader>
          <CardTitle>How each rolled-up invoice total breaks down</CardTitle>
          <CardDescription>
            A total the invoice prints as one figure is never benchmarked. Its
            line items come from the paired engineer assessment, and only when
            the section total agrees with the engineer assessment's.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {analysis.section_breakdowns.length ? (
            analysis.section_breakdowns.map((breakdown) => (
              <div key={breakdown.invoice_line_item_id}>
                <p className="mt-2 text-sm font-medium">
                  {breakdown.description}
                </p>
                <SectionBreakdownDetail breakdown={breakdown} />
              </div>
            ))
          ) : (
            <p className="text-sm text-muted-foreground">
              This invoice prints no rolled-up totals: every invoice line above
              is itemised on the invoice itself.
            </p>
          )}
        </CardContent>
      </Card>

      {/* Strategy Threshold Management Card */}
      {caseReference ? (
        <StrategyThresholdManagerCard
          caseReference={caseReference}
          onThresholdsChanged={onThresholdsChanged}
        />
      ) : null}

      <InvoiceDocumentPreviewDialog
        evidenceRow={inspectingRow}
        open={Boolean(inspectingRow)}
        onOpenChange={(open) => {
          if (!open) setInspectingRow(null)
        }}
        onSelectInvoice={onSelectInvoice}
      />

      <ChallengeApprovalDialog
        line={approvingLine}
        open={Boolean(approvingLine)}
        onOpenChange={(open) => {
          if (!open) setApprovingLine(null)
        }}
        onApprove={handleApproveChallenge}
        existingApproval={
          approvingLine ? approvedChallenges.get(approvingLine.line_id) : undefined
        }
      />
    </>
  )
}

/** Management card for the 4th benchmark source: Insurer Strategy Thresholds */
export function StrategyThresholdManagerCard({
  caseReference,
  onThresholdsChanged,
}: {
  caseReference: string
  onThresholdsChanged?: () => void
}) {
  const [thresholds, setThresholds] = useState<StrategyThresholdItem[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [itemName, setItemName] = useState("")
  const [maxAmount, setMaxAmount] = useState("")
  const [description, setDescription] = useState("")

  const loadThresholds = () => {
    setLoading(true)
    fetchStrategyThresholds(caseReference)
      .then((res) => {
        setThresholds(res.thresholds || [])
      })
      .catch((err) => {
        toast.error("Failed to load insurer strategy thresholds", {
          description: documentApiErrorMessage(err),
        })
      })
      .finally(() => setLoading(false))
  }

  useEffect(() => {
    loadThresholds()
  }, [caseReference])

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!itemName.trim() || !maxAmount.trim()) {
      toast.error("Please enter both the item name and maximum amount.")
      return
    }
    const num = parseFloat(maxAmount)
    if (isNaN(num) || num < 0) {
      toast.error("Please enter a valid non-negative number for the amount.")
      return
    }
    setSaving(true)
    try {
      await createStrategyThreshold(caseReference, {
        item_name: itemName.trim(),
        max_amount_net: num.toFixed(2),
        description: description.trim(),
      })
      toast.success("Strategy threshold added successfully.")
      setItemName("")
      setMaxAmount("")
      setDescription("")
      setDialogOpen(false)
      loadThresholds()
      onThresholdsChanged?.()
    } catch (err) {
      toast.error("Failed to create strategy threshold", {
        description: documentApiErrorMessage(err),
      })
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (thresholdId: string, name: string) => {
    try {
      await deleteStrategyThreshold(caseReference, thresholdId)
      toast.success(`Removed threshold for ${name}`)
      loadThresholds()
      onThresholdsChanged?.()
    } catch (err) {
      toast.error("Failed to delete strategy threshold", {
        description: documentApiErrorMessage(err),
      })
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <CardTitle>4th Benchmark Source: Insurer Strategy Thresholds</CardTitle>
            <CardDescription>
              Configured policy caps and fee thresholds applied to invoice items (e.g. Labour rates, valeting & cleaning fees, environmental charges, disallowed fees).
            </CardDescription>
          </div>
          <Button size="sm" onClick={() => setDialogOpen(true)}>
            Add New Threshold
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <p className="text-sm text-muted-foreground">Loading strategy thresholds…</p>
        ) : thresholds.length === 0 ? (
          <p className="text-sm text-muted-foreground">No active strategy thresholds configured.</p>
        ) : (
          <div className="rounded-lg border overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-1/3">Repair Item / Charge Name</TableHead>
                  <TableHead className="text-right">Max Allowed (£)</TableHead>
                  <TableHead className="w-1/3">Policy Rule & Scope</TableHead>
                  <TableHead>Keywords Matched</TableHead>
                  <TableHead className="w-16 text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {thresholds.map((t) => (
                  <TableRow key={t.id}>
                    <TableCell className="font-medium">{t.item_name}</TableCell>
                    <TableCell className="text-right font-semibold tabular-nums text-primary">
                      {money(t.max_amount_net)}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {t.description}
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {t.keywords?.slice(0, 4).map((kw) => (
                          <Badge key={kw} variant="secondary" className="text-xs">
                            {kw}
                          </Badge>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-destructive hover:text-destructive"
                        onClick={() => handleDelete(t.id, t.item_name)}
                        title="Delete this threshold"
                      >
                        Delete
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Insurer Strategy Policy Threshold</DialogTitle>
            <DialogDescription>
              Set a maximum net amount cap (£) for specific invoice repair charges or fee items.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleCreate} className="flex flex-col gap-4 py-2">
            <label className="flex flex-col gap-1.5 text-sm font-medium">
              Item Name / Policy Target *
              <Input
                placeholder="e.g. Diagnostics Scan Fee"
                value={itemName}
                onChange={(e) => setItemName(e.target.value)}
                required
              />
            </label>
            <label className="flex flex-col gap-1.5 text-sm font-medium">
              Maximum Allowed Net Amount (£) *
              <Input
                type="number"
                step="0.01"
                min="0"
                placeholder="25.00"
                value={maxAmount}
                onChange={(e) => setMaxAmount(e.target.value)}
                required
              />
            </label>
            <label className="flex flex-col gap-1.5 text-sm font-medium">
              Policy Description / Rationale
              <Textarea
                placeholder="e.g. Insurer maximum cap of £25.00 for pre/post diagnostics scan."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="h-20 resize-none"
              />
            </label>
            <div className="flex justify-end gap-2 mt-2">
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={saving}>
                {saving ? "Saving…" : "Add Threshold"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </Card>
  )
}

/** The drafted email. It says it is a draft, and that nothing has been sent,
 * because nothing has: the server never sends it, and the only ways out of
 * here are the clipboard and the handler's own email app. */
export function ChallengeEmailDraftView({
  draft,
  onCopy,
}: {
  draft: ChallengeEmailDraft
  onCopy: (text: string) => void
}) {
  const text = `Subject: ${draft.subject}\n\n${draft.body}`
  return (
    <div className="flex flex-col gap-4">
      <Alert>
        <MailIcon />
        <AlertTitle>This is a draft. Nothing has been sent.</AlertTitle>
        <AlertDescription>
          ClaimGuard does not email anyone. Copy the draft, or open it in your
          email app, check it, and send it from there yourself.
        </AlertDescription>
      </Alert>
      <p className="text-xs text-muted-foreground">
        {generatedByLabel(draft.generated_by)} · total challenge amount in this
        draft {money(draft.total_challenge_amount)} across {draft.lines.length}{" "}
        {draft.lines.length === 1 ? "line" : "lines"}.
      </p>
      <label className="flex flex-col gap-1.5 text-sm font-medium">
        Subject
        <Input readOnly value={draft.subject} />
      </label>
      <label className="flex flex-col gap-1.5 text-sm font-medium">
        Body
        <Textarea readOnly value={draft.body} className="h-64 min-h-40 resize-y [field-sizing:fixed] font-mono text-xs" />
      </label>
      <div className="flex flex-wrap justify-end gap-2">
        <Button variant="outline" onClick={() => onCopy(text)}>
          Copy
        </Button>
        <Button asChild>
          <a href={mailtoHref(draft.subject, draft.body)}>Open in email app</a>
        </Button>
      </div>
    </div>
  )
}

/** Benchmark analysis: the new invoice against both benchmarks, the
 * challenges, and the draft email. */
export function BenchmarkAnalysisScreen({
  caseReference,
  onUploadNewInvoice,
}: {
  caseReference: string
  onUploadNewInvoice: () => void
}) {
  const [invoiceId, setInvoiceId] = useState<string | undefined>(undefined)
  const [analysis, setAnalysis] = useState<BenchmarkAnalysisPayload | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [drafting, setDrafting] = useState(false)
  const [draft, setDraft] = useState<ChallengeEmailDraft | null>(null)

  useEffect(() => {
    let active = true
    void fetchBenchmarkAnalysis(caseReference, invoiceId)
      .then((payload) => {
        if (!active) return
        setAnalysis(payload)
        setError(null)
      })
      .catch((e) => {
        if (!active) return
        setAnalysis(null)
        setError(documentApiErrorMessage(e))
      })
      .finally(() => {
        if (active) setLoading(false)
      })
    return () => {
      active = false
    }
  }, [caseReference, invoiceId])

  async function draftEmail(lineIds: string[], adjustments?: ChallengeLineAdjustmentInput[]) {
    if (!analysis || drafting) return
    setDrafting(true)
    try {
      setDraft(
        await draftChallengeEmail(caseReference, {
          invoiceId: analysis.invoice.id,
          lineIds,
          adjustments,
        })
      )
    } catch (e) {
      toast.error("The email could not be drafted", {
        description: documentApiErrorMessage(e),
      })
    } finally {
      setDrafting(false)
    }
  }

  function copy(text: string) {
    void navigator.clipboard
      .writeText(text)
      .then(() =>
        toast.success("Draft copied", {
          description: "Nothing has been sent.",
        })
      )
      .catch(() => toast.error("The draft could not be copied"))
  }

  return (
    <>
      <ScreenHeading
        title="Benchmark analysis"
        description="Every line item of the new invoice -- from the invoice first, then from its engineer assessment -- against the third-party and the In-house P90 for its vehicle category. Red where a benchmark is violated."
      />
      {error ? (
        <Alert variant="destructive">
          <AlertCircleIcon />
          <AlertTitle>The analysis could not be loaded</AlertTitle>
          <AlertDescription className="flex flex-col items-start gap-3">
            <span>
              {error} If no new invoice has been uploaded yet, upload one
              first.
            </span>
            <Button variant="outline" size="sm" onClick={onUploadNewInvoice}>
              Upload new invoice
            </Button>
          </AlertDescription>
        </Alert>
      ) : loading || !analysis ? (
        <p className="text-sm text-muted-foreground">Loading the analysis…</p>
      ) : (
        <BenchmarkAnalysisView
          key={analysis.invoice.id}
          analysis={analysis}
          caseReference={caseReference}
          onThresholdsChanged={() => {
            void fetchBenchmarkAnalysis(caseReference, invoiceId)
              .then((payload) => {
                setAnalysis(payload)
                setError(null)
              })
              .catch((e) => {
                setError(documentApiErrorMessage(e))
              })
          }}
          onSelectInvoice={(id) => {
            setLoading(true)
            setInvoiceId(id)
          }}
          onDraftEmail={(lineIds, adjustments) => void draftEmail(lineIds, adjustments)}
          drafting={drafting}
        />
      )}
      <Dialog
        open={draft != null}
        onOpenChange={(open) => {
          if (!open) setDraft(null)
        }}
      >
        <DialogContent className="max-h-[90dvh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>Challenge email draft</DialogTitle>
            <DialogDescription>
              For invoice {analysis?.invoice.invoice_number ?? ""}. Every £
              figure comes from the analysis.
            </DialogDescription>
          </DialogHeader>
          {draft ? <ChallengeEmailDraftView draft={draft} onCopy={copy} /> : null}
        </DialogContent>
      </Dialog>
    </>
  )
}
