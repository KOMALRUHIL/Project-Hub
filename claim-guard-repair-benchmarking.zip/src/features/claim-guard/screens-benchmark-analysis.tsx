import { useEffect, useState } from "react"
import {
  AlertCircleIcon,
  CheckCircle2Icon,
  ChevronDownIcon,
  ChevronUpIcon,
  MailIcon,
  SlidersHorizontalIcon,
} from "lucide-react"
import { toast } from "sonner"

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Textarea } from "@/components/ui/textarea"
import { cn } from "@/lib/utils"

import {
  benchmarkCellState,
  challengePriceTotal,
  challengeSummary,
  documentOrder,
  generatedByLabel,
  isChallenge,
  lowLineDistance,
  mailtoHref,
  money,
  observationsLabel,
  sortByChallengeLevel,
  toNumber,
} from "./benchmark-analysis-rows"
import {
  createStrategyThreshold,
  deleteStrategyThreshold,
  draftChallengeEmail,
  fetchBenchmarkAnalysis,
  fetchStrategyThresholds,
  type AnalysisBenchmark,
  type AnalysisLine,
  type BenchmarkAnalysisPayload,
  type BenchmarkEvidenceRow,
  type BenchmarkSource,
  type ChallengeEmailDraft,
  type ChallengeLevel,
  type ChallengeLineAdjustmentInput,
  type StrategyThresholdItem,
} from "./benchmark-api"
import {
  InvoiceDocumentPreviewDialog,
  OriginBadge,
  SourceEvidenceModal,
  VehicleCategoryBadge,
} from "./benchmark-evidence"
import { documentApiErrorMessage } from "./document-api"
import { SectionBreakdownDetail } from "./extracts-section"
import { Metric, ScreenHeading } from "./shared"

export type AnalysisSort = "document" | "level"

const LEVEL_LABELS: Record<ChallengeLevel, string> = {
  high: "High",
  medium: "Medium",
  low: "Low",
}

function LevelBadge({ level }: { level: ChallengeLevel | null }) {
  if (!level) return <span className="text-muted-foreground">—</span>
  if (level === "low")
    return (
      <Badge
        variant="outline"
        className="border-amber-400 text-amber-800 dark:text-amber-300"
      >
        Low
      </Badge>
    )
  return <Badge variant="destructive">{LEVEL_LABELS[level]}</Badge>
}

/** One benchmark's cell. Red when the line violates it, amber when the line
 * is above it but inside the rule, and "No data" -- never £0.00 -- when the
 * source holds nothing for this repair item in this category. `n` sits
 * beside every P90. Clickable to open a dedicated evidence pop-up window. */
function BenchmarkCell({
  benchmark,
  onClick,
}: {
  benchmark: AnalysisBenchmark
  onClick?: () => void
}) {
  const state = benchmarkCellState(benchmark)
  const isInteractive = state !== "no-data" && Boolean(onClick)
  return (
    <TableCell
      data-benchmark-state={state}
      onClick={isInteractive ? onClick : undefined}
      className={cn(
        "text-right tabular-nums",
        isInteractive && "cursor-pointer hover:bg-muted/50 hover:underline transition-colors",
        state === "violated" && "bg-destructive/10 font-medium text-destructive",
        state === "above" &&
          "bg-amber-50 text-amber-800 dark:bg-amber-950/30 dark:text-amber-300"
      )}
      title={isInteractive ? "Click to open historical benchmark evidence popup" : undefined}
    >
      {state === "no-data" ? (
        <span className="text-muted-foreground">No data</span>
      ) : (
        <>
          <span className="font-medium">{money(benchmark.p90)}</span>{" "}
          <span className="text-xs opacity-80">
            {observationsLabel(benchmark.observations)}
          </span>
          {toNumber(benchmark.difference_pct) != null &&
          (state === "violated" || state === "above") ? (
            <span className="block text-xs font-semibold">
              +{benchmark.difference_pct}% over
            </span>
          ) : null}
        </>
      )}
    </TableCell>
  )
}

function ChallengeAmountCell({
  line,
  approved,
}: {
  line: AnalysisLine
  approved?: { amount: string; note: string }
}) {
  if (isChallenge(line) || approved) {
    const effectiveAmount = approved?.amount ?? line.challenge.challenge_amount
    const invoicedAmt = toNumber(line.amount) ?? 0
    const reductionAmt = toNumber(effectiveAmount) ?? 0
    const justifiedAmt = Math.max(0, invoicedAmt - reductionAmt).toFixed(2)

    return (
      <TableCell className="text-right tabular-nums">
        <div className="flex flex-col items-end gap-0.5">
          <span className="font-semibold text-destructive">
            Save {money(effectiveAmount)}
          </span>
          <span className="text-xs text-muted-foreground">
            Justified {money(justifiedAmt)}
          </span>
        </div>
      </TableCell>
    )
  }
  if (line.challenge.level === "low") {
    const distance = lowLineDistance(line)
    return (
      <TableCell className="text-right text-xs text-amber-800 tabular-nums dark:text-amber-300">
        <span>{distance != null ? `${money(distance)} above P90` : "Above P90"} · not counted</span>
      </TableCell>
    )
  }
  return (
    <TableCell className="text-right text-muted-foreground">—</TableCell>
  )
}

/** Interactive dialog to preview, edit, and approve a benchmark challenge */
export function ChallengeApprovalDialog({
  line,
  open,
  onOpenChange,
  onApprove,
  existingApproval,
}: {
  line: AnalysisLine | null
  open: boolean
  onOpenChange: (open: boolean) => void
  onApprove: (lineId: string, amount: string, note: string, draftNow?: boolean) => void
  existingApproval?: { amount: string; note: string }
}) {
  if (!line) return null
  const defaultAmount =
    existingApproval?.amount ??
    (line.challenge.challenge_amount !== "0.00" ? line.challenge.challenge_amount : line.amount) ??
    ""
  const defaultNote = existingApproval?.note ?? ""
  const [challengeAmount, setChallengeAmount] = useState(defaultAmount)
  const [note, setNote] = useState(defaultNote)

  useEffect(() => {
    if (line) {
      setChallengeAmount(
        existingApproval?.amount ??
          (line.challenge.challenge_amount !== "0.00" ? line.challenge.challenge_amount : line.amount) ??
          ""
      )
      setNote(existingApproval?.note ?? "")
    }
  }, [line, existingApproval])

  const linePrice = parseFloat(line.amount || "0")
  const numChallenge = parseFloat(challengeAmount || "0")
  const netJustified = isNaN(linePrice) || isNaN(numChallenge) ? 0 : Math.max(0, linePrice - numChallenge)

  const handleSubmit = (draftNow = false) => {
    const parsed = parseFloat(challengeAmount)
    if (isNaN(parsed) || parsed <= 0) {
      toast.error("Please enter a valid challenge reduction amount greater than £0.00.")
      return
    }
    if (parsed > linePrice) {
      toast.error("Challenge reduction amount cannot exceed the total invoiced item price.")
      return
    }
    onApprove(line.line_id, parsed.toFixed(2), note.trim(), draftNow)
    toast.success(`Challenge approved for ${line.description}`, {
      description: `Reduction of ${money(parsed.toFixed(2))} confirmed (justified price ${money(netJustified.toFixed(2))}).`,
    })
    onOpenChange(false)
  }

  const handleResetToSystem = () => {
    setChallengeAmount(line.challenge.challenge_amount || "0.00")
    setNote("")
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90dvh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <DialogTitle>Preview & Approve Challenge</DialogTitle>
            <LevelBadge level={line.challenge.level} />
          </div>
          <DialogDescription>
            Review the benchmark evidence, adjust the challenge reduction amount if required, and approve the line for the dispute email.
          </DialogDescription>
        </DialogHeader>

        <div className="rounded-lg border bg-muted/30 p-3 space-y-2 text-sm">
          <div className="flex justify-between font-medium">
            <span>Item: {line.description}</span>
            <OriginBadge origin={line.origin} />
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground pt-1">
            <div>
              <span className="font-semibold text-foreground">Invoiced Item Price:</span>{" "}
              {money(line.amount)}
            </div>
            <div>
              <span className="font-semibold text-foreground">Benchmark Justified Price:</span>{" "}
              {money(line.challenge.justified_amount)}
            </div>
          </div>
          <div className="text-xs text-muted-foreground pt-1">
            <span className="font-semibold text-foreground">Benchmark Evidence & Rule:</span>
            <p className="mt-0.5">{line.challenge.reason}</p>
          </div>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault()
            handleSubmit(false)
          }}
          className="space-y-4 pt-2"
        >
          <div className="space-y-1.5">
            <div className="flex justify-between items-center text-sm font-medium">
              <label htmlFor="challenge-amount">Challenge Reduction Amount (£) *</label>
              {line.challenge.challenge_amount !== "0.00" ? (
                <button
                  type="button"
                  onClick={handleResetToSystem}
                  className="text-xs text-primary hover:underline"
                >
                  Reset to system ({money(line.challenge.challenge_amount)})
                </button>
              ) : null}
            </div>
            <Input
              id="challenge-amount"
              type="number"
              step="0.01"
              min="0.01"
              max={line.amount}
              value={challengeAmount}
              onChange={(e) => setChallengeAmount(e.target.value)}
              required
              className="text-base font-semibold"
            />
            <p className="text-xs text-muted-foreground">
              Adjusted proposed justified price:{" "}
              <span className="font-semibold text-foreground">{money(netJustified.toFixed(2))}</span>
            </p>
          </div>

          <div className="space-y-1.5">
            <label htmlFor="challenge-note" className="text-sm font-medium">
              Handler Dispute Rationale / Note (Optional)
            </label>
            <Textarea
              id="challenge-note"
              placeholder="e.g. Capped per insurer policy threshold; excess repair charges disallowed."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="h-20 resize-none text-xs"
            />
          </div>

          <div className="flex flex-wrap justify-end gap-2 pt-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button
              type="button"
              variant="secondary"
              onClick={() => handleSubmit(true)}
            >
              Approve & Draft Email
            </Button>
            <Button type="submit">
              Approve Challenge
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}


/** The analysis itself, rendered from a payload so it can be tested without
 * a network. The `initial*` props seed the local state for the same reason:
 * a server render has no pointer to click the sort, a checkbox or a toggle. */
export function BenchmarkAnalysisView({
  analysis,
  caseReference,
  onThresholdsChanged,
  onSelectInvoice,
  onDraftEmail,
  drafting,
  initialSort = "document",
  initialSelected = [],
}: {
  analysis: BenchmarkAnalysisPayload
  caseReference?: string
  onThresholdsChanged?: () => void
  onSelectInvoice: (invoiceId: string) => void
  onDraftEmail: (lineIds: string[], adjustments?: ChallengeLineAdjustmentInput[]) => void
  drafting: boolean
  initialSort?: AnalysisSort
  initialSelected?: string[]
  initialEvidenceOpen?: string[]
}) {
  const [sort, setSort] = useState<AnalysisSort>(initialSort)
  const [selected, setSelected] = useState<Set<string>>(
    () => new Set(initialSelected)
  )
  const [inspectingSource, setInspectingSource] = useState<{
    line: AnalysisLine
    source: BenchmarkSource
  } | null>(null)
  const [inspectingRow, setInspectingRow] = useState<BenchmarkEvidenceRow | null>(
    null
  )
  const [approvingLine, setApprovingLine] = useState<AnalysisLine | null>(null)
  const [approvedChallenges, setApprovedChallenges] = useState<
    Map<string, { amount: string; note: string }>
  >(new Map())

  const { invoice } = analysis
  const lines =
    sort === "level"
      ? sortByChallengeLevel(analysis.lines)
      : documentOrder(analysis.lines)
  const summary = challengeSummary(analysis.lines)
  const challengeLines = lines.filter((l) => isChallenge(l) || approvedChallenges.has(l.line_id))
  const selectedIds = lines
    .filter(
      (line) => selected.has(line.line_id) && (isChallenge(line) || approvedChallenges.has(line.line_id))
    )
    .map((line) => line.line_id)
  const selectedTotal = lines
    .filter((line) => selected.has(line.line_id) && (isChallenge(line) || approvedChallenges.has(line.line_id)))
    .reduce((total, line) => {
      const approved = approvedChallenges.get(line.line_id)
      const amt = approved ? toNumber(approved.amount) : toNumber(line.challenge.challenge_amount)
      return total + (amt ?? 0)
    }, 0)

  function handleApproveChallenge(
    lineId: string,
    amount: string,
    note: string,
    draftNow = false
  ) {
    const nextApproved = new Map(approvedChallenges)
    nextApproved.set(lineId, { amount, note })
    setApprovedChallenges(nextApproved)

    const nextSelected = new Set(selected)
    nextSelected.add(lineId)
    setSelected(nextSelected)

    if (draftNow) {
      const activeIds = Array.from(nextSelected)
      const adjustments: ChallengeLineAdjustmentInput[] = activeIds.map((id) => ({
        line_id: id,
        adjusted_challenge_amount: nextApproved.get(id)?.amount,
        note: nextApproved.get(id)?.note,
      }))
      onDraftEmail(activeIds, adjustments)
    }
  }

  const handleDraftClick = () => {
    const adjustments: ChallengeLineAdjustmentInput[] = selectedIds.map((id) => ({
      line_id: id,
      adjusted_challenge_amount: approvedChallenges.get(id)?.amount,
      note: approvedChallenges.get(id)?.note,
    }))
    onDraftEmail(selectedIds, adjustments)
  }

  const vehicle =
    [invoice.vehicle_make, invoice.vehicle_model].filter(Boolean).join(" ") ||
    "Not printed"

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <CardTitle>
                Invoice {invoice.invoice_number ?? "number not printed"}
              </CardTitle>
              <CardDescription>
                Every line of this invoice, then every line of its engineer
                assessment, benchmarked across all 4 reference sources.
              </CardDescription>
            </div>
            {analysis.live_invoices.length > 1 ? (
              <select
                className="h-9 min-w-56 rounded-md border bg-background px-3 text-sm"
                aria-label="New invoice to analyse"
                value={invoice.id}
                onChange={(event) => onSelectInvoice(event.target.value)}
              >
                {analysis.live_invoices.map((option) => (
                  <option key={option.id} value={option.id}>
                    {[option.invoice_number ?? "Number not printed", option.registration]
                      .filter(Boolean)
                      .join(" · ")}
                  </option>
                ))}
              </select>
            ) : null}
          </div>
        </CardHeader>
        <CardContent>
          <dl className="grid gap-4 text-sm sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <dt className="text-xs text-muted-foreground">Vehicle</dt>
              <dd className="font-medium">{vehicle}</dd>
              <dd className="text-muted-foreground">
                {invoice.registration ?? "Registration not printed"}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-muted-foreground">Vehicle category</dt>
              <dd className="mt-1">
                <VehicleCategoryBadge
                  category={invoice.vehicle_category}
                  source={invoice.vehicle_category_source}
                />
              </dd>
            </div>
            <div>
              <dt className="text-xs text-muted-foreground">
                Paired engineer assessment
              </dt>
              <dd className="font-medium">
                {invoice.paired_assessment_number ?? (
                  <span className="font-normal text-muted-foreground">
                    No engineer assessment paired
                  </span>
                )}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-muted-foreground">Valuation rule</dt>
              <dd className="text-muted-foreground">
                Challenge when over the 50/50 price by more than {analysis.threshold_pct}%
                and by at least {money(analysis.minimum_challenge_amount)}.
              </dd>
            </div>
          </dl>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Metric
            label="50/50 challenge price total"
            value={money(challengePriceTotal(analysis.lines))}
            hint="Sum of proposed prices for this invoice's High and Medium lines only; excludes unchanged lines."
          />
          <Metric
            label="Total challenge amount"
            value={money(summary.total)}
            hint="Reduction requested on High and Medium lines only. Low lines are shown, never counted."
            emphasis={summary.total > 0}
          />
          <div className="min-w-0 px-1 py-1">
            <p className="text-xs font-medium text-muted-foreground">
              Challenges by level
            </p>
            <p className="mt-2 flex flex-wrap items-center gap-2 text-sm">
              <Badge variant="destructive">{summary.counts.high} high</Badge>
              <Badge variant="destructive">{summary.counts.medium} medium</Badge>
              <Badge
                variant="outline"
                className="border-amber-400 text-amber-800 dark:text-amber-300"
              >
                {summary.counts.low} low
              </Badge>
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              High: multiple benchmarks violated. Medium: one. Low: within tolerance.
            </p>
          </div>
          <Metric
            label="Approved & queued for email"
            value={money(selectedTotal)}
            hint={`${selectedIds.length} of ${challengeLines.length} challenges selected`}
          />
        </CardContent>
      </Card>

      {/* 4th Benchmark Source: Insurer Strategy Thresholds (Positioned above table, collapsible) */}
      {caseReference ? (
        <StrategyThresholdManagerCard
          caseReference={caseReference}
          onThresholdsChanged={onThresholdsChanged}
        />
      ) : null}

      <Card>
        <CardHeader>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <CardTitle>Line items against benchmarks</CardTitle>
              <CardDescription>
                Click any benchmark figure or percentage to view contributing historical evidence in a pop-up window. Click Challenge to preview, edit, and approve dispute amounts.
              </CardDescription>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="inline-flex rounded-md border p-0.5" role="group" aria-label="Order">
                <Button
                  size="sm"
                  variant={sort === "document" ? "secondary" : "ghost"}
                  aria-pressed={sort === "document"}
                  onClick={() => setSort("document")}
                >
                  As on the documents
                </Button>
                <Button
                  size="sm"
                  variant={sort === "level" ? "secondary" : "ghost"}
                  aria-pressed={sort === "level"}
                  onClick={() => setSort("level")}
                >
                  By challenge level
                </Button>
              </div>
              <Button
                size="sm"
                variant="outline"
                disabled={!challengeLines.length}
                onClick={() => {
                  if (selectedIds.length === challengeLines.length) {
                    setSelected(new Set())
                  } else {
                    const next = new Set(challengeLines.map((line) => line.line_id))
                    setSelected(next)
                  }
                }}
              >
                {challengeLines.length &&
                selectedIds.length === challengeLines.length
                  ? "Clear selection"
                  : "Select all challenges"}
              </Button>
              <Button
                size="sm"
                disabled={!selectedIds.length || drafting}
                onClick={handleDraftClick}
              >
                {drafting ? "Drafting…" : `Draft email (${selectedIds.length})`}
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div data-testid="analysis-table" className="rounded-lg border overflow-x-auto">
            <Table className="min-w-[980px] table-fixed [&_th]:h-auto [&_th]:py-3 [&_th]:whitespace-normal">
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[24%]">Description</TableHead>
                  <TableHead className="w-[11%] text-right font-semibold text-foreground">
                    Item price
                  </TableHead>
                  <TableHead className="w-[12%] text-right">
                    Third-party P90 (n)
                  </TableHead>
                  <TableHead className="w-[12%] text-right">In-house P90 (n)</TableHead>
                  <TableHead className="w-[12%] text-right">Previous live P90 (n)</TableHead>
                  <TableHead className="w-[11%] text-right">Strategy threshold</TableHead>
                  <TableHead className="w-[9%] text-center">Challenge level</TableHead>
                  <TableHead className="w-[13%] text-right">Challenge amount</TableHead>
                  <TableHead className="w-[10%] text-center">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {lines.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={9} className="whitespace-normal py-8 text-center text-muted-foreground">
                      No item prices are available to compare. Review this invoice in Document intelligence.
                      If it contains section totals, pair its engineer assessment and check that detailed rows
                      were extracted and the section totals agree.
                    </TableCell>
                  </TableRow>
                )}
                {lines.map((line) => {
                  const isApproved = approvedChallenges.has(line.line_id)
                  const isChallenged = isChallenge(line) || isApproved

                  return (
                    <TableRow
                      key={line.line_id}
                      data-line-id={line.line_id}
                      data-level={line.challenge.level ?? "none"}
                      className={cn(
                        line.challenge.level === "low" &&
                          "bg-amber-50/60 dark:bg-amber-950/20",
                        isApproved && "bg-emerald-50/40 dark:bg-emerald-950/20"
                      )}
                    >
                      {/* 1. Description */}
                      <TableCell className="whitespace-normal [overflow-wrap:anywhere]">
                        <span className="font-medium">{line.description}</span>
                        <span className="mt-1 flex flex-wrap items-center gap-1.5">
                          <OriginBadge origin={line.origin} />
                          {line.repair_item ? (
                            <span className="text-xs text-muted-foreground">
                              {line.repair_item}
                            </span>
                          ) : null}
                        </span>
                      </TableCell>

                      {/* 2. New Invoice Item Price */}
                      <TableCell className="text-right tabular-nums font-semibold text-foreground">
                        {money(line.amount)}
                      </TableCell>

                      {/* 3. Third-party P90 */}
                      <BenchmarkCell
                        benchmark={line.benchmarks.third_party}
                        onClick={() =>
                          setInspectingSource({ line, source: "third_party" })
                        }
                      />

                      {/* 4. In-house P90 */}
                      <BenchmarkCell
                        benchmark={line.benchmarks.aviva_dlg}
                        onClick={() =>
                          setInspectingSource({ line, source: "aviva_dlg" })
                        }
                      />

                      {/* 5. Previous live P90 */}
                      <BenchmarkCell
                        benchmark={
                          line.benchmarks.new_invoices ?? {
                            available: false,
                            p90: null,
                            observations: 0,
                            above_p90: false,
                            violated: false,
                            difference: null,
                            difference_pct: null,
                            evidence: [],
                          }
                        }
                        onClick={() =>
                          setInspectingSource({ line, source: "new_invoices" })
                        }
                      />

                      {/* 6. Strategy Threshold */}
                      <BenchmarkCell
                        benchmark={
                          line.benchmarks.strategy_threshold ?? {
                            available: false,
                            p90: null,
                            observations: 0,
                            above_p90: false,
                            violated: false,
                            difference: null,
                            difference_pct: null,
                            evidence: [],
                          }
                        }
                        onClick={() =>
                          setInspectingSource({ line, source: "strategy_threshold" })
                        }
                      />

                      {/* 7. Challenge Level */}
                      <TableCell className="text-center">
                        <LevelBadge level={line.challenge.level} />
                      </TableCell>

                      {/* 8. Challenge Amount & Justified */}
                      <ChallengeAmountCell
                        line={line}
                        approved={approvedChallenges.get(line.line_id)}
                      />

                      {/* 9. Challenge Action */}
                      <TableCell className="text-center">
                        {isApproved ? (
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            className="h-7 px-2 text-xs border-emerald-500 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 dark:bg-emerald-950/40 dark:text-emerald-300 gap-1 font-medium"
                            onClick={() => setApprovingLine(line)}
                          >
                            <CheckCircle2Icon className="size-3.5 text-emerald-600" />
                            Approved
                          </Button>
                        ) : isChallenged ? (
                          <Button
                            type="button"
                            size="sm"
                            className="h-7 px-2.5 text-xs font-semibold bg-destructive hover:bg-destructive/90 text-white"
                            onClick={() => setApprovingLine(line)}
                          >
                            Challenge
                          </Button>
                        ) : line.challenge.level === "low" ? (
                          <Button
                            type="button"
                            size="sm"
                            variant="ghost"
                            className="h-7 px-2 text-xs text-muted-foreground hover:text-foreground"
                            onClick={() => setApprovingLine(line)}
                          >
                            Review
                          </Button>
                        ) : (
                          <span className="text-muted-foreground">—</span>
                        )}
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Rolled-up totals breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>How each rolled-up invoice total breaks down</CardTitle>
          <CardDescription>
            A total the invoice prints as one figure is never benchmarked. Its
            line items come from the paired engineer assessment, and only when
            the section total agrees with the engineer assessment&apos;s.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {analysis.section_breakdowns.length ? (
            analysis.section_breakdowns.map((breakdown) => (
              <div key={breakdown.invoice_line_item_id}>
                <p className="mt-2 text-sm font-medium">
                  {breakdown.description}
                </p>
                <SectionBreakdownDetail breakdown={breakdown} />
              </div>
            ))
          ) : (
            <p className="text-sm text-muted-foreground">
              This invoice prints no rolled-up totals: every invoice line above
              is itemised on the invoice itself.
            </p>
          )}
        </CardContent>
      </Card>

      {/* Pop-up dialog for specific benchmark source historical evidence */}
      <SourceEvidenceModal
        line={inspectingSource?.line ?? null}
        source={inspectingSource?.source ?? null}
        open={Boolean(inspectingSource)}
        onOpenChange={(open) => {
          if (!open) setInspectingSource(null)
        }}
        onShowInvoice={(row) => setInspectingRow(row)}
      />

      {/* Pop-up dialog for full historical invoice inspection */}
      <InvoiceDocumentPreviewDialog
        evidenceRow={inspectingRow}
        open={Boolean(inspectingRow)}
        onOpenChange={(open) => {
          if (!open) setInspectingRow(null)
        }}
        onSelectInvoice={onSelectInvoice}
      />

      {/* Pop-up dialog for previewing, editing, and approving a challenge */}
      <ChallengeApprovalDialog
        line={approvingLine}
        open={Boolean(approvingLine)}
        onOpenChange={(open) => {
          if (!open) setApprovingLine(null)
        }}
        onApprove={handleApproveChallenge}
        existingApproval={
          approvingLine ? approvedChallenges.get(approvingLine.line_id) : undefined
        }
      />
    </>
  )
}

/** Management card for the 4th benchmark source: Insurer Strategy Thresholds (collapsible at top) */
export function StrategyThresholdManagerCard({
  caseReference,
  onThresholdsChanged,
}: {
  caseReference: string
  onThresholdsChanged?: () => void
}) {
  const [thresholds, setThresholds] = useState<StrategyThresholdItem[]>([])
  const [loading, setLoading] = useState(true)
  const [open, setOpen] = useState(false)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [itemName, setItemName] = useState("")
  const [maxAmount, setMaxAmount] = useState("")
  const [description, setDescription] = useState("")

  const loadThresholds = () => {
    setLoading(true)
    fetchStrategyThresholds(caseReference)
      .then((res) => {
        setThresholds(res.thresholds || [])
      })
      .catch((err) => {
        toast.error("Failed to load insurer strategy thresholds", {
          description: documentApiErrorMessage(err),
        })
      })
      .finally(() => setLoading(false))
  }

  useEffect(() => {
    loadThresholds()
  }, [caseReference])

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!itemName.trim() || !maxAmount.trim()) {
      toast.error("Please enter both the item name and maximum amount.")
      return
    }
    const num = parseFloat(maxAmount)
    if (isNaN(num) || num < 0) {
      toast.error("Please enter a valid non-negative number for the amount.")
      return
    }
    setSaving(true)
    try {
      await createStrategyThreshold(caseReference, {
        item_name: itemName.trim(),
        max_amount_net: num.toFixed(2),
        description: description.trim(),
      })
      toast.success("Strategy threshold added successfully.")
      setItemName("")
      setMaxAmount("")
      setDescription("")
      setDialogOpen(false)
      loadThresholds()
      onThresholdsChanged?.()
    } catch (err) {
      toast.error("Failed to create strategy threshold", {
        description: documentApiErrorMessage(err),
      })
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (thresholdId: string, name: string) => {
    try {
      await deleteStrategyThreshold(caseReference, thresholdId)
      toast.success(`Removed threshold for ${name}`)
      loadThresholds()
      onThresholdsChanged?.()
    } catch (err) {
      toast.error("Failed to delete strategy threshold", {
        description: documentApiErrorMessage(err),
      })
    }
  }

  return (
    <Card className="border-primary/20 bg-muted/20">
      <CardHeader className="py-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <SlidersHorizontalIcon className="size-4 text-primary" />
            <CardTitle className="text-sm font-semibold">
              4th Benchmark Source: Insurer Strategy Thresholds
            </CardTitle>
            <Badge variant="secondary" className="text-xs">
              {thresholds.length} rule{thresholds.length === 1 ? "" : "s"} active
            </Badge>
          </div>
          <div className="flex items-center gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="h-8 text-xs gap-1"
              onClick={() => setOpen(!open)}
            >
              {open ? (
                <>
                  <ChevronUpIcon className="size-3.5" />
                  Hide rules
                </>
              ) : (
                <>
                  <ChevronDownIcon className="size-3.5" />
                  Show rules ({thresholds.length})
                </>
              )}
            </Button>
            <Button size="sm" className="h-8 text-xs" onClick={() => setDialogOpen(true)}>
              Add New Threshold
            </Button>
          </div>
        </div>
        {!open && thresholds.length > 0 ? (
          <div className="flex flex-wrap gap-1.5 pt-1 text-xs text-muted-foreground">
            {thresholds.slice(0, 5).map((t) => (
              <span
                key={t.id}
                className="inline-flex items-center gap-1 rounded bg-background px-2 py-0.5 border text-[11px]"
              >
                <span className="font-medium text-foreground">{t.item_name}:</span>
                <span className="text-primary font-semibold">max £{t.max_amount_net}</span>
              </span>
            ))}
            {thresholds.length > 5 ? (
              <span className="text-[11px] self-center">+{thresholds.length - 5} more</span>
            ) : null}
          </div>
        ) : null}
      </CardHeader>
      {open ? (
        <CardContent className="pt-0">
          {loading ? (
            <p className="text-xs text-muted-foreground py-2">Loading strategy thresholds…</p>
          ) : thresholds.length === 0 ? (
            <p className="text-xs text-muted-foreground py-2">No active strategy thresholds configured.</p>
          ) : (
            <div className="rounded-lg border bg-background overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-1/3">Repair Item / Charge Name</TableHead>
                    <TableHead className="text-right">Max Allowed (£)</TableHead>
                    <TableHead className="w-1/3">Policy Rule & Scope</TableHead>
                    <TableHead>Keywords Matched</TableHead>
                    <TableHead className="w-16 text-right">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {thresholds.map((t) => (
                    <TableRow key={t.id}>
                      <TableCell className="font-medium">{t.item_name}</TableCell>
                      <TableCell className="text-right font-semibold tabular-nums text-primary">
                        {money(t.max_amount_net)}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {t.description}
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {t.keywords?.slice(0, 4).map((kw) => (
                            <Badge key={kw} variant="secondary" className="text-[10px]">
                              {kw}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 text-xs text-destructive hover:text-destructive"
                          onClick={() => handleDelete(t.id, t.item_name)}
                          title="Delete this threshold"
                        >
                          Delete
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      ) : null}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Insurer Strategy Policy Threshold</DialogTitle>
            <DialogDescription>
              Set a maximum net amount cap (£) for specific invoice repair charges or fee items.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleCreate} className="flex flex-col gap-4 py-2">
            <label className="flex flex-col gap-1.5 text-sm font-medium">
              Item Name / Policy Target *
              <Input
                placeholder="e.g. Diagnostics Scan Fee"
                value={itemName}
                onChange={(e) => setItemName(e.target.value)}
                required
              />
            </label>
            <label className="flex flex-col gap-1.5 text-sm font-medium">
              Maximum Allowed Net Amount (£) *
              <Input
                type="number"
                step="0.01"
                min="0"
                placeholder="25.00"
                value={maxAmount}
                onChange={(e) => setMaxAmount(e.target.value)}
                required
              />
            </label>
            <label className="flex flex-col gap-1.5 text-sm font-medium">
              Policy Description / Rationale
              <Textarea
                placeholder="e.g. Insurer maximum cap of £25.00 for pre/post diagnostics scan."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="h-20 resize-none text-xs"
              />
            </label>
            <div className="flex justify-end gap-2 mt-2">
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={saving}>
                {saving ? "Saving…" : "Add Threshold"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </Card>
  )
}


/** The drafted email. It says it is a draft, and that nothing has been sent,
 * because nothing has: the server never sends it, and the only ways out of
 * here are the clipboard and the handler's own email app. */
export function ChallengeEmailDraftView({
  draft,
  onCopy,
}: {
  draft: ChallengeEmailDraft
  onCopy: (text: string) => void
}) {
  const text = `Subject: ${draft.subject}\n\n${draft.body}`
  return (
    <div className="flex flex-col gap-4">
      <Alert>
        <MailIcon />
        <AlertTitle>This is a draft. Nothing has been sent.</AlertTitle>
        <AlertDescription>
          ClaimGuard does not email anyone. Copy the draft, or open it in your
          email app, check it, and send it from there yourself.
        </AlertDescription>
      </Alert>
      <p className="text-xs text-muted-foreground">
        {generatedByLabel(draft.generated_by)} · total challenge amount in this
        draft {money(draft.total_challenge_amount)} across {draft.lines.length}{" "}
        {draft.lines.length === 1 ? "line" : "lines"}.
      </p>
      <label className="flex flex-col gap-1.5 text-sm font-medium">
        Subject
        <Input readOnly value={draft.subject} />
      </label>
      <label className="flex flex-col gap-1.5 text-sm font-medium">
        Body
        <Textarea readOnly value={draft.body} className="h-64 min-h-40 resize-y [field-sizing:fixed] font-mono text-xs" />
      </label>
      <div className="flex flex-wrap justify-end gap-2">
        <Button variant="outline" onClick={() => onCopy(text)}>
          Copy
        </Button>
        <Button asChild>
          <a href={mailtoHref(draft.subject, draft.body)}>Open in email app</a>
        </Button>
      </div>
    </div>
  )
}

/** Benchmark analysis: the new invoice against both benchmarks, the
 * challenges, and the draft email. */
export function BenchmarkAnalysisScreen({
  caseReference,
  onUploadNewInvoice,
}: {
  caseReference: string
  onUploadNewInvoice: () => void
}) {
  const [invoiceId, setInvoiceId] = useState<string | undefined>(undefined)
  const [analysis, setAnalysis] = useState<BenchmarkAnalysisPayload | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [drafting, setDrafting] = useState(false)
  const [draft, setDraft] = useState<ChallengeEmailDraft | null>(null)

  useEffect(() => {
    let active = true
    void fetchBenchmarkAnalysis(caseReference, invoiceId)
      .then((payload) => {
        if (!active) return
        setAnalysis(payload)
        setError(null)
      })
      .catch((e) => {
        if (!active) return
        setAnalysis(null)
        setError(documentApiErrorMessage(e))
      })
      .finally(() => {
        if (active) setLoading(false)
      })
    return () => {
      active = false
    }
  }, [caseReference, invoiceId])

  async function draftEmail(lineIds: string[], adjustments?: ChallengeLineAdjustmentInput[]) {
    if (!analysis || drafting) return
    setDrafting(true)
    try {
      setDraft(
        await draftChallengeEmail(caseReference, {
          invoiceId: analysis.invoice.id,
          lineIds,
          adjustments,
        })
      )
    } catch (e) {
      toast.error("The email could not be drafted", {
        description: documentApiErrorMessage(e),
      })
    } finally {
      setDrafting(false)
    }
  }

  function copy(text: string) {
    void navigator.clipboard
      .writeText(text)
      .then(() =>
        toast.success("Draft copied", {
          description: "Nothing has been sent.",
        })
      )
      .catch(() => toast.error("The draft could not be copied"))
  }

  return (
    <>
      <ScreenHeading
        title="Benchmark analysis"
        description="Every line item of the new invoice -- from the invoice first, then from its engineer assessment -- against the third-party and the In-house P90 for its vehicle category. Red where a benchmark is violated."
      />
      {error ? (
        <Alert variant="destructive">
          <AlertCircleIcon />
          <AlertTitle>The analysis could not be loaded</AlertTitle>
          <AlertDescription className="flex flex-col items-start gap-3">
            <span>
              {error} If no new invoice has been uploaded yet, upload one
              first.
            </span>
            <Button variant="outline" size="sm" onClick={onUploadNewInvoice}>
              Upload new invoice
            </Button>
          </AlertDescription>
        </Alert>
      ) : loading || !analysis ? (
        <p className="text-sm text-muted-foreground">Loading the analysis…</p>
      ) : (
        <BenchmarkAnalysisView
          key={analysis.invoice.id}
          analysis={analysis}
          caseReference={caseReference}
          onThresholdsChanged={() => {
            void fetchBenchmarkAnalysis(caseReference, invoiceId)
              .then((payload) => {
                setAnalysis(payload)
                setError(null)
              })
              .catch((e) => {
                setError(documentApiErrorMessage(e))
              })
          }}
          onSelectInvoice={(id) => {
            setLoading(true)
            setInvoiceId(id)
          }}
          onDraftEmail={(lineIds, adjustments) => void draftEmail(lineIds, adjustments)}
          drafting={drafting}
        />
      )}
      <Dialog
        open={draft != null}
        onOpenChange={(open) => {
          if (!open) setDraft(null)
        }}
      >
        <DialogContent className="max-h-[90dvh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>Challenge email draft</DialogTitle>
            <DialogDescription>
              For invoice {analysis?.invoice.invoice_number ?? ""}. Every £
              figure comes from the analysis.
            </DialogDescription>
          </DialogHeader>
          {draft ? <ChallengeEmailDraftView draft={draft} onCopy={copy} /> : null}
        </DialogContent>
      </Dialog>
    </>
  )
}
