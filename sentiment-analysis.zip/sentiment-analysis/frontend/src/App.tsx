import { useState, useEffect, useRef } from 'react';
import { 
  Upload, 
  FileSpreadsheet, 
  ArrowRight, 
  Download, 
  Search, 
  BrainCircuit, 
  Database,
  BarChart4,
  Info,
  Trash2,
  DatabaseZap
} from 'lucide-react';
import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import { AzureConfig } from './components/AzureConfig';
import { AgentConsole, type LogEntry } from './components/AgentConsole';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';

interface RowData {
  csat: number | string;
  comment: string;
  surveyName: string;
  originalRow: any;
  sentiment?: 'positive' | 'negative' | 'neutral';
  sentimentConfidence?: number;
  theme?: string;
  themeConfidence?: number;
}

export function App() {
  const [activeStep, setActiveStep] = useState<'upload' | 'sentiment' | 'theme'>('upload');

  // File Upload State
  const [fileData, setFileData] = useState<RowData[]>([]);
  const [fileName, setFileName] = useState<string>('');
  const [missingCommentsCount, setMissingCommentsCount] = useState<number>(0);
  const [missingCommentsPct, setMissingCommentsPct] = useState<number>(0);
  
  // Themes Mapping State
  const [themesMap, setThemesMap] = useState<Record<string, string[]>>({
    positive: ['Quick Resolution', 'Friendly Agent', 'Clear Explanation', 'Easy Claims Process', 'Good Coverage', 'Reasonable Pricing', 'Helpful Staff'],
    negative: ['Long Wait Time', 'Rude Agent', 'Confusing Plan Terms', 'Claim Denied', 'High Premiums', 'Poor Communication', 'Delayed Payout'],
    neutral: ['General Inquiry', 'Plan Details Request', 'Payment Status Check', 'Address Update', 'Unrelated Call', 'No Comment Provided', 'Other']
  });
  const [themesFileName, setThemesFileName] = useState<string>('Themes_mapping.csv (Default)');

  // Caching State from Backend
  const [cacheCounts, setCacheCounts] = useState<{ sentimentCount: number; themeCount: number }>({
    sentimentCount: 0,
    themeCount: 0
  });

  const refreshCacheCounts = async () => {
    try {
      const res = await fetch('http://localhost:8080/api/cache-stats');
      if (res.ok) {
        const data = await res.json();
        setCacheCounts({
          sentimentCount: data.sentiment_count || 0,
          themeCount: data.theme_count || 0
        });
      }
    } catch (e) {
      console.log('Failed to fetch cache counts from backend server.');
    }
  };

  // Check backend cache stats on mount
  useEffect(() => {
    refreshCacheCounts();
  }, []);

  const handleClearCache = async () => {
    if (confirm('Are you sure you want to delete all cached LLM responses in the backend database? This will force calls to the LLM for all comments.')) {
      try {
        const res = await fetch('http://localhost:8080/api/clear-cache', { method: 'POST' });
        if (res.ok) {
          refreshCacheCounts();
          alert('LLM Backend Cache database cleared successfully.');
        } else {
          throw new Error('Not Ok');
        }
      } catch (e) {
        alert('Failed to connect to backend server to clear cache.');
      }
    }
  };

  // Agent State (Sentiment)
  const [sentimentProgress, setSentimentProgress] = useState<number>(0);
  const [isSentimentRunning, setIsSentimentRunning] = useState<boolean>(false);
  const [sentimentLogs, setSentimentLogs] = useState<LogEntry[]>([]);
  
  // Agent State (Theme)
  const [themeProgress, setThemeProgress] = useState<number>(0);
  const [isThemeRunning, setIsThemeRunning] = useState<boolean>(false);
  const [themeLogs, setThemeLogs] = useState<LogEntry[]>([]);

  // Search & Pagination in tables
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  const isSentimentRunningRef = useRef(isSentimentRunning);
  const sentimentProgressRef = useRef(sentimentProgress);
  const isThemeRunningRef = useRef(isThemeRunning);
  const themeProgressRef = useRef(themeProgress);

  useEffect(() => { isSentimentRunningRef.current = isSentimentRunning; }, [isSentimentRunning]);
  useEffect(() => { sentimentProgressRef.current = sentimentProgress; }, [sentimentProgress]);
  useEffect(() => { isThemeRunningRef.current = isThemeRunning; }, [isThemeRunning]);
  useEffect(() => { themeProgressRef.current = themeProgress; }, [themeProgress]);

  // Pre-load default themes from public directory if available
  useEffect(() => {
    fetch('/Themes_mapping.csv')
      .then(res => {
        if (res.ok) return res.text();
        throw new Error('Default Themes not found');
      })
      .then(text => {
        const parsed = parseThemesCSV(text);
        setThemesMap(parsed);
        setThemesFileName('Themes_mapping.csv (Preloaded)');
      })
      .catch(err => {
        console.log('Using fallback default themes:', err.message);
      });
  }, []);

  const getTimestamp = () => {
    const now = new Date();
    return now.toTimeString().split(' ')[0];
  };

  const parseThemesCSV = (text: string): Record<string, string[]> => {
    const result: Record<string, string[]> = { positive: [], negative: [], neutral: [] };
    const parsed = Papa.parse(text, { header: true, skipEmptyLines: true });
    
    parsed.data.forEach((row: any) => {
      const sentiment = String(row.sentiment || '').trim().toLowerCase();
      const themeStr = String(row.theme || '').trim();
      
      if (sentiment && themeStr) {
        const rawThemes = themeStr.split(',');
        const themes = rawThemes.map(t => {
          let clean = t.trim();
          if (clean.startsWith("'") && clean.endsWith("'")) {
            clean = clean.substring(1, clean.length - 1);
          }
          return clean.trim();
        }).filter(Boolean);

        if (sentiment === 'positive' || sentiment === 'negative' || sentiment === 'neutral') {
          result[sentiment] = themes;
        }
      }
    });
    return result;
  };

  const handleThemesUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setThemesFileName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const parsed = parseThemesCSV(text);
      setThemesMap(parsed);
    };
    reader.readAsText(file);
  };

  const handleMainFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    
    const reader = new FileReader();
    if (file.name.endsWith('.csv')) {
      reader.onload = (event) => {
        const text = event.target?.result as string;
        Papa.parse(text, {
          header: true,
          dynamicTyping: true,
          skipEmptyLines: true,
          complete: (results) => {
            processRawData(results.data);
          }
        });
      };
      reader.readAsText(file);
    } else if (file.name.endsWith('.xlsx') || file.name.endsWith('.xls')) {
      reader.onload = (event) => {
        const data = new Uint8Array(event.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);
        processRawData(jsonData);
      };
      reader.readAsArrayBuffer(file);
    }
  };

  const processRawData = (rows: any[]) => {
    if (rows.length === 0) return;
    const firstRow = rows[0];
    const keys = Object.keys(firstRow);

    const csatKey = keys.find(k => k.toLowerCase() === 'csat');
    const commentKey = keys.find(k => k.toLowerCase() === 'comment');
    const surveyNameKey = keys.find(k => k.toLowerCase() === 'reporting survey-name' || k.toLowerCase() === 'reporting survey name');

    let missing = 0;
    const mapped: RowData[] = rows.map(row => {
      const comment = commentKey ? row[commentKey] : '';
      
      // Check blank or empty
      const cleanComment = comment ? String(comment).trim().toLowerCase() : '';
      const isEmpty = !cleanComment || cleanComment === 'na' || cleanComment === 'n/a' || cleanComment === 'nothing' || cleanComment === 'none' || cleanComment === 'nil';
      if (isEmpty) missing++;

      return {
        csat: csatKey ? row[csatKey] : '',
        comment: comment ? String(comment).trim() : '',
        surveyName: surveyNameKey ? String(row[surveyNameKey]).trim() : 'Auto Call Survey',
        originalRow: row
      };
    });

    setFileData(mapped);
    setMissingCommentsCount(missing);
    setMissingCommentsPct(mapped.length > 0 ? Math.round((missing / mapped.length) * 100) : 0);
    
    setSentimentProgress(0);
    setThemeProgress(0);
    setSentimentLogs([]);
    setThemeLogs([]);
    setIsSentimentRunning(false);
    setIsThemeRunning(false);
    setCurrentPage(1);
  };

  const startSentimentAnalysis = async () => {
    if (fileData.length === 0) return;
    setIsSentimentRunning(true);

    const logsBuffer = [...sentimentLogs];
    if (logsBuffer.length === 0) {
      logsBuffer.push({
        timestamp: getTimestamp(),
        type: 'info',
        message: 'Sentiment Analysis Agent initiated on FastAPI backend.'
      });
      setSentimentLogs([...logsBuffer]);
    }

    for (let i = sentimentProgressRef.current; i < fileData.length; i++) {
      if (!isSentimentRunningRef.current) break;

      const row = fileData[i];
      logsBuffer.push({
        timestamp: getTimestamp(),
        type: 'agent',
        message: `Analyzing Row ${i + 1}/${fileData.length} (CSAT: ${row.csat || 'N/A'})...`
      });
      setSentimentLogs([...logsBuffer]);

      let sentiment: 'positive' | 'negative' | 'neutral' = 'neutral';
      let confidence = 1.0;

      try {
        const res = await fetch('http://localhost:8080/api/analyze-sentiment', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            csat: row.csat,
            comment: row.comment,
            surveyName: row.surveyName
          })
        });

        if (!res.ok) {
          const errText = await res.text();
          throw new Error(`API Error: ${errText}`);
        }

        const data = await res.json();
        sentiment = data.sentiment;
        confidence = data.confidence;

        // Print source log details
        let sourceLog = 'Backend Rule';
        if (data.source === 'cache') sourceLog = 'Database Cache';
        else if (data.source === 'llm') sourceLog = 'Azure OpenAI API';
        else if (data.source === 'mock') sourceLog = 'Sandbox Simulator';

        logsBuffer.push({
          timestamp: getTimestamp(),
          type: 'success',
          message: `↳ [${sourceLog}] Classified: ${sentiment} (Conf: ${Math.round(confidence * 100)}%)`
        });
      } catch (err: any) {
        logsBuffer.push({
          timestamp: getTimestamp(),
          type: 'error',
          message: `↳ Connection Failure: ${err.message}. Please verify Flask is running on port 8080.`
        });
        setIsSentimentRunning(false);
        setSentimentLogs([...logsBuffer]);
        break;
      }

      setFileData(prev => {
        const copy = [...prev];
        copy[i] = {
          ...copy[i],
          sentiment,
          sentimentConfidence: parseFloat(confidence.toFixed(2))
        };
        return copy;
      });

      const nextProgress = i + 1;
      setSentimentProgress(nextProgress);
      
      if (nextProgress % 5 === 0 || nextProgress === fileData.length) {
        refreshCacheCounts();
      }

      // Small UI render delay
      await new Promise(resolve => setTimeout(resolve, 30));
    }

    setIsSentimentRunning(false);
    refreshCacheCounts();
  };

  const startThemeMapping = async () => {
    if (fileData.length === 0) return;
    setIsThemeRunning(true);

    const logsBuffer = [...themeLogs];
    if (logsBuffer.length === 0) {
      logsBuffer.push({
        timestamp: getTimestamp(),
        type: 'info',
        message: 'Theme Mapping Agent initiated on FastAPI backend.'
      });
      setThemeLogs([...logsBuffer]);
    }

    for (let i = themeProgressRef.current; i < fileData.length; i++) {
      if (!isThemeRunningRef.current) break;

      const row = fileData[i];
      const sentiment = row.sentiment || 'neutral';
      const allowedThemes = themesMap[sentiment] || ['Other'];

      logsBuffer.push({
        timestamp: getTimestamp(),
        type: 'agent',
        message: `Row ${i + 1}/${fileData.length} (Sentiment: ${sentiment}) - Mapping Theme...`
      });
      setThemeLogs([...logsBuffer]);

      let theme = 'Other';
      let confidence = 1.0;

      try {
        const res = await fetch('http://localhost:8080/api/map-theme', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            comment: row.comment,
            sentiment: sentiment,
            allowedThemes: allowedThemes
          })
        });

        if (!res.ok) {
          const errText = await res.text();
          throw new Error(`API Error: ${errText}`);
        }

        const data = await res.json();
        theme = data.theme;
        confidence = data.confidence;

        let sourceLog = 'Backend Rule';
        if (data.source === 'cache') sourceLog = 'Database Cache';
        else if (data.source === 'llm') sourceLog = 'Azure OpenAI API';
        else if (data.source === 'mock') sourceLog = 'Sandbox Simulator';

        logsBuffer.push({
          timestamp: getTimestamp(),
          type: 'success',
          message: `↳ [${sourceLog}] Theme Mapped: '${theme}' (Conf: ${Math.round(confidence * 100)}%)`
        });
      } catch (err: any) {
        logsBuffer.push({
          timestamp: getTimestamp(),
          type: 'error',
          message: `↳ Connection Failure: ${err.message}. Please verify Flask is running on port 8080.`
        });
        setIsThemeRunning(false);
        setThemeLogs([...logsBuffer]);
        break;
      }

      setFileData(prev => {
        const copy = [...prev];
        copy[i] = {
          ...copy[i],
          theme,
          themeConfidence: parseFloat(confidence.toFixed(2))
        };
        return copy;
      });

      const nextProgress = i + 1;
      setThemeProgress(nextProgress);

      if (nextProgress % 5 === 0 || nextProgress === fileData.length) {
        refreshCacheCounts();
      }

      await new Promise(resolve => setTimeout(resolve, 30));
    }

    setIsThemeRunning(false);
    refreshCacheCounts();
  };

  const handleExportSentimentData = () => {
    if (fileData.length === 0) return;
    
    const exportRows = fileData.map(r => {
      return {
        ...r.originalRow,
        csat_sentiment: r.sentiment || 'Pending',
        sentiment_confidence: r.sentimentConfidence !== undefined ? r.sentimentConfidence : '',
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(exportRows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Sentiment Analysis");

    const outputName = fileName ? `${fileName.split('.')[0]}_sentiment_analyzed.xlsx` : 'sentiment_results.xlsx';
    XLSX.writeFile(workbook, outputName);
  };

  const handleExportThemeData = () => {
    if (fileData.length === 0) return;
    
    const exportRows = fileData.map(r => {
      return {
        ...r.originalRow,
        csat_sentiment: r.sentiment || 'Pending',
        sentiment_confidence: r.sentimentConfidence !== undefined ? r.sentimentConfidence : '',
        csat_theme: r.theme || 'Pending',
        theme_confidence: r.themeConfidence !== undefined ? r.themeConfidence : '',
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(exportRows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Theme & Sentiment Analysis");

    const outputName = fileName ? `${fileName.split('.')[0]}_fully_enriched.xlsx` : 'fully_enriched_results.xlsx';
    XLSX.writeFile(workbook, outputName);
  };

  const filteredData = fileData.filter(d => {
    const term = searchQuery.toLowerCase();
    return (
      String(d.comment).toLowerCase().includes(term) ||
      String(d.csat).toLowerCase().includes(term) ||
      String(d.surveyName).toLowerCase().includes(term) ||
      (d.sentiment && d.sentiment.toLowerCase().includes(term)) ||
      (d.theme && d.theme.toLowerCase().includes(term))
    );
  });

  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  const paginatedData = filteredData.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const totalCacheItems = cacheCounts.sentimentCount + cacheCounts.themeCount;

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col font-sans">
      
      {/* Top Header Section */}
      <header className="h-16 shrink-0 border-b border-border bg-[#0E1118] px-8 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center border border-primary/40 shadow-md shadow-primary/10">
            <BrainCircuit className="w-4 h-4 text-primary" />
          </div>
          <div>
            <h1 className="text-sm font-extrabold tracking-tight">SentioAgent Auto</h1>
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">Insurance CSAT Analytics Console</p>
          </div>
        </div>

        <div className="flex items-center gap-3 text-xs">
          {totalCacheItems > 0 && (
            <div className="flex items-center gap-1.5 border border-primary/25 px-2.5 py-1.5 rounded-full bg-primary/10 text-primary-foreground font-semibold">
              <DatabaseZap className="w-3.5 h-3.5 text-primary" />
              <span>Cache: {totalCacheItems.toLocaleString()} LLM keys saved</span>
            </div>
          )}
          <div className="hidden sm:flex items-center gap-2 border border-border px-3 py-1.5 rounded-full bg-muted/30">
            <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />
            <span className="text-muted-foreground">Azure AI Integration Enabled</span>
          </div>
        </div>
      </header>

      {/* Main Workspace Scroll Area */}
      <main className="flex-1 overflow-y-auto p-6 md:p-8 max-w-7xl mx-auto w-full space-y-6">
        
        {/* Azure Config Settings Drawer */}
        <AzureConfig onRefreshStats={refreshCacheCounts} />

        {/* Cache status details */}
        <div className="flex flex-wrap items-center justify-between gap-4 p-4 border border-border bg-card/20 rounded-xl">
          <div className="flex items-center gap-2.5">
            <DatabaseZap className="w-4 h-4 text-primary" />
            <div>
              <p className="text-xs font-bold text-foreground">SQLite Database Caching Status</p>
              <p className="text-[10px] text-muted-foreground">
                Persistent backend server cache has {cacheCounts.sentimentCount} sentiments and {cacheCounts.themeCount} themes saved. Repeated files run instantly.
              </p>
            </div>
          </div>
          {totalCacheItems > 0 && (
            <button
              onClick={handleClearCache}
              className="flex items-center gap-1.5 bg-rose-500/10 hover:bg-rose-500/25 border border-rose-500/20 text-rose-400 text-[10px] font-bold px-3 py-1.5 rounded-md transition-colors"
            >
              <Trash2 className="w-3 h-3" /> Clear Backend Cache Database
            </button>
          )}
        </div>

        {/* Steps navigation bar */}
        <div className="grid grid-cols-3 gap-1 p-1 bg-muted/60 border border-border rounded-xl">
          <button
            onClick={() => setActiveStep('upload')}
            className={`flex items-center justify-center gap-2 py-3.5 text-xs font-bold rounded-lg transition-all ${activeStep === 'upload' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>1. File Profiler & Upload</span>
          </button>
          
          <button
            onClick={() => setActiveStep('sentiment')}
            disabled={fileData.length === 0}
            className={`flex items-center justify-center gap-2 py-3.5 text-xs font-bold rounded-lg transition-all disabled:opacity-40 disabled:cursor-not-allowed ${activeStep === 'sentiment' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}
          >
            <BrainCircuit className="w-3.5 h-3.5" />
            <span>2. Sentiment Extraction</span>
          </button>

          <button
            onClick={() => setActiveStep('theme')}
            disabled={fileData.length === 0 || sentimentProgress < fileData.length}
            className={`flex items-center justify-center gap-2 py-3.5 text-xs font-bold rounded-lg transition-all disabled:opacity-40 disabled:cursor-not-allowed ${activeStep === 'theme' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}
          >
            <BarChart4 className="w-3.5 h-3.5" />
            <span>3. Theme Intelligence</span>
          </button>
        </div>

        {/* STEP 1: FILE PROFILER & UPLOAD */}
        {activeStep === 'upload' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Upload Area Controls */}
            <div className="lg:col-span-2 space-y-6">
              <div className="border border-dashed border-border bg-card/15 hover:bg-card/25 rounded-2xl p-8 transition-colors flex flex-col items-center justify-center text-center space-y-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                  <Upload className="w-6 h-6 animate-bounce" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-foreground">Upload Auto-Insurance Review Data</h3>
                  <p className="text-xs text-muted-foreground max-w-sm mt-1">
                    Drag and drop your Excel (`.xlsx`) or CSV (`.csv`) file here. The file must contain the columns: `csat` and `comment`.
                  </p>
                </div>
                <div className="relative">
                  <input
                    type="file"
                    accept=".csv, .xlsx, .xls"
                    onChange={handleMainFileUpload}
                    className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                  />
                  <button className="bg-primary hover:bg-primary/90 text-primary-foreground text-xs font-bold px-5 py-2.5 rounded-lg shadow-md shadow-primary/10 transition-colors">
                    Select Customer File
                  </button>
                </div>
                {fileName && (
                  <div className="flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded-full text-xs text-emerald-400 font-semibold">
                    <FileSpreadsheet className="w-3.5 h-3.5" />
                    <span>Loaded: {fileName}</span>
                  </div>
                )}
              </div>

              {fileData.length > 0 && (
                <div className="border border-border bg-card/30 backdrop-blur-xl rounded-2xl p-6 space-y-6">
                  <div className="flex justify-between items-center border-b border-border pb-4">
                    <div>
                      <h4 className="text-sm font-bold text-foreground">File Profile Metadata</h4>
                      <p className="text-xs text-muted-foreground mt-0.5">Statistical scan of import contents</p>
                    </div>
                    <span className="text-[10px] bg-primary/10 border border-primary/20 text-primary px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider">Auto Insurance Domain</span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div className="bg-muted/40 border border-border p-3.5 rounded-xl text-center">
                      <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Total Rows</p>
                      <p className="text-xl font-black text-foreground mt-1">{fileData.length}</p>
                    </div>
                    <div className="bg-muted/40 border border-border p-3.5 rounded-xl text-center">
                      <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Total Columns</p>
                      <p className="text-xl font-black text-foreground mt-1">
                        {fileData[0]?.originalRow ? Object.keys(fileData[0].originalRow).length : 0}
                      </p>
                    </div>
                    <div className="bg-muted/40 border border-border p-3.5 rounded-xl text-center">
                      <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Missing Comments</p>
                      <p className="text-xl font-black text-amber-500 mt-1">{missingCommentsCount}</p>
                    </div>
                    <div className="bg-muted/40 border border-border p-3.5 rounded-xl text-center">
                      <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Missing Ratio</p>
                      <p className="text-xl font-black text-amber-500 mt-1">{missingCommentsPct}%</p>
                    </div>
                  </div>

                  <div className="flex gap-3 bg-indigo-500/10 border border-indigo-500/20 p-4 rounded-xl text-xs text-indigo-400">
                    <Info className="w-5 h-5 shrink-0 mt-0.5" />
                    <div className="space-y-1">
                      <p className="font-bold text-foreground">Programmatic Rules Optimization</p>
                      <p className="text-[11px] leading-relaxed text-muted-foreground">
                        To minimize API costs, comments that are blank, <span className="font-mono text-indigo-300">"na"</span>, or <span className="font-mono text-indigo-300">"nothing"</span> will automatically bypass LLM queries. They are immediately classified as <span className="font-semibold text-foreground">neutral</span> with 100% confidence.
                      </p>
                    </div>
                  </div>

                  <div className="flex justify-end pt-2">
                    <button 
                      onClick={() => setActiveStep('sentiment')}
                      className="flex items-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground text-xs font-bold px-5 py-3 rounded-lg shadow-md shadow-primary/10 transition-all"
                    >
                      Proceed to Sentiment Agent <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Themes Mapping Settings Panel */}
            <div className="space-y-6">
              <div className="border border-border bg-card/30 backdrop-blur-xl rounded-2xl p-6 space-y-6">
                <div>
                  <h4 className="text-sm font-bold text-foreground">Themes Taxonomy Mappings</h4>
                  <p className="text-xs text-muted-foreground mt-0.5">Used for Stage 3 categorization</p>
                </div>

                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-semibold text-emerald-400 flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" /> Positive Themes
                      </span>
                      <span className="text-muted-foreground text-[10px]">{themesMap.positive.length} mapped</span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {themesMap.positive.map(t => (
                        <span key={t} className="text-[10px] bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-md font-medium">
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-semibold text-rose-400 flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-rose-400" /> Negative Themes
                      </span>
                      <span className="text-muted-foreground text-[10px]">{themesMap.negative.length} mapped</span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {themesMap.negative.map(t => (
                        <span key={t} className="text-[10px] bg-rose-500/10 border border-rose-500/20 text-rose-400 px-2 py-0.5 rounded-md font-medium">
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-semibold text-slate-400 flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-slate-400" /> Neutral Themes
                      </span>
                      <span className="text-muted-foreground text-[10px]">{themesMap.neutral.length} mapped</span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {themesMap.neutral.map(t => (
                        <span key={t} className="text-[10px] bg-slate-500/10 border border-slate-500/20 text-slate-400 px-2 py-0.5 rounded-md font-medium">
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="border-t border-border pt-4 space-y-3">
                  <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Upload Custom Taxonomy</p>
                  <div className="flex items-center justify-between gap-2 border border-border bg-muted/40 rounded-lg p-2.5">
                    <span className="text-[11px] text-foreground truncate max-w-[150px] font-medium">{themesFileName}</span>
                    <div className="relative">
                      <input
                        type="file"
                        accept=".csv"
                        onChange={handleThemesUpload}
                        className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                      />
                      <button className="text-[10px] bg-primary/10 border border-primary/20 text-primary font-bold px-3 py-1.5 rounded hover:bg-primary/20 transition-colors">
                        Upload CSV
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        )}

        {/* STEP 2: SENTIMENT ANALYSIS CONSOLE */}
        {activeStep === 'sentiment' && (
          <div className="space-y-6">
            <AgentConsole
              isRunning={isSentimentRunning}
              progress={fileData.length > 0 ? (sentimentProgress / fileData.length) * 100 : 0}
              currentIndex={sentimentProgress}
              totalItems={fileData.length}
              logs={sentimentLogs}
              onStart={startSentimentAnalysis}
              onPause={() => setIsSentimentRunning(false)}
              title="Agent: Sentiment Classification Pipeline"
              modelName="FastAPI Azure Agent"
              isMockMode={false} // Managed backend-side
            />

            {sentimentProgress > 0 && (
              <div className="border border-border bg-card/30 backdrop-blur-xl rounded-2xl p-6 space-y-6">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                  <div>
                    <h3 className="text-sm font-bold text-foreground">CSAT & Sentiment Analytics Dashboard</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">Real-time analytical graphs updated by Agent outputs</p>
                  </div>
                  
                  {sentimentProgress >= fileData.length && (
                    <button
                      onClick={handleExportSentimentData}
                      className="flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold px-4 py-2 rounded-lg transition-all shadow-md shadow-emerald-500/20 shrink-0 self-start sm:self-auto"
                    >
                      <Download className="w-3.5 h-3.5" /> Download Sentiment Output (Excel)
                    </button>
                  )}
                </div>
                <AnalyticsDashboard data={fileData} type="sentiment" />
              </div>
            )}

            {fileData.length > 0 && (
              <div className="border border-border bg-card/30 backdrop-blur-xl rounded-2xl p-6 space-y-4">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                  <div>
                    <h3 className="text-sm font-bold text-foreground">Data Preview Table</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">Detailed records containing customer survey feedback</p>
                  </div>
                  
                  <div className="relative w-full sm:w-72">
                    <Search className="w-4 h-4 text-muted-foreground absolute left-3 top-2.5" />
                    <input
                      type="text"
                      placeholder="Search comments or values..."
                      value={searchQuery}
                      onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
                      className="w-full text-xs bg-background border border-border rounded-lg pl-9 pr-4 py-2 text-foreground focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary"
                    />
                  </div>
                </div>

                <div className="overflow-x-auto rounded-lg border border-border">
                  <table className="w-full text-xs text-left border-collapse">
                    <thead>
                      <tr className="bg-muted/60 text-muted-foreground border-b border-border font-semibold">
                        <th className="px-4 py-3">CSAT</th>
                        <th className="px-4 py-3">Reporting Survey Name</th>
                        <th className="px-4 py-3">Customer Call Comment</th>
                        <th className="px-4 py-3 text-center">Assigned Sentiment</th>
                        <th className="px-4 py-3 text-right">Confidence</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border/60">
                      {paginatedData.map((row, idx) => {
                        const score = row.sentiment;
                        const badgeColor = score === 'positive' 
                          ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' 
                          : score === 'negative'
                          ? 'text-rose-400 bg-rose-500/10 border-rose-500/20'
                          : score === 'neutral'
                          ? 'text-slate-400 bg-slate-500/10 border-slate-500/20'
                          : 'text-muted-foreground/60 bg-muted/20';

                        return (
                          <tr key={idx} className="hover:bg-white/5 transition-colors">
                            <td className="px-4 py-3.5 font-bold font-mono text-primary text-center w-16">{row.csat ?? 'N/A'}</td>
                            <td className="px-4 py-3.5 max-w-[150px] truncate text-muted-foreground">{row.surveyName}</td>
                            <td className="px-4 py-3.5 max-w-sm xl:max-w-md truncate font-medium text-foreground">{row.comment || <span className="text-muted-foreground/40 italic">No comment provided</span>}</td>
                            <td className="px-4 py-3.5 text-center w-36">
                              <span className={`px-2.5 py-0.5 rounded-full border text-[10px] font-semibold uppercase tracking-wider ${badgeColor}`}>
                                {row.sentiment || 'Waiting'}
                              </span>
                            </td>
                            <td className="px-4 py-3.5 text-right font-mono font-semibold w-20">
                              {row.sentimentConfidence !== undefined ? `${Math.round(row.sentimentConfidence * 100)}%` : '—'}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                {totalPages > 1 && (
                  <div className="flex justify-between items-center text-xs text-muted-foreground border-t border-border pt-4">
                    <span>Showing Page {currentPage} of {totalPages} ({filteredData.length} records)</span>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                        disabled={currentPage === 1}
                        className="px-3 py-1.5 rounded border border-border hover:bg-muted disabled:opacity-40 disabled:hover:bg-transparent transition-colors font-semibold"
                      >
                        Prev
                      </button>
                      <button
                        onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                        disabled={currentPage === totalPages}
                        className="px-3 py-1.5 rounded border border-border hover:bg-muted disabled:opacity-40 disabled:hover:bg-transparent transition-colors font-semibold"
                      >
                        Next
                      </button>
                    </div>
                  </div>
                )}

                {sentimentProgress >= fileData.length && (
                  <div className="flex justify-end pt-4 border-t border-border">
                    <button 
                      onClick={() => setActiveStep('theme')}
                      className="flex items-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground text-xs font-bold px-5 py-3 rounded-lg shadow-md shadow-primary/10 transition-all"
                    >
                      Proceed to Theme Mapping Agent <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* STEP 3: THEME INTELLIGENCE */}
        {activeStep === 'theme' && (
          <div className="space-y-6">
            <AgentConsole
              isRunning={isThemeRunning}
              progress={fileData.length > 0 ? (themeProgress / fileData.length) * 100 : 0}
              currentIndex={themeProgress}
              totalItems={fileData.length}
              logs={themeLogs}
              onStart={startThemeMapping}
              onPause={() => setIsThemeRunning(false)}
              title="Agent: Operational Theme Taxonomy Mapping"
              modelName="FastAPI Azure Agent"
              isMockMode={false} // Managed backend-side
            />

            {themeProgress > 0 && (
              <div className="border border-border bg-card/30 backdrop-blur-xl rounded-2xl p-6 space-y-6">
                <div>
                  <h3 className="text-sm font-bold text-foreground">Operational Theme Analysis</h3>
                  <p className="text-xs text-muted-foreground mt-0.5">Actionable insights driven by automated semantic topic classification</p>
                </div>
                <AnalyticsDashboard data={fileData} type="theme" />
              </div>
            )}

            {fileData.length > 0 && (
              <div className="border border-border bg-card/30 backdrop-blur-xl rounded-2xl p-6 space-y-4">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                  <div>
                    <h3 className="text-sm font-bold text-foreground">Enriched Datatable</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">Analyzed records featuring full Sentiment & Theme categorizations</p>
                  </div>
                  
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                    <div className="relative w-full sm:w-60">
                      <Search className="w-4 h-4 text-muted-foreground absolute left-3 top-2.5" />
                      <input
                        type="text"
                        placeholder="Search themes/sentiments..."
                        value={searchQuery}
                        onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
                        className="w-full text-xs bg-background border border-border rounded-lg pl-9 pr-4 py-2 text-foreground focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary"
                      />
                    </div>

                    {themeProgress >= fileData.length && (
                      <button
                        onClick={handleExportThemeData}
                        className="flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold px-4 py-2 rounded-lg transition-all shadow-md shadow-emerald-500/20"
                      >
                        <Download className="w-3.5 h-3.5" /> Download Enriched Output (Excel)
                      </button>
                    )}
                  </div>
                </div>

                <div className="overflow-x-auto rounded-lg border border-border">
                  <table className="w-full text-xs text-left border-collapse">
                    <thead>
                      <tr className="bg-muted/60 text-muted-foreground border-b border-border font-semibold">
                        <th className="px-4 py-3">CSAT</th>
                        <th className="px-4 py-3">Feedback Comment</th>
                        <th className="px-4 py-3 text-center">Sentiment</th>
                        <th className="px-4 py-3 text-center">Mapped Topic / Theme</th>
                        <th className="px-4 py-3 text-right">Theme Conf</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border/60">
                      {paginatedData.map((row, idx) => {
                        const score = row.sentiment;
                        const badgeColor = score === 'positive' 
                          ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' 
                          : score === 'negative'
                          ? 'text-rose-400 bg-rose-500/10 border-rose-500/20'
                          : score === 'neutral'
                          ? 'text-slate-400 bg-slate-500/10 border-slate-500/20'
                          : 'text-muted-foreground/60 bg-muted/20';

                        return (
                          <tr key={idx} className="hover:bg-white/5 transition-colors">
                            <td className="px-4 py-3.5 font-bold font-mono text-primary text-center w-16">{row.csat ?? 'N/A'}</td>
                            <td className="px-4 py-3.5 max-w-sm xl:max-w-md truncate font-medium text-foreground">{row.comment || <span className="text-muted-foreground/40 italic">No comment provided</span>}</td>
                            <td className="px-4 py-3.5 text-center w-28">
                              <span className={`px-2 py-0.5 rounded-full border text-[9px] font-semibold uppercase tracking-wider ${badgeColor}`}>
                                {row.sentiment || 'Waiting'}
                              </span>
                            </td>
                            <td className="px-4 py-3.5 text-center w-48 font-semibold text-foreground">
                              {row.theme ? (
                                <span className="bg-primary/10 border border-primary/20 text-primary px-2.5 py-0.5 rounded-md">
                                  {row.theme}
                                </span>
                              ) : (
                                <span className="text-muted-foreground/45 italic">Pending stage 3</span>
                              )}
                            </td>
                            <td className="px-4 py-3.5 text-right font-mono font-semibold w-20">
                              {row.themeConfidence !== undefined ? `${Math.round(row.themeConfidence * 100)}%` : '—'}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                {totalPages > 1 && (
                  <div className="flex justify-between items-center text-xs text-muted-foreground border-t border-border pt-4">
                    <span>Showing Page {currentPage} of {totalPages} ({filteredData.length} records)</span>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                        disabled={currentPage === 1}
                        className="px-3 py-1.5 rounded border border-border hover:bg-muted disabled:opacity-40 disabled:hover:bg-transparent transition-colors font-semibold"
                      >
                        Prev
                      </button>
                      <button
                        onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                        disabled={currentPage === totalPages}
                        className="px-3 py-1.5 rounded border border-border hover:bg-muted disabled:opacity-40 disabled:hover:bg-transparent transition-colors font-semibold"
                      >
                        Next
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

      </main>
    </div>
  );
}

export default App;
