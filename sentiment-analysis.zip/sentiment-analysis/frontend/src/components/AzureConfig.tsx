import { useState, useEffect } from 'react';
import { Settings, ShieldAlert, Sparkles, HelpCircle, Activity, Key } from 'lucide-react';

export interface BackendStatus {
  status: 'connected' | 'offline';
  mode: 'azure' | 'sandbox';
  deployment: string;
}

interface AzureConfigProps {
  onRefreshStats: () => void;
}

export function AzureConfig({ onRefreshStats }: AzureConfigProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [backendStatus, setBackendStatus] = useState<BackendStatus>({
    status: 'offline',
    mode: 'sandbox',
    deployment: 'Mock Simulator'
  });
  const [isChecking, setIsChecking] = useState(false);

  const checkBackendStatus = async () => {
    setIsChecking(true);
    try {
      const res = await fetch('http://localhost:8080/api/status');
      if (res.ok) {
        const data = await res.json();
        setBackendStatus({
          status: 'connected',
          mode: data.mode,
          deployment: data.deployment
        });
        onRefreshStats();
      } else {
        throw new Error('Not Ok');
      }
    } catch (e) {
      setBackendStatus({
        status: 'offline',
        mode: 'sandbox',
        deployment: 'Mock Simulator'
      });
    } finally {
      setIsChecking(false);
    }
  };

  // Check on mount
  useEffect(() => {
    checkBackendStatus();
    // Periodically check status
    const interval = setInterval(checkBackendStatus, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="border border-border bg-card/60 backdrop-blur-xl rounded-xl overflow-hidden shadow-xl transition-all duration-300">
      {/* Header */}
      <div 
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center justify-between px-6 py-4 cursor-pointer hover:bg-accent/30 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
            <Settings className="w-4 h-4 text-primary" />
          </div>
          <div>
            <h3 className="text-sm font-semibold tracking-tight">Backend Server Status</h3>
            <p className="text-xs text-muted-foreground">
              {backendStatus.status === 'connected'
                ? `Connected to local Flask server · Mode: ${backendStatus.mode === 'azure' ? 'Azure OpenAI (' + backendStatus.deployment + ')' : 'Sandbox Simulator'}`
                : 'Offline · Local Flask server not detected on port 8080'}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {backendStatus.status === 'connected' ? (
            <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/25 px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider flex items-center gap-1">
              <Activity className="w-2.5 h-2.5 animate-pulse" /> Online
            </span>
          ) : (
            <span className="text-[10px] bg-rose-500/10 text-rose-400 border border-rose-500/25 px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider flex items-center gap-1">
              Offline
            </span>
          )}
          <button className="text-xs text-muted-foreground hover:text-foreground font-semibold">
            {isOpen ? 'Collapse' : 'Expand Details'}
          </button>
        </div>
      </div>

      {/* Form Content */}
      {isOpen && (
        <div className="px-6 pb-6 pt-2 border-t border-border bg-muted/20 space-y-4 animate-in fade-in slide-in-from-top-1 duration-150">
          <div className="flex items-start gap-3 p-3 bg-primary/5 border border-primary/15 rounded-lg text-xs text-muted-foreground">
            <HelpCircle className="w-4 h-4 text-primary shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-foreground">Secure Architecture:</span> The React frontend no longer stores or exposes API credentials. All file parsing, programmatic rule filters, and Azure OpenAI requests are managed on the **Flask Backend**.
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-secondary/30 rounded-xl border border-border space-y-2">
              <h4 className="text-xs font-bold text-foreground flex items-center gap-1.5">
                <Key className="w-3.5 h-3.5 text-primary" /> Credentials Configuration
              </h4>
              <p className="text-[11px] text-muted-foreground leading-relaxed">
                To link your Azure OpenAI account, open and edit the configuration file:
              </p>
              <div className="p-2 bg-[#0B0D13] font-mono text-[10px] text-sky-400 rounded border border-border select-all">
                d:\Komal\sentiment-analysis\backend\.env
              </div>
              <p className="text-[10px] text-muted-foreground italic">
                Set <code className="text-foreground">AZURE_OPENAI_KEY</code> and <code className="text-foreground">AZURE_OPENAI_ENDPOINT</code>. Restart the Flask server after changing the file.
              </p>
            </div>

            <div className="p-4 bg-secondary/30 rounded-xl border border-border space-y-2.5 flex flex-col justify-between">
              <div>
                <h4 className="text-xs font-bold text-foreground flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Active Service Mode
                </h4>
                <p className="text-[11px] text-muted-foreground leading-relaxed mt-1">
                  {backendStatus.mode === 'azure'
                    ? 'Azure OpenAI deployment active. Your customer call comments are sent securely to the Azure cloud endpoint.'
                    : 'Mock Sandbox Mode is active because no Azure credentials were found in the backend configuration.'}
                </p>
              </div>
              
              <div className="flex gap-2">
                <button
                  onClick={checkBackendStatus}
                  disabled={isChecking}
                  className="text-xs bg-primary/10 border border-primary/20 hover:bg-primary/20 text-primary font-bold px-3 py-1.5 rounded transition-colors disabled:opacity-50"
                >
                  {isChecking ? 'Checking...' : 'Check Connection'}
                </button>
              </div>
            </div>
          </div>

          {backendStatus.status === 'offline' && (
            <div className="flex gap-2 items-center p-3 bg-rose-500/10 border border-rose-500/20 rounded-lg text-xs text-rose-400">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span>
                <strong>Warning:</strong> Backend is offline. Please make sure to run your Python server using:
                <code className="ml-1 bg-black px-1.5 py-0.5 rounded font-mono text-white text-[10px]">python main.py</code>
              </span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
