import { useEffect, useRef } from 'react';
import { Terminal, Play, Pause, Loader2, Coins, ShieldCheck } from 'lucide-react';

export interface LogEntry {
  timestamp: string;
  type: 'info' | 'success' | 'warning' | 'error' | 'agent';
  message: string;
}

interface AgentConsoleProps {
  isRunning: boolean;
  progress: number; // 0 to 100
  currentIndex: number;
  totalItems: number;
  logs: LogEntry[];
  onStart: () => void;
  onPause: () => void;
  title: string;
  modelName: string;
  isMockMode: boolean;
}

export function AgentConsole({
  isRunning,
  progress,
  currentIndex,
  totalItems,
  logs,
  onStart,
  onPause,
  title,
  modelName,
  isMockMode,
}: AgentConsoleProps) {
  const terminalRef = useRef<HTMLDivElement>(null);

  // Auto-scroll terminal to bottom when logs update
  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [logs]);

  // Compute stats
  const completed = currentIndex;
  const percentage = Math.round(progress);
  
  // Simple estimation of tokens and cost
  const estimatedInputTokens = completed * 150;
  const estimatedOutputTokens = completed * 40;
  const totalEstimatedTokens = estimatedInputTokens + estimatedOutputTokens;
  const estimatedCost = isMockMode 
    ? 0.00 
    : ((estimatedInputTokens * 0.15) / 1_000_000) + ((estimatedOutputTokens * 0.60) / 1_000_000);

  return (
    <div className="border border-border bg-card/40 backdrop-blur-xl rounded-xl p-6 shadow-xl space-y-6">
      {/* Console Header */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 border-b border-border pb-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center animate-pulse">
            <Terminal className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <h3 className="text-base font-bold text-foreground flex items-center gap-2">
              {title}
            </h3>
            <p className="text-xs text-muted-foreground">
              Agent Instance running on <span className="font-semibold text-primary">{isMockMode ? 'Sandbox Simulator' : modelName}</span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {isRunning ? (
            <button
              onClick={onPause}
              className="flex items-center gap-2 bg-amber-500/10 hover:bg-amber-500/25 border border-amber-500/30 text-amber-400 text-xs font-semibold px-4 py-2 rounded-lg transition-all"
            >
              <Pause className="w-3.5 h-3.5" /> Pause Analysis
            </button>
          ) : (
            <button
              onClick={onStart}
              disabled={completed >= totalItems && totalItems > 0}
              className="flex items-center gap-2 bg-primary hover:bg-primary/95 border border-primary/20 text-primary-foreground text-xs font-semibold px-4 py-2 rounded-lg transition-all shadow-md shadow-primary/20 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {completed >= totalItems && totalItems > 0 ? (
                <>Analysis Completed</>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" /> {completed > 0 ? 'Resume Agent' : 'Start Agent'}
                </>
              )}
            </button>
          )}
        </div>
      </div>

      {/* Progress & Speed Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-muted/30 border border-border p-3.5 rounded-lg">
          <p className="text-[10px] text-muted-foreground uppercase font-semibold tracking-wider">Analysis Progress</p>
          <div className="flex items-baseline gap-1.5 mt-1">
            <span className="text-xl font-bold tracking-tight text-foreground">{completed}</span>
            <span className="text-xs text-muted-foreground">/ {totalItems} rows</span>
          </div>
          <p className="text-[10px] text-muted-foreground mt-0.5">{percentage}% completed</p>
        </div>

        <div className="bg-muted/30 border border-border p-3.5 rounded-lg">
          <p className="text-[10px] text-muted-foreground uppercase font-semibold tracking-wider">Current Status</p>
          <div className="flex items-center gap-2 mt-1">
            {isRunning ? (
              <>
                <Loader2 className="w-4 h-4 text-primary animate-spin" />
                <span className="text-sm font-bold text-foreground">Processing</span>
              </>
            ) : completed >= totalItems && totalItems > 0 ? (
              <>
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span className="text-sm font-bold text-emerald-400">Idle (Done)</span>
              </>
            ) : (
              <>
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                <span className="text-sm font-bold text-foreground">Paused</span>
              </>
            )}
          </div>
          <p className="text-[10px] text-muted-foreground mt-0.5">Sequential (1-by-1) mode</p>
        </div>

        <div className="bg-muted/30 border border-border p-3.5 rounded-lg">
          <p className="text-[10px] text-muted-foreground uppercase font-semibold tracking-wider">Estimated Tokens</p>
          <div className="flex items-baseline gap-1.5 mt-1">
            <span className="text-xl font-bold tracking-tight text-foreground">
              {totalEstimatedTokens.toLocaleString()}
            </span>
          </div>
          <p className="text-[10px] text-muted-foreground mt-0.5">
            {estimatedInputTokens.toLocaleString()} in / {estimatedOutputTokens.toLocaleString()} out
          </p>
        </div>

        <div className="bg-muted/30 border border-border p-3.5 rounded-lg">
          <p className="text-[10px] text-muted-foreground uppercase font-semibold tracking-wider">Accumulated Cost</p>
          <div className="flex items-center gap-1.5 mt-1 text-emerald-400">
            <Coins className="w-4 h-4 text-emerald-500" />
            <span className="text-xl font-bold tracking-tight">
              ${estimatedCost.toFixed(4)}
            </span>
          </div>
          <p className="text-[10px] text-muted-foreground mt-0.5">
            {isMockMode ? 'Sandbox mode (free)' : 'Azure estimated rate'}
          </p>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="space-y-1.5">
        <div className="flex justify-between text-xs text-muted-foreground font-semibold">
          <span>Overall Execution Speed</span>
          <span>{percentage}%</span>
        </div>
        <div className="w-full h-2 bg-muted rounded-full overflow-hidden border border-border">
          <div 
            className="h-full bg-gradient-to-r from-primary to-indigo-400 rounded-full transition-all duration-300"
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>

      {/* Live Terminal Log */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs font-semibold text-muted-foreground px-1">
          <span className="flex items-center gap-1.5"><Terminal className="w-3.5 h-3.5 text-emerald-400" /> Agent Terminal Output</span>
          <span>Buffer: {logs.length} events</span>
        </div>
        <div 
          ref={terminalRef}
          className="h-60 rounded-lg border border-border bg-[#0B0D13] p-4 font-mono text-[11px] leading-relaxed overflow-y-auto space-y-1.5 shadow-inner"
        >
          {logs.length === 0 ? (
            <div className="h-full flex items-center justify-center text-muted-foreground/60 select-none">
              <span>Waiting for analysis triggers... Press Start to initiate Agent logic.</span>
            </div>
          ) : (
            logs.map((log, idx) => {
              let color = 'text-muted-foreground';
              if (log.type === 'success') color = 'text-emerald-400';
              if (log.type === 'error') color = 'text-rose-400';
              if (log.type === 'warning') color = 'text-amber-400';
              if (log.type === 'agent') color = 'text-sky-400 font-medium';

              return (
                <div key={idx} className={`flex items-start gap-2 ${color} hover:bg-white/5 px-1 py-0.5 rounded transition-colors`}>
                  <span className="text-muted-foreground/45 shrink-0 select-none font-sans">[{log.timestamp}]</span>
                  <span className="whitespace-pre-wrap">{log.message}</span>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
