import { BarChart, Percent, MessageSquare, TrendingUp, AlertTriangle } from 'lucide-react';

interface SentimentData {
  csat: number | string;
  comment: string;
  surveyName: string;
  sentiment?: 'positive' | 'negative' | 'neutral';
  sentimentConfidence?: number;
  theme?: string;
  themeConfidence?: number;
}

interface AnalyticsDashboardProps {
  data: SentimentData[];
  type: 'sentiment' | 'theme';
}

export function AnalyticsDashboard({ data, type }: AnalyticsDashboardProps) {
  const analyzedData = data.filter(d => type === 'sentiment' ? d.sentiment : d.theme);
  const total = analyzedData.length;

  if (total === 0) {
    return (
      <div className="flex flex-col items-center justify-center p-12 border border-dashed border-border rounded-xl bg-card/25 text-muted-foreground">
        <AlertTriangle className="w-8 h-8 text-amber-500 mb-3 animate-bounce" />
        <p className="text-sm font-semibold">No analyzed data found.</p>
        <p className="text-xs text-muted-foreground/80 mt-1">Start the AI Agent to run calculations and generate analytics.</p>
      </div>
    );
  }

  // --- Sentiment Calculations ---
  const positiveRows = analyzedData.filter(d => d.sentiment === 'positive');
  const negativeRows = analyzedData.filter(d => d.sentiment === 'negative');
  const neutralRows = analyzedData.filter(d => d.sentiment === 'neutral');

  const positivePct = Math.round((positiveRows.length / total) * 100);
  const negativePct = Math.round((negativeRows.length / total) * 100);
  const neutralPct = Math.round((neutralRows.length / total) * 100);

  // Average CSAT
  const getAverageCsat = (rows: SentimentData[]) => {
    if (rows.length === 0) return 0;
    const sum = rows.reduce((acc, row) => acc + (Number(row.csat) || 0), 0);
    return Math.round((sum / rows.length) * 10) / 10;
  };

  const avgCsatPositive = getAverageCsat(positiveRows);
  const avgCsatNegative = getAverageCsat(negativeRows);
  const avgCsatNeutral = getAverageCsat(neutralRows);
  const avgCsatTotal = getAverageCsat(analyzedData);

  // Average Confidence (Accuracy)
  const getAverageConfidence = (field: 'sentimentConfidence' | 'themeConfidence') => {
    const validRows = analyzedData.filter(d => d[field] !== undefined);
    if (validRows.length === 0) return 0;
    const sum = validRows.reduce((acc, row) => acc + (row[field] || 0), 0);
    return Math.round((sum / validRows.length) * 100);
  };

  const avgSentimentAccuracy = getAverageConfidence('sentimentConfidence');
  const avgThemeAccuracy = getAverageConfidence('themeConfidence');

  // Alignment Score
  const getAlignmentScore = () => {
    let aligned = 0;
    let applicable = 0;
    analyzedData.forEach(d => {
      const csat = Number(d.csat);
      if (isNaN(csat)) return;
      if (d.sentiment === 'positive' && csat >= 6) {
        aligned++;
      } else if (d.sentiment === 'negative' && csat <= 4) {
        aligned++;
      } else if (d.sentiment === 'neutral' && csat > 4 && csat < 6) {
        aligned++;
      }
      applicable++;
    });
    return applicable > 0 ? Math.round((aligned / applicable) * 100) : 100;
  };

  // --- Theme Calculations ---
  const themeCounts: { [theme: string]: { count: number; sumCsat: number; confidenceSum: number } } = {};
  analyzedData.forEach(d => {
    if (d.theme) {
      if (!themeCounts[d.theme]) {
        themeCounts[d.theme] = { count: 0, sumCsat: 0, confidenceSum: 0 };
      }
      themeCounts[d.theme].count++;
      themeCounts[d.theme].sumCsat += Number(d.csat) || 0;
      themeCounts[d.theme].confidenceSum += d.themeConfidence || 0;
    }
  });

  const themeList = Object.entries(themeCounts)
    .map(([theme, stats]) => ({
      theme,
      count: stats.count,
      avgCsat: Math.round((stats.sumCsat / stats.count) * 10) / 10,
      avgConfidence: Math.round((stats.confidenceSum / stats.count) * 100),
      percentage: Math.round((stats.count / total) * 100),
    }))
    .sort((a, b) => b.count - a.count);

  return (
    <div className="space-y-6">
      {/* Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {type === 'sentiment' ? (
          <>
            <div className="bg-card/30 border border-border p-4 rounded-xl">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Sentiment Accuracy</p>
                  <p className="text-2xl font-black text-foreground mt-1">{avgSentimentAccuracy}%</p>
                </div>
                <div className="w-8 h-8 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                  <Percent className="w-4 h-4" />
                </div>
              </div>
              <p className="text-[10px] text-muted-foreground mt-1.5">Average model confidence score</p>
            </div>

            <div className="bg-card/30 border border-border p-4 rounded-xl">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">CSAT-Sentiment Alignment</p>
                  <p className="text-2xl font-black text-emerald-400 mt-1">{getAlignmentScore()}%</p>
                </div>
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                  <TrendingUp className="w-4 h-4" />
                </div>
              </div>
              <p className="text-[10px] text-muted-foreground mt-1.5">Matches with customer CSAT ratings</p>
            </div>

            <div className="bg-card/30 border border-border p-4 rounded-xl">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Average Call CSAT</p>
                  <p className="text-2xl font-black text-foreground mt-1">{avgCsatTotal}</p>
                </div>
                <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
                  <MessageSquare className="w-4 h-4" />
                </div>
              </div>
              <p className="text-[10px] text-muted-foreground mt-1.5">Scale of 1 to 10 points</p>
            </div>

            <div className="bg-card/30 border border-border p-4 rounded-xl">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Predominant Class</p>
                  <p className="text-2xl font-black text-rose-400 mt-1">
                    {negativeRows.length > positiveRows.length && negativeRows.length > neutralRows.length
                      ? 'Negative'
                      : positiveRows.length > neutralRows.length
                      ? 'Positive'
                      : 'Neutral'}
                  </p>
                </div>
                <div className="w-8 h-8 rounded-lg bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400">
                  <BarChart className="w-4 h-4" />
                </div>
              </div>
              <p className="text-[10px] text-muted-foreground mt-1.5">Most frequent category</p>
            </div>
          </>
        ) : (
          <>
            <div className="bg-card/30 border border-border p-4 rounded-xl">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Theme Mapping Accuracy</p>
                  <p className="text-2xl font-black text-foreground mt-1">{avgThemeAccuracy}%</p>
                </div>
                <div className="w-8 h-8 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                  <Percent className="w-4 h-4" />
                </div>
              </div>
              <p className="text-[10px] text-muted-foreground mt-1.5">Average theme match confidence</p>
            </div>

            <div className="bg-card/30 border border-border p-4 rounded-xl">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Assigned Topics</p>
                  <p className="text-2xl font-black text-emerald-400 mt-1">{themeList.length}</p>
                </div>
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                  <MessageSquare className="w-4 h-4" />
                </div>
              </div>
              <p className="text-[10px] text-muted-foreground mt-1.5">Unique categories mapped</p>
            </div>

            <div className="bg-card/30 border border-border p-4 rounded-xl">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Primary Driver</p>
                  <p className="text-lg font-black text-foreground mt-1.5 truncate max-w-[150px]">
                    {themeList[0]?.theme || 'None'}
                  </p>
                </div>
                <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
                  <BarChart className="w-4 h-4" />
                </div>
              </div>
              <p className="text-[10px] text-muted-foreground mt-1">Responsible for {themeList[0]?.percentage || 0}% of complaints</p>
            </div>

            <div className="bg-card/30 border border-border p-4 rounded-xl">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Lowest CSAT Theme</p>
                  <p className="text-lg font-black text-rose-400 mt-1.5 truncate max-w-[150px]">
                    {[...themeList].sort((a,b) => a.avgCsat - b.avgCsat)[0]?.theme || 'None'}
                  </p>
                </div>
                <div className="w-8 h-8 rounded-lg bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400">
                  <AlertTriangle className="w-4 h-4" />
                </div>
              </div>
              <p className="text-[10px] text-muted-foreground mt-1">High friction operational area</p>
            </div>
          </>
        )}
      </div>

      {/* Charts Grid */}
      {type === 'sentiment' ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Sentiment Distribution SVG Chart */}
          <div className="bg-card/25 border border-border p-6 rounded-xl space-y-4">
            <h4 className="text-sm font-bold text-foreground">Sentiment Distribution</h4>
            <div className="relative h-60 flex items-center justify-center">
              <svg viewBox="0 0 400 220" className="w-full h-full">
                <rect x="50" y={200 - (positivePct * 1.5)} width="60" height={positivePct * 1.5} rx="6" fill="url(#positiveGrad)" />
                <text x="80" y={190 - (positivePct * 1.5)} textAnchor="middle" fill="#10B981" className="font-mono text-xs font-bold">{positivePct}%</text>
                <text x="80" y="215" textAnchor="middle" fill="oklch(0.60 0.01 260)" className="text-[10px] font-semibold uppercase">Positive</text>

                <rect x="170" y={200 - (neutralPct * 1.5)} width="60" height={neutralPct * 1.5} rx="6" fill="url(#neutralGrad)" />
                <text x="200" y={190 - (neutralPct * 1.5)} textAnchor="middle" fill="#94A3B8" className="font-mono text-xs font-bold">{neutralPct}%</text>
                <text x="200" y="215" textAnchor="middle" fill="oklch(0.60 0.01 260)" className="text-[10px] font-semibold uppercase">Neutral</text>

                <rect x="290" y={200 - (negativePct * 1.5)} width="60" height={negativePct * 1.5} rx="6" fill="url(#negativeGrad)" />
                <text x="320" y={190 - (negativePct * 1.5)} textAnchor="middle" fill="#F43F5E" className="font-mono text-xs font-bold">{negativePct}%</text>
                <text x="320" y="215" textAnchor="middle" fill="oklch(0.60 0.01 260)" className="text-[10px] font-semibold uppercase">Negative</text>

                <line x1="20" y1="200" x2="380" y2="200" stroke="oklch(0.22 0.012 260)" strokeWidth="2" />

                <defs>
                  <linearGradient id="positiveGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#10B981" />
                    <stop offset="100%" stopColor="#059669" stopOpacity="0.4" />
                  </linearGradient>
                  <linearGradient id="neutralGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#94A3B8" />
                    <stop offset="100%" stopColor="#64748B" stopOpacity="0.4" />
                  </linearGradient>
                  <linearGradient id="negativeGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#F43F5E" />
                    <stop offset="100%" stopColor="#E11D48" stopOpacity="0.4" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
            <p className="text-[11px] text-muted-foreground text-center">
              Positive: {positiveRows.length} calls · Neutral: {neutralRows.length} calls · Negative: {negativeRows.length} calls
            </p>
          </div>

          {/* Average CSAT by Sentiment */}
          <div className="bg-card/25 border border-border p-6 rounded-xl space-y-4">
            <h4 className="text-sm font-bold text-foreground">Average CSAT rating by Sentiment</h4>
            <div className="relative h-60 flex items-center justify-center">
              <svg viewBox="0 0 400 220" className="w-full h-full">
                <line x1="40" y1="30" x2="380" y2="30" stroke="oklch(0.22 0.012 260)" strokeDasharray="3 3" />
                <text x="35" y="34" textAnchor="end" fill="oklch(0.60 0.01 260)" className="font-mono text-[9px]">10</text>

                <line x1="40" y1="115" x2="380" y2="115" stroke="oklch(0.22 0.012 260)" strokeDasharray="3 3" />
                <text x="35" y="119" textAnchor="end" fill="oklch(0.60 0.01 260)" className="font-mono text-[9px]">5</text>

                <rect x="70" y={200 - (avgCsatPositive * 17)} width="50" height={avgCsatPositive * 17} rx="4" fill="#10B981" fillOpacity="0.85" />
                <text x="95" y={190 - (avgCsatPositive * 17)} textAnchor="middle" fill="#10B981" className="font-mono text-xs font-bold">{avgCsatPositive}</text>
                <text x="95" y="215" textAnchor="middle" fill="oklch(0.60 0.01 260)" className="text-[10px] font-semibold">Positive</text>

                <rect x="180" y={200 - (avgCsatNeutral * 17)} width="50" height={avgCsatNeutral * 17} rx="4" fill="#94A3B8" fillOpacity="0.85" />
                <text x="205" y={190 - (avgCsatNeutral * 17)} textAnchor="middle" fill="#94A3B8" className="font-mono text-xs font-bold">{avgCsatNeutral}</text>
                <text x="205" y="215" textAnchor="middle" fill="oklch(0.60 0.01 260)" className="text-[10px] font-semibold">Neutral</text>

                <rect x="290" y={200 - (avgCsatNegative * 17)} width="50" height={avgCsatNegative * 17} rx="4" fill="#F43F5E" fillOpacity="0.85" />
                <text x="315" y={190 - (avgCsatNegative * 17)} textAnchor="middle" fill="#F43F5E" className="font-mono text-xs font-bold">{avgCsatNegative}</text>
                <text x="315" y="215" textAnchor="middle" fill="oklch(0.60 0.01 260)" className="text-[10px] font-semibold">Negative</text>

                <line x1="40" y1="200" x2="380" y2="200" stroke="oklch(0.22 0.012 260)" strokeWidth="2" />
              </svg>
            </div>
            <p className="text-[11px] text-muted-foreground text-center">
              Positive: {avgCsatPositive}/10 · Neutral: {avgCsatNeutral}/10 · Negative: {avgCsatNegative}/10 average score
            </p>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Top Themes Distribution */}
          <div className="bg-card/25 border border-border p-6 rounded-xl space-y-4">
            <h4 className="text-sm font-bold text-foreground">Dominant Customer Feedback Themes</h4>
            <div className="space-y-3.5">
              {themeList.slice(0, 5).map((themeItem, index) => (
                <div key={themeItem.theme} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-medium text-foreground truncate max-w-[250px]">
                      {index + 1}. {themeItem.theme}
                    </span>
                    <span className="text-muted-foreground font-mono font-semibold">{themeItem.count} calls ({themeItem.percentage}%)</span>
                  </div>
                  <div className="w-full h-2 bg-muted rounded-full overflow-hidden border border-border">
                    <div 
                      className={`h-full rounded-full ${index === 0 ? 'bg-primary' : 'bg-primary/70'}`}
                      style={{ width: `${themeItem.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
              {themeList.length > 5 && (
                <p className="text-[11px] text-muted-foreground italic text-right">+ {themeList.length - 5} other themes mapping</p>
              )}
            </div>
          </div>

          {/* Average CSAT by Theme */}
          <div className="bg-card/25 border border-border p-6 rounded-xl space-y-4">
            <h4 className="text-sm font-bold text-foreground">Average CSAT rating by Theme</h4>
            <div className="space-y-3">
              {themeList.slice(0, 5).map((themeItem) => {
                const csatColor = themeItem.avgCsat >= 7 
                  ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' 
                  : themeItem.avgCsat <= 4 
                  ? 'text-rose-400 bg-rose-500/10 border-rose-500/20' 
                  : 'text-amber-400 bg-amber-500/10 border-amber-500/20';

                return (
                  <div key={themeItem.theme} className="flex justify-between items-center p-2 rounded-lg bg-muted/40 border border-border">
                    <span className="text-xs font-semibold text-foreground truncate max-w-[200px]">{themeItem.theme}</span>
                    <div className="flex items-center gap-3">
                      <span className="text-[10px] text-muted-foreground font-semibold">Conf: {themeItem.avgConfidence}%</span>
                      <span className={`text-xs px-2.5 py-0.5 font-bold border rounded-md ${csatColor}`}>
                        CSAT: {themeItem.avgCsat}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
