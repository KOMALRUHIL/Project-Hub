import os
import sqlite3
import time
import httpx
from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv

# Load env variables from .env file
load_dotenv()

app = Flask(__name__)
# Enable CORS for all routes so frontend on port 5173 can call these APIs
CORS(app)

DB_PATH = "cache.db"

def is_configured() -> bool:
    api_key = os.getenv("AZURE_OPENAI_KEY")
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    if not api_key or not endpoint:
        return False
    # Check if they are default template placeholders
    if "your_azure_openai_key" in api_key.lower() or "your-resource-name" in endpoint.lower():
        return False
    return True

# Initialize local sqlite cache database
def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sentiment_cache (
        comment TEXT PRIMARY KEY,
        sentiment TEXT,
        confidence REAL
    )
    """)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS theme_cache (
        key TEXT PRIMARY KEY,
        theme TEXT,
        confidence REAL
    )
    """)
    conn.commit()
    conn.close()

init_db()

# Mock sentiment classifier helper for Sandbox mode
def get_mock_sentiment(comment: str, csat: int | str) -> tuple[str, float]:
    import random
    clean = comment.lower()
    
    # Keyword plan rules
    if "plan" in clean or "policy detail" in clean or "insurance plan" in clean:
        return "neutral", 0.95
        
    # Out of scope rules
    if not any(x in clean for x in ["claim", "insurance", "agent", "rep", "service", "call"]):
        return "neutral", 0.90
        
    # Key sentiments
    if any(x in clean for x in ["rude", "wait", "denied", "slow", "bad", "worst", "terrible"]):
        return "negative", round(0.85 + random.random() * 0.15, 2)
    elif any(x in clean for x in ["friendly", "quick", "help", "great", "easy", "good", "excellent"]):
        return "positive", round(0.85 + random.random() * 0.15, 2)
        
    # fallback to CSAT value
    try:
        csat_val = int(csat)
        if csat_val >= 7:
            return "positive", round(0.80 + random.random() * 0.18, 2)
        elif csat_val <= 4:
            return "negative", round(0.80 + random.random() * 0.18, 2)
    except ValueError:
        pass
        
    return "neutral", round(0.70 + random.random() * 0.20, 2)

# Mock theme categorizer helper for Sandbox mode
def get_mock_theme(comment: str, sentiment: str, allowed: list[str]) -> tuple[str, float]:
    import random
    if not allowed:
        return "Other", 1.0
        
    clean = comment.lower()
    theme = allowed[0]
    
    if sentiment == "positive":
        if any(x in clean for x in ["rep", "agent", "person", "officer", "staff"]):
            theme = next((t for t in allowed if "Agent" in t or "Representative" in t or "Staff" in t), allowed[0])
        elif any(x in clean for x in ["quick", "fast", "speed", "time"]):
            theme = next((t for t in allowed if "Resolution" in t or "Time" in t or "Claims Process" in t), allowed[0])
        elif any(x in clean for x in ["explain", "clear", "understand"]):
            theme = next((t for t in allowed if "Explanation" in t or "Clear" in t), allowed[0])
        elif any(x in clean for x in ["price", "rate", "premium", "cost"]):
            theme = next((t for t in allowed if "Pricing" in t or "Reasonable" in t), allowed[0])
    elif sentiment == "negative":
        if any(x in clean for x in ["hold", "wait", "hour", "time"]):
            theme = next((t for t in allowed if "Wait" in t or "Hold" in t), allowed[0])
        elif any(x in clean for x in ["rude", "attitude", "unhelpful"]):
            theme = next((t for t in allowed if "Rude" in t or "Agent" in t), allowed[0])
        elif any(x in clean for x in ["deny", "denied", "reject"]):
            theme = next((t for t in allowed if "Denied" in t or "Claim" in t), allowed[0])
        elif any(x in clean for x in ["price", "premium", "expensive", "high"]):
            theme = next((t for t in allowed if "Premiums" in t or "Cost" in t), allowed[0])
    else:
        # neutral
        if "plan" in clean or "policy" in clean:
            theme = next((t for t in allowed if "Plan" in t or "Details" in t), allowed[0])
        elif any(x in clean for x in ["pay", "bill", "invoice"]):
            theme = next((t for t in allowed if "Payment" in t or "Check" in t), allowed[0])
        else:
            theme = next((t for t in allowed if "General" in t or "Inquiry" in t), allowed[0])
            
    if theme == allowed[0] and allowed:
        theme = allowed[random.randint(0, len(allowed) - 1)]
        
    return theme, round(0.80 + random.random() * 0.20, 2)

@app.route("/api/analyze-sentiment", methods=["POST"])
def analyze_sentiment():
    req = request.json
    csat = req.get("csat", "")
    comment = req.get("comment", "")
    surveyName = req.get("surveyName", "Auto Call Survey")
    
    comment_clean = comment.strip().lower()
    
    # Rule 1: Programmatic bypass for empty reviews
    if not comment_clean or comment_clean in ["na", "n/a", "nothing", "none", "nil"]:
        return jsonify({"sentiment": "neutral", "confidence": 1.0, "source": "rule"})
        
    # Rule 2: Check Cache
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT sentiment, confidence FROM sentiment_cache WHERE comment = ?", (comment_clean,))
    row = cursor.fetchone()
    conn.close()
    
    if row:
        return jsonify({"sentiment": row[0], "confidence": row[1], "source": "cache"})
        
    # Check if Azure OpenAI API is configured
    api_key = os.getenv("AZURE_OPENAI_KEY")
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o-mini")
    api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")
    
    if not is_configured():
        # Run Mock Sandbox Mode if env config is missing or unconfigured
        time.sleep(0.18)
        sentiment, confidence = get_mock_sentiment(comment_clean, csat)
        return jsonify({"sentiment": sentiment, "confidence": confidence, "source": "mock"})
        
    # Call Azure OpenAI API
    try:
        system_prompt = (
            "You are a customer service analyst for an auto insurance firm. Classify the customer feedback comment as exactly 'positive', 'negative', or 'neutral'.\n"
            "Rules:\n"
            "- If the comment discusses the insurance plan structure/details or pricing structure, classify as 'neutral'.\n"
            "- If the call comment is not related to auto insurance claims, policy terms, representatives, or claims department, classify as 'neutral'.\n"
            "Your output must be raw JSON: {\"sentiment\": \"positive\"|\"negative\"|\"neutral\", \"confidence\": float}"
        )
        user_prompt = f"CSAT: {csat}\nSurvey: {surveyName}\nComment: \"{comment}\""
        
        headers = {
            "Content-Type": "application/json",
            "api-key": api_key
        }
        
        payload = {
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            "max_tokens": 50,
            "temperature": 0.0,
            "response_format": {"type": "json_object"}
        }
        
        url = f"{endpoint.rstrip('/')}/openai/deployments/{deployment}/chat/completions?api-version={api_version}"
        
        with httpx.Client() as client:
            resp = client.post(url, headers=headers, json=payload, timeout=12.0)
            if resp.status_code != 200:
                raise Exception(f"Azure HTTP Error {resp.status_code}: {resp.text}")
            
            result = resp.json()
            content = result["choices"][0]["message"]["content"]
            
            content_clean = content.strip()
            if content_clean.startswith("```json"):
                content_clean = content_clean[7:]
            elif content_clean.startswith("```"):
                content_clean = content_clean[3:]
            if content_clean.endswith("```"):
                content_clean = content_clean[:-3]
                
            import json
            data = json.loads(content_clean.strip())
            sentiment = data["sentiment"]
            confidence = float(data["confidence"])
            
            # Write results back to cache database
            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()
            cursor.execute("INSERT OR REPLACE INTO sentiment_cache (comment, sentiment, confidence) VALUES (?, ?, ?)", 
                           (comment_clean, sentiment, confidence))
            conn.commit()
            conn.close()
            
            return jsonify({"sentiment": sentiment, "confidence": confidence, "source": "llm"})
    except Exception as e:
        print("LLM Error:", e)
        # Fallback response
        return jsonify({"sentiment": "neutral", "confidence": 0.50, "source": "fallback", "error": str(e)})

@app.route("/api/map-theme", methods=["POST"])
def map_theme():
    req = request.json
    comment = req.get("comment", "")
    sentiment = req.get("sentiment", "neutral")
    allowedThemes = req.get("allowedThemes", ["Other"])
    
    comment_clean = comment.strip().lower()
    cache_key = f"{comment_clean}|{sentiment.lower()}"
    
    # Rule 1: Programmatic bypass for empty reviews
    if not comment_clean or comment_clean in ["na", "n/a", "nothing", "none", "nil"]:
        default_theme = "No Comment Provided" if "No Comment Provided" in allowedThemes else (allowedThemes[0] if allowedThemes else "Other")
        return jsonify({"theme": default_theme, "confidence": 1.0, "source": "rule"})
        
    # Rule 2: Check Cache
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT theme, confidence FROM theme_cache WHERE key = ?", (cache_key,))
    row = cursor.fetchone()
    conn.close()
    
    if row:
        return jsonify({"theme": row[0], "confidence": row[1], "source": "cache"})
        
    # Check if Azure OpenAI API is configured
    api_key = os.getenv("AZURE_OPENAI_KEY")
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o-mini")
    api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")
    
    if not is_configured():
        time.sleep(0.18)
        theme, confidence = get_mock_theme(comment_clean, sentiment, allowedThemes)
        return jsonify({"theme": theme, "confidence": confidence, "source": "mock"})
        
    # Call Azure OpenAI API
    try:
        system_prompt = (
            f"You are a customer feedback categorizer for an auto insurance business.\n"
            f"Given a comment classified with '{sentiment}' sentiment, select the single most appropriate theme from the following allowed themes:\n"
            + "\n".join(f"- {t}" for t in allowedThemes) + "\n"
            f"Rules:\n"
            f"- You MUST select EXACTLY ONE theme from the allowed list. Do not output anything outside this list.\n"
            f"Your output must be raw JSON: {{\"theme\": \"<selected_theme_name>\", \"confidence\": float}}"
        )
        user_prompt = f"Comment: \"{comment}\""
        
        headers = {
            "Content-Type": "application/json",
            "api-key": api_key
        }
        
        payload = {
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            "max_tokens": 50,
            "temperature": 0.0,
            "response_format": {"type": "json_object"}
        }
        
        url = f"{endpoint.rstrip('/')}/openai/deployments/{deployment}/chat/completions?api-version={api_version}"
        
        with httpx.Client() as client:
            resp = client.post(url, headers=headers, json=payload, timeout=12.0)
            if resp.status_code != 200:
                raise Exception(f"Azure HTTP Error {resp.status_code}: {resp.text}")
                
            result = resp.json()
            content = result["choices"][0]["message"]["content"]
            
            content_clean = content.strip()
            if content_clean.startswith("```json"):
                content_clean = content_clean[7:]
            elif content_clean.startswith("```"):
                content_clean = content_clean[3:]
            if content_clean.endswith("```"):
                content_clean = content_clean[:-3]
                
            import json
            data = json.loads(content_clean.strip())
            selected_theme = data["theme"]
            confidence = float(data["confidence"])
            
            matched = next((t for t in allowedThemes if t.lower() == selected_theme.lower()), allowedThemes[0])
            
            # Save to Cache
            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()
            cursor.execute("INSERT OR REPLACE INTO theme_cache (key, theme, confidence) VALUES (?, ?, ?)", 
                           (cache_key, matched, confidence))
            conn.commit()
            conn.close()
            
            return jsonify({"theme": matched, "confidence": confidence, "source": "llm"})
    except Exception as e:
        print("Theme mapping error:", e)
        return jsonify({"theme": allowedThemes[0] if allowedThemes else "Other", "confidence": 0.50, "source": "fallback"})

@app.route("/api/cache-stats", methods=["GET"])
def cache_stats():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM sentiment_cache")
    sent_count = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM theme_cache")
    theme_count = cursor.fetchone()[0]
    conn.close()
    return jsonify({"sentiment_count": sent_count, "theme_count": theme_count})

@app.route("/api/clear-cache", methods=["POST"])
def clear_cache():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM sentiment_cache")
    cursor.execute("DELETE FROM theme_cache")
    conn.commit()
    conn.close()
    return jsonify({"status": "success", "message": "Cache database cleared."})

@app.route("/api/status", methods=["GET"])
def get_status():
    deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o-mini")
    configured = is_configured()
    return jsonify({
        "status": "connected",
        "mode": "azure" if configured else "sandbox",
        "deployment": deployment if configured else "Mock Simulator"
    })

if __name__ == "__main__":
    # Start the Flask app directly on port 8080
    app.run(host="127.0.0.1", port=8080, debug=False)
