import httpx

def run_tests():
    print("Starting integration tests on http://localhost:8080...")
    
    # 1. Test Status
    try:
        r = httpx.get("http://localhost:8080/api/status")
        print("Status Code /api/status:", r.status_code)
        print("Response /api/status:", r.json())
    except Exception as e:
        print("Failed to reach /api/status:", e)
        return

    # 2. Test Cache Stats
    try:
        r = httpx.get("http://localhost:8080/api/cache-stats")
        print("Status Code /api/cache-stats:", r.status_code)
        print("Response /api/cache-stats:", r.json())
    except Exception as e:
        print("Failed to reach /api/cache-stats:", e)

    # 3. Test Analyze Sentiment (with programmatic bypass row)
    try:
        payload = {
            "csat": 1,
            "comment": "na",
            "surveyName": "Test Survey"
        }
        r = httpx.post("http://localhost:8080/api/analyze-sentiment", json=payload)
        print("Status Code /api/analyze-sentiment (bypass):", r.status_code)
        print("Response /api/analyze-sentiment (bypass):", r.json())
    except Exception as e:
        print("Failed to reach /api/analyze-sentiment:", e)

    # 4. Test Analyze Sentiment (normal comments, runs mock classification in sandbox mode)
    try:
        payload = {
            "csat": 9,
            "comment": "The customer representative was extremely friendly and resolved my auto claim quickly!",
            "surveyName": "Test Survey"
        }
        r = httpx.post("http://localhost:8080/api/analyze-sentiment", json=payload)
        print("Status Code /api/analyze-sentiment (normal):", r.status_code)
        print("Response /api/analyze-sentiment (normal):", r.json())
    except Exception as e:
        print("Failed to reach /api/analyze-sentiment:", e)

    # 5. Test Map Theme (runs mock theme assignment)
    try:
        payload = {
            "comment": "The customer representative was extremely friendly and resolved my auto claim quickly!",
            "sentiment": "positive",
            "allowedThemes": ["Quick Resolution", "Friendly Agent", "Clear Explanation", "Easy Claims Process"]
        }
        r = httpx.post("http://localhost:8080/api/map-theme", json=payload)
        print("Status Code /api/map-theme:", r.status_code)
        print("Response /api/map-theme:", r.json())
    except Exception as e:
        print("Failed to reach /api/map-theme:", e)

if __name__ == "__main__":
    run_tests()
