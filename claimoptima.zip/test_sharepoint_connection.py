import os, requests
import pandas as pd
from sharepoint_config import SHAREPOINT_FOLDER_PATH, SHAREPOINT_LINK

# 1. Test Local/Synced SharePoint Folder
if SHAREPOINT_FOLDER_PATH:
    os.makedirs(SHAREPOINT_FOLDER_PATH, exist_ok=True)
    test_path = os.path.join(SHAREPOINT_FOLDER_PATH, 'test_sharepoint_verification.csv')
    pd.DataFrame({'Claim_ID': [101, 102], 'Status': ['Live Sync Working', 'Verified']}).to_csv(test_path, index=False)
    print(f'[SUCCESS] Verified local SharePoint folder! Saved test file to: {test_path}')

# 2. Test SharePoint Webhook / Web Link
if SHAREPOINT_LINK and SHAREPOINT_LINK.startswith(('http://', 'https://')):
    try:
        sample_xlsx = os.path.join(os.path.dirname(__file__), "backend_output", "clinical_complexity_working_dataset.xlsx")
        if os.path.exists(sample_xlsx):
            with open(sample_xlsx, "rb") as f_in:
                file_bytes = f_in.read()
            content_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            print(f"[TEST] Sending clinical_complexity_working_dataset.xlsx ({len(file_bytes):,} bytes)...")
        else:
            file_bytes = b'Claim_ID,Status\n101,Verified\n'
            content_type = "text/csv"
            print("[TEST] Sending test CSV data...")

        resp = requests.post(
            SHAREPOINT_LINK, 
            data=file_bytes, 
            headers={"Content-Type": content_type, "X-Source": "ClaimOptima-AI-Engine"}, 
            timeout=15
        )
        if resp.status_code in [200, 201, 202, 204]:
            print(f'[SUCCESS] SharePoint/OneDrive Webhook responded with HTTP {resp.status_code} (File successfully saved in cloud!)')
        else:
            print(f'[NOTICE] Webhook responded with HTTP {resp.status_code}: {resp.text}')
    except Exception as e:
        print(f'[ERROR] Could not connect to Webhook: {e}')

if not SHAREPOINT_FOLDER_PATH and not SHAREPOINT_LINK:
    print('[NOTE] Please paste your SharePoint folder path or link into sharepoint_config.py first!')
