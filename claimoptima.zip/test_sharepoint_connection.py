import os, requests
import pandas as pd
from sharepoint_config import SHAREPOINT_FOLDER_PATH, SHAREPOINT_LINK

# 1. Test Local/Synced SharePoint Folder
if SHAREPOINT_FOLDER_PATH:
    os.makedirs(SHAREPOINT_FOLDER_PATH, exist_ok=True)
    test_path = os.path.join(SHAREPOINT_FOLDER_PATH, 'test_sharepoint_verification.csv')
    pd.DataFrame({'Claim_ID': [101, 102], 'Status': ['Live Sync Working', 'Verified']}).to_csv(test_path, index=False)
    print(f'[SUCCESS] Verified local SharePoint folder! Saved test file to: {test_path}')

# 2. Test SharePoint Webhook / Web Link
if SHAREPOINT_LINK and SHAREPOINT_LINK.startswith(('http://', 'https://')):
    resp = requests.post(SHAREPOINT_LINK, data='Claim_ID,Status\n101,Verified\n', headers={'Content-Type': 'text/csv'}, timeout=10)
    print(f'[SUCCESS] SharePoint Webhook responded with HTTP {resp.status_code}')

if not SHAREPOINT_FOLDER_PATH and not SHAREPOINT_LINK:
    print('[NOTE] Please paste your SharePoint folder path or link into sharepoint_config.py first!')
