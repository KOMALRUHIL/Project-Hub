# ==============================================================================
# 🔗 SHAREPOINT DESTINATION & CUSTOM OUTPUT CONFIGURATION
# ==============================================================================
# You can specify your SharePoint destination in two ways:
#
# 1. LOCAL / SYNCED SHAREPOINT FOLDER PATH (Recommended if using OneDrive / SharePoint sync):
#    Example: SHAREPOINT_FOLDER_PATH = r"C:\Users\YourName\YourCompany\TeamName - Documents\ClaimOptima_Outputs"
#
# 2. SHAREPOINT WEB LINK / WEBHOOK (If using Power Automate or direct Webhook):
#    Example: SHAREPOINT_LINK = "https://yourcompany.sharepoint.com/sites/YourTeam/Shared%20Documents/..."
# ==============================================================================

# Option 1: Local / Synced SharePoint folder path
SHAREPOINT_FOLDER_PATH = ""

# Option 2: SharePoint web link / webhook URL
SHAREPOINT_LINK = ""

