function App() {
return (
<div>
                                          : (agent1SidebarStep === "scores" && activeAgent === 1
                                              ? "bg-[#0066FF] border-2 border-solid border-[#00D2FF] text-white shadow-md scale-[1.02] cursor-pointer"
                                              : (seenSteps.scores 
                                                  ? "bg-slate-900 border-2 border-solid border-emerald-500 text-white cursor-pointer"
                                                  : "bg-transparent border-2 border-dashed border-slate-700 text-slate-400 cursor-pointer"))
                                  }`}
                              >
                                  <span className="text-[10px] font-bold leading-tight">4. Funnel & Cohorts</span>
                                  {seenSteps.scores && <span className="text-[9px] text-emerald-400 font-mono font-bold mt-0.5">✓</span>}
                              </div>

                              <span className={`text-xs font-bold transition-all ${seenSteps.scores ? "text-emerald-400 font-bold animate-pulse" : "text-slate-700"}`}>
                                  ─▶
                              </span>

                              {/* 5. Lineage */}
                              <div 
                                  onClick={(e) => { if (claims.length > 0) { e.stopPropagation(); setActiveAgent(1); setAgent1SidebarStep("tree"); } }}
                                  className={`flex-1 rounded-lg py-2 px-1 text-center transition-all flex flex-col justify-center items-center ${
                                      claims.length === 0 

</div>
);
}