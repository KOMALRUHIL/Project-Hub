function App() {
return (
<div>
                  {activeAgent === 1 && agent1SidebarStep === "scores" && (
                      <div className="flex-1 flex flex-col min-h-0 p-3 space-y-2.5 overflow-hidden">
                          
                          {/* 1. TOP CENTERED MAXIMUM COMPLEXITY BANNER */}
                          <div className="shrink-0 bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border border-[#00D2FF]/40 rounded-xl px-4 py-2 shadow-md flex items-center justify-between relative overflow-hidden">
                              <div className="absolute inset-0 bg-[#00D2FF]/5 pointer-events-none" />
                              
                              <div className="flex-1 flex items-center justify-center space-x-2 z-10 font-heading">
                                  <span className="text-sm">⚡</span>
                                  <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                                      Maximum Complexity Score:
                                  </span>
                                  <span className="text-2xl font-black text-[#00D2FF] font-mono tracking-tight ml-1">
                                      {cohortIntelligence.max} / 100
                                  </span>
                                  <span className="text-[11px] text-slate-300 font-mono ml-3 bg-slate-950/80 border border-slate-800 px-3 py-1 rounded-lg shadow-inner">
                                      (Minimum Complexity: <strong className="text-emerald-400">{cohortIntelligence.min}</strong> | Average Complexity: <strong className="text-[#00D2FF]">{cohortIntelligence.avg}</strong> across <strong className="text-white">{cohortIntelligence.totalCount}</strong> Claims)
                                  </span>
                              </div>

                              <div className="z-10 flex items-center space-x-2 shrink-0">
                                  <button 
                                      onClick={handleDownloadCSV}
                                      className="px-2.5 py-1 bg-slate-900/90 hover:bg-slate-800 text-emerald-400 border border-emerald-500/30 font-bold text-[11px] rounded-lg transition flex items-center space-x-1 font-heading cursor-pointer"
                                      title="Export calculated complexity dataset"
                                  >
                                      <span>📥 Download CSV</span>
                                  </button>
                                  <button 
                                      onClick={() => setAgent1SidebarStep("tree")}
                                      className="px-3 py-1 bg-[#0066FF] hover:bg-[#0052CC] text-white font-bold text-xs rounded-lg transition shadow flex items-center space-x-1 font-heading cursor-pointer"
                                  >
                                      <span>5. Lineage Tree ➔</span>
                                  </button>
                                  <button 
                                      onClick={() => setAgent1SidebarStep("neural")}
                                      className="px-3 py-1 bg-gradient-to-r from-[#0066FF] to-[#00D2FF] hover:from-[#0052CC] hover:to-[#00B4D8] text-slate-950 font-bold text-xs rounded-lg transition shadow flex items-center space-x-1 font-heading cursor-pointer"
                                  >
                                      <span>6. Neural Graph ➔</span>
                                  </button>
                              </div>
                          </div>

                          {/* 2. THREE STATISTICALLY ADAPTIVE RISK TIER CARDS (High Risk > 72, Low & Moderate Adaptive) */}
                          <div className="grid grid-cols-3 gap-2.5 shrink-0 select-none font-heading">
                              
                              {/* Low Tier Card */}

</div>
</div>
</div>
</div>
</div>
)}
</div>
);
}