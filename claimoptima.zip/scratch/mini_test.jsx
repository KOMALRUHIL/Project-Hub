function App() { return (
<>
                      </div>
                  )}

                  {/* ========================================================================= */}
                  {/* STEP 6: AUTHENTIC POWER BI COMPASS D3 FORCE KNOWLEDGE GRAPH              */}
                  {/* (Ported from KPIDashboardGraph.tsx - 100% Dynamic from Active Dataset)    */}
                  {/* ========================================================================= */}
                  {agent1SidebarStep === "neural" && (() => {
                      return (
                          <D3CompassKnowledgeGraph 
                              calculatedClaims={calculatedClaims}
                              domainFlowData={domainFlowData}
                              cohortIntelligence={cohortIntelligence}
                              defaultScoringWeights={defaultScoringWeights}
                              weights={weights}
                              cohortTopLimit={cohortTopLimit}
                              setCohortTopLimit={setCohortTopLimit}
                              isGraphFullscreen={isGraphFullscreen}
                              setIsGraphFullscreen={setIsGraphFullscreen}
                              setActiveAgent={setActiveAgent}
                              handleDispatchToAgent2={handleDispatchToAgent2}
                              isAgent2Mode={false}
                          />
                      );
                  })()}

                      </div>
                  </>
              )}

              {/* ========================================================================= */}

</>
); }