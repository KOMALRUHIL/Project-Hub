import os
import shutil

filepath = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "frontend", "src", "ai_conclave", "ClaimOptimaApp.jsx"))
mirror_filepath = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "AI_Conclave", "ClaimOptimaApp.jsx"))

with open(filepath, "rb") as f:
    raw = f.read().decode("utf-8")

lines = raw.splitlines(keepends=True)

# Verify index 7951 is </div> and index 7958 is )}
print("Index 7951:", ascii(lines[7951].strip()))
print("Index 7958:", ascii(lines[7958].strip()))

funnel_component = '''
                                           {/* 3. CASCADING DOMAIN FINANCIAL CONTRIBUTION FUNNEL (COMPACT, 100% VISIBLE WITH ZERO SCROLLING) */}
                                           <div className="flex-1 bg-slate-950 border border-slate-800 rounded-xl p-2.5 flex flex-col justify-between shadow-md min-h-0 overflow-hidden">
                                               
                                               <div className="shrink-0 flex justify-between items-center pb-1 border-b border-slate-800">
                                                   <div className="flex items-center space-x-2">
                                                       <span className="text-sm">🌪️</span>
                                                       <div>
                                                           <h3 className="text-xs font-bold text-white font-heading uppercase tracking-wider">
                                                               Domain SHAP Dollar Escalation Funnel ({selectedDemandRiskFilter.toUpperCase()} TIER: {activeFilteredDemandClaims.length} CLAIMS)
                                                           </h3>
                                                           <p className="text-[9px] text-slate-400 font-sans">
                                                               Mean SHAP (SHapley Additive exPlanations) values quantifying each domain's dollar addition to baseline claim demand.
                                                           </p>
                                                       </div>
                                                   </div>

                                                   <div className="flex items-center space-x-1 bg-slate-900 border border-slate-800 p-0.5 rounded-lg font-heading text-[10px]">
                                                       <button 
                                                           onClick={() => setSelectedDemandRiskFilter("all")}
                                                           className={`px-2 py-0.5 rounded transition cursor-pointer ${selectedDemandRiskFilter === "all" ? "bg-slate-800 text-white font-bold" : "text-slate-400 hover:text-slate-200"}`}
                                                       >
                                                           All ({demandCohortIntelligence.totalCount})
                                                       </button>
                                                       <button 
                                                           onClick={() => setSelectedDemandRiskFilter("low")}
                                                           className={`px-2 py-0.5 rounded transition cursor-pointer ${selectedDemandRiskFilter === "low" ? "bg-emerald-500 text-slate-950 font-bold" : "text-slate-400 hover:text-slate-200"}`}
                                                       >
                                                           Low ({demandCohortIntelligence.low.count})
                                                       </button>
                                                       <button 
                                                           onClick={() => setSelectedDemandRiskFilter("medium")}
                                                           className={`px-2 py-0.5 rounded transition cursor-pointer ${selectedDemandRiskFilter === "medium" ? "bg-blue-500 text-white font-bold" : "text-slate-400 hover:text-slate-200"}`}
                                                       >
                                                           Moderate ({demandCohortIntelligence.medium.count})
                                                       </button>
                                                       <button 
                                                           onClick={() => setSelectedDemandRiskFilter("high")}
                                                           className={`px-2 py-0.5 rounded transition cursor-pointer ${selectedDemandRiskFilter === "high" ? "bg-[#0066FF] text-slate-950 font-bold" : "text-slate-400 hover:text-slate-200"}`}
                                                       >
                                                           High ({demandCohortIntelligence.high.count})
                                                       </button>
                                                   </div>
                                               </div>

                                               {/* 8 CASCADING DOMAIN FUNNEL BARS (REVERTED TO MIN, AVG, MAX LIKE BEFORE) */}
                                               <div className="flex-1 flex flex-col justify-around py-0.5 select-none min-h-0 overflow-hidden">
                                                   {segmentDomainDemandFunnel.map((domain) => (
                                                       <div key={domain.key} className="flex items-center space-x-2.5 group">
                                                           
                                                           {/* Left: Domain Icon & Title */}
                                                           <div className="w-40 shrink-0 flex items-center space-x-1.5 text-xs font-heading">
                                                               <span className="text-sm">{domain.icon}</span>
                                                               <span className="font-bold text-slate-200 text-[10.5px] truncate" title={domain.title}>
                                                                   {domain.title}
                                                               </span>
                                                           </div>

                                                           {/* Center: Horizontally Centered Symmetrical Inverted Funnel Bar */}
                                                           <div className="flex-1 flex flex-col items-center justify-center space-y-0.5">
                                                               
                                                               {/* Outlier Header Centered Above Bar */}
                                                               <div 
                                                                   className="flex flex-col space-y-0.5 transition-all duration-500 min-w-[320px]"
                                                                   style={{ width: `${domain.funnelWidth}%` }}
                                                               >
                                                                   <div className="flex items-center justify-between text-[8px] font-mono px-0.5 text-slate-400">
                                                                       <span className="flex items-center space-x-1 truncate">
                                                                           <span className="h-1 w-1 rounded-full bg-emerald-400" />
                                                                           <span>SHAP Escalation: <strong className="text-emerald-300">+${domain.avgDollars.toLocaleString()}</strong> • <strong className="text-rose-400">{domain.outlierPct}% Outliers</strong> (≥ ${domain.domainOutlierCutoff?.toLocaleString()})</span>
                                                                       </span>
                                                                       <span className="text-slate-500 hidden md:inline text-[7.5px]">
                                                                           Click right box to inspect ➔
                                                                       </span>
                                                                   </div>

                                                                   <div 
                                                                       className="h-0.5 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800 pointer-events-none"
                                                                       title={`Outlier Rate: ${domain.outlierPct}%`}
                                                                   >
                                                                       <div 
                                                                           className="h-full bg-gradient-to-r from-emerald-500 via-amber-500 to-rose-500 rounded-full transition-all duration-500"
                                                                           style={{ width: `${Math.max(3, domain.outlierPct)}%` }}
                                                                       />
                                                                   </div>
                                                               </div>

                                                               {/* Main Symmetrical Centered Funnel Bar showing Min, Avg, and Max */}
                                                               <div 
                                                                   className="h-6.5 rounded-lg bg-gradient-to-r from-[#0052CC] via-[#0066FF] to-emerald-400 border border-emerald-400/40 px-3 flex items-center justify-between shadow transition-all duration-500 relative overflow-hidden font-mono min-w-[320px]"
                                                                   style={{ width: `${domain.funnelWidth}%` }}
                                                               >
                                                                   <div className="absolute inset-0 bg-white/5 opacity-50 pointer-events-none" />

                                                                   {/* Inside Left: Min Dollars */}
                                                                   <span className="text-[9.5px] font-bold text-slate-100 z-10 opacity-95 shrink-0 bg-slate-950/60 px-2 py-0.5 rounded border border-white/10">
                                                                       Min: ${domain.minDollars.toLocaleString()}
                                                                   </span>

                                                                   {/* Inside Center: Avg Dollars + % Share */}
                                                                   <div className="flex items-center space-x-1.5 z-10 shrink-0">
                                                                       <span className="text-[11px] font-black text-white drop-shadow">
                                                                           Avg: +${domain.avgDollars.toLocaleString()}
                                                                       </span>
                                                                       <span className="text-[8.5px] font-bold text-slate-950 bg-emerald-400 px-1 py-0.2 rounded shadow">
                                                                           {domain.sharePct}% Share
                                                                       </span>
                                                                   </div>

                                                                   {/* Inside Right: Max Dollars */}
                                                                   <span className="text-[9.5px] font-bold text-cyan-200 z-10 opacity-95 shrink-0 bg-slate-950/60 px-2 py-0.5 rounded border border-cyan-300/20">
                                                                       Max: ${domain.maxDollars.toLocaleString()}
                                                                   </span>
                                                               </div>

                                                           </div>

                                                           {/* Right: Clickable Outlier Badge */}
                                                           <div className="w-14 shrink-0 flex justify-end">
                                                               <button 
                                                                   onClick={() => setActiveOutlierDemandDomain(domain)}
                                                                   className="bg-slate-900 hover:bg-slate-800 border border-rose-500/40 hover:border-rose-400 px-1.5 py-0.5 rounded-lg flex flex-col items-center justify-center transition cursor-pointer shadow-inner w-full group-hover:border-rose-400"
                                                                   title="Inspect domain loss demand outliers"
                                                               >
                                                                   <span className="text-[7.5px] text-slate-400 font-mono">Outliers</span>
                                                                   <span className="text-[10px] font-black text-rose-400 font-mono group-hover:scale-105 transition">
                                                                       {domain.outlierPct}% 🔍
                                                                   </span>
                                                               </button>
                                                           </div>

                                                       </div>
                                                   ))}
                                               </div>

                                           </div>

                                       </div>
'''

new_lines = lines[:7952] + [funnel_component + "\n"] + lines[7958:]

with open(filepath, "wb") as f:
    f.write("".join(new_lines).encode("utf-8"))

print(f"SUCCESS: Inserted Cascading Funnel into frontend/src/ai_conclave/ClaimOptimaApp.jsx")
shutil.copyfile(filepath, mirror_filepath)
print(f"SUCCESS: Mirrored to AI_Conclave/ClaimOptimaApp.jsx")
