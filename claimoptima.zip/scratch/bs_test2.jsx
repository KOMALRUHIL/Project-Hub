function App() {
return (
<>
                      {/* LEFT SIDEBAR: AGENT 1 STEPS (COLLAPSIBLE & UNIFORM) */}
                      {!isSidebarCollapsed && (
                  <aside className="w-56 bg-slate-900/90 border-r border-slate-800 p-3.5 flex flex-col justify-between shrink-0 select-none shadow-xl transition-all duration-300">
                      <div className="space-y-3">
                          <div className="flex justify-between items-start">
                              <div>
                                  <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block font-heading">
                                      Clinical Complexity Workspace
                                  </span>
                                  <h2 className="text-xs font-bold text-white mt-0.5 font-heading">
                                      Ingestion & Complexity
                                  </h2>
                              </div>
                              <button 
                                  onClick={() => setIsSidebarCollapsed(true)}
                                  className="h-6 w-6 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center text-xs transition cursor-pointer"
                                  title="Collapse Sidebar"
                              >
                                  ◀
                              </button>
                          </div>

                          <nav className="flex flex-col space-y-1 font-heading">
                              <button 
                                  onClick={() => setAgent1SidebarStep("input")}
                                  className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-semibold transition text-left cursor-pointer ${
                                      agent1SidebarStep === "input" 
                                          ? "bg-[#0066FF] text-white shadow-md ring-1 ring-[#0066FF]/50" 
                                          : "bg-slate-950/60 border border-slate-800/80 text-slate-300 hover:bg-slate-850 hover:text-white"
                                  }`}
                              >
                                  <span>1. Ingestion & Preview</span>
                                  {claims.length > 0 && <span className="text-emerald-400 font-bold">✓</span>}
                              </button>

                              <button 
                                  disabled={claims.length === 0}
                                  onClick={() => setAgent1SidebarStep("flowchart")}
                                  className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-semibold transition text-left cursor-pointer disabled:opacity-30 disabled:pointer-events-none ${
                                      agent1SidebarStep === "flowchart" 
                                          ? "bg-[#0066FF] text-white shadow-md ring-1 ring-[#0066FF]/50" 
                                          : "bg-slate-950/60 border border-slate-800/80 text-slate-300 hover:bg-slate-850 hover:text-white"
                                  }`}
                              >
                                  <span>2. Feature Tree</span>
                                  {claims.length > 0 && <span className="text-[#00D2FF] text-[10px] font-mono">8 Col</span>}
                              </button>

                              <button 
                                  disabled={claims.length === 0}
                                  onClick={() => setAgent1SidebarStep("weights")}
                                  className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-semibold transition text-left cursor-pointer disabled:opacity-30 disabled:pointer-events-none ${
                                      agent1SidebarStep === "weights" 
                                          ? "bg-[#0066FF] text-white shadow-md ring-1 ring-[#0066FF]/50" 
                                          : "bg-slate-950/60 border border-slate-800/80 text-slate-300 hover:bg-slate-850 hover:text-white"
                                  }`}
                              >
                                  <span>3. Weights Matrix</span>
                                  {claims.length > 0 && <span className="text-slate-400 text-[10px] font-mono">Matrix</span>}
                              </button>

                              <button 
                                  disabled={claims.length === 0}
                                  onClick={() => setAgent1SidebarStep("scores")}
                                  className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-semibold transition text-left cursor-pointer disabled:opacity-30 disabled:pointer-events-none ${
                                      agent1SidebarStep === "scores" 
                                          ? "bg-[#0066FF] text-white shadow-md ring-1 ring-[#0066FF]/50" 
                                          : "bg-slate-950/60 border border-slate-800/80 text-slate-300 hover:bg-slate-850 hover:text-white"
                                  }`}
                              >
                                  <span>4. Complexity & Funnel</span>
                                  {claims.length > 0 && <span className="text-emerald-400 text-[10px] font-mono font-bold">0-100</span>}
                              </button>

                              <button 
                                  disabled={claims.length === 0}
                                  onClick={() => setAgent1SidebarStep("tree")}
                                  className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-semibold transition text-left cursor-pointer disabled:opacity-30 disabled:pointer-events-none ${
                                      agent1SidebarStep === "tree" 
                                          ? "bg-[#0066FF] text-white shadow-md ring-1 ring-[#0066FF]/50" 
                                          : "bg-slate-950/60 border border-slate-800/80 text-slate-300 hover:bg-slate-850 hover:text-white"
                                  }`}
                              >
                                  <span>5. Clinical Lineage Tree</span>
                                  <span className="text-[9px] font-bold font-mono px-1.5 py-0.2 rounded bg-[#0066FF]/20 text-[#00D2FF]">
                                      L1➔L2➔L3
                                  </span>
                              </button>

                              <button 
                                  disabled={claims.length === 0}
                                  onClick={() => setAgent1SidebarStep("neural")}
                                  className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-semibold transition text-left cursor-pointer disabled:opacity-30 disabled:pointer-events-none ${
                                      agent1SidebarStep === "neural" 
                                          ? "bg-[#0066FF] text-white shadow-md ring-1 ring-[#0066FF]/50" 
                                          : "bg-slate-950/60 border border-slate-800/80 text-slate-300 hover:bg-slate-850 hover:text-white"
                                  }`}
                              >
                                  <span>6. Neural Risk Graph</span>
                                  {claims.length > 0 && <span className="text-[#00D2FF] text-[10px] font-mono">Graph</span>}
                              </button>
                          </nav>
                      </div>

                      {claims.length > 0 ? (
                          <div className="bg-slate-950 p-2.5 rounded-lg border border-emerald-500/30 space-y-1 font-heading">
                              <div className="flex items-center space-x-2">
                                  <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                                  <span className="text-[10px] font-bold text-emerald-400">File Ingested</span>
                              </div>
                              <p className="text-[10px] text-slate-300 font-mono truncate" title={uploadedFileName}>
                                  {uploadedFileName}
                              </p>
                              <div className="text-[9px] text-slate-400 font-mono">
                                  {claims.length} Records • {ingestedColumns.length} Cols
                              </div>
                          </div>
                      ) : (
                          <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-[10px] text-slate-500 italic text-center font-heading">
                              No file inputted yet.
                          </div>
                      )}
                  </aside>
              )}

                      {/* FLOATING EXPAND SIDEBAR BUTTON WHEN COLLAPSED */}
                      {isSidebarCollapsed && (
                          <button 
                              onClick={() => setIsSidebarCollapsed(false)}
                              className="absolute top-2 left-2 z-40 h-8 px-3 rounded-lg bg-slate-900 border border-slate-700 text-slate-200 hover:text-white hover:border-[#00D2FF] shadow-2xl flex items-center space-x-1.5 text-xs font-bold transition cursor-pointer font-heading hover:scale-105"
                              title="Expand Left Navigation Menu"
                          >
                              <span>▶</span>
                              <span className="text-[11px]">Expand Menu</span>
                          </button>
                      )}

                      {/* RIGHT MAIN WORKSPACE FOR AGENT 1 */}
                      <div className="flex-1 flex flex-col min-h-0 bg-slate-950 overflow-hidden relative">
                  
                  {/* STEP 1: FILE INGESTION & DOCUMENT PIPELINE */}
                  {activeAgent === 1 && agent1SidebarStep === "input" && (
                      <div className={`flex-1 flex flex-col min-h-0 p-4 space-y-3 font-heading select-none ${showPreviewTable ? "overflow-hidden" : "overflow-y-auto"}`}>
                          
                          {/* VIEW 1: PIPELINE DIAGRAM & CONTROLS (VANISHES WHEN PREVIEW IS ACTIVE) */}
                          {!showPreviewTable && (
                              <div className="bg-slate-900/95 border border-slate-800/80 rounded-2xl p-5 shadow-2xl backdrop-blur-md relative overflow-hidden select-none">
                                  {/* SVG Keyframe styles for animated flowing dashes */}
                                  <style>{`
                                      @keyframes flowDash {
                                          0% { stroke-dashoffset: 24; }
                                          100% { stroke-dashoffset: 0; }
                                      }
                                      .animate-flow-dash {
                                          animation: flowDash 0.75s linear infinite;
                                      }
                                      @keyframes pulseGlow {
                                          0%, 100% { opacity: 0.85; transform: scale(1); }
                                          50% { opacity: 1; transform: scale(1.02); }
                                      }
                                      .animate-pulse-glow {
                                          animation: pulseGlow 1.8s ease-in-out infinite;
                                      }
                                  `}</style>

                                  {/* Automatic Data Ingestion Flow Header */}
                                  <div className="flex flex-wrap items-center justify-between gap-3 mb-5 pb-4 border-b border-slate-800/70">
                                      <div className="flex items-center space-x-3.5">
                                          <div className={`h-10 w-10 rounded-xl flex items-center justify-center text-base font-black shadow-md transition-all ${
                                              pipelinePhase === "reading_docs" ? "bg-[#00D2FF]/20 text-[#00D2FF] ring-2 ring-[#00D2FF]/50 animate-pulse" :
                                              pipelinePhase === "excel_lag" ? "bg-cyan-500/20 text-cyan-400 ring-2 ring-cyan-400/50" :
                                              pipelinePhase === "cleaning" ? "bg-amber-500/20 text-amber-400 ring-2 ring-amber-400/50 animate-pulse" :
                                              pipelinePhase === "ready_lag" || pipelinePhase === "completed" ? "bg-emerald-500/20 text-emerald-400 ring-2 ring-emerald-500/50" :
                                              "bg-gradient-to-tr from-[#0066FF] to-[#00D2FF] text-slate-950"
                                          }`}>
                                              {pipelinePhase === "reading_docs" ? "1" :
                                               pipelinePhase === "excel_lag" ? "⏸" :
                                               pipelinePhase === "cleaning" ? "2" :
                                               pipelinePhase === "ready_lag" ? "⏸" :
                                               pipelinePhase === "completed" ? "✓" : "⚡"}
                                          </div>
                                          <div>
                                              <div className="flex items-center space-x-2">
                                                  <span className="text-[10px] font-bold text-[#00D2FF] bg-[#00D2FF]/10 border border-[#00D2FF]/30 px-2.5 py-0.5 rounded-full font-mono uppercase tracking-wider">
                                                      Automatic Data Ingestion Flow
                                                  </span>
                                                  <span className="text-[10px] font-mono text-slate-400">
                                                      2,700+ Case Documents ➔ 6 Relational Tables ➔ HIPAA Masking
                                                  </span>
                                              </div>
                                              <h2 className="text-sm sm:text-base font-bold text-white mt-1 font-heading">
                                                  {pipelinePhase === "idle" && "2,700+ Case Documents Ingested ➔ Excel Database ➔ Master Claims Repository"}
                                                  {pipelinePhase === "reading_docs" && "Stage 1: Ingesting 2,700+ Documents — Converting Unstructured Files into Excel Matrix"}
                                                  {pipelinePhase === "excel_lag" && "⏸ Intermediate Settling: 6 Strict Relational Tables Generated"}
                                                  {pipelinePhase === "cleaning" && "Stage 2: Data Cleaning & HIPAA Masking — Normalizing 176+ Derived Variables"}
                                                  {pipelinePhase === "ready_lag" && "⏸ Cleaning Complete — Consolidating Master Claims Repository..."}
                                                  {pipelinePhase === "completed" && "Ingestion & Structuring Complete — Master Claims Repository is 100% Ready!"}
                                              </h2>
                                          </div>
                                      </div>

                                      {/* Top Action Buttons (Preview / Feature Architecture) */}
                                      {pipelineStatus === "completed" && (
                                          <div className="flex items-center space-x-2.5 font-heading">
                                              <button
                                                  onClick={() => setShowPreviewTable(true)}
                                                  className="px-4 py-2 bg-gradient-to-r from-emerald-400 via-[#00D2FF] to-emerald-400 hover:from-[#FF6B35] hover:to-[#FF5B35] text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-emerald-500/20 hover:scale-105 transition flex items-center space-x-1.5 cursor-pointer font-heading border border-emerald-400/50"
                                              >
                                                  <span>🔍 Preview Ingested Dataset</span>
                                                  <span>➔</span>
                                              </button>
                                              <button 
                                                  onClick={handleTriggerFeatureExtraction}
                                                  className="px-4 py-2 bg-[#0066FF] hover:bg-[#0052CC] text-white font-bold text-xs rounded-xl transition shadow-lg flex items-center space-x-1.5 font-heading cursor-pointer hover:scale-[1.02]"
                                              >
                                                  <span>Proceed to Feature Architecture ➔</span>
                                              </button>
                                          </div>
                                      )}
                                  </div>

                                  {/* THE 3-COLUMN DIAGRAM */}
                                  <div className="overflow-x-auto pb-2">
                                      <div className="min-w-[840px] flex items-center justify-between gap-2 px-2 py-3">
                                          
                                          {/* COLUMN 1: DOCS (2,700+ Case Documents Ingested + 3 Sources) */}
                                          <div className="w-[230px] flex flex-col items-center">
                                              {/* Header */}
                                              <div className="flex items-center space-x-2 mb-3">
                                                  <div className="p-1.5 rounded-lg bg-[#0066FF]/15 border border-[#0066FF]/30 text-[#00D2FF]">
                                                      <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                                                          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                                                          <polyline points="14 2 14 8 20 8"></polyline>
                                                          <line x1="16" y1="13" x2="8" y2="13"></line>
                                                          <line x1="16" y1="17" x2="8" y2="17"></line>
                                                      </svg>
                                                  </div>
                                                  <span className="text-lg font-black text-white tracking-wide font-heading">
                                                      Case Documents
                                                  </span>
                                                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-slate-800 text-[#00D2FF] border border-[#00D2FF]/30">
                                                      2,700+ Docs
                                                  </span>
                                              </div>

                                              {/* 3 Stacked Ingestion Boxes */}
                                              <div className="w-full space-y-2.5">
                                                  {/* Box 1: Medical Records */}
                                                  <div className={`p-2.5 rounded-xl border transition-all duration-300 ${
                                                      pipelinePhase === "reading_docs"
                                                          ? "bg-slate-850 border-[#00D2FF] shadow-lg shadow-[#00D2FF]/20 ring-1 ring-[#00D2FF]/50"
                                                          : (pipelinePhase !== "idle")
                                                          ? "bg-slate-900/90 border-emerald-500/40"
                                                          : "bg-slate-900/80 border-slate-800 hover:border-slate-700"
                                                  }`}>
                                                      <div className="flex items-center space-x-2.5">
                                                          <div className="h-7 w-7 rounded-lg bg-[#0066FF]/15 border border-[#0066FF]/30 flex items-center justify-center text-sm">
                                                              📋
                                                          </div>
                                                          <div className="min-w-0 flex-1">
                                                              <div className="text-xs font-bold text-white truncate">Medical Records</div>
                                                              <div className="text-[10px] text-slate-400 truncate">Doctor narratives, ICD-10</div>
                                                          </div>
                                                      </div>
                                                  </div>

                                                  {/* Box 2: Police Reports */}
                                                  <div className={`p-2.5 rounded-xl border transition-all duration-300 ${
                                                      pipelinePhase === "reading_docs"
                                                          ? "bg-slate-850 border-[#00D2FF] shadow-lg shadow-[#00D2FF]/20 ring-1 ring-[#00D2FF]/50"
                                                          : (pipelinePhase !== "idle")
                                                          ? "bg-slate-900/90 border-emerald-500/40"
                                                          : "bg-slate-900/80 border-slate-800 hover:border-slate-700"
                                                  }`}>
                                                      <div className="flex items-center space-x-2.5">
                                                          <div className="h-7 w-7 rounded-lg bg-[#00D2FF]/15 border border-[#00D2FF]/30 flex items-center justify-center text-sm">
                                                              🚔
                                                          </div>
                                                          <div className="min-w-0 flex-1">
                                                              <div className="text-xs font-bold text-white truncate">Police Accident Reports</div>
                                                              <div className="text-[10px] text-slate-400 truncate">Biomechanics, impact speed</div>
                                                          </div>
                                                      </div>
                                                  </div>

                                                  {/* Box 3: Billing Invoices */}
                                                  <div className={`p-2.5 rounded-xl border transition-all duration-300 ${
                                                      pipelinePhase === "reading_docs"
                                                          ? "bg-slate-850 border-[#00D2FF] shadow-lg shadow-[#00D2FF]/20 ring-1 ring-[#00D2FF]/50"
                                                          : (pipelinePhase !== "idle")
                                                          ? "bg-slate-900/90 border-emerald-500/40"
                                                          : "bg-slate-900/80 border-slate-800 hover:border-slate-700"
                                                  }`}>
                                                      <div className="flex items-center space-x-2.5">
                                                          <div className="h-7 w-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-sm">
                                                              🧾
                                                          </div>
                                                          <div className="min-w-0 flex-1">
                                                              <div className="text-xs font-bold text-white truncate">Hospital Billing Invoices</div>
                                                              <div className="text-[10px] text-slate-400 truncate">Line-item CPT codes & fees</div>
                                                          </div>
                                                      </div>
                                                  </div>
                                              </div>

                                              {/* Label Underneath */}
                                              <div className="mt-2 text-center">
                                                  <span className="text-base font-black text-white tracking-wide font-heading block">
                                                      2,700+ Documents
                                                  </span>
                                                  <span className="text-[10px] font-mono text-[#00D2FF]">
                                                      Unstructured Ingestion
                                                  </span>
                                              </div>
                                          </div>

                                          {/* CONNECTOR 1: 3 CONVERGING ARROWS labeled "Extracting data into Excel" */}
                                          <div className="flex-1 flex flex-col items-center justify-center px-1">
                                              {/* Flow Label */}
                                              <div className={`px-2.5 py-1 rounded-full text-xs font-bold font-mono transition-all duration-300 mb-1 flex items-center space-x-1.5 ${
                                                  pipelinePhase === "reading_docs"
                                                      ? "bg-[#00D2FF]/15 text-[#00D2FF] border border-[#00D2FF]/40 shadow-md shadow-[#00D2FF]/20 animate-pulse"
                                                      : pipelinePhase === "excel_lag"
                                                      ? "bg-cyan-500/10 text-cyan-400 border border-cyan-500/30"
                                                      : (pipelinePhase === "cleaning" || pipelinePhase === "ready_lag" || pipelinePhase === "completed")
                                                      ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                                                      : "bg-slate-800/80 text-slate-400 border border-slate-700/60"
                                              }`}>
                                                  <span>Extracting data into Excel</span>
                                                  {pipelinePhase === "reading_docs" && (
                                                      <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#00D2FF] animate-ping" />
                                                  )}
                                                  {pipelinePhase === "excel_lag" && (
                                                      <span className="text-[10px] text-cyan-300 font-mono">(Settled)</span>
                                                  )}
                                                  {(pipelinePhase === "cleaning" || pipelinePhase === "ready_lag" || pipelinePhase === "completed") && (
                                                      <span>✓</span>
                                                  )}
                                              </div>

                                              {/* SVG Curves: 3 converging paths */}
                                              <svg className="w-full h-44 overflow-visible" viewBox="0 0 160 176" preserveAspectRatio="none">
                                                  <defs>
                                                      <marker id="arrow-reading-moving" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="6" markerHeight="6" orient="auto">
                                                          <path d="M 0 1 L 8 5 L 0 9 z" fill="#00D2FF" />
                                                      </marker>
                                                      <marker id="arrow-reading-stopped" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="6" markerHeight="6" orient="auto">
                                                          <path d="M 0 1 L 8 5 L 0 9 z" fill="#10B981" />
                                                      </marker>
                                                      <marker id="arrow-reading-idle" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="6" markerHeight="6" orient="auto">
                                                          <path d="M 0 1 L 8 5 L 0 9 z" fill="#475569" />
                                                      </marker>
                                                  </defs>

                                                  {/* Top Path */}
                                                  <path
                                                      d="M 0 28 C 90 28, 100 80, 155 80"
                                                      fill="none"
                                                      stroke={
                                                          pipelinePhase === "reading_docs" ? "#00D2FF" :
                                                          (pipelinePhase !== "idle") ? "#10B981" : "#475569"
                                                      }
                                                      strokeWidth={pipelinePhase === "reading_docs" ? "3" : "2"}
                                                      strokeDasharray={pipelinePhase === "reading_docs" ? "7 4" : (pipelinePhase === "idle" ? "5 4" : "none")}
                                                      className={pipelinePhase === "reading_docs" ? "animate-flow-dash" : ""}
                                                      markerEnd={
                                                          pipelinePhase === "reading_docs" ? "url(#arrow-reading-moving)" :
                                                          (pipelinePhase !== "idle") ? "url(#arrow-reading-stopped)" : "url(#arrow-reading-idle)"
                                                      }
                                                  />

                                                  {/* Middle Path */}
                                                  <path
                                                      d="M 0 88 L 155 88"
                                                      fill="none"
                                                      stroke={
                                                          pipelinePhase === "reading_docs" ? "#00D2FF" :
                                                          (pipelinePhase !== "idle") ? "#10B981" : "#475569"
                                                      }
                                                      strokeWidth={pipelinePhase === "reading_docs" ? "3" : "2"}
                                                      strokeDasharray={pipelinePhase === "reading_docs" ? "7 4" : (pipelinePhase === "idle" ? "5 4" : "none")}
                                                      className={pipelinePhase === "reading_docs" ? "animate-flow-dash" : ""}
                                                      markerEnd={
                                                          pipelinePhase === "reading_docs" ? "url(#arrow-reading-moving)" :
                                                          (pipelinePhase !== "idle") ? "url(#arrow-reading-stopped)" : "url(#arrow-reading-idle)"
                                                      }
                                                  />

                                                  {/* Bottom Path */}
                                                  <path
                                                      d="M 0 148 C 90 148, 100 96, 155 96"
                                                      fill="none"
                                                      stroke={
                                                          pipelinePhase === "reading_docs" ? "#00D2FF" :
                                                          (pipelinePhase !== "idle") ? "#10B981" : "#475569"
                                                      }
                                                      strokeWidth={pipelinePhase === "reading_docs" ? "3" : "2"}
                                                      strokeDasharray={pipelinePhase === "reading_docs" ? "7 4" : (pipelinePhase === "idle" ? "5 4" : "none")}
                                                      className={pipelinePhase === "reading_docs" ? "animate-flow-dash" : ""}
                                                      markerEnd={
                                                          pipelinePhase === "reading_docs" ? "url(#arrow-reading-moving)" :
                                                          (pipelinePhase !== "idle") ? "url(#arrow-reading-stopped)" : "url(#arrow-reading-idle)"
                                                      }
                                                  />
                                              </svg>
                                          </div>

                                          {/* COLUMN 2: EXCEL DATABASE (6 Strict Tables Formed) */}
                                          <div className="w-[220px] flex flex-col items-center">
                                              {/* Excel Box */}
                                              <div className={`w-full min-h-[190px] rounded-2xl border transition-all duration-300 p-2.5 flex flex-col justify-between ${
                                                  pipelinePhase === "excel_lag"
                                                      ? "bg-slate-850 border-[#00D2FF] shadow-2xl shadow-[#00D2FF]/30 ring-2 ring-[#00D2FF] scale-[1.03]"
                                                      : (pipelinePhase === "cleaning" || pipelinePhase === "ready_lag" || pipelinePhase === "completed")
                                                      ? "bg-slate-900/95 border-emerald-500/50 shadow-md"
                                                      : pipelinePhase === "reading_docs"
                                                      ? "bg-slate-900/80 border-[#00D2FF]/40 animate-pulse"
                                                      : "bg-slate-900/70 border-slate-800"
                                              }`}>
                                                  <div>
                                                      <div className="flex items-center justify-between mb-1.5">
                                                          <div className="h-6 w-6 rounded-lg bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-xs font-bold text-emerald-400">
                                                              📊
                                                          </div>
                                                          {pipelinePhase === "excel_lag" ? (
                                                              <span className="text-[9px] font-mono font-bold text-[#00D2FF] bg-[#00D2FF]/10 px-2 py-0.5 rounded-full border border-[#00D2FF]/30 animate-pulse">
                                                                  ⏸ 6 Tables Settling
                                                              </span>
                                                          ) : (pipelinePhase === "cleaning" || pipelinePhase === "ready_lag" || pipelinePhase === "completed") ? (
                                                              <span className="text-[9px] font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/30">
                                                                  ✓ 6 Tables Formed
                                                              </span>
                                                          ) : (
                                                              <span className="text-[9px] font-mono text-slate-500 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
                                                                  6 Strict Tables
                                                              </span>
                                                          )}
                                                      </div>

                                                      <div className="text-xs font-bold text-white font-heading">
                                                          Excel Database
                                                      </div>
                                                  </div>

                                                  {/* 6 Strict Relational Tables Display */}
                                                  <div className="bg-slate-950/90 rounded-lg p-1.5 border border-slate-800/80 space-y-1 font-mono text-[8.5px] my-1">
                                                      <div className="flex items-center justify-between text-slate-200">
                                                          <span className="truncate">1. Claims Master Index</span>
                                                          <span className="text-[#00D2FF]">Primary</span>
                                                      </div>
                                                      <div className="flex items-center justify-between text-slate-200">
                                                          <span className="truncate">2. Medical Billing CPTs</span>
                                                          <span className="text-emerald-400">Finance</span>
                                                      </div>
                                                      <div className="flex items-center justify-between text-slate-200">
                                                          <span className="truncate">3. Diagnoses</span>
                                                          <span className="text-[#00D2FF]">Clinical</span>
                                                      </div>
                                                      <div className="flex items-center justify-between text-slate-200">
                                                          <span className="truncate">4. Utilization</span>
                                                          <span className="text-amber-400">Care</span>
                                                      </div>
                                                      <div className="flex items-center justify-between text-slate-200">
                                                          <span className="truncate">5. Biomechanics</span>
                                                          <span className="text-purple-400">Impact</span>
                                                      </div>
                                                      <div className="flex items-center justify-between text-slate-200">
                                                          <span className="truncate">6. Claimant Demographics</span>
                                                          <span className="text-teal-400">Profile</span>
                                                      </div>
                                                  </div>

                                                  <div className="text-[9px] font-mono text-slate-400 flex justify-between items-center pt-1 border-t border-slate-800/70">
                                                      <span>Structured Schema</span>
                                                      <span className="text-[#00D2FF] font-bold">6 Tables</span>
                                                  </div>
                                              </div>

                                              {/* Text Label Underneath */}
                                              <div className="mt-2 text-center">
                                                  <span className="text-base font-black text-white tracking-wide font-heading block">
                                                      Excel Database
                                                  </span>
                                                  <span className="text-[10px] font-mono text-slate-400">
                                                      6 Strict Relational Tables
                                                  </span>
                                              </div>
                                          </div>

                                          {/* CONNECTOR 2: 3 HORIZONTAL ARROWS labeled "Data Cleaning & Masking" */}
                                          <div className="flex-1 flex flex-col items-center justify-center px-1">
                                              {/* Flow Label */}
                                              <div className={`px-2.5 py-1 rounded-full text-xs font-bold font-mono transition-all duration-300 mb-1 flex items-center space-x-1.5 ${
                                                  pipelinePhase === "cleaning"
                                                      ? "bg-amber-500/15 text-amber-300 border border-amber-500/40 shadow-md shadow-amber-500/20 animate-pulse"
                                                      : pipelinePhase === "ready_lag"
                                                      ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                                                      : pipelinePhase === "completed"
                                                      ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                                                      : "bg-slate-800/80 text-slate-400 border border-slate-700/60"
                                              }`}>
                                                  <span>Data Cleaning & Masking</span>
                                                  {pipelinePhase === "cleaning" && (
                                                      <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
                                                  )}
                                                  {pipelinePhase === "ready_lag" && (
                                                      <span className="text-[10px] text-emerald-300 font-mono">(Stopped)</span>
                                                  )}
                                                  {pipelinePhase === "completed" && (
                                                      <span>✓</span>
                                                  )}
                                              </div>

                                              {/* SVG 3 Parallel Horizontal Arrows */}
                                              <svg className="w-full h-44 overflow-visible" viewBox="0 0 160 176" preserveAspectRatio="none">
                                                  <defs>
                                                      <marker id="arrow-cleaning-moving" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="6" markerHeight="6" orient="auto">
                                                          <path d="M 0 1 L 8 5 L 0 9 z" fill="#F59E0B" />
                                                      </marker>
                                                      <marker id="arrow-cleaning-stopped" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="6" markerHeight="6" orient="auto">
                                                          <path d="M 0 1 L 8 5 L 0 9 z" fill="#10B981" />
                                                      </marker>
                                                      <marker id="arrow-cleaning-idle" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="6" markerHeight="6" orient="auto">
                                                          <path d="M 0 1 L 8 5 L 0 9 z" fill="#475569" />
                                                      </marker>
                                                  </defs>

                                                  {/* Arrow 1: Horizontal at y=50 */}
                                                  <line
                                                      x1="0" y1="50" x2="155" y2="50"
                                                      stroke={
                                                          pipelinePhase === "cleaning" ? "#F59E0B" :
                                                          (pipelinePhase === "ready_lag" || pipelinePhase === "completed") ? "#10B981" : "#475569"
                                                      }
                                                      strokeWidth={pipelinePhase === "cleaning" ? "3" : "2"}
                                                      strokeDasharray={pipelinePhase === "cleaning" ? "7 4" : (pipelinePhase === "idle" || pipelinePhase === "reading_docs" || pipelinePhase === "excel_lag" ? "5 4" : "none")}
                                                      className={pipelinePhase === "cleaning" ? "animate-flow-dash" : ""}
                                                      markerEnd={
                                                          pipelinePhase === "cleaning" ? "url(#arrow-cleaning-moving)" :
                                                          (pipelinePhase === "ready_lag" || pipelinePhase === "completed") ? "url(#arrow-cleaning-stopped)" : "url(#arrow-cleaning-idle)"
                                                      }
                                                  />

                                                  {/* Arrow 2: Horizontal at y=88 */}
                                                  <line
                                                      x1="0" y1="88" x2="155" y2="88"
                                                      stroke={
                                                          pipelinePhase === "cleaning" ? "#F59E0B" :
                                                          (pipelinePhase === "ready_lag" || pipelinePhase === "completed") ? "#10B981" : "#475569"
                                                      }
                                                      strokeWidth={pipelinePhase === "cleaning" ? "3" : "2"}
                                                      strokeDasharray={pipelinePhase === "cleaning" ? "7 4" : (pipelinePhase === "idle" || pipelinePhase === "reading_docs" || pipelinePhase === "excel_lag" ? "5 4" : "none")}
                                                      className={pipelinePhase === "cleaning" ? "animate-flow-dash" : ""}
                                                      markerEnd={
                                                          pipelinePhase === "cleaning" ? "url(#arrow-cleaning-moving)" :
                                                          (pipelinePhase === "ready_lag" || pipelinePhase === "completed") ? "url(#arrow-cleaning-stopped)" : "url(#arrow-cleaning-idle)"
                                                      }
                                                  />

                                                  {/* Arrow 3: Horizontal at y=126 */}
                                                  <line
                                                      x1="0" y1="126" x2="155" y2="126"
                                                      stroke={
                                                          pipelinePhase === "cleaning" ? "#F59E0B" :
                                                          (pipelinePhase === "ready_lag" || pipelinePhase === "completed") ? "#10B981" : "#475569"
                                                      }
                                                      strokeWidth={pipelinePhase === "cleaning" ? "3" : "2"}
                                                      strokeDasharray={pipelinePhase === "cleaning" ? "7 4" : (pipelinePhase === "idle" || pipelinePhase === "reading_docs" || pipelinePhase === "excel_lag" ? "5 4" : "none")}
                                                      className={pipelinePhase === "cleaning" ? "animate-flow-dash" : ""}
                                                      markerEnd={
                                                          pipelinePhase === "cleaning" ? "url(#arrow-cleaning-moving)" :
                                                          (pipelinePhase === "ready_lag" || pipelinePhase === "completed") ? "url(#arrow-cleaning-stopped)" : "url(#arrow-cleaning-idle)"
                                                      }
                                                  />
                                              </svg>
                                          </div>

                                          {/* COLUMN 3: MASTER CLAIMS REPOSITORY */}
                                          <div className="w-[230px] flex flex-col items-center">
                                              {/* Ready Box */}
                                              <div className={`w-full min-h-[190px] rounded-2xl border transition-all duration-300 p-2.5 flex flex-col justify-between ${
                                                  pipelinePhase === "ready_lag"
                                                      ? "bg-slate-850 border-emerald-400 shadow-2xl shadow-emerald-500/30 ring-2 ring-emerald-400 scale-[1.03]"
                                                      : pipelinePhase === "completed"
                                                      ? "bg-slate-900/95 border-emerald-500 shadow-xl shadow-emerald-500/20 ring-1 ring-emerald-500/40"
                                                      : "bg-slate-900/70 border-slate-800"
                                              }`}>
                                                  <div>
                                                      <div className="flex items-center justify-between mb-1.5">
                                                          <div className="h-6 w-6 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-xs font-bold text-emerald-400">
                                                              {pipelinePhase === "completed" ? "✓" : "🔒"}
                                                          </div>
                                                          {pipelinePhase === "ready_lag" ? (
                                                              <span className="text-[9px] font-mono font-bold text-emerald-300 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/30 animate-pulse">
                                                                  ⏸ Finalizing...
                                                              </span>
                                                          ) : pipelinePhase === "completed" ? (
                                                              <span className="text-[9px] font-mono font-bold text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded-full border border-emerald-500/40 animate-pulse">
                                                                  ✓ 100% Ready
                                                              </span>
                                                          ) : (
                                                              <span className="text-[9px] font-mono text-slate-500 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
                                                                  Master Store
                                                              </span>
                                                          )}
                                                      </div>

                                                      <div className="text-xs font-bold text-white font-heading">
                                                          Master Claims Repository
                                                      </div>
                                                  </div>

                                                  {/* Highlights */}
                                                  <div className="bg-slate-950/85 rounded-lg p-2 border border-slate-800/80 space-y-1.5 font-sans text-[9.5px] my-1">
                                                      <div className="flex items-center space-x-1.5 text-emerald-400">
                                                          <span className="font-bold">🔒</span>
                                                          <span className="font-semibold truncate">HIPAA PII Data Masking</span>
                                                      </div>
                                                      <div className="flex items-center space-x-1.5 text-blue-300">
                                                          <span className="font-bold">🧹</span>
                                                          <span className="truncate">Cleaned Outputs & Reconciled</span>
                                                      </div>
                                                      <div className="flex items-center space-x-1.5 text-[#00D2FF]">
                                                          <span className="font-bold">⚡</span>
                                                          <span className="truncate">176+ Derived Features Mapped</span>
                                                      </div>
                                                      <div className="flex justify-between items-center text-[9px] font-mono text-slate-400 pt-1 border-t border-slate-800/70">
                                                          <span>Consolidated Database</span>
                                                          <span className="text-emerald-400 font-bold">{claims.length > 0 ? claims.length : 50} Records • 214 Cols</span>
                                                      </div>
                                                  </div>

                                                  <div className="text-[9px] font-mono text-slate-400 flex justify-between items-center pt-1 border-t border-slate-800/70">
                                                      <span>Status</span>
                                                      <span className={pipelinePhase === "completed" ? "text-emerald-400 font-bold" : "text-slate-500"}>
                                                          {pipelinePhase === "completed" ? "Ready to Preview" : "Awaiting Run"}
                                                      </span>
                                                  </div>
                                              </div>

                                              {/* Text Label Underneath */}
                                              <div className="mt-2 text-center">
                                                  <span className="text-base font-black text-white tracking-wide font-heading block">
                                                      Master Repository
                                                  </span>
                                                  <span className="text-[10px] font-mono text-slate-400">
                                                      De-identified & Standardized
                                                  </span>
                                              </div>
                                          </div>

                                      </div>
                                  </div>

                                  {/* INTERACTIVE CONTROLS / PROGRESS BAR / PREVIEW CALLOUT */}
                                  {pipelineStatus === "idle" && (
                                      <div className="mt-4 pt-4 border-t border-slate-800/80 text-center space-y-3">
                                          <div className="text-xs text-slate-300 font-sans max-w-lg mx-auto">
                                              Trigger the autonomous pipeline to ingest 2,700+ case documents into 6 relational tables, execute HIPAA PII masking, clean 176+ derived variables, and unlock dataset preview.
                                          </div>
                                          <button 
                                              onClick={handleRunDocumentPipeline}
                                              className="px-8 py-3 bg-gradient-to-r from-[#0066FF] via-[#00D2FF] to-[#0066FF] hover:from-[#FF6B35] hover:to-[#FF5B35] text-slate-950 font-black text-xs sm:text-sm rounded-xl transition-all shadow-xl shadow-[#0066FF]/25 hover:scale-[1.02] inline-flex items-center space-x-2 font-heading cursor-pointer border border-[#00D2FF]/60"
                                          >
                                              <span>⚡ Process Documents (2,700+ Docs ➔ 6 Strict Tables ➔ Clean & Standardize)</span>
                                              <span>➔</span>
                                          </button>
                                      </div>
                                  )}

                                  {/* LIVE PIPELINE PROGRESS & LOGS STREAM */}
                                  {pipelineStatus === "running" && (
                                      <div className="mt-4 pt-4 border-t border-slate-800/80 space-y-3 animate-fade-in">
                                          <div className="flex justify-between items-center text-xs font-mono">
                                              <div className="flex items-center space-x-2 text-[#00D2FF]">
                                                  <span className="h-2 w-2 rounded-full bg-[#00D2FF] animate-ping" />
                                                  <span className="font-bold">
                                                      {pipelinePhase === "reading_docs" && "Ingesting 2,700+ Docs: Extracting into Excel Database..."}
                                                      {pipelinePhase === "excel_lag" && "⏸ Intermediate Settling: 6 Relational Tables Structured..."}
                                                      {pipelinePhase === "cleaning" && "Data Cleaning & Masking: HIPAA de-identification & variable normalization..."}
                                                      {pipelinePhase === "ready_lag" && "⏸ Finalizing Master Claims Repository..."}
                                                  </span>
                                              </div>
                                              <span className="text-emerald-400 font-bold font-mono">{pipelineProgress}%</span>
                                          </div>

                                          <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800 p-0.5">
                                              <div 
                                                  className="h-full bg-gradient-to-r from-[#0066FF] via-[#00D2FF] to-emerald-400 rounded-full transition-all duration-300"
                                                  style={{ width: `${pipelineProgress}%` }}
                                              />
                                          </div>

                                          <div className="space-y-1 text-slate-300 bg-slate-950 p-3 rounded-xl border border-slate-850 font-mono text-[11px] max-h-28 overflow-y-auto">
                                              {pipelineLogs.map((log, idx) => (
                                                  <div key={idx} className="flex space-x-2">
                                                      <span className="text-emerald-400 font-bold">❯</span>
                                                      <span>{log}</span>
                                                  </div>
                                              ))}
                                          </div>
                                      </div>
                                  )}

                                  {/* PIPELINE COMPLETED - OPTION TO PREVIEW */}
                                  {pipelineStatus === "completed" && (
                                      <div className="mt-4 pt-4 border-t border-emerald-500/30 flex flex-wrap items-center justify-between gap-3 animate-fade-in">
                                          <div className="flex items-center space-x-2.5">
                                              <div className="h-8 w-8 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 text-sm font-bold">
                                                  ✓
                                              </div>
                                              <div>
                                                  <div className="text-xs font-bold text-white">
                                                      Document Ingestion, Relational Structuring & HIPAA Masking Completed Successfully!
                                                  </div>
                                                  <div className="text-[11px] text-slate-400 font-mono">
                                                      2,700+ case documents converted into 6 strict relational tables and cleaned into Master Claims Repository ({claims.length || 50} records, 214 columns).
                                                  </div>
                                              </div>
                                          </div>

                                          <div className="flex items-center space-x-2 font-heading">
                                              <button 
                                                  onClick={() => setShowPreviewTable(true)}
                                                  className="px-6 py-2.5 bg-gradient-to-r from-emerald-400 via-[#00D2FF] to-emerald-400 hover:from-[#FF6B35] hover:to-[#FF5B35] text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-emerald-500/25 hover:scale-[1.02] inline-flex items-center space-x-1.5 cursor-pointer border border-emerald-400/60"
                                              >
                                                  <span>🔍 Preview Dataset</span>
                                                  <span>➔</span>
                                              </button>
                                              
                                              <button 
                                                  onClick={handleTriggerFeatureExtraction}
                                                  className="px-5 py-2.5 bg-slate-800 hover:bg-slate-750 text-white font-bold text-xs rounded-xl transition inline-flex items-center space-x-1.5 cursor-pointer border border-slate-700"
                                              >
                                                  <span>Proceed to Feature Architecture ➔</span>
                                              </button>
                                          </div>
                                      </div>
                                  )}
                              </div>
                          )}
{/* PREVIEW TABLE AND METRICS (WHEN showPreviewTable IS TRUE) */}
                          {showPreviewTable && (
                              <div className="flex flex-col min-h-0 flex-1 space-y-3 animate-fade-in w-full overflow-hidden">
                                  {/* Ingested File Header */}
                                  <div className="shrink-0 bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 shadow-md">
                                      <div className="flex items-center space-x-3">
                                          <div className="h-8 w-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 text-sm font-bold">
                                              ✓
                                          </div>
                                          <div>
                                              <span className="text-xs font-bold text-emerald-400 font-heading block">
                                                  Cleaned Master Claims Repository: Ready
                                              </span>
                                              <span className="text-[11px] text-slate-400 font-mono">
                                                  {rawMetadata.totalRecords || claims.length} Records • {rawMetadata.totalColumns || ingestedColumns.length} Columns Detected
                                              </span>
                                          </div>
                                      </div>

                                      <div className="flex items-center space-x-2 font-heading">
                                          <button 
                                              onClick={() => setShowPreviewTable(false)}
                                              className="px-3.5 py-1.5 bg-slate-850 hover:bg-slate-800 border border-slate-750 hover:border-[#00D2FF] text-slate-200 font-semibold text-xs rounded-lg transition cursor-pointer font-heading flex items-center space-x-1.5 shadow-sm"
                                          >
                                              <span>← Back to Pipeline Flow</span>
                                          </button>

                                          <button 
                                              onClick={handleRunDocumentPipeline}
                                              className="px-3 py-1.5 bg-slate-850 hover:bg-slate-800 border border-slate-750 text-slate-300 font-medium text-xs rounded-lg transition cursor-pointer font-heading"
                                          >
                                              <span>🔄 Re-run Pipeline</span>
                                          </button>

                                          <button 
                                              onClick={handleTriggerFeatureExtraction}
                                              className="px-4 py-2 bg-[#0066FF] hover:bg-[#0052CC] text-white font-bold text-xs rounded-lg transition shadow-md flex items-center space-x-1.5 font-heading cursor-pointer hover:scale-[1.01]"
                                          >
                                              <span>Proceed to Feature Architecture ➔</span>
                                          </button>
                                      </div>
                                  </div>

                                  {/* SUMMARY INFORMATION CARDS ABOVE PREVIEW TABLE */}
                                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 shrink-0 select-none font-heading">
                                      
                                      {/* Card 1: Total Records */}
                                      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 flex flex-col justify-between shadow-sm">
                                          <div className="flex justify-between items-center">
                                              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Records</span>
                                              <span className="text-sm">📊</span>
                                          </div>
                                          <div className="mt-1">
                                              <span className="text-lg font-extrabold text-white font-mono">
                                                  {rawMetadata.totalRecords || claims.length}
                                              </span>
                                              <span className="text-[10px] text-emerald-400 block font-mono">100% Ingested</span>
                                          </div>
                                      </div>

                                      {/* Card 2: Total Columns */}
                                      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 flex flex-col justify-between shadow-sm">
                                          <div className="flex justify-between items-center">
                                              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Columns</span>
                                              <span className="text-sm">📋</span>
                                          </div>
                                          <div className="mt-1">
                                              <span className="text-lg font-extrabold text-[#00D2FF] font-mono">
                                                  {rawMetadata.totalColumns || ingestedColumns.length}
                                              </span>
                                              <span className="text-[10px] text-slate-400 block font-mono">Raw Schema Mapped</span>
                                          </div>
                                      </div>

                                      {/* Card 3: Medical / Clinical Columns */}
                                      <div className="bg-slate-900/90 border border-emerald-500/30 rounded-xl p-3 flex flex-col justify-between shadow-sm">
                                          <div className="flex justify-between items-center">
                                              <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">Clinical Columns</span>
                                              <span className="text-sm">🏥</span>
                                          </div>
                                          <div className="mt-1">
                                              <span className="text-lg font-extrabold text-emerald-400 font-mono">
                                                  {rawMetadata.clinicalColumns.length || 8}
                                              </span>
                                              <span className="text-[10px] text-slate-400 block font-mono truncate" title={rawMetadata.clinicalColumns.join(', ')}>
                                                  ICD, Meds, Surgery
                                              </span>
                                          </div>
                                      </div>

                                      {/* Card 4: Financial Columns */}
                                      <div className="bg-slate-900/90 border border-amber-500/30 rounded-xl p-3 flex flex-col justify-between shadow-sm">
                                          <div className="flex justify-between items-center">
                                              <span className="text-[10px] font-bold text-amber-300 uppercase tracking-wider">Financial Columns</span>
                                              <span className="text-sm">💰</span>
                                          </div>
                                          <div className="mt-1">
                                              <span className="text-lg font-extrabold text-amber-300 font-mono">
                                                  {rawMetadata.financialColumns.length || 4}
                                              </span>
                                              <span className="text-[10px] text-slate-400 block font-mono truncate" title={rawMetadata.financialColumns.join(', ')}>
                                                  Billed, Demand, Paid
                                              </span>
                                          </div>
                                      </div>

                                      {/* Card 5: Claimant Details Columns */}
                                      <div className="bg-slate-900/90 border border-indigo-500/30 rounded-xl p-3 flex flex-col justify-between shadow-sm">
                                          <div className="flex justify-between items-center">
                                              <span className="text-[10px] font-bold text-indigo-300 uppercase tracking-wider">Claimant Columns</span>
                                              <span className="text-sm">👤</span>
                                          </div>
                                          <div className="mt-1">
                                              <span className="text-lg font-extrabold text-indigo-300 font-mono">
                                                  {rawMetadata.claimantColumns.length || 5}
                                              </span>
                                              <span className="text-[10px] text-slate-400 block font-mono truncate" title={rawMetadata.claimantColumns.join(', ')}>
                                          Age, Gender, RTW
                                              </span>
                                          </div>
                                      </div>

                                      {/* Card 6: Data Quality Score */}
                                      <div className="bg-slate-900/90 border border-teal-500/30 rounded-xl p-3 flex flex-col justify-between shadow-sm">
                                          <div className="flex justify-between items-center">
                                              <span className="text-[10px] font-bold text-teal-300 uppercase tracking-wider">Completeness</span>
                                              <span className="text-sm">✨</span>
                                          </div>
                                          <div className="mt-1">
                                              <span className="text-lg font-extrabold text-teal-300 font-mono">
                                                  {rawMetadata.dataQualityPct || 100.0}%
                                              </span>
                                              <span className="text-[10px] text-emerald-400 block font-mono">High Quality</span>
                                          </div>
                                      </div>
                                  </div>

                                  {/* RAW DATA PREVIEW TABLE (COVERS 100% WIDTH, INTERNALLY SCROLLABLE) */}
                                  <div className="flex-1 bg-slate-900 border border-slate-800 rounded-xl p-3 flex flex-col min-h-0 shadow-md w-full overflow-hidden">
                                      <div className="shrink-0 flex justify-between items-center pb-2 border-b border-slate-800">
                                          <div className="flex items-center space-x-2">
                                              <span className="text-xs font-bold text-slate-200 font-heading">Raw Columns Ingested Preview</span>
                                              <span className="text-[10px] text-emerald-400 font-mono bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30 font-bold">
                                                  Showing first {Math.min(claims.length, 50)} records
                                              </span>
                                          </div>

                                          <span className="text-[10px] text-slate-500 font-mono">
                                              Scroll vertically for all 50 rows • Horizontally for all {ingestedColumns.length} fields ➔
                                          </span>
                                      </div>

                                      <div className="flex-1 min-h-0 overflow-auto mt-2 rounded-lg border border-slate-800/80 bg-slate-950/60 shadow-inner w-full">
                                          <table className="w-full text-left border-collapse text-xs font-mono">
                                              <thead>
                                                  <tr className="bg-slate-900 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800 sticky top-0 z-20 font-heading">
                                                      <th className="p-2.5 bg-slate-900 sticky left-0 z-30 shadow-md">#</th>
                                                      {ingestedColumns.map((col, idx) => (
                                                          <th key={idx} className={`p-2.5 whitespace-nowrap bg-slate-900 ${idx === 0 ? "sticky left-[45px] z-30 border-r border-slate-800 shadow-md font-bold text-white" : ""}`}>
                                                              <div className="flex flex-col">
                                                                  <span>{col.name}</span>
                                                                  <span className="text-[8px] text-slate-500 font-mono normal-case">
                                                                      {col.type}
                                                                  </span>
                                                              </div>
                                                          </th>
                                                      ))}
                                                  </tr>
                                               </thead>
                                               <tbody className="divide-y divide-slate-850/70 font-mono text-[11px]">
                                                   {((rawRecords && rawRecords.length > 0) ? rawRecords : claims).slice(0, 50).map((row, rIdx) => (
                                                       <tr key={rIdx} className="hover:bg-slate-850/60 transition group">
                                                           <td className="p-2.5 text-slate-500 font-bold bg-slate-950/90 group-hover:bg-slate-900 sticky left-0 z-10 shadow-md">{rIdx + 1}</td>
                                                           {ingestedColumns.map((col, cIdx) => (
                                                               <td key={cIdx} className={`p-2.5 text-slate-300 whitespace-nowrap max-w-[220px] truncate ${cIdx === 0 ? "sticky left-[45px] z-10 bg-slate-950/90 group-hover:bg-slate-900 font-bold text-white border-r border-slate-850 shadow-md" : ""}`} title={String(row[col.name] || '')}>
                                                                   {String(row[col.name] || '')}
                                                               </td>
                                                           ))}
                                                       </tr>
                                                   ))}
                                               </tbody>
                                           </table>
                                      </div>

                                      <div className="shrink-0 pt-3 flex justify-between items-center border-t border-slate-800/80 mt-2">
                                          <span className="text-[11px] text-slate-400 font-mono">
                                              Dataset: <strong className="text-white font-semibold">Master Claims Repository</strong> • Ready for mathematical complexity calculation
                                          </span>
                                          <button 
                                              onClick={handleTriggerFeatureExtraction}
                                              className="px-5 py-2 bg-gradient-to-r from-[#0066FF] to-[#00D2FF] hover:from-[#FF6B35] hover:to-[#FF5B35] text-slate-950 font-bold text-xs rounded-xl transition shadow-lg inline-flex items-center space-x-1.5 font-heading cursor-pointer hover:scale-[1.02]"
                                          >
                                              <span>Proceed to Feature Architecture ➔</span>
                                          </button>
                                      </div>
                                  </div>
                              </div>
                          )}

                      </div>
                  )}


</div></>
);
}