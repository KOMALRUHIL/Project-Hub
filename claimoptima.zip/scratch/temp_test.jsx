function Test() {
return (
<div>
                                                      </span>
                                                  </div>

                                                  <div 
                                                      className="h-1 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-850 pointer-events-none"
                                                      title={`Outlier Rate: ${domain.outlierPct}%`}
                                                  >
                                                      <div 
                                                          className="h-full bg-gradient-to-r from-amber-500 via-rose-500 to-rose-600 rounded-full transition-all duration-500"
                                                          style={{ width: `${Math.max(3, domain.outlierPct)}%` }}
                                                      />
                                                  </div>
                                              </div>

                                              {/* Main Symmetrical Centered Funnel Bar */}
                                              <div 
                                                  className="h-7.5 rounded-lg bg-gradient-to-r from-[#0052CC] via-[#0066FF] to-[#00D2FF] border border-[#00D2FF]/40 px-3 flex items-center justify-between shadow-md transition-all duration-500 relative overflow-hidden font-mono min-w-[320px]"
                                                  style={{ width: `${domain.funnelWidth}%` }}
                                              >
                                                  <div className="absolute inset-0 bg-white/5 opacity-50 pointer-events-none" />

                                                  {/* Inside Left: Min Score */}
                                                  <span className="text-[10px] font-bold text-slate-100 z-10 opacity-95 shrink-0 bg-slate-950/40 px-1.5 py-0.2 rounded border border-white/10">
                                                      Min: {domain.minPoints} pts
                                                  </span>

                                                  {/* Inside Center: Avg Score & % Share */}
                                                  <div className="flex items-center space-x-1.5 z-10 shrink-0">
                                                      <span className="text-xs font-black text-white drop-shadow">
                                                          Avg: +{domain.avgPoints} pts
                                                      </span>
                                                      <span className="text-[9px] font-bold text-slate-950 bg-[#00D2FF] px-1.5 py-0.2 rounded shadow">
                                                          {domain.sharePct}% Share
                                                      </span>
                                                  </div>

                                                  {/* Inside Right: Max Score */}
                                                  <span className="text-[10px] font-bold text-amber-200 z-10 opacity-95 shrink-0 bg-slate-950/40 px-1.5 py-0.2 rounded border border-amber-300/20">
                                                      Max: {domain.maxPoints} pts
                                                  </span>
                                              </div>

                                          </div>

                                          {/* Right: Clickable Outlier Badge */}
                                          <div className="w-16 shrink-0 flex justify-end">
                                              <button 
                                                  onClick={() => setActiveOutlierDomain(domain)}
                                                  className="bg-slate-950 hover:bg-slate-850 border border-rose-500/40 hover:border-rose-400 px-2 py-1 rounded-lg flex flex-col items-center justify-center transition cursor-pointer shadow-inner w-full group-hover:border-rose-400"
                                                  title="Inspect which features derive outliers in this domain"
                                              >
                                                  <span className="text-[8px] text-slate-400 font-mono">Outliers</span>
                                                  <span className="text-xs font-black text-rose-400 font-mono group-hover:scale-105 transition">
                                                      {domain.outlierPct}% 🔍
                                                  </span>
                                              </button>
                                          </div>

                                      </div>
                                  ))}
                              </div>

                              {/* INLINE ANNOTATIONS LINES */}
                              <div className="shrink-0 pt-1.5 border-t border-slate-800/90 space-y-0.5 text-[11px] font-sans">
                                  <div className="flex items-start space-x-2">
                                      <span className="text-[#00D2FF] font-bold font-heading shrink-0">• Points (+pts) Meaning:</span>
                                      <span className="text-slate-300 leading-tight">
                                          {tierAnnotations.pointsLine}
                                      </span>
                                  </div>

                                  <div className="flex items-start space-x-2">
                                      <span className="text-[#00D2FF] font-bold font-heading shrink-0">• % Share Meaning:</span>
                                      <span className="text-slate-300 leading-tight">
                                          {tierAnnotations.shareLine}
                                      </span>
                                  </div>

                                  <div className="flex items-start space-x-2">
                                      <span className="text-emerald-400 font-bold font-heading shrink-0">• Actionable Triage Route:</span>
                                      <span className="text-emerald-300 font-medium leading-tight">
                                          {tierAnnotations.triageLine}
                                      </span>
                                  </div>
                              </div>

                          </div>

                          {/* OUTLIER FEATURE DRIVER INSPECTOR MODAL */}
                          {activeOutlierDomain && outlierDriverAnalysis && (
                              <div 
                                  className="fixed inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 md:p-6 z-[9999] animate-fade-in select-none"
                                  onClick={(e) => {
                                      if (e.target === e.currentTarget) setActiveOutlierDomain(null);
                                  }}
                              >
                                  <div className="relative bg-slate-900 border border-rose-500/40 rounded-2xl max-w-2xl w-full p-5 shadow-2xl flex flex-col space-y-4 max-h-[85vh] overflow-hidden my-auto">
                                      
                                      {/* Modal Header */}
                                      <div className="shrink-0 flex justify-between items-start border-b border-slate-800 pb-3">
                                          <div className="flex items-center space-x-3">
                                              <div className="h-10 w-10 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-xl text-rose-400">
                                                  🚨
                                              </div>
                                              <div>
                                                  <div className="flex items-center space-x-2">
                                                      <h3 className="text-base font-bold text-white font-heading">
                                                          {outlierDriverAnalysis.domain.title}: Outlier Feature Derivation
                                                      </h3>
                                                      <span className="text-xs font-bold text-rose-400 bg-rose-500/20 border border-rose-500/40 px-2 py-0.5 rounded font-mono">
                                                          &gt;90th Percentile Outliers ({outlierDriverAnalysis.outlierPct}%)
                                                      </span>
                                                  </div>
                                                  <p className="text-xs text-slate-400 mt-0.5 font-sans">
                                                      Showing which specific features derive extreme outlier scores (Domain Score ≥ {outlierDriverAnalysis.p90Cutoff} pts) across {outlierDriverAnalysis.outlierCount} outlier claims.
                                                  </p>
                                              </div>
                                          </div>

                                          <button 
                                              onClick={() => setActiveOutlierDomain(null)}
                                              className="h-8 w-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center text-sm font-bold transition cursor-pointer"
                                          >
                                              ✕
                                          </button>
                                      </div>

                                      {/* Feature Drivers Ranked List */}
                                      <div className="flex-1 min-h-0 overflow-y-auto space-y-2.5 pr-1">
                                          <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block font-heading">
                                              Ranked Feature Contribution Among Outlier Claims:
                                          </span>

                                          <div className="space-y-2">
                                              {outlierDriverAnalysis.featureDrivers.map((fd, idx) => (
                                                  <div key={idx} className="bg-slate-950 border border-slate-850 hover:border-rose-500/40 rounded-xl p-3 space-y-1.5 transition">
                                                      <div className="flex justify-between items-center">
                                                          <div className="flex items-center space-x-2">
                                                              <span className="h-5 w-5 rounded-full bg-slate-800 text-slate-300 text-xs font-bold flex items-center justify-center font-mono">
                                                                  #{idx + 1}
                                                              </span>
                                                              <span className="text-xs font-bold text-white font-heading">
                                                                  {fd.featureName}
                                                              </span>
                                                              {fd.isLLM && (
                                                                  <span className="text-[9px] text-[#00D2FF] bg-[#0066FF]/20 px-1.5 py-0.2 rounded font-mono">
                                                                      LLM Extracted
                                                                  </span>
                                                              )}
                                                          </div>

                                                          <span className={`text-[10px] font-bold font-mono px-2 py-0.5 rounded border ${
                                                              fd.pctAboveAvg >= 60 
                                                                  ? "text-rose-400 bg-rose-500/20 border-rose-500/40" 
                                                                  : fd.pctAboveAvg >= 35 
                                                                  ? "text-amber-400 bg-amber-500/20 border-amber-500/40" 
                                                                  : "text-blue-400 bg-blue-500/20 border-blue-500/40"
                                                          }`}>
                                                              {fd.impactRank}
                                                          </span>
                                                      </div>

                                                      {/* Average Score Outlier Severity Bar */}
                                                                                                             {/* Outlier Rows Exceeding Feature Average */}
                                                       <div className="space-y-1 pt-1">
                                                           <div className="flex justify-between text-[10px] font-mono">
                                                               <span className="text-slate-300">
                                                                   Feature Outlier Average: <strong className="text-amber-300">+{fd.avgPtsOutlier} / {fd.maxPts} pts</strong>
                                                               </span>
                                                               <span className="text-rose-400 font-bold">
                                                                   {fd.countAboveAvg} of {fd.totalOutliers} files ({fd.pctAboveAvg}% &gt; Avg)
                                                               </span>
                                                           </div>
                                                           <div className="h-2.5 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                                                               <div 
                                                                   className="h-full bg-gradient-to-r from-amber-500 via-rose-500 to-rose-600 rounded-full transition-all duration-500"
                                                                   style={{ width: `${Math.max(3, fd.pctAboveAvg)}%` }}
                                                               />
                                                           </div>
                                                       </div>

                                                       <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono pt-0.5">
                                                           <span>Lift over baseline: <strong className="text-emerald-400">{fd.liftRatio}x</strong> higher (+{fd.avgPtsOutlier} vs +{fd.avgPtsCohort} pts cohort avg)</span>
                                                           <span>Cohort baseline avg: +{fd.avgPtsCohort} pts</span>
                                                       </div>
                                                   </div>
                                               ))}
                                           </div>
                                       </div>

                                       {/* Modal Footer */}
                                       <div className="shrink-0 border-t border-slate-800 pt-3 flex justify-between items-center">
                                           <span className="text-[11px] text-slate-500 font-heading">
                                               Features with high outlier prevalence derive the majority of extreme risk in this domain.
                                           </span>
                                           <button 
                                               onClick={() => setActiveOutlierDomain(null)}
                                               className="px-5 py-2 bg-gradient-to-r from-slate-800 to-slate-700 hover:from-slate-700 hover:to-slate-600 text-white font-bold text-xs rounded-xl transition shadow cursor-pointer font-heading"
                                           >
                                               Close Inspector ✕
                                           </button>
                                       </div>

                                   </div>
                               </div>
                           )}

                       </div>
                   )}

                  {/* STEP 5: CLINICAL LINEAGE TREE */}
                  {activeAgent === 1 && agent1SidebarStep === "tree" && (
                      <div className="flex-1 flex flex-col min-h-0 p-3 space-y-2 overflow-hidden select-none font-heading">
                          
                          {/* Tree Header & Scope / Case Switcher */}
                          <div className="shrink-0 bg-slate-900 border border-slate-800 rounded-xl px-4 py-2 flex justify-between items-center shadow-md">
                              <div className="flex items-center space-x-3">
                                  <div className="h-7 w-7 rounded-lg bg-gradient-to-tr from-[#0066FF] to-[#00D2FF] flex items-center justify-center text-slate-950 text-xs font-black shadow">
                                      🌲
                                  </div>
                                  <div>
                                      <div className="flex items-center space-x-2">
                                          <h2 className="text-xs font-bold text-white uppercase tracking-wider">
                                              Hierarchical Lineage: Contribution-Sorted Hierarchy (Domain ➔ Feature ➔ Occurrences)
                                          </h2>
                                          <span className="text-[10px] text-amber-400 font-mono font-bold bg-amber-500/10 px-2 py-0.2 rounded border border-amber-500/30">
                                              {treeViewScope === "cohort" ? "📊 Overall Cohort Aggregation" : `📁 Single Case (${activeTreeClaim?.JOB_ID || "Job"})`}
                                          </span>
                                      </div>
                                      <p className="text-[10px] text-slate-400 font-sans mt-0.2">
                                          {treeViewScope === "cohort" 
                                              ? "Showing average contribution points across all cohort claims. #1 Top paths highlighted." 
                                              : `Showing exact clinical points & record values for Claim ${activeTreeClaim?.JOB_ID}. #1 Top paths highlighted.`}
                                      </p>
                                  </div>
                              </div>

                              <div className="flex items-center space-x-3 font-mono text-xs">
                                  
                                  {/* SCOPE TOGGLE: OVERALL COHORT vs ONE-BY-ONE JOB ID */}
                                  <div className="flex items-center space-x-1 bg-slate-950 border border-slate-800 p-0.5 rounded-lg">
                                      <button 
                                          onClick={() => setTreeViewScope("cohort")}
                                          className={`px-2.5 py-1 rounded-md text-[10px] font-bold transition flex items-center space-x-1 cursor-pointer ${
                                              treeViewScope === "cohort" 
                                                  ? "bg-gradient-to-r from-[#0066FF] to-[#00D2FF] text-slate-950 shadow" 
                                                  : "text-slate-400 hover:text-white"
                                          }`}
                                      >
                                          <span>📊</span>
                                          <span>Overall Cohort</span>
                                      </button>

                                      <button 
                                          onClick={() => setTreeViewScope("job")}
                                          className={`px-2.5 py-1 rounded-md text-[10px] font-bold transition flex items-center space-x-1 cursor-pointer ${
                                              treeViewScope === "job" 
                                                  ? "bg-gradient-to-r from-[#0066FF] to-rose-500 text-slate-950 shadow font-extrabold" 
                                                  : "text-slate-400 hover:text-white"
                                          }`}
                                      >
                                          <span>📁</span>
                                          <span>One-by-One Case</span>
                                      </button>
                                  </div>

                                  {/* CASE SELECTOR DROPDOWN (VISIBLE IN ONE-BY-ONE JOB MODE) */}
                                  {treeViewScope === "job" && (
                                      <div className="flex items-center space-x-1.5 bg-slate-950 border border-slate-800 px-2.5 py-1 rounded-lg animate-fade-in">
                                          <span className="text-[10px] text-slate-500 font-semibold uppercase">Select Job:</span>
                                          <select 
                                              value={selectedTreeClaimId || (activeTreeClaim ? activeTreeClaim.JOB_ID : "")}
                                              onChange={(e) => setSelectedTreeClaimId(e.target.value)}
                                              className="bg-transparent text-[#00D2FF] font-bold text-xs focus:outline-none cursor-pointer"
                                          >
                                              {calculatedClaims.map(c => (
                                                  <option key={c.JOB_ID} value={c.JOB_ID} className="bg-slate-900 text-slate-200">
                                                      {c.JOB_ID} • {c.calculatedComplexity}/100 ({c.calculatedComplexity >= 72 ? "🔥 High" : c.calculatedComplexity <= 45 ? "🟢 Low" : "🔵 Mod"})
                                                  </option>
                                              ))}
                                          </select>
                                      </div>
                                  )}

                                  <button 
                                      onClick={() => setAgent1SidebarStep("neural")}
                                      className="px-3 py-1 bg-gradient-to-r from-[#0066FF] to-[#00D2FF] hover:from-[#0052CC] hover:to-[#00B4D8] text-slate-950 font-bold rounded-lg text-xs transition shadow flex items-center space-x-1 cursor-pointer font-heading hover:scale-[1.02]"
                                  >
                                      <span>6. Neural Graph ➔</span>
                                  </button>
                              </div>
                          </div>

                          {/* 3-COLUMN TREE LAYOUT WITH REAL SVG DYNAMIC CURVY BEZIER ARROWS */}
                          <div 
                              ref={containerRef}
                              className="flex-1 grid grid-cols-12 gap-5 min-h-0 overflow-hidden relative p-1"
                          >
                              <svg 
                                  className="absolute inset-0 w-full h-full pointer-events-none z-20"
                                  style={{ overflow: "visible" }}
                              >
                                  <defs>
                                      <marker 
                                          id="arrow-cyan" 
                                          viewBox="0 0 10 10" 
                                          refX="6" 
                                          refY="5" 
                                          markerWidth="7" 
                                          markerHeight="7" 
                                          orient="auto-start-reverse"
                                      >
                                          <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#00D2FF" />
                                      </marker>

                                      <marker 
                                          id="arrow-orange" 
                                          viewBox="0 0 10 10" 
                                          refX="6" 
                                          refY="5" 
                                          markerWidth="7" 
                                          markerHeight="7" 
                                          orient="auto-start-reverse"
                                      >
                                          <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#FF5B35" />
                                      </marker>

                                      <marker 
                                          id="arrow-amber" 
                                          viewBox="0 0 10 10" 
                                          refX="6" 
                                          refY="5" 
                                          markerWidth="7" 
                                          markerHeight="7" 
                                          orient="auto-start-reverse"
                                      >
                                          <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#F59E0B" />
                                      </marker>

                                      <marker 
                                          id="arrow-subdued" 
                                          viewBox="0 0 10 10" 
                                          refX="6" 
                                          refY="5" 
                                          markerWidth="4" 
                                          markerHeight="4" 
                                          orient="auto-start-reverse"
                                      >
                                          <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#334155" />
                                      </marker>

                                      <linearGradient id="grad-top-path" x1="0%" y1="0%" x2="100%" y2="0%">
                                          <stop offset="0%" stopColor="#0066FF" stopOpacity="1" />
                                          <stop offset="50%" stopColor="#00D2FF" stopOpacity="1" />
                                          <stop offset="100%" stopColor="#FF5B35" stopOpacity="1" />
                                      </linearGradient>

                                      <linearGradient id="grad-top-leaf" x1="0%" y1="0%" x2="100%" y2="0%">
                                          <stop offset="0%" stopColor="#FF5B35" stopOpacity="1" />
                                          <stop offset="50%" stopColor="#F59E0B" stopOpacity="1" />
                                          <stop offset="100%" stopColor="#10B981" stopOpacity="1" />
                                      </linearGradient>
                                  </defs>

                                  {/* L1 -> L2 Connecting Lines */}
                                  {arrowPaths.l1ToL2.map((p) => (
                                      <g key={`l1-${p.id}`}>
                                          {p.isActive && (
                                              <>
                                                  {/* Glowing Halo Shadow */}
                                                  <path 
                                                      d={p.d} 
                                                      fill="none" 
                                                      stroke="#00D2FF" 
                                                      strokeWidth="8" 
                                                      strokeOpacity="0.35" 
                                                      className="animate-pulse"
                                                  />
                                                  <path 
                                                      d={p.d} 
                                                      fill="none" 
                                                      stroke="url(#grad-top-path)" 
                                                      strokeWidth="3.5" 
                                                      markerEnd="url(#arrow-cyan)"
                                                  />
                                              </>
                                          )}
                                          {!p.isActive && (
                                              <path 
                                                  d={p.d} 
                                                  fill="none" 
                                                  stroke="#334155" 
                                                  strokeWidth="1.2" 
                                                  strokeOpacity="0.4"
                                                  strokeDasharray="4,4"
                                                  markerEnd="url(#arrow-subdued)"
                                              />
                                          )}
                                      </g>
                                  ))}

                                  {/* L2 -> L3 Connecting Lines */}
                                  {arrowPaths.l2ToL3.map((p) => (
                                      <g key={`l2-${p.id}`}>
                                          {p.isActive && (
                                              <>
                                                  {/* Glowing Halo Shadow */}
                                                  <path 
                                                      d={p.d} 
                                                      fill="none" 
                                                      stroke="#FF5B35" 
                                                      strokeWidth="7" 
                                                      strokeOpacity="0.3" 
                                                      className="animate-pulse"
                                                  />
                                                  <path 
                                                      d={p.d} 
                                                      fill="none" 
                                                      stroke="url(#grad-top-leaf)" 
                                                      strokeWidth="3" 
                                                      markerEnd="url(#arrow-orange)"
                                                  />
                                              </>
                                          )}
                                          {!p.isActive && (
                                              <path 
                                                  d={p.d} 
                                                  fill="none" 
                                                  stroke="#334155" 
                                                  strokeWidth="1" 
                                                  strokeOpacity="0.3"
                                                  strokeDasharray="3,3"
                                                  markerEnd="url(#arrow-subdued)"
                                              />
                                          )}
                                      </g>
                                  ))}
                              </svg>

                              {/* COLUMN 1 (L1): DOMAINS (SORTED BY POINT CONTRIBUTION) */}
                              <div className="col-span-4 flex flex-col min-h-0 bg-slate-900/80 border border-slate-800 rounded-xl p-2.5 shadow-inner z-10">
                                  <div className="shrink-0 flex justify-between items-center pb-1.5 mb-1.5 border-b border-slate-800">
                                      <div className="flex items-center space-x-1.5 font-heading">
                                          <span className="text-xs font-bold text-[#00D2FF]">L1</span>
                                          <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                                              Domains (Ranked by Impact)
                                          </span>
                                      </div>
                                      <span className="text-[10px] text-slate-500 font-mono">Select root ➔</span>
                                  </div>

                                  <div className="flex-1 overflow-y-auto space-y-1.5 pr-0.5">
                                      {sortedTreeDomains.map((d, rankIdx) => {
                                          const isSelected = activeTreeDomainObj.id === d.id;
                                          const isRank1 = rankIdx === 0;

                                          return (
                                              <div 
                                                  key={d.id}
                                                  ref={el => l1Refs.current[d.id] = el}
                                                  onClick={() => {
                                                      setSelectedTreeDomainId(d.id);
                                                      const feats = d.features || [];
                                                      if (feats.length > 0) setSelectedTreeFeatureId(feats[0].id);
                                                  }}
                                                  className={`rounded-xl p-2.5 transition-all duration-200 cursor-pointer border flex justify-between items-center relative select-none ${
                                                      isSelected 
                                                          ? "bg-slate-900 border-[#00D2FF] text-white ring-2 ring-[#00D2FF]/50 shadow-xl shadow-[#00D2FF]/25 translate-x-1 z-10" 
                                                          : "bg-slate-950/70 border-slate-800/80 text-slate-300 hover:border-slate-700 hover:bg-slate-900/60"
                                                  }`}
                                              >
                                                  <div className="flex items-center space-x-2">
                                                      <span className={`h-5 w-5 rounded-full text-[10px] font-bold flex items-center justify-center font-mono shrink-0 ${
                                                          isRank1 ? "bg-amber-400 text-slate-950 font-black shadow-md shadow-amber-400/40" : "bg-slate-800 text-slate-300"
                                                      }`}>
                                                          {isRank1 ? "👑" : `#${rankIdx + 1}`}
                                                      </span>
                                                      <span className="text-sm">{d.icon}</span>
                                                      <div>
                                                          <div className="flex items-center space-x-1.5">
                                                              <span className="text-[11px] font-bold font-heading block leading-tight">
                                                                  {d.title}
                                                              </span>
                                                              {isRank1 && (
                                                                  <span className="text-[8px] text-amber-300 bg-amber-400/15 border border-amber-400/30 px-1 py-0.2 rounded font-mono font-bold">
                                                                      Top Domain
                                                                  </span>
                                                              )}
                                                          </div>
                                                          <span className="text-[9px] text-slate-400 font-mono">
                                                              {(d.weight * 100).toFixed(0)}% Wt • {d.features.length} Feats
                                                          </span>
                                                      </div>
                                                  </div>

                                                  <div className="text-right">
                                                      <span className="text-[11px] font-extrabold text-[#00D2FF] font-mono block">
                                                          +{d.pts} pts
                                                      </span>
                                                      <span className={`text-[9px] font-bold font-mono ${isSelected ? "text-emerald-400" : "text-slate-600"}`}>
                                                          {isSelected ? "ACTIVE PATH ●" : "Select ❯"}
                                                      </span>
                                                  </div>
                                              </div>
                                          );
                                      })}
                                  </div>
                              </div>

                              {/* COLUMN 2 (L2): FEATURES (SORTED BY POINT CONTRIBUTION - #1 HIGHLIGHTED) */}
                              <div className="col-span-4 flex flex-col min-h-0 bg-slate-900/80 border border-slate-800 rounded-xl p-2.5 shadow-inner relative z-10">
                                  <div className="shrink-0 flex justify-between items-center pb-1.5 mb-1.5 border-b border-slate-800">
                                      <div className="flex items-center space-x-1.5 font-heading">
                                          <span className="text-xs font-bold text-[#00D2FF]">L2</span>
                                          <span className="text-xs font-bold text-slate-200 uppercase tracking-wider truncate max-w-[180px]">
                                              {activeTreeDomainObj.title} (Features)
                                          </span>
                                      </div>
                                      <span className="text-[10px] text-amber-400 font-mono font-bold">#1 Top Highlighted</span>
                                  </div>

                                  <div className="flex-1 overflow-y-auto space-y-1.5 pr-0.5">
                                      {sortedTreeFeatures.map((feat, fRankIdx) => {
                                          const isSelected = activeTreeFeatureObj?.id === feat.id;
                                          const isRank1 = fRankIdx === 0;

                                          return (
                                              <div 
                                                  key={feat.id}
                                                  ref={el => l2Refs.current[feat.id] = el}
                                                  onClick={() => setSelectedTreeFeatureId(feat.id)}
                                                  className={`rounded-xl p-2.5 transition-all duration-200 cursor-pointer border flex flex-col justify-between space-y-1 select-none relative ${
                                                      isSelected 
                                                          ? "bg-slate-900 border-[#00D2FF] text-white ring-2 ring-[#00D2FF]/60 shadow-xl shadow-[#FF5B35]/25 translate-x-1 z-10" 
                                                          : isRank1 
                                                          ? "bg-slate-950 border-amber-500/40 text-slate-200 hover:border-amber-400"
                                                          : "bg-slate-950/70 border-slate-800/80 text-slate-300 hover:border-slate-700 hover:bg-slate-900/60"
                                                  }`}
                                              >
                                                  <div className="flex justify-between items-start space-x-1.5">
                                                      <div className="flex items-center space-x-1.5">
                                                          <span className={`h-4 w-4 rounded-full text-[9px] font-bold flex items-center justify-center font-mono shrink-0 ${
                                                              isRank1 ? "bg-amber-400 text-slate-950 font-black" : "bg-slate-800 text-slate-300"
                                                          }`}>
                                                              {isRank1 ? "👑" : `#${fRankIdx + 1}`}
                                                          </span>
                                                          <span className="text-[11px] font-bold font-heading leading-tight text-slate-100">
                                                              {feat.name}
                                                          </span>
                                                      </div>

                                                      <div className="flex items-center space-x-1 shrink-0">
                                                          <span className="text-[10px] font-extrabold text-[#00D2FF] font-mono">
                                                              +{feat.pts} pts
                                                          </span>
                                                      </div>
                                                  </div>

                                                  {isRank1 && (
                                                      <div className="flex items-center space-x-1">
                                                          <span className="text-[8px] text-amber-300 bg-amber-400/15 border border-amber-400/30 px-1.5 py-0.2 rounded font-mono font-bold">
                                                              👑 #1 Top Contributing Feature in Domain
                                                          </span>
                                                      </div>
                                                  )}

                                                  {feat.rawVal && (
                                                      <div className="text-[9px] text-slate-300 font-mono bg-slate-950/80 px-2 py-0.5 rounded border border-slate-850 truncate" title={String(feat.rawVal)}>
                                                          Value: <strong className="text-[#00D2FF]">{String(feat.rawVal)}</strong>
                                                      </div>
                                                  )}

                                                  <div className="flex justify-between items-center pt-0.5">
                                                      <span className="text-[9px] text-slate-400 font-mono">
                                                          Max: {feat.maxPts} pts {feat.isLLM ? "• ✨ LLM" : ""}
                                                      </span>
                                                      <span className={`text-[9px] font-bold font-mono ${isSelected ? "text-[#00D2FF]" : isRank1 ? "text-amber-400" : "text-slate-500"}`}>
                                                          {isSelected ? "CONNECTED PATH ●" : "View Occurrences ❯"}
                                                      </span>
                                                  </div>
                                              </div>
                                          );
                                      })}
                                  </div>
                              </div>

                              {/* COLUMN 3 (L3): OCCURRENCES & ENTITIES (#1 HIGHEST OCCURRENCE HIGHLIGHTED) */}
                              <div className="col-span-4 flex flex-col min-h-0 bg-slate-900/80 border border-slate-800 rounded-xl p-2.5 shadow-inner z-10">
                                  <div className="shrink-0 flex justify-between items-center pb-1.5 mb-1.5 border-b border-slate-800">
                                      <div className="flex items-center space-x-1.5 font-heading">
                                          <span className="text-xs font-bold text-amber-400">L3</span>
                                          <span className="text-xs font-bold text-slate-200 uppercase tracking-wider truncate max-w-[180px]" title={activeTreeFeatureObj?.name}>
                                              {activeTreeFeatureObj?.name || "Occurrences & Evidence"}
                                          </span>
                                      </div>
                                      <span className="text-[10px] text-amber-400 font-mono font-bold">
                                          {featureOccurrenceData ? `${featureOccurrenceData.activeCount}/${featureOccurrenceData.totalClaims} Files` : "Cohort Occurrences"}
                                      </span>
                                  </div>

                                  {/* Top Occurrence Frequency Banner */}
                                  {featureOccurrenceData && (
                                      <div className="shrink-0 bg-slate-950 border border-amber-500/30 rounded-xl p-2 space-y-1 mb-1 shadow">
                                          <div className="flex justify-between items-center text-[10px] font-mono">
                                              <span className="text-slate-300 font-bold">Cohort Occurrence Rate:</span>
                                              <span className="text-amber-300 font-extrabold">
                                                  {featureOccurrenceData.activeCount} of {featureOccurrenceData.totalClaims} Claims ({featureOccurrenceData.prevalencePct}%)
                                              </span>
                                          </div>
                                          <div className="h-1.5 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                                              <div 
                                                  className="h-full bg-gradient-to-r from-amber-500 to-rose-500 rounded-full transition-all duration-500"
                                                  style={{ width: `${Math.max(4, featureOccurrenceData.prevalencePct)}%` }}
                                              />
                                          </div>
                                      </div>
                                  )}

                                  <div className="flex-1 overflow-y-auto space-y-1.5 pr-0.5">
                                      {featureOccurrenceData?.entities && featureOccurrenceData.entities.length > 0 ? (
                                          featureOccurrenceData.entities.map((ent, eIdx) => {
                                              const isTopEntity = eIdx === 0;

                                              return (
                                                  <div 
                                                      key={eIdx}
                                                      ref={el => l3Refs.current[eIdx] = el}
                                                      onClick={() => setSelectedEvidenceDisease(ent)}
                                                      className={`rounded-xl p-2.5 space-y-1 transition cursor-pointer shadow group select-none relative border ${
                                                          isTopEntity 
                                                              ? "bg-amber-950/25 border-amber-400 ring-2 ring-amber-400/60 shadow-xl shadow-amber-500/20 translate-x-1 z-10" 
                                                              : ent.isPresentInActive 
                                                              ? "bg-slate-900 border-[#00D2FF]/60 ring-1 ring-[#00D2FF]/40" 
                                                              : "bg-slate-950 border-slate-800/90 hover:border-amber-400/50"
                                                      }`}
                                                  >
                                                      <div className="flex justify-between items-start space-x-1.5">
                                                          <div className="flex items-center space-x-1.5">
                                                              <span className={`text-xs ${isTopEntity ? "text-amber-300 font-black" : "text-amber-400"}`}>
                                                                  {isTopEntity ? "👑" : "🍃"}
                                                              </span>
                                                              <span className={`text-[11px] font-bold font-heading leading-tight break-words ${
                                                                  isTopEntity ? "text-amber-200" : "text-white"
                                                              }`}>
                                                                  {ent.name}
                                                              </span>
                                                          </div>

                                                          <span className="text-[9px] text-[#00D2FF] bg-[#0066FF]/20 px-1.5 py-0.2 rounded font-mono border border-[#0066FF]/30 shrink-0 font-bold">
                                                              {ent.count}x ({ent.pct}%)
                                                          </span>
                                                      </div>

                                                      {isTopEntity && (
                                                          <div className="flex items-center space-x-1">
                                                              <span className="text-[8px] text-amber-300 bg-amber-400/20 border border-amber-400/40 px-1.5 py-0.2 rounded font-mono font-bold">
                                                                  👑 #1 Highest Occurring Entity ({ent.count} claims)
                                                              </span>
                                                          </div>
                                                      )}

                                                      {/* Frequency occurrence bar for this specific entity */}
                                                      <div className="space-y-0.5 pt-0.5">
                                                          <div className="h-1.5 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                                                              <div 
                                                                  className={`h-full rounded-full transition-all duration-500 ${
                                                                      isTopEntity ? "bg-gradient-to-r from-amber-400 to-rose-500" : "bg-[#00D2FF]"
                                                                  }`}
                                                                  style={{ width: `${Math.max(5, ent.pct)}%` }}
                                                              />
                                                          </div>
                                                      </div>

                                                      <p className="text-[10px] text-slate-300 font-sans leading-snug">
                                                          {ent.note}
                                                      </p>

                                                      <div className="flex justify-between items-center pt-1 border-t border-slate-850">
                                                          <span className={`text-[8px] px-1.5 py-0.2 rounded font-mono font-bold border ${
                                                              isTopEntity 
                                                                  ? "text-amber-300 bg-amber-500/20 border-amber-500/40" 
                                                                  : ent.isPresentInActive 
                                                                  ? "text-[#00D2FF] bg-[#0066FF]/20 border-[#0066FF]/40" 
                                                                  : "text-slate-400 bg-slate-800 border-slate-700"
                                                          }`}>
                                                              {isTopEntity ? "CONNECTED TOP LEAF ●" : ent.isPresentInActive ? "✓ In Selected Case" : ent.severity}
                                                          </span>
                                                          <span className="text-[9px] text-slate-500 group-hover:text-amber-400 font-bold transition">
                                                              Inspect NLP ➔
                                                          </span>
                                                      </div>
                                                  </div>
                                              );
                                          })
                                      ) : (
                                          <div className="p-4 text-center text-xs text-slate-500 italic">
                                              No occurrence entries for this feature.
                                          </div>
                                      )}
                                  </div>
                              </div>

                          </div>

                          {/* FOOTER NARRATIVE / NLP EVIDENCE INSPECTOR */}
                          {selectedEvidenceDisease && (
                              <div className="shrink-0 bg-slate-900 border border-amber-500/40 rounded-xl p-2.5 flex justify-between items-center shadow-lg animate-slide-in select-none">
                                  <div className="flex items-center space-x-2.5">
                                      <div className="h-6 w-6 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 text-xs font-bold">
                                          ✓
                                      </div>
                                      <div>
                                          <div className="flex items-center space-x-2">
                                              <span className="text-xs font-bold text-white font-heading">
                                                  NLP Entity Inspection: {selectedEvidenceDisease.name}
                                              </span>
                                              <span className="text-[9px] text-amber-400 font-mono bg-amber-500/10 px-2 py-0.2 rounded border border-amber-500/30">
                                                  {selectedEvidenceDisease.count} Occurrences ({selectedEvidenceDisease.pct}% Cohort Prevalence)
                                              </span>
                                          </div>
                                          <p className="text-[10px] text-slate-300 font-sans">
                                              <strong>Clinical Context & Cohort Distribution:</strong> {selectedEvidenceDisease.note}
                                          </p>
                                      </div>
                                  </div>

                                  <button 
                                      onClick={() => setSelectedEvidenceDisease(null)}
                                      className="px-2.5 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs font-bold transition cursor-pointer"
                                  >
                                      Close ✕
                                  </button>
                              </div>
                          )}

                      </div>
                  )}

                  {/* ========================================================================= */}
                  {/* STEP 6: AUTHENTIC POWER BI COMPASS D3 FORCE KNOWLEDGE GRAPH              */}
                  {/* (Ported from KPIDashboardGraph.tsx - 100% Dynamic from Active Dataset)    */}
                  {/* ========================================================================= */}
                  {agent1SidebarStep === "neural" && (() => {
                      return (
                          <D3CompassKnowledgeGraph 
                              calculatedClaims={calculatedClaims}
                              domainFlowData={domainFlowData}
                              cohortIntelligence={cohortIntelligence}
                              defaultScoringWeights={defaultScoringWeights}
                              weights={weights}
                              cohortTopLimit={cohortTopLimit}
                              setCohortTopLimit={setCohortTopLimit}
                              isGraphFullscreen={isGraphFullscreen}
                              setIsGraphFullscreen={setIsGraphFullscreen}
                              setActiveAgent={setActiveAgent}
                              handleDispatchToAgent2={handleDispatchToAgent2}
                              isAgent2Mode={false}
                          />
                      );
                  })()}

</div>
);
}