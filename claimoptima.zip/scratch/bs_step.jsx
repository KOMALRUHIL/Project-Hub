function App() {
return (
<>
                      {/* LEFT SIDEBAR: AGENT 1 STEPS (COLLAPSIBLE & UNIFORM) */}
                      {!isSidebarCollapsed && (
                  <aside className="w-56 bg-slate-900/90 border-r border-slate-800 p-3.5 flex flex-col justify-between shrink-0 select-none shadow-xl transition-all duration-300">
                      <div className="space-y-3">
                          <div className="flex justify-between items-start">
                              <div>
                                  <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block font-heading">
                                      Clinical Complexity Workspace
                                  </span>
                                  <h2 className="text-xs font-bold text-white mt-0.5 font-heading">
                                      Ingestion & Complexity
                                  </h2>
                              </div>
                              <button 
                                  onClick={() => setIsSidebarCollapsed(true)}
                                  className="h-6 w-6 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center text-xs transition cursor-pointer"
                                  title="Collapse Sidebar"
                              >
                                  ◀
                              </button>
                          </div>

                          <nav className="flex flex-col space-y-1 font-heading">
                              <button 
                                  onClick={() => setAgent1SidebarStep("input")}
                                  className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-semibold transition text-left cursor-pointer ${
                                      agent1SidebarStep === "input" 
                                          ? "bg-[#0066FF] text-white shadow-md ring-1 ring-[#0066FF]/50" 
                                          : "bg-slate-950/60 border border-slate-800/80 text-slate-300 hover:bg-slate-850 hover:text-white"
                                  }`}
                              >
                                  <span>1. Ingestion & Preview</span>
                                  {claims.length > 0 && <span className="text-emerald-400 font-bold">✓</span>}
                              </button>

                              <button 
                                  disabled={claims.length === 0}
                                  onClick={() => setAgent1SidebarStep("flowchart")}
                                  className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-semibold transition text-left cursor-pointer disabled:opacity-30 disabled:pointer-events-none ${
                                      agent1SidebarStep === "flowchart" 
                                          ? "bg-[#0066FF] text-white shadow-md ring-1 ring-[#0066FF]/50" 
                                          : "bg-slate-950/60 border border-slate-800/80 text-slate-300 hover:bg-slate-850 hover:text-white"
                                  }`}
                              >
                                  <span>2. Feature Tree</span>
                                  {claims.length > 0 && <span className="text-[#00D2FF] text-[10px] font-mono">8 Col</span>}
                              </button>

                              <button 
                                  disabled={claims.length === 0}
                                  onClick={() => setAgent1SidebarStep("weights")}
                                  className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-semibold transition text-left cursor-pointer disabled:opacity-30 disabled:pointer-events-none ${
                                      agent1SidebarStep === "weights" 
                                          ? "bg-[#0066FF] text-white shadow-md ring-1 ring-[#0066FF]/50" 
                                          : "bg-slate-950/60 border border-slate-800/80 text-slate-300 hover:bg-slate-850 hover:text-white"
                                  }`}
                              >
                                  <span>3. Weights Matrix</span>
                                  {claims.length > 0 && <span className="text-slate-400 text-[10px] font-mono">Matrix</span>}
                              </button>

                              <button 
                                  disabled={claims.length === 0}
                                  onClick={() => setAgent1SidebarStep("scores")}
                                  className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-semibold transition text-left cursor-pointer disabled:opacity-30 disabled:pointer-events-none ${
                                      agent1SidebarStep === "scores" 
                                          ? "bg-[#0066FF] text-white shadow-md ring-1 ring-[#0066FF]/50" 
                                          : "bg-slate-950/60 border border-slate-800/80 text-slate-300 hover:bg-slate-850 hover:text-white"
                                  }`}
                              >
                                  <span>4. Complexity & Funnel</span>
                                  {claims.length > 0 && <span className="text-emerald-400 text-[10px] font-mono font-bold">0-100</span>}
                              </button>

                              <button 
                                  disabled={claims.length === 0}
                                  onClick={() => setAgent1SidebarStep("tree")}
                                  className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-semibold transition text-left cursor-pointer disabled:opacity-30 disabled:pointer-events-none ${
                                      agent1SidebarStep === "tree" 
                                          ? "bg-[#0066FF] text-white shadow-md ring-1 ring-[#0066FF]/50" 
                                          : "bg-slate-950/60 border border-slate-800/80 text-slate-300 hover:bg-slate-850 hover:text-white"
                                  }`}
                              >
                                  <span>5. Clinical Lineage Tree</span>
                                  <span className="text-[9px] font-bold font-mono px-1.5 py-0.2 rounded bg-[#0066FF]/20 text-[#00D2FF]">
                                      L1➔L2➔L3
                                  </span>
                              </button>

                              <button 
                                  disabled={claims.length === 0}
                                  onClick={() => setAgent1SidebarStep("neural")}
                                  className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-semibold transition text-left cursor-pointer disabled:opacity-30 disabled:pointer-events-none ${
                                      agent1SidebarStep === "neural" 
                                          ? "bg-[#0066FF] text-white shadow-md ring-1 ring-[#0066FF]/50" 
                                          : "bg-slate-950/60 border border-slate-800/80 text-slate-300 hover:bg-slate-850 hover:text-white"
                                  }`}
                              >
                                  <span>6. Neural Risk Graph</span>
                                  {claims.length > 0 && <span className="text-[#00D2FF] text-[10px] font-mono">Graph</span>}
                              </button>
                          </nav>
                      </div>

                      {claims.length > 0 ? (
                          <div className="bg-slate-950 p-2.5 rounded-lg border border-emerald-500/30 space-y-1 font-heading">
                              <div className="flex items-center space-x-2">
                                  <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                                  <span className="text-[10px] font-bold text-emerald-400">File Ingested</span>
                              </div>
                              <p className="text-[10px] text-slate-300 font-mono truncate" title={uploadedFileName}>
                                  {uploadedFileName}
                              </p>
                              <div className="text-[9px] text-slate-400 font-mono">
                                  {claims.length} Records • {ingestedColumns.length} Cols
                              </div>
                          </div>
                      ) : (
                          <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-[10px] text-slate-500 italic text-center font-heading">
                              No file inputted yet.
                          </div>
                      )}
                  </aside>
              )}

                      {/* FLOATING EXPAND SIDEBAR BUTTON WHEN COLLAPSED */}
                      {isSidebarCollapsed && (
                          <button 
                              onClick={() => setIsSidebarCollapsed(false)}
                              className="absolute top-2 left-2 z-40 h-8 px-3 rounded-lg bg-slate-900 border border-slate-700 text-slate-200 hover:text-white hover:border-[#00D2FF] shadow-2xl flex items-center space-x-1.5 text-xs font-bold transition cursor-pointer font-heading hover:scale-105"
                              title="Expand Left Navigation Menu"
                          >
                              <span>▶</span>
                              <span className="text-[11px]">Expand Menu</span>
                          </button>
                      )}

                      {/* RIGHT MAIN WORKSPACE FOR AGENT 1 */}
                      <div className="flex-1 flex flex-col min-h-0 bg-slate-950 overflow-hidden relative">
                  
                  {/* STEP 1: FILE INGESTION & DOCUMENT PIPELINE */}
                  {activeAgent === 1 && agent1SidebarStep === "input" && (
                      <div className={`flex-1 flex flex-col min-h-0 p-4 space-y-3 font-heading select-none ${showPreviewTable ? "overflow-hidden" : "overflow-y-auto"}`}>
                          
                          {/* VIEW 1: PIPELINE DIAGRAM & CONTROLS (VANISHES WHEN PREVIEW IS ACTIVE) */}
                          {!showPreviewTable && (
                              <div className="bg-slate-900/95 border border-slate-800/80 rounded-2xl p-5 shadow-2xl backdrop-blur-md relative overflow-hidden select-none">
                                  {/* SVG Keyframe styles for animated flowing dashes */}
                                  <style>{`
                                      @keyframes flowDash {
                                          0% { stroke-dashoffset: 24; }
                                          100% { stroke-dashoffset: 0; }
                                      }
                                      .animate-flow-dash {
                                          animation: flowDash 0.75s linear infinite;
                                      }
                                      @keyframes pulseGlow {
                                          0%, 100% { opacity: 0.85; transform: scale(1); }
                                          50% { opacity: 1; transform: scale(1.02); }
                                      }
                                      .animate-pulse-glow {
                                          animation: pulseGlow 1.8s ease-in-out infinite;
                                      }
                                  `}</style>

                                  {/* Automatic Data Ingestion Flow Header */}
                                  <div className="flex flex-wrap items-center justify-between gap-3 mb-5 pb-4 border-b border-slate-800/70">
                                      <div className="flex items-center space-x-3.5">
                                          <div className={`h-10 w-10 rounded-xl flex items-center justify-center text-base font-black shadow-md transition-all ${
                                              pipelinePhase === "reading_docs" ? "bg-[#00D2FF]/20 text-[#00D2FF] ring-2 ring-[#00D2FF]/50 animate-pulse" :
                                              pipelinePhase === "excel_lag" ? "bg-cyan-500/20 text-cyan-400 ring-2 ring-cyan-400/50" :
                                              pipelinePhase === "cleaning" ? "bg-amber-500/20 text-amber-400 ring-2 ring-amber-400/50 animate-pulse" :
                                              pipelinePhase === "ready_lag" || pipelinePhase === "completed" ? "bg-emerald-500/20 text-emerald-400 ring-2 ring-emerald-500/50" :
                                              "bg-gradient-to-tr from-[#0066FF] to-[#00D2FF] text-slate-950"
                                          }`}>
                                              {pipelinePhase === "reading_docs" ? "1" :
                                               pipelinePhase === "excel_lag" ? "⏸" :
                                               pipelinePhase === "cleaning" ? "2" :
                                               pipelinePhase === "ready_lag" ? "⏸" :
                                               pipelinePhase === "completed" ? "✓" : "⚡"}
                                          </div>
                                          <div>
                                              <div className="flex items-center space-x-2">
                                                  <span className="text-[10px] font-bold text-[#00D2FF] bg-[#00D2FF]/10 border border-[#00D2FF]/30 px-2.5 py-0.5 rounded-full font-mono uppercase tracking-wider">
                                                      Automatic Data Ingestion Flow
                                                  </span>
                                                  <span className="text-[10px] font-mono text-slate-400">
                                                      2,700+ Case Documents ➔ 6 Relational Tables ➔ HIPAA Masking
                                                  </span>
                                              </div>
                                              <h2 className="text-sm sm:text-base font-bold text-white mt-1 font-heading">
                                                  {pipelinePhase === "idle" && "2,700+ Case Documents Ingested ➔ Excel Database ➔ Master Claims Repository"}
                                                  {pipelinePhase === "reading_docs" && "Stage 1: Ingesting 2,700+ Documents — Converting Unstructured Files into Excel Matrix"}
                                                  {pipelinePhase === "excel_lag" && "⏸ Intermediate Settling: 6 Strict Relational Tables Generated"}
                                                  {pipelinePhase === "cleaning" && "Stage 2: Data Cleaning & HIPAA Masking — Normalizing 176+ Derived Variables"}
                                                  {pipelinePhase === "ready_lag" && "⏸ Cleaning Complete — Consolidating Master Claims Repository..."}
                                                  {pipelinePhase === "completed" && "Ingestion & Structuring Complete — Master Claims Repository is 100% Ready!"}
                                              </h2>
                                          </div>
                                      </div>

                                      {/* Top Action Buttons (Preview / Feature Architecture) */}
                                      {pipelineStatus === "completed" && (
                                          <div className="flex items-center space-x-2.5 font-heading">
                                              <button
                                                  onClick={() => setShowPreviewTable(true)}
                                                  className="px-4 py-2 bg-gradient-to-r from-emerald-400 via-[#00D2FF] to-emerald-400 hover:from-[#FF6B35] hover:to-[#FF5B35] text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-emerald-500/20 hover:scale-105 transition flex items-center space-x-1.5 cursor-pointer font-heading border border-emerald-400/50"
                                              >
                                                  <span>🔍 Preview Ingested Dataset</span>
                                                  <span>➔</span>
                                              </button>
                                              <button 
                                                  onClick={handleTriggerFeatureExtraction}
                                                  className="px-4 py-2 bg-[#0066FF] hover:bg-[#0052CC] text-white font-bold text-xs rounded-xl transition shadow-lg flex items-center space-x-1.5 font-heading cursor-pointer hover:scale-[1.02]"
                                              >
                                                  <span>Proceed to Feature Architecture ➔</span>
                                              </button>
                                          </div>
                                      )}
                                  </div>

                                  {/* THE 3-COLUMN DIAGRAM */}
                                  <div className="overflow-x-auto pb-2">
                                      <div className="min-w-[840px] flex items-center justify-between gap-2 px-2 py-3">
                                          
                                          {/* COLUMN 1: DOCS (2,700+ Case Documents Ingested + 3 Sources) */}
                                          <div className="w-[230px] flex flex-col items-center">
                                              {/* Header */}
                                              <div className="flex items-center space-x-2 mb-3">
                                                  <div className="p-1.5 rounded-lg bg-[#0066FF]/15 border border-[#0066FF]/30 text-[#00D2FF]">
                                                      <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                                                          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                                                          <polyline points="14 2 14 8 20 8"></polyline>
                                                          <line x1="16" y1="13" x2="8" y2="13"></line>
                                                          <line x1="16" y1="17" x2="8" y2="17"></line>
                                                      </svg>
                                                  </div>
                                                  <span className="text-lg font-black text-white tracking-wide font-heading">
                                                      Case Documents
                                                  </span>
                                                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-slate-800 text-[#00D2FF] border border-[#00D2FF]/30">
                                                      2,700+ Docs
                                                  </span>
                                              </div>

                                              {/* 3 Stacked Ingestion Boxes */}
                                              <div className="w-full space-y-2.5">
                                                  {/* Box 1: Medical Records */}
                                                  <div className={`p-2.5 rounded-xl border transition-all duration-300 ${
                                                      pipelinePhase === "reading_docs"
                                                          ? "bg-slate-850 border-[#00D2FF] shadow-lg shadow-[#00D2FF]/20 ring-1 ring-[#00D2FF]/50"
                                                          : (pipelinePhase !== "idle")
                                                          ? "bg-slate-900/90 border-emerald-500/40"
                                                          : "bg-slate-900/80 border-slate-800 hover:border-slate-700"
                                                  }`}>
                                                      <div className="flex items-center space-x-2.5">
                                                          <div className="h-7 w-7 rounded-lg bg-[#0066FF]/15 border border-[#0066FF]/30 flex items-center justify-center text-sm">
                                                              📋
                                                          </div>
                                                          <div className="min-w-0 flex-1">
                                                              <div className="text-xs font-bold text-white truncate">Medical Records</div>
                                                              <div className="text-[10px] text-slate-400 truncate">Doctor narratives, ICD-10</div>
                                                          </div>
                                                      </div>
                                                  </div>

                                                  {/* Box 2: Police Reports */}
                                                  <div className={`p-2.5 rounded-xl border transition-all duration-300 ${
                                                      pipelinePhase === "reading_docs"
                                                          ? "bg-slate-850 border-[#00D2FF] shadow-lg shadow-[#00D2FF]/20 ring-1 ring-[#00D2FF]/50"
                                                          : (pipelinePhase !== "idle")
                                                          ? "bg-slate-900/90 border-emerald-500/40"
                                                          : "bg-slate-900/80 border-slate-800 hover:border-slate-700"
                                                  }`}>
                                                      <div className="flex items-center space-x-2.5">
                                                          <div className="h-7 w-7 rounded-lg bg-[#00D2FF]/15 border border-[#00D2FF]/30 flex items-center justify-center text-sm">
                                                              🚔
                                                          </div>
                                                          <div className="min-w-0 flex-1">
                                                              <div className="text-xs font-bold text-white truncate">Police Accident Reports</div>
                                                              <div className="text-[10px] text-slate-400 truncate">Biomechanics, impact speed</div>
                                                          </div>
                                                      </div>
                                                  </div>

                                                  {/* Box 3: Billing Invoices */}
                                                  <div className={`p-2.5 rounded-xl border transition-all duration-300 ${
                                                      pipelinePhase === "reading_docs"
                                                          ? "bg-slate-850 border-[#00D2FF] shadow-lg shadow-[#00D2FF]/20 ring-1 ring-[#00D2FF]/50"
                                                          : (pipelinePhase !== "idle")
                                                          ? "bg-slate-900/90 border-emerald-500/40"
                                                          : "bg-slate-900/80 border-slate-800 hover:border-slate-700"
                                                  }`}>
                                                      <div className="flex items-center space-x-2.5">
                                                          <div className="h-7 w-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-sm">
                                                              🧾
                                                          </div>
                                                          <div className="min-w-0 flex-1">
                                                              <div className="text-xs font-bold text-white truncate">Hospital Billing Invoices</div>
                                                              <div className="text-[10px] text-slate-400 truncate">Line-item CPT codes & fees</div>
                                                          </div>
                                                      </div>
                                                  </div>
                                              </div>

                                              {/* Label Underneath */}
                                              <div className="mt-2 text-center">
                                                  <span className="text-base font-black text-white tracking-wide font-heading block">
                                                      2,700+ Documents
                                                  </span>
                                                  <span className="text-[10px] font-mono text-[#00D2FF]">
                                                      Unstructured Ingestion
                                                  </span>
                                              </div>
                                          </div>

                                          {/* CONNECTOR 1: 3 CONVERGING ARROWS labeled "Extracting data into Excel" */}
                                          <div className="flex-1 flex flex-col items-center justify-center px-1">
                                              {/* Flow Label */}
                                              <div className={`px-2.5 py-1 rounded-full text-xs font-bold font-mono transition-all duration-300 mb-1 flex items-center space-x-1.5 ${
                                                  pipelinePhase === "reading_docs"
                                                      ? "bg-[#00D2FF]/15 text-[#00D2FF] border border-[#00D2FF]/40 shadow-md shadow-[#00D2FF]/20 animate-pulse"
                                                      : pipelinePhase === "excel_lag"
                                                      ? "bg-cyan-500/10 text-cyan-400 border border-cyan-500/30"
                                                      : (pipelinePhase === "cleaning" || pipelinePhase === "ready_lag" || pipelinePhase === "completed")
                                                      ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                                                      : "bg-slate-800/80 text-slate-400 border border-slate-700/60"
                                              }`}>
                                                  <span>Extracting data into Excel</span>
                                                  {pipelinePhase === "reading_docs" && (
                                                      <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#00D2FF] animate-ping" />
                                                  )}
                                                  {pipelinePhase === "excel_lag" && (
                                                      <span className="text-[10px] text-cyan-300 font-mono">(Settled)</span>
                                                  )}
                                                  {(pipelinePhase === "cleaning" || pipelinePhase === "ready_lag" || pipelinePhase === "completed") && (
                                                      <span>✓</span>
                                                  )}
                                              </div>

                                              {/* SVG Curves: 3 converging paths */}
                                              <svg className="w-full h-44 overflow-visible" viewBox="0 0 160 176" preserveAspectRatio="none">
                                                  <defs>
                                                      <marker id="arrow-reading-moving" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="6" markerHeight="6" orient="auto">
                                                          <path d="M 0 1 L 8 5 L 0 9 z" fill="#00D2FF" />
                                                      </marker>
                                                      <marker id="arrow-reading-stopped" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="6" markerHeight="6" orient="auto">
                                                          <path d="M 0 1 L 8 5 L 0 9 z" fill="#10B981" />
                                                      </marker>
                                                      <marker id="arrow-reading-idle" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="6" markerHeight="6" orient="auto">
                                                          <path d="M 0 1 L 8 5 L 0 9 z" fill="#475569" />
                                                      </marker>
                                                  </defs>

                                                  {/* Top Path */}
                                                  <path
                                                      d="M 0 28 C 90 28, 100 80, 155 80"
                                                      fill="none"
                                                      stroke={
                                                          pipelinePhase === "reading_docs" ? "#00D2FF" :
                                                          (pipelinePhase !== "idle") ? "#10B981" : "#475569"
                                                      }
                                                      strokeWidth={pipelinePhase === "reading_docs" ? "3" : "2"}
                                                      strokeDasharray={pipelinePhase === "reading_docs" ? "7 4" : (pipelinePhase === "idle" ? "5 4" : "none")}
                                                      className={pipelinePhase === "reading_docs" ? "animate-flow-dash" : ""}
                                                      markerEnd={
                                                          pipelinePhase === "reading_docs" ? "url(#arrow-reading-moving)" :
                                                          (pipelinePhase !== "idle") ? "url(#arrow-reading-stopped)" : "url(#arrow-reading-idle)"
                                                      }
                                                  />

                                                  {/* Middle Path */}
                                                  <path
                                                      d="M 0 88 L 155 88"
                                                      fill="none"
                                                      stroke={
                                                          pipelinePhase === "reading_docs" ? "#00D2FF" :
                                                          (pipelinePhase !== "idle") ? "#10B981" : "#475569"
                                                      }
                                                      strokeWidth={pipelinePhase === "reading_docs" ? "3" : "2"}
                                                      strokeDasharray={pipelinePhase === "reading_docs" ? "7 4" : (pipelinePhase === "idle" ? "5 4" : "none")}
                                                      className={pipelinePhase === "reading_docs" ? "animate-flow-dash" : ""}
                                                      markerEnd={
                                                          pipelinePhase === "reading_docs" ? "url(#arrow-reading-moving)" :
                                                          (pipelinePhase !== "idle") ? "url(#arrow-reading-stopped)" : "url(#arrow-reading-idle)"
                                                      }
                                                  />

                                                  {/* Bottom Path */}
                                                  <path
                                                      d="M 0 148 C 90 148, 100 96, 155 96"
                                                      fill="none"
                                                      stroke={
                                                          pipelinePhase === "reading_docs" ? "#00D2FF" :
                                                          (pipelinePhase !== "idle") ? "#10B981" : "#475569"
                                                      }
                                                      strokeWidth={pipelinePhase === "reading_docs" ? "3" : "2"}
                                                      strokeDasharray={pipelinePhase === "reading_docs" ? "7 4" : (pipelinePhase === "idle" ? "5 4" : "none")}
                                                      className={pipelinePhase === "reading_docs" ? "animate-flow-dash" : ""}
                                                      markerEnd={
                                                          pipelinePhase === "reading_docs" ? "url(#arrow-reading-moving)" :
                                                          (pipelinePhase !== "idle") ? "url(#arrow-reading-stopped)" : "url(#arrow-reading-idle)"
                                                      }
                                                  />
                                              </svg>
                                          </div>

                                          {/* COLUMN 2: EXCEL DATABASE (6 Strict Tables Formed) */}
                                          <div className="w-[220px] flex flex-col items-center">
                                              {/* Excel Box */}
                                              <div className={`w-full min-h-[190px] rounded-2xl border transition-all duration-300 p-2.5 flex flex-col justify-between ${
                                                  pipelinePhase === "excel_lag"
                                                      ? "bg-slate-850 border-[#00D2FF] shadow-2xl shadow-[#00D2FF]/30 ring-2 ring-[#00D2FF] scale-[1.03]"
                                                      : (pipelinePhase === "cleaning" || pipelinePhase === "ready_lag" || pipelinePhase === "completed")
                                                      ? "bg-slate-900/95 border-emerald-500/50 shadow-md"
                                                      : pipelinePhase === "reading_docs"
                                                      ? "bg-slate-900/80 border-[#00D2FF]/40 animate-pulse"
                                                      : "bg-slate-900/70 border-slate-800"
                                              }`}>
                                                  <div>
                                                      <div className="flex items-center justify-between mb-1.5">
                                                          <div className="h-6 w-6 rounded-lg bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-xs font-bold text-emerald-400">
                                                              📊
                                                          </div>
                                                          {pipelinePhase === "excel_lag" ? (
                                                              <span className="text-[9px] font-mono font-bold text-[#00D2FF] bg-[#00D2FF]/10 px-2 py-0.5 rounded-full border border-[#00D2FF]/30 animate-pulse">
                                                                  ⏸ 6 Tables Settling
                                                              </span>
                                                          ) : (pipelinePhase === "cleaning" || pipelinePhase === "ready_lag" || pipelinePhase === "completed") ? (
                                                              <span className="text-[9px] font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/30">
                                                                  ✓ 6 Tables Formed
                                                              </span>
                                                          ) : (
                                                              <span className="text-[9px] font-mono text-slate-500 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
                                                                  6 Strict Tables
                                                              </span>
                                                          )}
                                                      </div>

                                                      <div className="text-xs font-bold text-white font-heading">
                                                          Excel Database
                                                      </div>
                                                  </div>

                                                  {/* 6 Strict Relational Tables Display */}
                                                  <div className="bg-slate-950/90 rounded-lg p-1.5 border border-slate-800/80 space-y-1 font-mono text-[8.5px] my-1">
                                                      <div className="flex items-center justify-between text-slate-200">
                                                          <span className="truncate">1. Claims Master Index</span>
                                                          <span className="text-[#00D2FF]">Primary</span>
                                                      </div>
                                                      <div className="flex items-center justify-between text-slate-200">
                                                          <span className="truncate">2. Medical Billing CPTs</span>
                                                          <span className="text-emerald-400">Finance</span>
                                                      </div>
                                                      <div className="flex items-center justify-between text-slate-200">
                                                          <span className="truncate">3. Diagnoses</span>
                                                          <span className="text-[#00D2FF]">Clinical</span>
                                                      </div>
                                                      <div className="flex items-center justify-between text-slate-200">
                                                          <span className="truncate">4. Utilization</span>
                                                          <span className="text-amber-400">Care</span>
                                                      </div>
                                                      <div className="flex items-center justify-between text-slate-200">
                                                          <span className="truncate">5. Biomechanics</span>
                                                          <span className="text-purple-400">Impact</span>
                                                      </div>
                                                      <div className="flex items-center justify-between text-slate-200">
                                                          <span className="truncate">6. Claimant Demographics</span>
                                                          <span className="text-teal-400">Profile</span>
                                                      </div>
                                                  </div>

                                                  <div className="text-[9px] font-mono text-slate-400 flex justify-between items-center pt-1 border-t border-slate-800/70">
                                                      <span>Structured Schema</span>
                                                      <span className="text-[#00D2FF] font-bold">6 Tables</span>
                                                  </div>
                                              </div>

                                              {/* Text Label Underneath */}
                                              <div className="mt-2 text-center">
                                                  <span className="text-base font-black text-white tracking-wide font-heading block">
                                                      Excel Database
                                                  </span>
                                                  <span className="text-[10px] font-mono text-slate-400">
                                                      6 Strict Relational Tables
                                                  </span>
                                              </div>
                                          </div>

                                          {/* CONNECTOR 2: 3 HORIZONTAL ARROWS labeled "Data Cleaning & Masking" */}
                                          <div className="flex-1 flex flex-col items-center justify-center px-1">
                                              {/* Flow Label */}
                                              <div className={`px-2.5 py-1 rounded-full text-xs font-bold font-mono transition-all duration-300 mb-1 flex items-center space-x-1.5 ${
                                                  pipelinePhase === "cleaning"
                                                      ? "bg-amber-500/15 text-amber-300 border border-amber-500/40 shadow-md shadow-amber-500/20 animate-pulse"
                                                      : pipelinePhase === "ready_lag"
                                                      ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                                                      : pipelinePhase === "completed"
                                                      ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                                                      : "bg-slate-800/80 text-slate-400 border border-slate-700/60"
                                              }`}>
                                                  <span>Data Cleaning & Masking</span>
                                                  {pipelinePhase === "cleaning" && (
                                                      <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
                                                  )}
                                                  {pipelinePhase === "ready_lag" && (
                                                      <span className="text-[10px] text-emerald-300 font-mono">(Stopped)</span>
                                                  )}
                                                  {pipelinePhase === "completed" && (
                                                      <span>✓</span>
                                                  )}
                                              </div>

                                              {/* SVG 3 Parallel Horizontal Arrows */}
                                              <svg className="w-full h-44 overflow-visible" viewBox="0 0 160 176" preserveAspectRatio="none">
                                                  <defs>
                                                      <marker id="arrow-cleaning-moving" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="6" markerHeight="6" orient="auto">
                                                          <path d="M 0 1 L 8 5 L 0 9 z" fill="#F59E0B" />
                                                      </marker>
                                                      <marker id="arrow-cleaning-stopped" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="6" markerHeight="6" orient="auto">
                                                          <path d="M 0 1 L 8 5 L 0 9 z" fill="#10B981" />
                                                      </marker>
                                                      <marker id="arrow-cleaning-idle" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="6" markerHeight="6" orient="auto">
                                                          <path d="M 0 1 L 8 5 L 0 9 z" fill="#475569" />
                                                      </marker>
                                                  </defs>

                                                  {/* Arrow 1: Horizontal at y=50 */}
                                                  <line
                                                      x1="0" y1="50" x2="155" y2="50"
                                                      stroke={
                                                          pipelinePhase === "cleaning" ? "#F59E0B" :
                                                          (pipelinePhase === "ready_lag" || pipelinePhase === "completed") ? "#10B981" : "#475569"
                                                      }
                                                      strokeWidth={pipelinePhase === "cleaning" ? "3" : "2"}
                                                      strokeDasharray={pipelinePhase === "cleaning" ? "7 4" : (pipelinePhase === "idle" || pipelinePhase === "reading_docs" || pipelinePhase === "excel_lag" ? "5 4" : "none")}
                                                      className={pipelinePhase === "cleaning" ? "animate-flow-dash" : ""}
                                                      markerEnd={
                                                          pipelinePhase === "cleaning" ? "url(#arrow-cleaning-moving)" :
                                                          (pipelinePhase === "ready_lag" || pipelinePhase === "completed") ? "url(#arrow-cleaning-stopped)" : "url(#arrow-cleaning-idle)"
                                                      }
                                                  />

                                                  {/* Arrow 2: Horizontal at y=88 */}
                                                  <line
                                                      x1="0" y1="88" x2="155" y2="88"
                                                      stroke={
                                                          pipelinePhase === "cleaning" ? "#F59E0B" :
                                                          (pipelinePhase === "ready_lag" || pipelinePhase === "completed") ? "#10B981" : "#475569"
                                                      }
                                                      strokeWidth={pipelinePhase === "cleaning" ? "3" : "2"}
                                                      strokeDasharray={pipelinePhase === "cleaning" ? "7 4" : (pipelinePhase === "idle" || pipelinePhase === "reading_docs" || pipelinePhase === "excel_lag" ? "5 4" : "none")}
                                                      className={pipelinePhase === "cleaning" ? "animate-flow-dash" : ""}
                                                      markerEnd={
                                                          pipelinePhase === "cleaning" ? "url(#arrow-cleaning-moving)" :
                                                          (pipelinePhase === "ready_lag" || pipelinePhase === "completed") ? "url(#arrow-cleaning-stopped)" : "url(#arrow-cleaning-idle)"
                                                      }
                                                  />

                                                  {/* Arrow 3: Horizontal at y=126 */}
                                                  <line
                                                      x1="0" y1="126" x2="155" y2="126"
                                                      stroke={
                                                          pipelinePhase === "cleaning" ? "#F59E0B" :
                                                          (pipelinePhase === "ready_lag" || pipelinePhase === "completed") ? "#10B981" : "#475569"
                                                      }
                                                      strokeWidth={pipelinePhase === "cleaning" ? "3" : "2"}
                                                      strokeDasharray={pipelinePhase === "cleaning" ? "7 4" : (pipelinePhase === "idle" || pipelinePhase === "reading_docs" || pipelinePhase === "excel_lag" ? "5 4" : "none")}
                                                      className={pipelinePhase === "cleaning" ? "animate-flow-dash" : ""}
                                                      markerEnd={
                                                          pipelinePhase === "cleaning" ? "url(#arrow-cleaning-moving)" :
                                                          (pipelinePhase === "ready_lag" || pipelinePhase === "completed") ? "url(#arrow-cleaning-stopped)" : "url(#arrow-cleaning-idle)"
                                                      }
                                                  />
                                              </svg>
                                          </div>

                                          {/* COLUMN 3: MASTER CLAIMS REPOSITORY */}
                                          <div className="w-[230px] flex flex-col items-center">
                                              {/* Ready Box */}
                                              <div className={`w-full min-h-[190px] rounded-2xl border transition-all duration-300 p-2.5 flex flex-col justify-between ${
                                                  pipelinePhase === "ready_lag"
                                                      ? "bg-slate-850 border-emerald-400 shadow-2xl shadow-emerald-500/30 ring-2 ring-emerald-400 scale-[1.03]"
                                                      : pipelinePhase === "completed"
                                                      ? "bg-slate-900/95 border-emerald-500 shadow-xl shadow-emerald-500/20 ring-1 ring-emerald-500/40"
                                                      : "bg-slate-900/70 border-slate-800"
                                              }`}>
                                                  <div>
                                                      <div className="flex items-center justify-between mb-1.5">
                                                          <div className="h-6 w-6 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-xs font-bold text-emerald-400">
                                                              {pipelinePhase === "completed" ? "✓" : "🔒"}
                                                          </div>
                                                          {pipelinePhase === "ready_lag" ? (
                                                              <span className="text-[9px] font-mono font-bold text-emerald-300 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/30 animate-pulse">
                                                                  ⏸ Finalizing...
                                                              </span>
                                                          ) : pipelinePhase === "completed" ? (
                                                              <span className="text-[9px] font-mono font-bold text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded-full border border-emerald-500/40 animate-pulse">
                                                                  ✓ 100% Ready
                                                              </span>
                                                          ) : (
                                                              <span className="text-[9px] font-mono text-slate-500 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
                                                                  Master Store
                                                              </span>
                                                          )}
                                                      </div>

                                                      <div className="text-xs font-bold text-white font-heading">
                                                          Master Claims Repository
                                                      </div>
                                                  </div>

                                                  {/* Highlights */}
                                                  <div className="bg-slate-950/85 rounded-lg p-2 border border-slate-800/80 space-y-1.5 font-sans text-[9.5px] my-1">
                                                      <div className="flex items-center space-x-1.5 text-emerald-400">
                                                          <span className="font-bold">🔒</span>
                                                          <span className="font-semibold truncate">HIPAA PII Data Masking</span>
                                                      </div>
                                                      <div className="flex items-center space-x-1.5 text-blue-300">
                                                          <span className="font-bold">🧹</span>
                                                          <span className="truncate">Cleaned Outputs & Reconciled</span>
                                                      </div>
                                                      <div className="flex items-center space-x-1.5 text-[#00D2FF]">
                                                          <span className="font-bold">⚡</span>
                                                          <span className="truncate">176+ Derived Features Mapped</span>
                                                      </div>
                                                      <div className="flex justify-between items-center text-[9px] font-mono text-slate-400 pt-1 border-t border-slate-800/70">
                                                          <span>Consolidated Database</span>
                                                          <span className="text-emerald-400 font-bold">{claims.length > 0 ? claims.length : 50} Records • 214 Cols</span>
                                                      </div>
                                                  </div>

                                                  <div className="text-[9px] font-mono text-slate-400 flex justify-between items-center pt-1 border-t border-slate-800/70">
                                                      <span>Status</span>
                                                      <span className={pipelinePhase === "completed" ? "text-emerald-400 font-bold" : "text-slate-500"}>
                                                          {pipelinePhase === "completed" ? "Ready to Preview" : "Awaiting Run"}
                                                      </span>
                                                  </div>
                                              </div>

                                              {/* Text Label Underneath */}
                                              <div className="mt-2 text-center">
                                                  <span className="text-base font-black text-white tracking-wide font-heading block">
                                                      Master Repository
                                                  </span>
                                                  <span className="text-[10px] font-mono text-slate-400">
                                                      De-identified & Standardized
                                                  </span>
                                              </div>
                                          </div>

                                      </div>
                                  </div>

                                  {/* INTERACTIVE CONTROLS / PROGRESS BAR / PREVIEW CALLOUT */}
                                  {pipelineStatus === "idle" && (
                                      <div className="mt-4 pt-4 border-t border-slate-800/80 text-center space-y-3">
                                          <div className="text-xs text-slate-300 font-sans max-w-lg mx-auto">
                                              Trigger the autonomous pipeline to ingest 2,700+ case documents into 6 relational tables, execute HIPAA PII masking, clean 176+ derived variables, and unlock dataset preview.
                                          </div>
                                          <button 
                                              onClick={handleRunDocumentPipeline}
                                              className="px-8 py-3 bg-gradient-to-r from-[#0066FF] via-[#00D2FF] to-[#0066FF] hover:from-[#FF6B35] hover:to-[#FF5B35] text-slate-950 font-black text-xs sm:text-sm rounded-xl transition-all shadow-xl shadow-[#0066FF]/25 hover:scale-[1.02] inline-flex items-center space-x-2 font-heading cursor-pointer border border-[#00D2FF]/60"
                                          >
                                              <span>⚡ Process Documents (2,700+ Docs ➔ 6 Strict Tables ➔ Clean & Standardize)</span>
                                              <span>➔</span>
                                          </button>
                                      </div>
                                  )}

                                  {/* LIVE PIPELINE PROGRESS & LOGS STREAM */}
                                  {pipelineStatus === "running" && (
                                      <div className="mt-4 pt-4 border-t border-slate-800/80 space-y-3 animate-fade-in">
                                          <div className="flex justify-between items-center text-xs font-mono">
                                              <div className="flex items-center space-x-2 text-[#00D2FF]">
                                                  <span className="h-2 w-2 rounded-full bg-[#00D2FF] animate-ping" />
                                                  <span className="font-bold">
                                                      {pipelinePhase === "reading_docs" && "Ingesting 2,700+ Docs: Extracting into Excel Database..."}
                                                      {pipelinePhase === "excel_lag" && "⏸ Intermediate Settling: 6 Relational Tables Structured..."}
                                                      {pipelinePhase === "cleaning" && "Data Cleaning & Masking: HIPAA de-identification & variable normalization..."}
                                                      {pipelinePhase === "ready_lag" && "⏸ Finalizing Master Claims Repository..."}
                                                  </span>
                                              </div>
                                              <span className="text-emerald-400 font-bold font-mono">{pipelineProgress}%</span>
                                          </div>

                                          <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800 p-0.5">
                                              <div 
                                                  className="h-full bg-gradient-to-r from-[#0066FF] via-[#00D2FF] to-emerald-400 rounded-full transition-all duration-300"
                                                  style={{ width: `${pipelineProgress}%` }}
                                              />
                                          </div>

                                          <div className="space-y-1 text-slate-300 bg-slate-950 p-3 rounded-xl border border-slate-850 font-mono text-[11px] max-h-28 overflow-y-auto">
                                              {pipelineLogs.map((log, idx) => (
                                                  <div key={idx} className="flex space-x-2">
                                                      <span className="text-emerald-400 font-bold">❯</span>
                                                      <span>{log}</span>
                                                  </div>
                                              ))}
                                          </div>
                                      </div>
                                  )}

                                  {/* PIPELINE COMPLETED - OPTION TO PREVIEW */}
                                  {pipelineStatus === "completed" && (
                                      <div className="mt-4 pt-4 border-t border-emerald-500/30 flex flex-wrap items-center justify-between gap-3 animate-fade-in">
                                          <div className="flex items-center space-x-2.5">
                                              <div className="h-8 w-8 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 text-sm font-bold">
                                                  ✓
                                              </div>
                                              <div>
                                                  <div className="text-xs font-bold text-white">
                                                      Document Ingestion, Relational Structuring & HIPAA Masking Completed Successfully!
                                                  </div>
                                                  <div className="text-[11px] text-slate-400 font-mono">
                                                      2,700+ case documents converted into 6 strict relational tables and cleaned into Master Claims Repository ({claims.length || 50} records, 214 columns).
                                                  </div>
                                              </div>
                                          </div>

                                          <div className="flex items-center space-x-2 font-heading">
                                              <button 
                                                  onClick={() => setShowPreviewTable(true)}
                                                  className="px-6 py-2.5 bg-gradient-to-r from-emerald-400 via-[#00D2FF] to-emerald-400 hover:from-[#FF6B35] hover:to-[#FF5B35] text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-emerald-500/25 hover:scale-[1.02] inline-flex items-center space-x-1.5 cursor-pointer border border-emerald-400/60"
                                              >
                                                  <span>🔍 Preview Dataset</span>
                                                  <span>➔</span>
                                              </button>
                                              
                                              <button 
                                                  onClick={handleTriggerFeatureExtraction}
                                                  className="px-5 py-2.5 bg-slate-800 hover:bg-slate-750 text-white font-bold text-xs rounded-xl transition inline-flex items-center space-x-1.5 cursor-pointer border border-slate-700"
                                              >
                                                  <span>Proceed to Feature Architecture ➔</span>
                                              </button>
                                          </div>
                                      </div>
                                  )}
                              </div>
                          )}
{/* PREVIEW TABLE AND METRICS (WHEN showPreviewTable IS TRUE) */}
                          {showPreviewTable && (
                              <div className="flex flex-col min-h-0 flex-1 space-y-3 animate-fade-in w-full overflow-hidden">
                                  {/* Ingested File Header */}
                                  <div className="shrink-0 bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 shadow-md">
                                      <div className="flex items-center space-x-3">
                                          <div className="h-8 w-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 text-sm font-bold">
                                              ✓
                                          </div>
                                          <div>
                                              <span className="text-xs font-bold text-emerald-400 font-heading block">
                                                  Cleaned Master Claims Repository: Ready
                                              </span>
                                              <span className="text-[11px] text-slate-400 font-mono">
                                                  {rawMetadata.totalRecords || claims.length} Records • {rawMetadata.totalColumns || ingestedColumns.length} Columns Detected
                                              </span>
                                          </div>
                                      </div>

                                      <div className="flex items-center space-x-2 font-heading">
                                          <button 
                                              onClick={() => setShowPreviewTable(false)}
                                              className="px-3.5 py-1.5 bg-slate-850 hover:bg-slate-800 border border-slate-750 hover:border-[#00D2FF] text-slate-200 font-semibold text-xs rounded-lg transition cursor-pointer font-heading flex items-center space-x-1.5 shadow-sm"
                                          >
                                              <span>← Back to Pipeline Flow</span>
                                          </button>

                                          <button 
                                              onClick={handleRunDocumentPipeline}
                                              className="px-3 py-1.5 bg-slate-850 hover:bg-slate-800 border border-slate-750 text-slate-300 font-medium text-xs rounded-lg transition cursor-pointer font-heading"
                                          >
                                              <span>🔄 Re-run Pipeline</span>
                                          </button>

                                          <button 
                                              onClick={handleTriggerFeatureExtraction}
                                              className="px-4 py-2 bg-[#0066FF] hover:bg-[#0052CC] text-white font-bold text-xs rounded-lg transition shadow-md flex items-center space-x-1.5 font-heading cursor-pointer hover:scale-[1.01]"
                                          >
                                              <span>Proceed to Feature Architecture ➔</span>
                                          </button>
                                      </div>
                                  </div>

                                  {/* SUMMARY INFORMATION CARDS ABOVE PREVIEW TABLE */}
                                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 shrink-0 select-none font-heading">
                                      
                                      {/* Card 1: Total Records */}
                                      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 flex flex-col justify-between shadow-sm">
                                          <div className="flex justify-between items-center">
                                              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Records</span>
                                              <span className="text-sm">📊</span>
                                          </div>
                                          <div className="mt-1">
                                              <span className="text-lg font-extrabold text-white font-mono">
                                                  {rawMetadata.totalRecords || claims.length}
                                              </span>
                                              <span className="text-[10px] text-emerald-400 block font-mono">100% Ingested</span>
                                          </div>
                                      </div>

                                      {/* Card 2: Total Columns */}
                                      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 flex flex-col justify-between shadow-sm">
                                          <div className="flex justify-between items-center">
                                              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Columns</span>
                                              <span className="text-sm">📋</span>
                                          </div>
                                          <div className="mt-1">
                                              <span className="text-lg font-extrabold text-[#00D2FF] font-mono">
                                                  {rawMetadata.totalColumns || ingestedColumns.length}
                                              </span>
                                              <span className="text-[10px] text-slate-400 block font-mono">Raw Schema Mapped</span>
                                          </div>
                                      </div>

                                      {/* Card 3: Medical / Clinical Columns */}
                                      <div className="bg-slate-900/90 border border-emerald-500/30 rounded-xl p-3 flex flex-col justify-between shadow-sm">
                                          <div className="flex justify-between items-center">
                                              <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">Clinical Columns</span>
                                              <span className="text-sm">🏥</span>
                                          </div>
                                          <div className="mt-1">
                                              <span className="text-lg font-extrabold text-emerald-400 font-mono">
                                                  {rawMetadata.clinicalColumns.length || 8}
                                              </span>
                                              <span className="text-[10px] text-slate-400 block font-mono truncate" title={rawMetadata.clinicalColumns.join(', ')}>
                                                  ICD, Meds, Surgery
                                              </span>
                                          </div>
                                      </div>

                                      {/* Card 4: Financial Columns */}
                                      <div className="bg-slate-900/90 border border-amber-500/30 rounded-xl p-3 flex flex-col justify-between shadow-sm">
                                          <div className="flex justify-between items-center">
                                              <span className="text-[10px] font-bold text-amber-300 uppercase tracking-wider">Financial Columns</span>
                                              <span className="text-sm">💰</span>
                                          </div>
                                          <div className="mt-1">
                                              <span className="text-lg font-extrabold text-amber-300 font-mono">
                                                  {rawMetadata.financialColumns.length || 4}
                                              </span>
                                              <span className="text-[10px] text-slate-400 block font-mono truncate" title={rawMetadata.financialColumns.join(', ')}>
                                                  Billed, Demand, Paid
                                              </span>
                                          </div>
                                      </div>

                                      {/* Card 5: Claimant Details Columns */}
                                      <div className="bg-slate-900/90 border border-indigo-500/30 rounded-xl p-3 flex flex-col justify-between shadow-sm">
                                          <div className="flex justify-between items-center">
                                              <span className="text-[10px] font-bold text-indigo-300 uppercase tracking-wider">Claimant Columns</span>
                                              <span className="text-sm">👤</span>
                                          </div>
                                          <div className="mt-1">
                                              <span className="text-lg font-extrabold text-indigo-300 font-mono">
                                                  {rawMetadata.claimantColumns.length || 5}
                                              </span>
                                              <span className="text-[10px] text-slate-400 block font-mono truncate" title={rawMetadata.claimantColumns.join(', ')}>
                                          Age, Gender, RTW
                                              </span>
                                          </div>
                                      </div>

                                      {/* Card 6: Data Quality Score */}
                                      <div className="bg-slate-900/90 border border-teal-500/30 rounded-xl p-3 flex flex-col justify-between shadow-sm">
                                          <div className="flex justify-between items-center">
                                              <span className="text-[10px] font-bold text-teal-300 uppercase tracking-wider">Completeness</span>
                                              <span className="text-sm">✨</span>
                                          </div>
                                          <div className="mt-1">
                                              <span className="text-lg font-extrabold text-teal-300 font-mono">
                                                  {rawMetadata.dataQualityPct || 100.0}%
                                              </span>
                                              <span className="text-[10px] text-emerald-400 block font-mono">High Quality</span>
                                          </div>
                                      </div>
                                  </div>

                                  {/* RAW DATA PREVIEW TABLE (COVERS 100% WIDTH, INTERNALLY SCROLLABLE) */}
                                  <div className="flex-1 bg-slate-900 border border-slate-800 rounded-xl p-3 flex flex-col min-h-0 shadow-md w-full overflow-hidden">
                                      <div className="shrink-0 flex justify-between items-center pb-2 border-b border-slate-800">
                                          <div className="flex items-center space-x-2">
                                              <span className="text-xs font-bold text-slate-200 font-heading">Raw Columns Ingested Preview</span>
                                              <span className="text-[10px] text-emerald-400 font-mono bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30 font-bold">
                                                  Showing first {Math.min(claims.length, 50)} records
                                              </span>
                                          </div>

                                          <span className="text-[10px] text-slate-500 font-mono">
                                              Scroll vertically for all 50 rows • Horizontally for all {ingestedColumns.length} fields ➔
                                          </span>
                                      </div>

                                      <div className="flex-1 min-h-0 overflow-auto mt-2 rounded-lg border border-slate-800/80 bg-slate-950/60 shadow-inner w-full">
                                          <table className="w-full text-left border-collapse text-xs font-mono">
                                              <thead>
                                                  <tr className="bg-slate-900 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800 sticky top-0 z-20 font-heading">
                                                      <th className="p-2.5 bg-slate-900 sticky left-0 z-30 shadow-md">#</th>
                                                      {ingestedColumns.map((col, idx) => (
                                                          <th key={idx} className={`p-2.5 whitespace-nowrap bg-slate-900 ${idx === 0 ? "sticky left-[45px] z-30 border-r border-slate-800 shadow-md font-bold text-white" : ""}`}>
                                                              <div className="flex flex-col">
                                                                  <span>{col.name}</span>
                                                                  <span className="text-[8px] text-slate-500 font-mono normal-case">
                                                                      {col.type}
                                                                  </span>
                                                              </div>
                                                          </th>
                                                      ))}
                                                  </tr>
                                               </thead>
                                               <tbody className="divide-y divide-slate-850/70 font-mono text-[11px]">
                                                   {((rawRecords && rawRecords.length > 0) ? rawRecords : claims).slice(0, 50).map((row, rIdx) => (
                                                       <tr key={rIdx} className="hover:bg-slate-850/60 transition group">
                                                           <td className="p-2.5 text-slate-500 font-bold bg-slate-950/90 group-hover:bg-slate-900 sticky left-0 z-10 shadow-md">{rIdx + 1}</td>
                                                           {ingestedColumns.map((col, cIdx) => (
                                                               <td key={cIdx} className={`p-2.5 text-slate-300 whitespace-nowrap max-w-[220px] truncate ${cIdx === 0 ? "sticky left-[45px] z-10 bg-slate-950/90 group-hover:bg-slate-900 font-bold text-white border-r border-slate-850 shadow-md" : ""}`} title={String(row[col.name] || '')}>
                                                                   {String(row[col.name] || '')}
                                                               </td>
                                                           ))}
                                                       </tr>
                                                   ))}
                                               </tbody>
                                           </table>
                                      </div>

                                      <div className="shrink-0 pt-3 flex justify-between items-center border-t border-slate-800/80 mt-2">
                                          <span className="text-[11px] text-slate-400 font-mono">
                                              Dataset: <strong className="text-white font-semibold">Master Claims Repository</strong> • Ready for mathematical complexity calculation
                                          </span>
                                          <button 
                                              onClick={handleTriggerFeatureExtraction}
                                              className="px-5 py-2 bg-gradient-to-r from-[#0066FF] to-[#00D2FF] hover:from-[#FF6B35] hover:to-[#FF5B35] text-slate-950 font-bold text-xs rounded-xl transition shadow-lg inline-flex items-center space-x-1.5 font-heading cursor-pointer hover:scale-[1.02]"
                                          >
                                              <span>Proceed to Feature Architecture ➔</span>
                                          </button>
                                      </div>
                                  </div>
                              </div>
                          )}

                      </div>
                  )}

                  {/* STEP 2: FEATURE DERIVATION ARCHITECTURE */}
                  {activeAgent === 1 && agent1SidebarStep === "flowchart" && (
                      <div className="flex-1 flex flex-col min-h-0 p-4 space-y-3 overflow-hidden select-none">
                          <div className="shrink-0 flex justify-between items-center pb-2.5 border-b border-slate-800">
                              <div className="flex items-center space-x-3">
                                  <div className="flex items-center space-x-2">
                                      <span className="h-2.5 w-2.5 rounded-full bg-emerald-400" />
                                      <span className="text-xs font-bold text-white font-heading">
                                          Feature Derivation Architecture
                                      </span>
                                  </div>

                                  <span className="text-[10px] text-[#00D2FF] font-mono bg-[#0066FF]/20 border border-[#0066FF]/40 px-2 py-0.5 rounded font-bold">
                                      41 Features Derived across 8 Domains
                                  </span>
                              </div>

                              <div className="flex items-center space-x-2 font-heading">
                                  <button 
                                      onClick={() => {
                                          setShowAllNodes(!showAllNodes);
                                          setIsLivePlaying(false);
                                      }}
                                      className={`px-3 py-1.5 text-xs font-bold rounded-lg transition border flex items-center space-x-1.5 cursor-pointer font-heading ${
                                          showAllNodes 
                                              ? "bg-emerald-500/20 border-emerald-500 text-emerald-400 shadow-[0_0_10px_rgba(16,185,129,0.3)]" 
                                              : "bg-slate-900 border-slate-700 text-slate-300 hover:text-white hover:border-slate-500"
                                      }`}
                                  >
                                      <span>{showAllNodes ? "✓ All Features Displayed" : "👁️ Display All Features"}</span>
                                  </button>

                                  <button 
                                      onClick={() => setAgent1SidebarStep("weights")}
                                      className="px-4 py-1.5 bg-[#0066FF] hover:bg-[#0052CC] text-white text-xs font-bold rounded-lg transition shadow flex items-center space-x-1.5 cursor-pointer font-heading"
                                  >
                                      <span>Proceed to Weights Matrix ➔</span>
                                  </button>
                              </div>
                          </div>

                          <div className="flex-1 grid grid-cols-8 gap-2.5 min-h-0 overflow-hidden bg-slate-900/60 border border-slate-850 rounded-xl p-3 shadow-inner">
                              {domainFlowData.map((domain, dIdx) => {
                                  const isActiveDomain = activeDomainIndex === dIdx;
                                  const revealedForThisCol = showAllNodes 
                                      ? domain.features.length 
                                      : (revealedCounts && revealedCounts[dIdx] !== undefined ? revealedCounts[dIdx] : domain.features.length);

                                  return (
                                      <div 
                                          key={domain.id} 
                                          onClick={() => {
                                              setActiveDomainIndex(dIdx);
                                              setIsLivePlaying(false);
                                          }}
                                          className="flex flex-col min-h-0 relative cursor-pointer"
                                      >
                                          <div className={`min-h-[46px] shrink-0 rounded-lg px-1.5 py-1 flex flex-col justify-center items-center text-center shadow-md relative z-10 transition-all border font-heading ${
                                              isActiveDomain
                                                  ? "bg-slate-900 border-[#00D2FF] text-white ring-2 ring-[#00D2FF]/40 shadow-lg shadow-[#00D2FF]/20"
                                                  : "bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700"
                                          }`}>
                                              <span className="text-[11px] font-bold leading-tight break-words text-center w-full">
                                                  {domain.title}
                                              </span>
                                              <span className={`text-[9px] font-mono mt-0.5 ${isActiveDomain ? "text-[#00D2FF] font-bold" : "text-slate-500"}`}>
                                                  {domain.features.length} Features
                                              </span>
                                          </div>

                                          <div className="flex-1 flex flex-col justify-around py-1 relative min-h-0 mt-1">
                                              <div className={`absolute top-1 bottom-1 left-[8px] w-0.5 border-l-2 transition-all duration-500 pointer-events-none ${
                                                  isActiveDomain 
                                                      ? "border-[#00D2FF] border-dashed" 
                                                      : revealedForThisCol > 0 
                                                          ? "border-slate-700 border-dashed" 
                                                          : "border-slate-850 border-dashed"
                                              }`} />

                                              {isActiveDomain && isLivePlaying && !showAllNodes && (
                                                  <div className="absolute left-[5.5px] top-1 h-3.5 w-1.5 rounded-full bg-[#00D2FF] animate-pulse shadow-md shadow-[#00D2FF] pointer-events-none" />
                                              )}

                                              {domain.features.map((feat, fIdx) => {
                                                  const isRevealed = showAllNodes || fIdx < revealedForThisCol;
                                                  const isCurrentActiveNode = isActiveDomain && fIdx === (revealedForThisCol - 1) && !showAllNodes;

                                                  if (!isRevealed) {
                                                      return (
                                                          <div key={fIdx} className="relative flex items-center pl-[18px] opacity-20 pointer-events-none">
                                                              <div className="absolute left-[8px] w-[10px] h-0 border-t border-dashed border-slate-800" />
                                                              <div className="w-full bg-slate-950/40 border border-slate-850/60 rounded-md px-2 py-1 min-h-[38px] flex items-center">
                                                                  <span className="text-[9px] text-slate-600 font-mono leading-tight break-words">
                                                                      {feat.name}
                                                                  </span>
                                                              </div>
                                                          </div>
                                                      );
                                                  }

                                                  return (
                                                      <div 
                                                          key={fIdx} 
                                                          className={`relative flex items-center pl-[18px] transition-all duration-500 ${
                                                              isCurrentActiveNode ? "scale-[1.03] z-20" : ""
                                                          }`}
                                                      >
                                                          <div className={`absolute left-[8px] w-[10px] h-0 border-t-2 border-dashed transition-colors duration-300 ${
                                                              isCurrentActiveNode ? "border-[#00D2FF]" : "border-slate-700"
                                                          }`} />

                                                          <div className={`absolute left-[6px] h-2 w-2 rounded-full transition-all duration-300 ${
                                                              isCurrentActiveNode 
                                                                  ? "bg-[#00D2FF] ring-2 ring-[#00D2FF]/60 shadow-sm" 
                                                                  : "bg-slate-700"
                                                          }`} />

                                                          <div className={`w-full rounded-md px-2 py-1.5 shadow transition-all flex flex-col justify-between space-y-0.5 border min-h-[38px] ${
                                                              isCurrentActiveNode 
                                                                  ? "bg-slate-900 border-[#00D2FF] shadow-lg shadow-[#00D2FF]/20 ring-1 ring-[#00D2FF]/50 animate-slide-in" 
                                                                  : "bg-slate-950 border-slate-800 hover:border-slate-700"
                                                          }`}>
                                                              <div className="flex justify-between items-start space-x-1">
                                                                  <span className={`text-[10px] font-bold leading-snug break-words pr-0.5 font-heading ${
                                                                      isCurrentActiveNode ? "text-white" : "text-slate-200"
                                                                  }`}>
                                                                      {feat.name}
                                                                  </span>
                                                                  <span className="text-[10px] text-emerald-400 font-bold shrink-0 self-start ml-0.5">
                                                                      ✓
                                                                  </span>
                                                              </div>

                                                              <div className="pt-0.5 flex items-center justify-between">
                                                                  {feat.isLLM && (
                                                                      <div className="pt-0.5 flex items-center justify-start">
                                                                          <span className={`inline-flex items-center space-x-1 px-1.5 py-0.2 rounded text-[8px] font-bold font-mono tracking-wide ${
                                                                              isCurrentActiveNode 
                                                                                  ? "bg-[#0066FF]/30 text-[#00D2FF] border border-[#00D2FF]/60 animate-pulse" 
                                                                                  : "bg-indigo-500/20 text-indigo-300 border border-indigo-500/40"
                                                                          }`}>
                                                                              <span>✨</span>
                                                                              <span>LLM Extracted</span>
                                                                          </span>
                                                                      </div>
                                                                  )}
                                                              </div>
                                                          </div>
                                                      </div>
                                                  );
                                              })}
                                          </div>
                                      </div>
                                  );
                              })}
                          </div>

                          <div className="shrink-0 pt-1 flex justify-between items-center text-[10px] text-slate-400 font-mono">
                              <span className="text-slate-400">All 41 features mapped into 8 calibrated clinical domains.</span>
                              <span className="text-emerald-400 font-bold">✓ 41 Calibrated Features Ready</span>
                          </div>
                      </div>
                  )}

                  {/* STEP 3: DOMAIN WEIGHTS MATRIX */}
                  {activeAgent === 1 && agent1SidebarStep === "weights" && (
                      <div className="flex-1 flex flex-col min-h-0 p-5 space-y-3.5 overflow-hidden relative">
                          <div className="shrink-0 bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex justify-between items-center shadow-md">
                              <div>
                                  <h2 className="text-sm font-bold text-white font-heading">
                                      Domain Weight Calibration & Direct Weighted Budget Allocation
                                  </h2>
                                  <p className="text-[11px] text-slate-400">
                                      Each domain is scored on a direct 0–100 scale. The total claim complexity is the pure weighted sum of all 8 domains.
                                  </p>
                              </div>

                              <div className="flex items-center space-x-3 font-heading">
                                  <div className="flex items-center space-x-1.5 bg-slate-950 border border-slate-800 p-1 rounded-lg">
                                      <span className="text-[10px] text-slate-500 font-semibold px-1.5">Presets:</span>
                                      <button 
                                          onClick={() => applyPresetWeights("default")}
                                          className="px-2.5 py-1 text-[11px] font-medium rounded hover:bg-slate-800 text-slate-300 transition cursor-pointer"
                                      >
                                          Standard Default
                                      </button>
                                      <button 
                                          onClick={() => applyPresetWeights("balanced")}
                                          className="px-2.5 py-1 text-[11px] font-medium rounded hover:bg-slate-800 text-slate-300 transition cursor-pointer"
                                      >
                                          ⚖️ Balanced
                                      </button>
                                      <button 
                                          onClick={() => applyPresetWeights("clinicalHeavy")}
                                          className="px-2.5 py-1 text-[11px] font-medium rounded hover:bg-slate-800 text-slate-300 transition cursor-pointer"
                                      >
                                          🏥 Clinical Heavy
                                      </button>
                                      <button 
                                          onClick={() => applyPresetWeights("pharmaHeavy")}
                                          className="px-2.5 py-1 text-[11px] font-medium rounded hover:bg-slate-800 text-slate-300 transition cursor-pointer"
                                      >
                                          💊 Pharma Heavy
                                      </button>
                                  </div>

                                  <div className={`px-4 py-1.5 rounded-lg border font-bold text-xs flex items-center space-x-2 font-mono ${
                                      isNot100Percent 
                                          ? "bg-rose-500/20 text-rose-400 border-rose-500/40 animate-pulse" 
                                          : "bg-emerald-500/20 text-emerald-400 border-emerald-500/40"
                                  }`}>
                                      <span>Total Budget:</span>
                                      <span className="text-sm">{(weightsSum * 100).toFixed(0)}%</span>
                                      {isNot100Percent ? <span>(Must = 100%)</span> : <span>✓</span>}
                                  </div>
                              </div>
                          </div>

                          <div className="flex-1 grid grid-cols-4 grid-rows-2 gap-3 min-h-0 overflow-y-auto">
                              {domainFlowData.map((domain) => {
                                  const w = weights[domain.id] || 0;

                                  return (
                                      <div 
                                          key={domain.id} 
                                          className="bg-slate-900 border border-slate-800 hover:border-slate-750 rounded-xl p-3.5 flex flex-col justify-between shadow transition"
                                      >
                                          <div>
                                               <div className="flex justify-between items-center mb-2">
                                                   <div className="flex items-center space-x-2">
                                                       <span className="text-base">{domain.icon}</span>
                                                       <span className="text-xs font-bold text-slate-100 font-heading">
                                                           {domain.title}
                                                       </span>
                                                   </div>
                                                   <div className="flex items-center space-x-1.5 font-mono">
                                                       <span className="text-[10px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded font-bold">
                                                           {domain.features.length} Features
                                                       </span>
                                                       <span className="text-xs font-bold text-[#00D2FF] bg-[#0066FF]/20 border border-[#0066FF]/40 px-2 py-0.5 rounded">
                                                           {(w * 100).toFixed(0)}%
                                                       </span>
                                                   </div>
                                               </div>

                                              <p className="text-[11px] text-slate-300 leading-snug font-sans mb-3">
                                                  {domain.oneLiner}
                                              </p>
                                          </div>

                                          <div className="space-y-2 pt-1 border-t border-slate-800/80">
                                              <input 
                                                  type="range" 
                                                  min="0" 
                                                  max="50" 
                                                  step="5"
                                                  value={Math.round(w * 100)}
                                                  onChange={(e) => {
                                                      const val = parseFloat(e.target.value) / 100;
                                                      setWeights(prev => ({ ...prev, [domain.id]: val }));
                                                  }}
                                                  className="w-full accent-[#0066FF] cursor-pointer"
                                              />

                                              <button 
                                                  onClick={() => setActiveFormulaDomain(domain)}
                                                  className="w-full py-1.5 bg-slate-950 hover:bg-slate-850 text-[#00D2FF] hover:text-white border border-slate-800 hover:border-[#0066FF]/60 rounded-lg text-[10px] font-bold transition flex items-center justify-center space-x-1.5 font-heading cursor-pointer"
                                              >
                                                  <span>📐 View Scoring Formula & Rules</span>
                                                  <span>➔</span>
                                              </button>
                                          </div>
                                      </div>
                                  );
                              })}
                          </div>



                          {/* MASTER DATASET EXPORT ACTION */}
                          <div className="shrink-0 flex items-center justify-between pt-1">
                              <span className="text-xs text-slate-400 font-heading">
                                  Recalculate complexity index across all claims and synchronize master data file.
                              </span>
                              <div className="flex items-center space-x-2">
                                  <button 
                                      onClick={handleDownloadCSV}
                                      className="px-3 py-2 bg-slate-900 hover:bg-slate-850 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold transition flex items-center space-x-1 font-heading cursor-pointer shadow"
                                      title="Download calculated complexity dataset for Power BI"
                                  >
                                      <span>📥 Export Power BI Master CSV</span>
                                  </button>
                                  <button 
                                      onClick={handleRecalculateWeights}
                                      disabled={isNot100Percent}
                                      className="px-6 py-2 bg-gradient-to-r from-[#0066FF] to-[#00D2FF] hover:from-[#FF6B35] hover:to-[#FF5B35] disabled:opacity-30 disabled:pointer-events-none text-slate-950 font-bold text-xs rounded-xl transition shadow-lg shadow-[#FF5B35]/20 flex items-center space-x-2 font-heading cursor-pointer"
                                  >
                                      <span>⚡ Compute Complexity Index & Sync</span>
                                      <span>➔</span>
                                  </button>
                              </div>
                          </div>

                          {/* FORMULA MODAL OVERLAY */}
                          {activeFormulaDomain && (
                              <div 
                                  className="fixed inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 md:p-6 z-[9999] animate-fade-in select-none"
                                  onClick={(e) => {
                                      if (e.target === e.currentTarget) setActiveFormulaDomain(null);
                                  }}
                              >
                                  <div className="relative bg-slate-900 border border-slate-750 rounded-2xl max-w-3xl w-full p-5 md:p-6 shadow-2xl flex flex-col space-y-3.5 max-h-[90vh] overflow-hidden my-auto">
                                      <div className="shrink-0 flex justify-between items-start border-b border-slate-800 pb-3">
                                          <div className="flex items-center space-x-3">
                                              <div className="h-10 w-10 rounded-xl bg-[#0066FF]/10 border border-[#0066FF]/30 flex items-center justify-center text-xl">
                                                  {activeFormulaDomain.icon}
                                              </div>
                                              <div>
                                                  <div className="flex items-center space-x-2">
                                                      <h3 className="text-base font-bold text-white font-heading">
                                                          {activeFormulaDomain.title} Scoring Formula & Lineage
                                                      </h3>
                                                      <span className="text-xs font-bold text-[#00D2FF] bg-[#0066FF]/20 border border-[#0066FF]/40 px-2 py-0.5 rounded font-mono">
                                                          Weight: {((weights[activeFormulaDomain.id] || 0) * 100).toFixed(0)}%
                                                      </span>
                                                  </div>
                                                  <p className="text-xs text-slate-400 mt-0.5">
                                                      {activeFormulaDomain.oneLiner}
                                                  </p>
                                              </div>
                                          </div>

                                          <button 
                                              onClick={() => setActiveFormulaDomain(null)}
                                              className="h-8 w-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center text-sm font-bold transition cursor-pointer"
                                              title="Close Formula Screen"
                                          >
                                              ✕
                                          </button>
                                      </div>

                                      <div className="shrink-0 bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                                          <span className="text-[10px] font-bold text-[#00D2FF] uppercase tracking-wider block font-heading">
                                              Pure Weighted Contribution Formula:
                                          </span>
                                          <div className="text-xs text-white font-mono bg-slate-900/80 px-3 py-1.5 rounded border border-slate-850 leading-relaxed break-words">
                                              {activeFormulaDomain.formulaStr}
                                          </div>
                                      </div>

                                      <div className="flex-1 min-h-0 overflow-y-auto space-y-2.5 pr-1.5">
                                          <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block font-heading">
                                              Calibrated Feature Point Brackets (0–100 Domain Scale):
                                          </span>

                                          <div className="grid grid-cols-2 gap-2.5">
                                              {activeFormulaDomain.ruleTiers?.map((r, idx) => (
                                                  <div key={idx} className="bg-slate-950/70 border border-slate-800 rounded-xl p-3 space-y-1.5">
                                                      <div className="flex justify-between items-center">
                                                          <span className="text-xs font-bold text-slate-100 font-heading">
                                                              {r.feature}
                                                          </span>
                                                      </div>
                                                      <div className="space-y-1 text-[11px] text-slate-400 font-mono">
                                                          {r.tiers.map((tier, tIdx) => (
                                                              <div key={tIdx} className="flex items-center space-x-1.5">
                                                                  <span className="text-[#00D2FF] font-bold">›</span>
                                                                  <span>{tier}</span>
                                                              </div>
                                                          ))}
                                                      </div>
                                                  </div>
                                              ))}
                                          </div>
                                      </div>

                                      <div className="shrink-0 border-t border-slate-800 pt-3 flex justify-between items-center">
                                          <span className="text-[11px] text-slate-500 font-heading">
                                              Direct weighted sum cleanly scales from 0 to 100 without arbitrary multipliers.
                                          </span>
                                          <button 
                                              onClick={() => setActiveFormulaDomain(null)}
                                              className="px-5 py-2 bg-gradient-to-r from-[#0066FF] to-[#0052CC] hover:from-[#0052CC] hover:to-[#0066FF] text-white font-bold text-xs rounded-xl transition shadow cursor-pointer font-heading flex items-center space-x-1.5"
                                          >
                                              <span>Close & Return to Weights</span>
                                              <span>✓</span>
                                          </button>
                                      </div>
                                  </div>
                              </div>
                          )}

                      </div>
                  )}

                  {/* STEP 4: COMPACT FUNNEL + INLINE ANNOTATIONS */}
                  {activeAgent === 1 && agent1SidebarStep === "scores" && (
                      <div className="flex-1 flex flex-col min-h-0 p-3 space-y-2.5 overflow-hidden">
                          
                          {/* 1. TOP CENTERED MAXIMUM COMPLEXITY BANNER */}
                          <div className="shrink-0 bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border border-[#00D2FF]/40 rounded-xl px-4 py-2 shadow-md flex items-center justify-between relative overflow-hidden">
                              <div className="absolute inset-0 bg-[#00D2FF]/5 pointer-events-none" />
                              
                              <div className="flex-1 flex items-center justify-center space-x-2 z-10 font-heading">
                                  <span className="text-sm">⚡</span>
                                  <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                                      Maximum Complexity Score:
                                  </span>
                                  <span className="text-2xl font-black text-[#00D2FF] font-mono tracking-tight ml-1">
                                      {cohortIntelligence.max} / 100
                                  </span>
                                  <span className="text-[11px] text-slate-300 font-mono ml-3 bg-slate-950/80 border border-slate-800 px-3 py-1 rounded-lg shadow-inner">
                                      (Minimum Complexity: <strong className="text-emerald-400">{cohortIntelligence.min}</strong> | Average Complexity: <strong className="text-[#00D2FF]">{cohortIntelligence.avg}</strong> across <strong className="text-white">{cohortIntelligence.totalCount}</strong> Claims)
                                  </span>
                              </div>

                              <div className="z-10 flex items-center space-x-2 shrink-0">
                                  <button 
                                      onClick={handleDownloadCSV}
                                      className="px-2.5 py-1 bg-slate-900/90 hover:bg-slate-800 text-emerald-400 border border-emerald-500/30 font-bold text-[11px] rounded-lg transition flex items-center space-x-1 font-heading cursor-pointer"
                                      title="Export calculated complexity dataset"
                                  >
                                      <span>📥 Download CSV</span>
                                  </button>
                                  <button 
                                      onClick={() => setAgent1SidebarStep("tree")}
                                      className="px-3 py-1 bg-[#0066FF] hover:bg-[#0052CC] text-white font-bold text-xs rounded-lg transition shadow flex items-center space-x-1 font-heading cursor-pointer"
                                  >
                                      <span>5. Lineage Tree ➔</span>
                                  </button>
                                  <button 
                                      onClick={() => setAgent1SidebarStep("neural")}
                                      className="px-3 py-1 bg-gradient-to-r from-[#0066FF] to-[#00D2FF] hover:from-[#0052CC] hover:to-[#00B4D8] text-slate-950 font-bold text-xs rounded-lg transition shadow flex items-center space-x-1 font-heading cursor-pointer"
                                  >
                                      <span>6. Neural Graph ➔</span>
                                  </button>
                              </div>
                          </div>

                          {/* 2. THREE STATISTICALLY ADAPTIVE RISK TIER CARDS (High Risk > 72, Low & Moderate Adaptive) */}
                          <div className="grid grid-cols-3 gap-2.5 shrink-0 select-none font-heading">
                              
                              {/* Low Tier Card */}
                              <div 
                                  onClick={() => setSelectedRiskFilter("low")}
                                  className={`rounded-xl px-3.5 py-2 flex justify-between items-center transition cursor-pointer border ${
                                      selectedRiskFilter === "low" 
                                          ? "bg-slate-900 border-emerald-500 shadow-md ring-2 ring-emerald-500/50 scale-[1.01]" 
                                          : "bg-slate-900/70 border-slate-800 hover:border-slate-700"
                                  }`}
                              >
                                  <div>
                                      <div className="flex items-center space-x-1.5">
                                          <span className="h-2 w-2 rounded-full bg-emerald-400" />
                                          <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">
                                              Low Risk (0 – {cohortIntelligence.lowCutoff}) {selectedRiskFilter === "low" && "• Active"}
                                          </span>
                                      </div>
                                      <div className="flex items-baseline space-x-2 mt-0.5">
                                          <span className="text-lg font-black text-slate-100 font-mono">
                                              {cohortIntelligence.low.pct}%
                                          </span>
                                          <span className="text-[10px] text-slate-400">({cohortIntelligence.low.count} claims • Avg: {cohortIntelligence.low.avg}/100)</span>
                                      </div>
                                  </div>
                                  <span className="text-base">🟢</span>
                              </div>

                              {/* Medium Tier Card */}
                              <div 
                                  onClick={() => setSelectedRiskFilter("medium")}
                                  className={`rounded-xl px-3.5 py-2 flex justify-between items-center transition cursor-pointer border ${
                                      selectedRiskFilter === "medium" 
                                          ? "bg-slate-900 border-blue-500 shadow-md ring-2 ring-blue-500/50 scale-[1.01]" 
                                          : "bg-slate-900/70 border-slate-800 hover:border-slate-700"
                                  }`}
                              >
                                  <div>
                                      <div className="flex items-center space-x-1.5">
                                          <span className="h-2 w-2 rounded-full bg-blue-400" />
                                          <span className="text-[10px] font-bold text-blue-400 uppercase tracking-wider">
                                              Moderate Risk ({cohortIntelligence.lowCutoff + 1} – 72) {selectedRiskFilter === "medium" && "• Active"}
                                          </span>
                                      </div>
                                      <div className="flex items-baseline space-x-2 mt-0.5">
                                          <span className="text-lg font-black text-slate-100 font-mono">
                                              {cohortIntelligence.medium.pct}%
                                          </span>
                                          <span className="text-[10px] text-slate-400">({cohortIntelligence.medium.count} claims • Avg: {cohortIntelligence.medium.avg}/100)</span>
                                      </div>
                                  </div>
                                  <span className="text-base">🔵</span>
                              </div>

                              {/* High Tier Card */}
                              <div 
                                  onClick={() => setSelectedRiskFilter("high")}
                                  className={`rounded-xl px-3.5 py-2 flex justify-between items-center transition cursor-pointer border ${
                                      selectedRiskFilter === "high" 
                                          ? "bg-slate-900 border-[#00D2FF] shadow-md ring-2 ring-[#00D2FF]/50 scale-[1.01]" 
                                          : "bg-slate-900/70 border-slate-800 hover:border-slate-750"
                                  }`}
                              >
                                  <div>
                                      <div className="flex items-center space-x-1.5">
                                          <span className="h-2 w-2 rounded-full bg-[#0066FF] animate-ping" />
                                          <span className="text-[10px] font-bold text-[#00D2FF] uppercase tracking-wider">
                                              High Risk (&gt; 72) {selectedRiskFilter === "high" && "• Active"}
                                          </span>
                                      </div>
                                      <div className="flex items-baseline space-x-2 mt-0.5">
                                          <span className="text-lg font-black text-[#00D2FF] font-mono">
                                              {cohortIntelligence.high.pct}%
                                          </span>
                                          <span className="text-[10px] text-slate-300">({cohortIntelligence.high.count} claims • Avg: {cohortIntelligence.high.avg}/100)</span>
                                      </div>
                                  </div>
                                  <span className="text-base">🔥</span>
                              </div>

                          </div>

                          {/* 3. CASCADING DOMAIN POINT CONTRIBUTION FUNNEL WITH OUTLIER THIN BARS & INSIDE BAR MIN/AVG/MAX */}
                          <div className="flex-1 bg-slate-900 border border-slate-800 rounded-xl p-3 flex flex-col justify-between shadow-md min-h-0 overflow-hidden">
                              
                              <div className="shrink-0 flex justify-between items-center pb-1.5 border-b border-slate-800">
                                  <div className="flex items-center space-x-2">
                                      <span className="text-sm">🌪️</span>
                                      <h3 className="text-xs font-bold text-white font-heading uppercase tracking-wider">
                                          Domain Point Contribution Funnel ({selectedRiskFilter.toUpperCase()} TIER: {activeFilteredRows.length} CLAIMS)
                                      </h3>
                                  </div>

                                  <div className="flex items-center space-x-2">
                                      <div className="flex items-center space-x-1.5 bg-slate-950 border border-slate-800 px-2 py-0.5 rounded-lg text-[10px] font-mono">
                                          <span className="text-slate-500">Weight Preset:</span>
                                          <select 
                                              value={activeWeightPreset}
                                              onChange={(e) => applyPresetWeights(e.target.value)}
                                              className="bg-slate-900 border border-slate-700 text-[#00D2FF] text-[10px] font-bold rounded px-1.5 py-0.5 cursor-pointer focus:outline-none"
                                          >
                                              <option value="default">Standard / Default</option>
                                              <option value="balanced">⚖️ Balanced</option>
                                              <option value="clinicalHeavy">🏥 Clinical Heavy</option>
                                              <option value="pharmaHeavy">💊 Pharma Heavy</option>
                                          </select>
                                      </div>
                                      <div className="flex items-center space-x-1 bg-slate-950 border border-slate-800 p-0.5 rounded-lg font-heading text-[10px]">
                                      <button 
                                          onClick={() => setSelectedRiskFilter("all")}
                                          className={`px-2 py-0.5 rounded transition cursor-pointer ${selectedRiskFilter === "all" ? "bg-slate-800 text-white font-bold" : "text-slate-400 hover:text-slate-200"}`}
                                      >
                                          All ({cohortIntelligence.totalCount})
                                      </button>
                                      <button 
                                          onClick={() => setSelectedRiskFilter("low")}
                                          className={`px-2 py-0.5 rounded transition cursor-pointer ${selectedRiskFilter === "low" ? "bg-emerald-500 text-slate-950 font-bold" : "text-slate-400 hover:text-slate-200"}`}
                                      >
                                          Low ({cohortIntelligence.low.count})
                                      </button>
                                      <button 
                                          onClick={() => setSelectedRiskFilter("medium")}
                                          className={`px-2 py-0.5 rounded transition cursor-pointer ${selectedRiskFilter === "medium" ? "bg-blue-500 text-white font-bold" : "text-slate-400 hover:text-slate-200"}`}
                                      >
                                          Moderate ({cohortIntelligence.medium.count})
                                      </button>
                                      <button 
                                          onClick={() => setSelectedRiskFilter("high")}
                                          className={`px-2 py-0.5 rounded transition cursor-pointer ${selectedRiskFilter === "high" ? "bg-[#0066FF] text-slate-950 font-bold" : "text-slate-400 hover:text-slate-200"}`}
                                      >
                                          High ({cohortIntelligence.high.count})
                                      </button>
                                  </div>
                              </div>

                              {/* 8 CASCADING DOMAIN FUNNEL BARS (SYMMETRICAL INVERTED FUNNEL SHAPE) */}
                              <div className="flex-1 flex flex-col justify-around py-1 space-y-2 select-none min-h-0 overflow-y-auto pr-1">
                                  {segmentDomainFunnel.map((domain) => (
                                      <div key={domain.key} className="flex items-center space-x-3 group">
                                          
                                          {/* Left: Domain Icon & Title */}
                                          <div className="w-44 shrink-0 flex items-center space-x-2 text-xs font-heading">
                                              <span className="text-base">{domain.icon}</span>
                                              <span className="font-bold text-slate-200 text-[11px] truncate" title={domain.title}>
                                                  {domain.title}
                                              </span>
                                          </div>

                                          {/* Center: Horizontally Centered Inverted Funnel Bar */}
                                          <div className="flex-1 flex flex-col items-center justify-center space-y-0.5">
                                              
                                              {/* Outlier Header & Thin Line Centered Above Bar */}
                                              <div 
                                                  className="flex flex-col space-y-0.5 transition-all duration-500 min-w-[320px]"
                                                  style={{ width: `${domain.funnelWidth}%` }}
                                              >
                                                  <div className="flex items-center justify-between text-[8.5px] font-mono px-0.5 text-slate-400">
                                                      <span className="flex items-center space-x-1 truncate">
                                                          <span className="h-1.5 w-1.5 rounded-full bg-rose-500" />
                                                          <span>Outliers: <strong className="text-rose-400">{domain.outlierPct}%</strong> (≥ {domain.domainOutlierCutoff} pts)</span>
                                                      </span>
                                                      <span className="text-slate-500 hidden md:inline text-[8px]">
                                                          Click right box to inspect ➔
                                                      </span>
                                                  </div>

                                                  <div 
                                                      className="h-1 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-850 pointer-events-none"
                                                      title={`Outlier Rate: ${domain.outlierPct}%`}
                                                  >
                                                      <div 
                                                          className="h-full bg-gradient-to-r from-amber-500 via-rose-500 to-rose-600 rounded-full transition-all duration-500"
                                                          style={{ width: `${Math.max(3, domain.outlierPct)}%` }}
                                                      />
                                                  </div>
                                              </div>

                                              {/* Main Symmetrical Centered Funnel Bar */}
                                              <div 
                                                  className="h-7.5 rounded-lg bg-gradient-to-r from-[#0052CC] via-[#0066FF] to-[#00D2FF] border border-[#00D2FF]/40 px-3 flex items-center justify-between shadow-md transition-all duration-500 relative overflow-hidden font-mono min-w-[320px]"
                                                  style={{ width: `${domain.funnelWidth}%` }}
                                              >
                                                  <div className="absolute inset-0 bg-white/5 opacity-50 pointer-events-none" />

                                                  {/* Inside Left: Min Score */}
                                                  <span className="text-[10px] font-bold text-slate-100 z-10 opacity-95 shrink-0 bg-slate-950/40 px-1.5 py-0.2 rounded border border-white/10">
                                                      Min: {domain.minPoints} pts
                                                  </span>

                                                  {/* Inside Center: Avg Score & % Share */}
                                                  <div className="flex items-center space-x-1.5 z-10 shrink-0">
                                                      <span className="text-xs font-black text-white drop-shadow">
                                                          Avg: +{domain.avgPoints} pts
                                                      </span>
                                                      <span className="text-[9px] font-bold text-slate-950 bg-[#00D2FF] px-1.5 py-0.2 rounded shadow">
                                                          {domain.sharePct}% Share
                                                      </span>
                                                  </div>

                                                  {/* Inside Right: Max Score */}
                                                  <span className="text-[10px] font-bold text-amber-200 z-10 opacity-95 shrink-0 bg-slate-950/40 px-1.5 py-0.2 rounded border border-amber-300/20">
                                                      Max: {domain.maxPoints} pts
                                                  </span>
                                              </div>

                                          </div>

                                          {/* Right: Clickable Outlier Badge */}
                                          <div className="w-16 shrink-0 flex justify-end">
                                              <button 
                                                  onClick={() => setActiveOutlierDomain(domain)}
                                                  className="bg-slate-950 hover:bg-slate-850 border border-rose-500/40 hover:border-rose-400 px-2 py-1 rounded-lg flex flex-col items-center justify-center transition cursor-pointer shadow-inner w-full group-hover:border-rose-400"
                                                  title="Inspect which features derive outliers in this domain"
                                              >
                                                  <span className="text-[8px] text-slate-400 font-mono">Outliers</span>
                                                  <span className="text-xs font-black text-rose-400 font-mono group-hover:scale-105 transition">
                                                      {domain.outlierPct}% 🔍
                                                  </span>
                                              </button>
                                          </div>

                                      </div>
                                  ))}
                              </div>

                              {/* INLINE ANNOTATIONS LINES */}
                              <div className="shrink-0 pt-1.5 border-t border-slate-800/90 space-y-0.5 text-[11px] font-sans">
                                  <div className="flex items-start space-x-2">
                                      <span className="text-[#00D2FF] font-bold font-heading shrink-0">• Points (+pts) Meaning:</span>
                                      <span className="text-slate-300 leading-tight">
                                          {tierAnnotations.pointsLine}
                                      </span>
                                  </div>

                                  <div className="flex items-start space-x-2">
                                      <span className="text-[#00D2FF] font-bold font-heading shrink-0">• % Share Meaning:</span>
                                      <span className="text-slate-300 leading-tight">
                                          {tierAnnotations.shareLine}
                                      </span>
                                  </div>

                                  <div className="flex items-start space-x-2">
                                      <span className="text-emerald-400 font-bold font-heading shrink-0">• Actionable Triage Route:</span>
                                      <span className="text-emerald-300 font-medium leading-tight">
                                          {tierAnnotations.triageLine}
                                      </span>
                                  </div>
                              </div>

                          </div>

                          {/* OUTLIER FEATURE DRIVER INSPECTOR MODAL */}
                          {activeOutlierDomain && outlierDriverAnalysis && (
                              <div 
                                  className="fixed inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 md:p-6 z-[9999] animate-fade-in select-none"
                                  onClick={(e) => {
                                      if (e.target === e.currentTarget) setActiveOutlierDomain(null);
                                  }}
                              >
                                  <div className="relative bg-slate-900 border border-rose-500/40 rounded-2xl max-w-2xl w-full p-5 shadow-2xl flex flex-col space-y-4 max-h-[85vh] overflow-hidden my-auto">
                                      
                                      {/* Modal Header */}
                                      <div className="shrink-0 flex justify-between items-start border-b border-slate-800 pb-3">
                                          <div className="flex items-center space-x-3">
                                              <div className="h-10 w-10 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-xl text-rose-400">
                                                  🚨
                                              </div>
                                              <div>
                                                  <div className="flex items-center space-x-2">
                                                      <h3 className="text-base font-bold text-white font-heading">
                                                          {outlierDriverAnalysis.domain.title}: Outlier Feature Derivation
                                                      </h3>
                                                      <span className="text-xs font-bold text-rose-400 bg-rose-500/20 border border-rose-500/40 px-2 py-0.5 rounded font-mono">
                                                          &gt;90th Percentile Outliers ({outlierDriverAnalysis.outlierPct}%)
                                                      </span>
                                                  </div>
                                                  <p className="text-xs text-slate-400 mt-0.5 font-sans">
                                                      Showing which specific features derive extreme outlier scores (Domain Score ≥ {outlierDriverAnalysis.p90Cutoff} pts) across {outlierDriverAnalysis.outlierCount} outlier claims.
                                                  </p>
                                              </div>
                                          </div>

                                          <button 
                                              onClick={() => setActiveOutlierDomain(null)}
                                              className="h-8 w-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center text-sm font-bold transition cursor-pointer"
                                          >
                                              ✕
                                          </button>
                                      </div>

                                      {/* Feature Drivers Ranked List */}
                                      <div className="flex-1 min-h-0 overflow-y-auto space-y-2.5 pr-1">
                                          <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block font-heading">
                                              Ranked Feature Contribution Among Outlier Claims:
                                          </span>

                                          <div className="space-y-2">
                                              {outlierDriverAnalysis.featureDrivers.map((fd, idx) => (
                                                  <div key={idx} className="bg-slate-950 border border-slate-850 hover:border-rose-500/40 rounded-xl p-3 space-y-1.5 transition">
                                                      <div className="flex justify-between items-center">
                                                          <div className="flex items-center space-x-2">
                                                              <span className="h-5 w-5 rounded-full bg-slate-800 text-slate-300 text-xs font-bold flex items-center justify-center font-mono">
                                                                  #{idx + 1}
                                                              </span>
                                                              <span className="text-xs font-bold text-white font-heading">
                                                                  {fd.featureName}
                                                              </span>
                                                              {fd.isLLM && (
                                                                  <span className="text-[9px] text-[#00D2FF] bg-[#0066FF]/20 px-1.5 py-0.2 rounded font-mono">
                                                                      LLM Extracted
                                                                  </span>
                                                              )}
                                                          </div>

                                                          <span className={`text-[10px] font-bold font-mono px-2 py-0.5 rounded border ${
                                                              fd.pctAboveAvg >= 60 
                                                                  ? "text-rose-400 bg-rose-500/20 border-rose-500/40" 
                                                                  : fd.pctAboveAvg >= 35 
                                                                  ? "text-amber-400 bg-amber-500/20 border-amber-500/40" 
                                                                  : "text-blue-400 bg-blue-500/20 border-blue-500/40"
                                                          }`}>
                                                              {fd.impactRank}
                                                          </span>
                                                      </div>

                                                      {/* Average Score Outlier Severity Bar */}
                                                                                                             {/* Outlier Rows Exceeding Feature Average */}
                                                       <div className="space-y-1 pt-1">
                                                           <div className="flex justify-between text-[10px] font-mono">
                                                               <span className="text-slate-300">
                                                                   Feature Outlier Average: <strong className="text-amber-300">+{fd.avgPtsOutlier} / {fd.maxPts} pts</strong>
                                                               </span>
                                                               <span className="text-rose-400 font-bold">
                                                                   {fd.countAboveAvg} of {fd.totalOutliers} files ({fd.pctAboveAvg}% &gt; Avg)
                                                               </span>
                                                           </div>
                                                           <div className="h-2.5 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                                                               <div 
                                                                   className="h-full bg-gradient-to-r from-amber-500 via-rose-500 to-rose-600 rounded-full transition-all duration-500"
                                                                   style={{ width: `${Math.max(3, fd.pctAboveAvg)}%` }}
                                                               />
                                                           </div>
                                                       </div>

                                                       <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono pt-0.5">
                                                           <span>Lift over baseline: <strong className="text-emerald-400">{fd.liftRatio}x</strong> higher (+{fd.avgPtsOutlier} vs +{fd.avgPtsCohort} pts cohort avg)</span>
                                                           <span>Cohort baseline avg: +{fd.avgPtsCohort} pts</span>
                                                       </div>
                                                   </div>
                                               ))}
                                           </div>
                                       </div>

                                       {/* Modal Footer */}
                                       <div className="shrink-0 border-t border-slate-800 pt-3 flex justify-between items-center">
                                           <span className="text-[11px] text-slate-500 font-heading">
                                               Features with high outlier prevalence derive the majority of extreme risk in this domain.
                                           </span>
                                           <button 
                                               onClick={() => setActiveOutlierDomain(null)}
                                               className="px-5 py-2 bg-gradient-to-r from-slate-800 to-slate-700 hover:from-slate-700 hover:to-slate-600 text-white font-bold text-xs rounded-xl transition shadow cursor-pointer font-heading"
                                           >
                                               Close Inspector ✕
                                           </button>
                                       </div>

                                   </div>
                               </div>
                           )}

                       </div>
                   )}

                  {/* STEP 5: CLINICAL LINEAGE TREE */}
                  {activeAgent === 1 && agent1SidebarStep === "tree" && (
                      <div className="flex-1 flex flex-col min-h-0 p-3 space-y-2 overflow-hidden select-none font-heading">
                          
                          {/* Tree Header & Scope / Case Switcher */}
                          <div className="shrink-0 bg-slate-900 border border-slate-800 rounded-xl px-4 py-2 flex justify-between items-center shadow-md">
                              <div className="flex items-center space-x-3">
                                  <div className="h-7 w-7 rounded-lg bg-gradient-to-tr from-[#0066FF] to-[#00D2FF] flex items-center justify-center text-slate-950 text-xs font-black shadow">
                                      🌲
                                  </div>
                                  <div>
                                      <div className="flex items-center space-x-2">
                                          <h2 className="text-xs font-bold text-white uppercase tracking-wider">
                                              Hierarchical Lineage: Contribution-Sorted Hierarchy (Domain ➔ Feature ➔ Occurrences)
                                          </h2>
                                          <span className="text-[10px] text-amber-400 font-mono font-bold bg-amber-500/10 px-2 py-0.2 rounded border border-amber-500/30">
                                              {treeViewScope === "cohort" ? "📊 Overall Cohort Aggregation" : `📁 Single Case (${activeTreeClaim?.JOB_ID || "Job"})`}
                                          </span>
                                      </div>
                                      <p className="text-[10px] text-slate-400 font-sans mt-0.2">
                                          {treeViewScope === "cohort" 
                                              ? "Showing average contribution points across all cohort claims. #1 Top paths highlighted." 
                                              : `Showing exact clinical points & record values for Claim ${activeTreeClaim?.JOB_ID}. #1 Top paths highlighted.`}
                                      </p>
                                  </div>
                              </div>

                              <div className="flex items-center space-x-3 font-mono text-xs">
                                  
                                  {/* SCOPE TOGGLE: OVERALL COHORT vs ONE-BY-ONE JOB ID */}
                                  <div className="flex items-center space-x-1 bg-slate-950 border border-slate-800 p-0.5 rounded-lg">
                                      <button 
                                          onClick={() => setTreeViewScope("cohort")}
                                          className={`px-2.5 py-1 rounded-md text-[10px] font-bold transition flex items-center space-x-1 cursor-pointer ${
                                              treeViewScope === "cohort" 
                                                  ? "bg-gradient-to-r from-[#0066FF] to-[#00D2FF] text-slate-950 shadow" 
                                                  : "text-slate-400 hover:text-white"
                                          }`}
                                      >
                                          <span>📊</span>
                                          <span>Overall Cohort</span>
                                      </button>

                                      <button 
                                          onClick={() => setTreeViewScope("job")}
                                          className={`px-2.5 py-1 rounded-md text-[10px] font-bold transition flex items-center space-x-1 cursor-pointer ${
                                              treeViewScope === "job" 
                                                  ? "bg-gradient-to-r from-[#0066FF] to-rose-500 text-slate-950 shadow font-extrabold" 
                                                  : "text-slate-400 hover:text-white"
                                          }`}
                                      >
                                          <span>📁</span>
                                          <span>One-by-One Case</span>
                                      </button>
                                  </div>

                                  {/* CASE SELECTOR DROPDOWN (VISIBLE IN ONE-BY-ONE JOB MODE) */}
                                  {treeViewScope === "job" && (
                                      <div className="flex items-center space-x-1.5 bg-slate-950 border border-slate-800 px-2.5 py-1 rounded-lg animate-fade-in">
                                          <span className="text-[10px] text-slate-500 font-semibold uppercase">Select Job:</span>
                                          <select 
                                              value={selectedTreeClaimId || (activeTreeClaim ? activeTreeClaim.JOB_ID : "")}
                                              onChange={(e) => setSelectedTreeClaimId(e.target.value)}
                                              className="bg-transparent text-[#00D2FF] font-bold text-xs focus:outline-none cursor-pointer"
                                          >
                                              {calculatedClaims.map(c => (
                                                  <option key={c.JOB_ID} value={c.JOB_ID} className="bg-slate-900 text-slate-200">
                                                      {c.JOB_ID} • {c.calculatedComplexity}/100 ({c.calculatedComplexity >= 72 ? "🔥 High" : c.calculatedComplexity <= 45 ? "🟢 Low" : "🔵 Mod"})
                                                  </option>
                                              ))}
                                          </select>
                                      </div>
                                  )}

                                  <button 
                                      onClick={() => setAgent1SidebarStep("neural")}
                                      className="px-3 py-1 bg-gradient-to-r from-[#0066FF] to-[#00D2FF] hover:from-[#0052CC] hover:to-[#00B4D8] text-slate-950 font-bold rounded-lg text-xs transition shadow flex items-center space-x-1 cursor-pointer font-heading hover:scale-[1.02]"
                                  >
                                      <span>6. Neural Graph ➔</span>
                                  </button>
                              </div>
                          </div>

                          {/* 3-COLUMN TREE LAYOUT WITH REAL SVG DYNAMIC CURVY BEZIER ARROWS */}
                          <div 
                              ref={containerRef}
                              className="flex-1 grid grid-cols-12 gap-5 min-h-0 overflow-hidden relative p-1"
                          >
                              <svg 
                                  className="absolute inset-0 w-full h-full pointer-events-none z-20"
                                  style={{ overflow: "visible" }}
                              >
                                  <defs>
                                      <marker 
                                          id="arrow-cyan" 
                                          viewBox="0 0 10 10" 
                                          refX="6" 
                                          refY="5" 
                                          markerWidth="7" 
                                          markerHeight="7" 
                                          orient="auto-start-reverse"
                                      >
                                          <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#00D2FF" />
                                      </marker>

                                      <marker 
                                          id="arrow-orange" 
                                          viewBox="0 0 10 10" 
                                          refX="6" 
                                          refY="5" 
                                          markerWidth="7" 
                                          markerHeight="7" 
                                          orient="auto-start-reverse"
                                      >
                                          <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#FF5B35" />
                                      </marker>

                                      <marker 
                                          id="arrow-amber" 
                                          viewBox="0 0 10 10" 
                                          refX="6" 
                                          refY="5" 
                                          markerWidth="7" 
                                          markerHeight="7" 
                                          orient="auto-start-reverse"
                                      >
                                          <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#F59E0B" />
                                      </marker>

                                      <marker 
                                          id="arrow-subdued" 
                                          viewBox="0 0 10 10" 
                                          refX="6" 
                                          refY="5" 
                                          markerWidth="4" 
                                          markerHeight="4" 
                                          orient="auto-start-reverse"
                                      >
                                          <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#334155" />
                                      </marker>

                                      <linearGradient id="grad-top-path" x1="0%" y1="0%" x2="100%" y2="0%">
                                          <stop offset="0%" stopColor="#0066FF" stopOpacity="1" />
                                          <stop offset="50%" stopColor="#00D2FF" stopOpacity="1" />
                                          <stop offset="100%" stopColor="#FF5B35" stopOpacity="1" />
                                      </linearGradient>

                                      <linearGradient id="grad-top-leaf" x1="0%" y1="0%" x2="100%" y2="0%">
                                          <stop offset="0%" stopColor="#FF5B35" stopOpacity="1" />
                                          <stop offset="50%" stopColor="#F59E0B" stopOpacity="1" />
                                          <stop offset="100%" stopColor="#10B981" stopOpacity="1" />
                                      </linearGradient>
                                  </defs>

                                  {/* L1 -> L2 Connecting Lines */}
                                  {arrowPaths.l1ToL2.map((p) => (
                                      <g key={`l1-${p.id}`}>
                                          {p.isActive && (
                                              <>
                                                  {/* Glowing Halo Shadow */}
                                                  <path 
                                                      d={p.d} 
                                                      fill="none" 
                                                      stroke="#00D2FF" 
                                                      strokeWidth="8" 
                                                      strokeOpacity="0.35" 
                                                      className="animate-pulse"
                                                  />
                                                  <path 
                                                      d={p.d} 
                                                      fill="none" 
                                                      stroke="url(#grad-top-path)" 
                                                      strokeWidth="3.5" 
                                                      markerEnd="url(#arrow-cyan)"
                                                  />
                                              </>
                                          )}
                                          {!p.isActive && (
                                              <path 
                                                  d={p.d} 
                                                  fill="none" 
                                                  stroke="#334155" 
                                                  strokeWidth="1.2" 
                                                  strokeOpacity="0.4"
                                                  strokeDasharray="4,4"
                                                  markerEnd="url(#arrow-subdued)"
                                              />
                                          )}
                                      </g>
                                  ))}

                                  {/* L2 -> L3 Connecting Lines */}
                                  {arrowPaths.l2ToL3.map((p) => (
                                      <g key={`l2-${p.id}`}>
                                          {p.isActive && (
                                              <>
                                                  {/* Glowing Halo Shadow */}
                                                  <path 
                                                      d={p.d} 
                                                      fill="none" 
                                                      stroke="#FF5B35" 
                                                      strokeWidth="7" 
                                                      strokeOpacity="0.3" 
                                                      className="animate-pulse"
                                                  />
                                                  <path 
                                                      d={p.d} 
                                                      fill="none" 
                                                      stroke="url(#grad-top-leaf)" 
                                                      strokeWidth="3" 
                                                      markerEnd="url(#arrow-orange)"
                                                  />
                                              </>
                                          )}
                                          {!p.isActive && (
                                              <path 
                                                  d={p.d} 
                                                  fill="none" 
                                                  stroke="#334155" 
                                                  strokeWidth="1" 
                                                  strokeOpacity="0.3"
                                                  strokeDasharray="3,3"
                                                  markerEnd="url(#arrow-subdued)"
                                              />
                                          )}
                                      </g>
                                  ))}
                              </svg>

                              {/* COLUMN 1 (L1): DOMAINS (SORTED BY POINT CONTRIBUTION) */}
                              <div className="col-span-4 flex flex-col min-h-0 bg-slate-900/80 border border-slate-800 rounded-xl p-2.5 shadow-inner z-10">
                                  <div className="shrink-0 flex justify-between items-center pb-1.5 mb-1.5 border-b border-slate-800">
                                      <div className="flex items-center space-x-1.5 font-heading">
                                          <span className="text-xs font-bold text-[#00D2FF]">L1</span>
                                          <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                                              Domains (Ranked by Impact)
                                          </span>
                                      </div>
                                      <span className="text-[10px] text-slate-500 font-mono">Select root ➔</span>
                                  </div>

                                  <div className="flex-1 overflow-y-auto space-y-1.5 pr-0.5">
                                      {sortedTreeDomains.map((d, rankIdx) => {
                                          const isSelected = activeTreeDomainObj.id === d.id;
                                          const isRank1 = rankIdx === 0;

                                          return (
                                              <div 
                                                  key={d.id}
                                                  ref={el => l1Refs.current[d.id] = el}
                                                  onClick={() => {
                                                      setSelectedTreeDomainId(d.id);
                                                      const feats = d.features || [];
                                                      if (feats.length > 0) setSelectedTreeFeatureId(feats[0].id);
                                                  }}
                                                  className={`rounded-xl p-2.5 transition-all duration-200 cursor-pointer border flex justify-between items-center relative select-none ${
                                                      isSelected 
                                                          ? "bg-slate-900 border-[#00D2FF] text-white ring-2 ring-[#00D2FF]/50 shadow-xl shadow-[#00D2FF]/25 translate-x-1 z-10" 
                                                          : "bg-slate-950/70 border-slate-800/80 text-slate-300 hover:border-slate-700 hover:bg-slate-900/60"
                                                  }`}
                                              >
                                                  <div className="flex items-center space-x-2">
                                                      <span className={`h-5 w-5 rounded-full text-[10px] font-bold flex items-center justify-center font-mono shrink-0 ${
                                                          isRank1 ? "bg-amber-400 text-slate-950 font-black shadow-md shadow-amber-400/40" : "bg-slate-800 text-slate-300"
                                                      }`}>
                                                          {isRank1 ? "👑" : `#${rankIdx + 1}`}
                                                      </span>
                                                      <span className="text-sm">{d.icon}</span>
                                                      <div>
                                                          <div className="flex items-center space-x-1.5">
                                                              <span className="text-[11px] font-bold font-heading block leading-tight">
                                                                  {d.title}
                                                              </span>
                                                              {isRank1 && (
                                                                  <span className="text-[8px] text-amber-300 bg-amber-400/15 border border-amber-400/30 px-1 py-0.2 rounded font-mono font-bold">
                                                                      Top Domain
                                                                  </span>
                                                              )}
                                                          </div>
                                                          <span className="text-[9px] text-slate-400 font-mono">
                                                              {(d.weight * 100).toFixed(0)}% Wt • {d.features.length} Feats
                                                          </span>
                                                      </div>
                                                  </div>

                                                  <div className="text-right">
                                                      <span className="text-[11px] font-extrabold text-[#00D2FF] font-mono block">
                                                          +{d.pts} pts
                                                      </span>
                                                      <span className={`text-[9px] font-bold font-mono ${isSelected ? "text-emerald-400" : "text-slate-600"}`}>
                                                          {isSelected ? "ACTIVE PATH ●" : "Select ❯"}
                                                      </span>
                                                  </div>
                                              </div>
                                          );
                                      })}
                                  </div>
                              </div>

                              {/* COLUMN 2 (L2): FEATURES (SORTED BY POINT CONTRIBUTION - #1 HIGHLIGHTED) */}
                              <div className="col-span-4 flex flex-col min-h-0 bg-slate-900/80 border border-slate-800 rounded-xl p-2.5 shadow-inner relative z-10">
                                  <div className="shrink-0 flex justify-between items-center pb-1.5 mb-1.5 border-b border-slate-800">
                                      <div className="flex items-center space-x-1.5 font-heading">
                                          <span className="text-xs font-bold text-[#00D2FF]">L2</span>
                                          <span className="text-xs font-bold text-slate-200 uppercase tracking-wider truncate max-w-[180px]">
                                              {activeTreeDomainObj.title} (Features)
                                          </span>
                                      </div>
                                      <span className="text-[10px] text-amber-400 font-mono font-bold">#1 Top Highlighted</span>
                                  </div>

                                  <div className="flex-1 overflow-y-auto space-y-1.5 pr-0.5">
                                      {sortedTreeFeatures.map((feat, fRankIdx) => {
                                          const isSelected = activeTreeFeatureObj?.id === feat.id;
                                          const isRank1 = fRankIdx === 0;

                                          return (
                                              <div 
                                                  key={feat.id}
                                                  ref={el => l2Refs.current[feat.id] = el}
                                                  onClick={() => setSelectedTreeFeatureId(feat.id)}
                                                  className={`rounded-xl p-2.5 transition-all duration-200 cursor-pointer border flex flex-col justify-between space-y-1 select-none relative ${
                                                      isSelected 
                                                          ? "bg-slate-900 border-[#00D2FF] text-white ring-2 ring-[#00D2FF]/60 shadow-xl shadow-[#FF5B35]/25 translate-x-1 z-10" 
                                                          : isRank1 
                                                          ? "bg-slate-950 border-amber-500/40 text-slate-200 hover:border-amber-400"
                                                          : "bg-slate-950/70 border-slate-800/80 text-slate-300 hover:border-slate-700 hover:bg-slate-900/60"
                                                  }`}
                                              >
                                                  <div className="flex justify-between items-start space-x-1.5">
                                                      <div className="flex items-center space-x-1.5">
                                                          <span className={`h-4 w-4 rounded-full text-[9px] font-bold flex items-center justify-center font-mono shrink-0 ${
                                                              isRank1 ? "bg-amber-400 text-slate-950 font-black" : "bg-slate-800 text-slate-300"
                                                          }`}>
                                                              {isRank1 ? "👑" : `#${fRankIdx + 1}`}
                                                          </span>
                                                          <span className="text-[11px] font-bold font-heading leading-tight text-slate-100">
                                                              {feat.name}
                                                          </span>
                                                      </div>

                                                      <div className="flex items-center space-x-1 shrink-0">
                                                          <span className="text-[10px] font-extrabold text-[#00D2FF] font-mono">
                                                              +{feat.pts} pts
                                                          </span>
                                                      </div>
                                                  </div>

                                                  {isRank1 && (
                                                      <div className="flex items-center space-x-1">
                                                          <span className="text-[8px] text-amber-300 bg-amber-400/15 border border-amber-400/30 px-1.5 py-0.2 rounded font-mono font-bold">
                                                              👑 #1 Top Contributing Feature in Domain
                                                          </span>
                                                      </div>
                                                  )}

                                                  {feat.rawVal && (
                                                      <div className="text-[9px] text-slate-300 font-mono bg-slate-950/80 px-2 py-0.5 rounded border border-slate-850 truncate" title={String(feat.rawVal)}>
                                                          Value: <strong className="text-[#00D2FF]">{String(feat.rawVal)}</strong>
                                                      </div>
                                                  )}

                                                  <div className="flex justify-between items-center pt-0.5">
                                                      <span className="text-[9px] text-slate-400 font-mono">
                                                          Max: {feat.maxPts} pts {feat.isLLM ? "• ✨ LLM" : ""}
                                                      </span>
                                                      <span className={`text-[9px] font-bold font-mono ${isSelected ? "text-[#00D2FF]" : isRank1 ? "text-amber-400" : "text-slate-500"}`}>
                                                          {isSelected ? "CONNECTED PATH ●" : "View Occurrences ❯"}
                                                      </span>
                                                  </div>
                                              </div>
                                          );
                                      })}
                                  </div>
                              </div>

                              {/* COLUMN 3 (L3): OCCURRENCES & ENTITIES (#1 HIGHEST OCCURRENCE HIGHLIGHTED) */}
                              <div className="col-span-4 flex flex-col min-h-0 bg-slate-900/80 border border-slate-800 rounded-xl p-2.5 shadow-inner z-10">
                                  <div className="shrink-0 flex justify-between items-center pb-1.5 mb-1.5 border-b border-slate-800">
                                      <div className="flex items-center space-x-1.5 font-heading">
                                          <span className="text-xs font-bold text-amber-400">L3</span>
                                          <span className="text-xs font-bold text-slate-200 uppercase tracking-wider truncate max-w-[180px]" title={activeTreeFeatureObj?.name}>
                                              {activeTreeFeatureObj?.name || "Occurrences & Evidence"}
                                          </span>
                                      </div>
                                      <span className="text-[10px] text-amber-400 font-mono font-bold">
                                          {featureOccurrenceData ? `${featureOccurrenceData.activeCount}/${featureOccurrenceData.totalClaims} Files` : "Cohort Occurrences"}
                                      </span>
                                  </div>

                                  {/* Top Occurrence Frequency Banner */}
                                  {featureOccurrenceData && (
                                      <div className="shrink-0 bg-slate-950 border border-amber-500/30 rounded-xl p-2 space-y-1 mb-1 shadow">
                                          <div className="flex justify-between items-center text-[10px] font-mono">
                                              <span className="text-slate-300 font-bold">Cohort Occurrence Rate:</span>
                                              <span className="text-amber-300 font-extrabold">
                                                  {featureOccurrenceData.activeCount} of {featureOccurrenceData.totalClaims} Claims ({featureOccurrenceData.prevalencePct}%)
                                              </span>
                                          </div>
                                          <div className="h-1.5 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                                              <div 
                                                  className="h-full bg-gradient-to-r from-amber-500 to-rose-500 rounded-full transition-all duration-500"
                                                  style={{ width: `${Math.max(4, featureOccurrenceData.prevalencePct)}%` }}
                                              />
                                          </div>
                                      </div>
                                  )}

                                  <div className="flex-1 overflow-y-auto space-y-1.5 pr-0.5">
                                      {featureOccurrenceData?.entities && featureOccurrenceData.entities.length > 0 ? (
                                          featureOccurrenceData.entities.map((ent, eIdx) => {
                                              const isTopEntity = eIdx === 0;

                                              return (
                                                  <div 
                                                      key={eIdx}
                                                      ref={el => l3Refs.current[eIdx] = el}
                                                      onClick={() => setSelectedEvidenceDisease(ent)}
                                                      className={`rounded-xl p-2.5 space-y-1 transition cursor-pointer shadow group select-none relative border ${
                                                          isTopEntity 
                                                              ? "bg-amber-950/25 border-amber-400 ring-2 ring-amber-400/60 shadow-xl shadow-amber-500/20 translate-x-1 z-10" 
                                                              : ent.isPresentInActive 
                                                              ? "bg-slate-900 border-[#00D2FF]/60 ring-1 ring-[#00D2FF]/40" 
                                                              : "bg-slate-950 border-slate-800/90 hover:border-amber-400/50"
                                                      }`}
                                                  >
                                                      <div className="flex justify-between items-start space-x-1.5">
                                                          <div className="flex items-center space-x-1.5">
                                                              <span className={`text-xs ${isTopEntity ? "text-amber-300 font-black" : "text-amber-400"}`}>
                                                                  {isTopEntity ? "👑" : "🍃"}
                                                              </span>
                                                              <span className={`text-[11px] font-bold font-heading leading-tight break-words ${
                                                                  isTopEntity ? "text-amber-200" : "text-white"
                                                              }`}>
                                                                  {ent.name}
                                                              </span>
                                                          </div>

                                                          <span className="text-[9px] text-[#00D2FF] bg-[#0066FF]/20 px-1.5 py-0.2 rounded font-mono border border-[#0066FF]/30 shrink-0 font-bold">
                                                              {ent.count}x ({ent.pct}%)
                                                          </span>
                                                      </div>

                                                      {isTopEntity && (
                                                          <div className="flex items-center space-x-1">
                                                              <span className="text-[8px] text-amber-300 bg-amber-400/20 border border-amber-400/40 px-1.5 py-0.2 rounded font-mono font-bold">
                                                                  👑 #1 Highest Occurring Entity ({ent.count} claims)
                                                              </span>
                                                          </div>
                                                      )}

                                                      {/* Frequency occurrence bar for this specific entity */}
                                                      <div className="space-y-0.5 pt-0.5">
                                                          <div className="h-1.5 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                                                              <div 
                                                                  className={`h-full rounded-full transition-all duration-500 ${
                                                                      isTopEntity ? "bg-gradient-to-r from-amber-400 to-rose-500" : "bg-[#00D2FF]"
                                                                  }`}
                                                                  style={{ width: `${Math.max(5, ent.pct)}%` }}
                                                              />
                                                          </div>
                                                      </div>

                                                      <p className="text-[10px] text-slate-300 font-sans leading-snug">
                                                          {ent.note}
                                                      </p>

                                                      <div className="flex justify-between items-center pt-1 border-t border-slate-850">
                                                          <span className={`text-[8px] px-1.5 py-0.2 rounded font-mono font-bold border ${
                                                              isTopEntity 
                                                                  ? "text-amber-300 bg-amber-500/20 border-amber-500/40" 
                                                                  : ent.isPresentInActive 
                                                                  ? "text-[#00D2FF] bg-[#0066FF]/20 border-[#0066FF]/40" 
                                                                  : "text-slate-400 bg-slate-800 border-slate-700"
                                                          }`}>
                                                              {isTopEntity ? "CONNECTED TOP LEAF ●" : ent.isPresentInActive ? "✓ In Selected Case" : ent.severity}
                                                          </span>
                                                          <span className="text-[9px] text-slate-500 group-hover:text-amber-400 font-bold transition">
                                                              Inspect NLP ➔
                                                          </span>
                                                      </div>
                                                  </div>
                                              );
                                          })
                                      ) : (
                                          <div className="p-4 text-center text-xs text-slate-500 italic">
                                              No occurrence entries for this feature.
                                          </div>
                                      )}
                                  </div>
                              </div>

                          </div>

                          {/* FOOTER NARRATIVE / NLP EVIDENCE INSPECTOR */}
                          {selectedEvidenceDisease && (
                              <div className="shrink-0 bg-slate-900 border border-amber-500/40 rounded-xl p-2.5 flex justify-between items-center shadow-lg animate-slide-in select-none">
                                  <div className="flex items-center space-x-2.5">
                                      <div className="h-6 w-6 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 text-xs font-bold">
                                          ✓
                                      </div>
                                      <div>
                                          <div className="flex items-center space-x-2">
                                              <span className="text-xs font-bold text-white font-heading">
                                                  NLP Entity Inspection: {selectedEvidenceDisease.name}
                                              </span>
                                              <span className="text-[9px] text-amber-400 font-mono bg-amber-500/10 px-2 py-0.2 rounded border border-amber-500/30">
                                                  {selectedEvidenceDisease.count} Occurrences ({selectedEvidenceDisease.pct}% Cohort Prevalence)
                                              </span>
                                          </div>
                                          <p className="text-[10px] text-slate-300 font-sans">
                                              <strong>Clinical Context & Cohort Distribution:</strong> {selectedEvidenceDisease.note}
                                          </p>
                                      </div>
                                  </div>

                                  <button 
                                      onClick={() => setSelectedEvidenceDisease(null)}
                                      className="px-2.5 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs font-bold transition cursor-pointer"
                                  >
                                      Close ✕
                                  </button>
                              </div>
                          )}

                      </div>
                  )}

                  {/* ========================================================================= */}
                  {/* STEP 6: AUTHENTIC POWER BI COMPASS D3 FORCE KNOWLEDGE GRAPH              */}
                  {/* (Ported from KPIDashboardGraph.tsx - 100% Dynamic from Active Dataset)    */}
                  {/* ========================================================================= */}
                  {agent1SidebarStep === "neural" && (() => {
                      return (
                          <D3CompassKnowledgeGraph 
                              calculatedClaims={calculatedClaims}
                              domainFlowData={domainFlowData}
                              cohortIntelligence={cohortIntelligence}
                              defaultScoringWeights={defaultScoringWeights}
                              weights={weights}
                              cohortTopLimit={cohortTopLimit}
                              setCohortTopLimit={setCohortTopLimit}
                              isGraphFullscreen={isGraphFullscreen}
                              setIsGraphFullscreen={setIsGraphFullscreen}
                              setActiveAgent={setActiveAgent}
                              handleDispatchToAgent2={handleDispatchToAgent2}
                              isAgent2Mode={false}
                          />
                      );
                  })()}

                      </div>
                  </>
              )}

</div></>
);
}