function App() {
return (
<div>
                  {activeAgent === 1 && agent1SidebarStep === "scores" && (
                      <div className="flex-1 flex flex-col min-h-0 p-3 space-y-2.5 overflow-hidden">
                          
                          {/* 1. TOP CENTERED MAXIMUM COMPLEXITY BANNER */}
                          <div className="shrink-0 bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border border-[#00D2FF]/40 rounded-xl px-4 py-2 shadow-md flex items-center justify-between relative overflow-hidden">
                              <div className="absolute inset-0 bg-[#00D2FF]/5 pointer-events-none" />
                              
                              <div className="flex-1 flex items-center justify-center space-x-2 z-10 font-heading">
                                  <span className="text-sm">⚡</span>
                                  <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                                      Maximum Complexity Score:
                                  </span>
                                  <span className="text-2xl font-black text-[#00D2FF] font-mono tracking-tight ml-1">
                                      {cohortIntelligence.max} / 100
                                  </span>
                                  <span className="text-[11px] text-slate-300 font-mono ml-3 bg-slate-950/80 border border-slate-800 px-3 py-1 rounded-lg shadow-inner">
                                      (Minimum Complexity: <strong className="text-emerald-400">{cohortIntelligence.min}</strong> | Average Complexity: <strong className="text-[#00D2FF]">{cohortIntelligence.avg}</strong> across <strong className="text-white">{cohortIntelligence.totalCount}</strong> Claims)
                                  </span>
                              </div>

                              <div className="z-10 flex items-center space-x-2 shrink-0">
                                  <button 
                                      onClick={handleDownloadCSV}
                                      className="px-2.5 py-1 bg-slate-900/90 hover:bg-slate-800 text-emerald-400 border border-emerald-500/30 font-bold text-[11px] rounded-lg transition flex items-center space-x-1 font-heading cursor-pointer"
                                      title="Export calculated complexity dataset"
                                  >
                                      <span>📥 Download CSV</span>
                                  </button>
                                  <button 
                                      onClick={() => setAgent1SidebarStep("tree")}
                                      className="px-3 py-1 bg-[#0066FF] hover:bg-[#0052CC] text-white font-bold text-xs rounded-lg transition shadow flex items-center space-x-1 font-heading cursor-pointer"
                                  >
                                      <span>5. Lineage Tree ➔</span>
                                  </button>
                                  <button 
                                      onClick={() => setAgent1SidebarStep("neural")}
                                      className="px-3 py-1 bg-gradient-to-r from-[#0066FF] to-[#00D2FF] hover:from-[#0052CC] hover:to-[#00B4D8] text-slate-950 font-bold text-xs rounded-lg transition shadow flex items-center space-x-1 font-heading cursor-pointer"
                                  >
                                      <span>6. Neural Graph ➔</span>
                                  </button>
                              </div>
                          </div>

                          {/* 2. THREE STATISTICALLY ADAPTIVE RISK TIER CARDS (High Risk > 72, Low & Moderate Adaptive) */}
                          <div className="grid grid-cols-3 gap-2.5 shrink-0 select-none font-heading">
                              
                              {/* Low Tier Card */}
                              <div 
                                  onClick={() => setSelectedRiskFilter("low")}
                                  className={`rounded-xl px-3.5 py-2 flex justify-between items-center transition cursor-pointer border ${
                                      selectedRiskFilter === "low" 
                                          ? "bg-slate-900 border-emerald-500 shadow-md ring-2 ring-emerald-500/50 scale-[1.01]" 
                                          : "bg-slate-900/70 border-slate-800 hover:border-slate-700"
                                  }`}
                              >
                                  <div>
                                      <div className="flex items-center space-x-1.5">
                                          <span className="h-2 w-2 rounded-full bg-emerald-400" />
                                          <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">
                                              Low Risk (0 – {cohortIntelligence.lowCutoff}) {selectedRiskFilter === "low" && "• Active"}
                                          </span>
                                      </div>
                                      <div className="flex items-baseline space-x-2 mt-0.5">
                                          <span className="text-lg font-black text-slate-100 font-mono">
                                              {cohortIntelligence.low.pct}%
                                          </span>
                                          <span className="text-[10px] text-slate-400">({cohortIntelligence.low.count} claims • Avg: {cohortIntelligence.low.avg}/100)</span>
                                      </div>
                                  </div>
                                  <span className="text-base">🟢</span>
                              </div>

                              {/* Medium Tier Card */}
                              <div 
                                  onClick={() => setSelectedRiskFilter("medium")}
                                  className={`rounded-xl px-3.5 py-2 flex justify-between items-center transition cursor-pointer border ${
                                      selectedRiskFilter === "medium" 
                                          ? "bg-slate-900 border-blue-500 shadow-md ring-2 ring-blue-500/50 scale-[1.01]" 
                                          : "bg-slate-900/70 border-slate-800 hover:border-slate-700"
                                  }`}
                              >
                                  <div>
                                      <div className="flex items-center space-x-1.5">
                                          <span className="h-2 w-2 rounded-full bg-blue-400" />
                                          <span className="text-[10px] font-bold text-blue-400 uppercase tracking-wider">
                                              Moderate Risk ({cohortIntelligence.lowCutoff + 1} – 72) {selectedRiskFilter === "medium" && "• Active"}
                                          </span>
                                      </div>
                                      <div className="flex items-baseline space-x-2 mt-0.5">
                                          <span className="text-lg font-black text-slate-100 font-mono">
                                              {cohortIntelligence.medium.pct}%
                                          </span>
                                          <span className="text-[10px] text-slate-400">({cohortIntelligence.medium.count} claims • Avg: {cohortIntelligence.medium.avg}/100)</span>
                                      </div>
                                  </div>
                                  <span className="text-base">🔵</span>
                              </div>

                              {/* High Tier Card */}
                              <div 
                                  onClick={() => setSelectedRiskFilter("high")}
                                  className={`rounded-xl px-3.5 py-2 flex justify-between items-center transition cursor-pointer border ${
                                      selectedRiskFilter === "high" 
                                          ? "bg-slate-900 border-[#00D2FF] shadow-md ring-2 ring-[#00D2FF]/50 scale-[1.01]" 
                                          : "bg-slate-900/70 border-slate-800 hover:border-slate-750"
                                  }`}
                              >
                                  <div>
                                      <div className="flex items-center space-x-1.5">
                                          <span className="h-2 w-2 rounded-full bg-[#0066FF] animate-ping" />
                                          <span className="text-[10px] font-bold text-[#00D2FF] uppercase tracking-wider">
                                              High Risk (&gt; 72) {selectedRiskFilter === "high" && "• Active"}
                                          </span>
                                      </div>
                                      <div className="flex items-baseline space-x-2 mt-0.5">
                                          <span className="text-lg font-black text-[#00D2FF] font-mono">
                                              {cohortIntelligence.high.pct}%
                                          </span>
                                          <span className="text-[10px] text-slate-300">({cohortIntelligence.high.count} claims • Avg: {cohortIntelligence.high.avg}/100)</span>
                                      </div>
                                  </div>
                                  <span className="text-base">🔥</span>
                              </div>

                          </div>

                          {/* 3. CASCADING DOMAIN POINT CONTRIBUTION FUNNEL WITH OUTLIER THIN BARS & INSIDE BAR MIN/AVG/MAX */}
                          <div className="flex-1 bg-slate-900 border border-slate-800 rounded-xl p-3 flex flex-col justify-between shadow-md min-h-0 overflow-hidden">
                              
                              <div className="shrink-0 flex justify-between items-center pb-1.5 border-b border-slate-800">
                                  <div className="flex items-center space-x-2">
                                      <span className="text-sm">🌪️</span>
                                      <h3 className="text-xs font-bold text-white font-heading uppercase tracking-wider">
                                          Domain Point Contribution Funnel ({selectedRiskFilter.toUpperCase()} TIER: {activeFilteredRows.length} CLAIMS)
                                      </h3>
                                  </div>

                                  <div className="flex items-center space-x-2">
                                      <div className="flex items-center space-x-1.5 bg-slate-950 border border-slate-800 px-2 py-0.5 rounded-lg text-[10px] font-mono">
                                          <span className="text-slate-500">Weight Preset:</span>
                                          <select 
                                              value={activeWeightPreset}
                                              onChange={(e) => applyPresetWeights(e.target.value)}
                                              className="bg-slate-900 border border-slate-700 text-[#00D2FF] text-[10px] font-bold rounded px-1.5 py-0.5 cursor-pointer focus:outline-none"
                                          >
                                              <option value="default">Standard / Default</option>
                                              <option value="balanced">⚖️ Balanced</option>
                                              <option value="clinicalHeavy">🏥 Clinical Heavy</option>
                                              <option value="pharmaHeavy">💊 Pharma Heavy</option>
                                          </select>
                                      </div>
                                      <div className="flex items-center space-x-1 bg-slate-950 border border-slate-800 p-0.5 rounded-lg font-heading text-[10px]">
                                      <button 
                                          onClick={() => setSelectedRiskFilter("all")}
                                          className={`px-2 py-0.5 rounded transition cursor-pointer ${selectedRiskFilter === "all" ? "bg-slate-800 text-white font-bold" : "text-slate-400 hover:text-slate-200"}`}
                                      >
                                          All ({cohortIntelligence.totalCount})
                                      </button>
                                      <button 
                                          onClick={() => setSelectedRiskFilter("low")}
                                          className={`px-2 py-0.5 rounded transition cursor-pointer ${selectedRiskFilter === "low" ? "bg-emerald-500 text-slate-950 font-bold" : "text-slate-400 hover:text-slate-200"}`}
                                      >
                                          Low ({cohortIntelligence.low.count})
                                      </button>
                                      <button 
                                          onClick={() => setSelectedRiskFilter("medium")}
                                          className={`px-2 py-0.5 rounded transition cursor-pointer ${selectedRiskFilter === "medium" ? "bg-blue-500 text-white font-bold" : "text-slate-400 hover:text-slate-200"}`}
                                      >
                                          Moderate ({cohortIntelligence.medium.count})
                                      </button>
                                      <button 
                                          onClick={() => setSelectedRiskFilter("high")}
                                          className={`px-2 py-0.5 rounded transition cursor-pointer ${selectedRiskFilter === "high" ? "bg-[#0066FF] text-slate-950 font-bold" : "text-slate-400 hover:text-slate-200"}`}
                                      >
                                          High ({cohortIntelligence.high.count})
                                      </button>
                                  </div>
                              </div>

                              {/* 8 CASCADING DOMAIN FUNNEL BARS (SYMMETRICAL INVERTED FUNNEL SHAPE) */}
                              <div className="flex-1 flex flex-col justify-around py-1 space-y-2 select-none min-h-0 overflow-y-auto pr-1">
                                  {segmentDomainFunnel.map((domain) => (
                                      <div key={domain.key} className="flex items-center space-x-3 group">
                                          
                                          {/* Left: Domain Icon & Title */}
                                          <div className="w-44 shrink-0 flex items-center space-x-2 text-xs font-heading">
                                              <span className="text-base">{domain.icon}</span>
                                              <span className="font-bold text-slate-200 text-[11px] truncate" title={domain.title}>
                                                  {domain.title}
                                              </span>
                                          </div>

                                          {/* Center: Horizontally Centered Inverted Funnel Bar */}
                                          <div className="flex-1 flex flex-col items-center justify-center space-y-0.5">
                                              
                                              {/* Outlier Header & Thin Line Centered Above Bar */}
                                              <div 
                                                  className="flex flex-col space-y-0.5 transition-all duration-500 min-w-[320px]"
                                                  style={{ width: `${domain.funnelWidth}%` }}
                                              >
                                                  <div className="flex items-center justify-between text-[8.5px] font-mono px-0.5 text-slate-400">
                                                      <span className="flex items-center space-x-1 truncate">
                                                          <span className="h-1.5 w-1.5 rounded-full bg-rose-500" />
                                                          <span>Outliers: <strong className="text-rose-400">{domain.outlierPct}%</strong> (≥ {domain.domainOutlierCutoff} pts)</span>
                                                      </span>
                                                      <span className="text-slate-500 hidden md:inline text-[8px]">
                                                          Click right box to inspect ➔
                                                      </span>
                                                  </div>

                                                  <div 
                                                      className="h-1 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-850 pointer-events-none"
                                                      title={`Outlier Rate: ${domain.outlierPct}%`}
                                                  >
                                                      <div 
                                                          className="h-full bg-gradient-to-r from-amber-500 via-rose-500 to-rose-600 rounded-full transition-all duration-500"
                                                          style={{ width: `${Math.max(3, domain.outlierPct)}%` }}
                                                      />
                                                  </div>
                                              </div>

                                              {/* Main Symmetrical Centered Funnel Bar */}
                                              <div 
                                                  className="h-7.5 rounded-lg bg-gradient-to-r from-[#0052CC] via-[#0066FF] to-[#00D2FF] border border-[#00D2FF]/40 px-3 flex items-center justify-between shadow-md transition-all duration-500 relative overflow-hidden font-mono min-w-[320px]"
                                                  style={{ width: `${domain.funnelWidth}%` }}
                                              >
                                                  <div className="absolute inset-0 bg-white/5 opacity-50 pointer-events-none" />

                                                  {/* Inside Left: Min Score */}
                                                  <span className="text-[10px] font-bold text-slate-100 z-10 opacity-95 shrink-0 bg-slate-950/40 px-1.5 py-0.2 rounded border border-white/10">
                                                      Min: {domain.minPoints} pts
                                                  </span>

                                                  {/* Inside Center: Avg Score & % Share */}
                                                  <div className="flex items-center space-x-1.5 z-10 shrink-0">
                                                      <span className="text-xs font-black text-white drop-shadow">
                                                          Avg: +{domain.avgPoints} pts
                                                      </span>
                                                      <span className="text-[9px] font-bold text-slate-950 bg-[#00D2FF] px-1.5 py-0.2 rounded shadow">
                                                          {domain.sharePct}% Share
                                                      </span>
                                                  </div>

                                                  {/* Inside Right: Max Score */}
                                                  <span className="text-[10px] font-bold text-amber-200 z-10 opacity-95 shrink-0 bg-slate-950/40 px-1.5 py-0.2 rounded border border-amber-300/20">
                                                      Max: {domain.maxPoints} pts
                                                  </span>
                                              </div>

                                          </div>

                                          {/* Right: Clickable Outlier Badge */}
                                          <div className="w-16 shrink-0 flex justify-end">
                                              <button 
                                                  onClick={() => setActiveOutlierDomain(domain)}
                                                  className="bg-slate-950 hover:bg-slate-850 border border-rose-500/40 hover:border-rose-400 px-2 py-1 rounded-lg flex flex-col items-center justify-center transition cursor-pointer shadow-inner w-full group-hover:border-rose-400"
                                                  title="Inspect which features derive outliers in this domain"
                                              >
                                                  <span className="text-[8px] text-slate-400 font-mono">Outliers</span>
                                                  <span className="text-xs font-black text-rose-400 font-mono group-hover:scale-105 transition">
                                                      {domain.outlierPct}% 🔍
                                                  </span>
                                              </button>
                                          </div>

                                      </div>
                                  ))}
                              </div>

                              {/* INLINE ANNOTATIONS LINES */}
                              <div className="shrink-0 pt-1.5 border-t border-slate-800/90 space-y-0.5 text-[11px] font-sans">
                                  <div className="flex items-start space-x-2">
                                      <span className="text-[#00D2FF] font-bold font-heading shrink-0">• Points (+pts) Meaning:</span>
                                      <span className="text-slate-300 leading-tight">
                                          {tierAnnotations.pointsLine}
                                      </span>
                                  </div>

                                  <div className="flex items-start space-x-2">
                                      <span className="text-[#00D2FF] font-bold font-heading shrink-0">• % Share Meaning:</span>
                                      <span className="text-slate-300 leading-tight">
                                          {tierAnnotations.shareLine}
                                      </span>
                                  </div>

                                  <div className="flex items-start space-x-2">
                                      <span className="text-emerald-400 font-bold font-heading shrink-0">• Actionable Triage Route:</span>
                                      <span className="text-emerald-300 font-medium leading-tight">
                                          {tierAnnotations.triageLine}
                                      </span>
                                  </div>
                              </div>

                          </div>

                          {/* OUTLIER FEATURE DRIVER INSPECTOR MODAL */}
                          {activeOutlierDomain && outlierDriverAnalysis && (
                              <div 
                                  className="fixed inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 md:p-6 z-[9999] animate-fade-in select-none"
                                  onClick={(e) => {
                                      if (e.target === e.currentTarget) setActiveOutlierDomain(null);
                                  }}
                              >
                                  <div className="relative bg-slate-900 border border-rose-500/40 rounded-2xl max-w-2xl w-full p-5 shadow-2xl flex flex-col space-y-4 max-h-[85vh] overflow-hidden my-auto">
                                      
                                      {/* Modal Header */}
                                      <div className="shrink-0 flex justify-between items-start border-b border-slate-800 pb-3">
                                          <div className="flex items-center space-x-3">
                                              <div className="h-10 w-10 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-xl text-rose-400">
                                                  🚨
                                              </div>
                                              <div>
                                                  <div className="flex items-center space-x-2">
                                                      <h3 className="text-base font-bold text-white font-heading">
                                                          {outlierDriverAnalysis.domain.title}: Outlier Feature Derivation
                                                      </h3>
                                                      <span className="text-xs font-bold text-rose-400 bg-rose-500/20 border border-rose-500/40 px-2 py-0.5 rounded font-mono">
                                                          &gt;90th Percentile Outliers ({outlierDriverAnalysis.outlierPct}%)
                                                      </span>
                                                  </div>
                                                  <p className="text-xs text-slate-400 mt-0.5 font-sans">
                                                      Showing which specific features derive extreme outlier scores (Domain Score ≥ {outlierDriverAnalysis.p90Cutoff} pts) across {outlierDriverAnalysis.outlierCount} outlier claims.
                                                  </p>
                                              </div>
                                          </div>

                                          <button 
                                              onClick={() => setActiveOutlierDomain(null)}
                                              className="h-8 w-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center text-sm font-bold transition cursor-pointer"
                                          >
                                              ✕
                                          </button>
                                      </div>

                                      {/* Feature Drivers Ranked List */}
                                      <div className="flex-1 min-h-0 overflow-y-auto space-y-2.5 pr-1">
                                          <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block font-heading">
                                              Ranked Feature Contribution Among Outlier Claims:
                                          </span>

                                          <div className="space-y-2">
                                              {outlierDriverAnalysis.featureDrivers.map((fd, idx) => (
                                                  <div key={idx} className="bg-slate-950 border border-slate-850 hover:border-rose-500/40 rounded-xl p-3 space-y-1.5 transition">
                                                      <div className="flex justify-between items-center">
                                                          <div className="flex items-center space-x-2">
                                                              <span className="h-5 w-5 rounded-full bg-slate-800 text-slate-300 text-xs font-bold flex items-center justify-center font-mono">
                                                                  #{idx + 1}
                                                              </span>
                                                              <span className="text-xs font-bold text-white font-heading">
                                                                  {fd.featureName}
                                                              </span>
                                                              {fd.isLLM && (
                                                                  <span className="text-[9px] text-[#00D2FF] bg-[#0066FF]/20 px-1.5 py-0.2 rounded font-mono">
                                                                      LLM Extracted
                                                                  </span>
                                                              )}
                                                          </div>

                                                          <span className={`text-[10px] font-bold font-mono px-2 py-0.5 rounded border ${
                                                              fd.pctAboveAvg >= 60 
                                                                  ? "text-rose-400 bg-rose-500/20 border-rose-500/40" 
                                                                  : fd.pctAboveAvg >= 35 
                                                                  ? "text-amber-400 bg-amber-500/20 border-amber-500/40" 
                                                                  : "text-blue-400 bg-blue-500/20 border-blue-500/40"
                                                          }`}>
                                                              {fd.impactRank}
                                                          </span>
                                                      </div>

                                                      {/* Average Score Outlier Severity Bar */}
                                                                                                             {/* Outlier Rows Exceeding Feature Average */}
                                                       <div className="space-y-1 pt-1">
                                                           <div className="flex justify-between text-[10px] font-mono">
                                                               <span className="text-slate-300">
                                                                   Feature Outlier Average: <strong className="text-amber-300">+{fd.avgPtsOutlier} / {fd.maxPts} pts</strong>
                                                               </span>
                                                               <span className="text-rose-400 font-bold">
                                                                   {fd.countAboveAvg} of {fd.totalOutliers} files ({fd.pctAboveAvg}% &gt; Avg)
                                                               </span>
                                                           </div>
                                                           <div className="h-2.5 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                                                               <div 
                                                                   className="h-full bg-gradient-to-r from-amber-500 via-rose-500 to-rose-600 rounded-full transition-all duration-500"
                                                                   style={{ width: `${Math.max(3, fd.pctAboveAvg)}%` }}
                                                               />
                                                           </div>
                                                       </div>

                                                       <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono pt-0.5">
                                                           <span>Lift over baseline: <strong className="text-emerald-400">{fd.liftRatio}x</strong> higher (+{fd.avgPtsOutlier} vs +{fd.avgPtsCohort} pts cohort avg)</span>
                                                           <span>Cohort baseline avg: +{fd.avgPtsCohort} pts</span>
                                                       </div>
                                                   </div>
                                               ))}
                                           </div>
                                       </div>

                                       {/* Modal Footer */}
                                       <div className="shrink-0 border-t border-slate-800 pt-3 flex justify-between items-center">
                                           <span className="text-[11px] text-slate-500 font-heading">
                                               Features with high outlier prevalence derive the majority of extreme risk in this domain.
                                           </span>
                                           <button 
                                               onClick={() => setActiveOutlierDomain(null)}
                                               className="px-5 py-2 bg-gradient-to-r from-slate-800 to-slate-700 hover:from-slate-700 hover:to-slate-600 text-white font-bold text-xs rounded-xl transition shadow cursor-pointer font-heading"
                                           >
                                               Close Inspector ✕
                                           </button>
                                       </div>

                                   </div>
                               </div>
                           )}

                       </div>
                   )}

</div>
);
}