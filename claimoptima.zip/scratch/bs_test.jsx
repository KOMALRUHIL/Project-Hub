function App() {
return (
<>
                      {/* LEFT SIDEBAR: AGENT 1 STEPS (COLLAPSIBLE & UNIFORM) */}
                      {!isSidebarCollapsed && (
                  <aside className="w-56 bg-slate-900/90 border-r border-slate-800 p-3.5 flex flex-col justify-between shrink-0 select-none shadow-xl transition-all duration-300">
                      <div className="space-y-3">
                          <div className="flex justify-between items-start">
                              <div>
                                  <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block font-heading">
                                      Clinical Complexity Workspace
                                  </span>
                                  <h2 className="text-xs font-bold text-white mt-0.5 font-heading">
                                      Ingestion & Complexity
                                  </h2>
                              </div>
                              <button 
                                  onClick={() => setIsSidebarCollapsed(true)}
                                  className="h-6 w-6 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center text-xs transition cursor-pointer"
                                  title="Collapse Sidebar"
                              >
                                  ◀
                              </button>
                          </div>

                          <nav className="flex flex-col space-y-1 font-heading">
                              <button 
                                  onClick={() => setAgent1SidebarStep("input")}
                                  className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-semibold transition text-left cursor-pointer ${
                                      agent1SidebarStep === "input" 
                                          ? "bg-[#0066FF] text-white shadow-md ring-1 ring-[#0066FF]/50" 
                                          : "bg-slate-950/60 border border-slate-800/80 text-slate-300 hover:bg-slate-850 hover:text-white"
                                  }`}
                              >
                                  <span>1. Ingestion & Preview</span>
                                  {claims.length > 0 && <span className="text-emerald-400 font-bold">✓</span>}
                              </button>

                              <button 
                                  disabled={claims.length === 0}
                                  onClick={() => setAgent1SidebarStep("flowchart")}
                                  className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-semibold transition text-left cursor-pointer disabled:opacity-30 disabled:pointer-events-none ${
                                      agent1SidebarStep === "flowchart" 
                                          ? "bg-[#0066FF] text-white shadow-md ring-1 ring-[#0066FF]/50" 
                                          : "bg-slate-950/60 border border-slate-800/80 text-slate-300 hover:bg-slate-850 hover:text-white"
                                  }`}
                              >
                                  <span>2. Feature Tree</span>
                                  {claims.length > 0 && <span className="text-[#00D2FF] text-[10px] font-mono">8 Col</span>}
                              </button>

                              <button 
                                  disabled={claims.length === 0}
                                  onClick={() => setAgent1SidebarStep("weights")}
                                  className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-semibold transition text-left cursor-pointer disabled:opacity-30 disabled:pointer-events-none ${
                                      agent1SidebarStep === "weights" 
                                          ? "bg-[#0066FF] text-white shadow-md ring-1 ring-[#0066FF]/50" 
                                          : "bg-slate-950/60 border border-slate-800/80 text-slate-300 hover:bg-slate-850 hover:text-white"
                                  }`}
                              >
                                  <span>3. Weights Matrix</span>
                                  {claims.length > 0 && <span className="text-slate-400 text-[10px] font-mono">Matrix</span>}
                              </button>

                              <button 
                                  disabled={claims.length === 0}
                                  onClick={() => setAgent1SidebarStep("scores")}
                                  className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-semibold transition text-left cursor-pointer disabled:opacity-30 disabled:pointer-events-none ${
                                      agent1SidebarStep === "scores" 
                                          ? "bg-[#0066FF] text-white shadow-md ring-1 ring-[#0066FF]/50" 
                                          : "bg-slate-950/60 border border-slate-800/80 text-slate-300 hover:bg-slate-850 hover:text-white"
                                  }`}
                              >
                                  <span>4. Complexity & Funnel</span>
                                  {claims.length > 0 && <span className="text-emerald-400 text-[10px] font-mono font-bold">0-100</span>}
                              </button>

                              <button 
                                  disabled={claims.length === 0}
                                  onClick={() => setAgent1SidebarStep("tree")}
                                  className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-semibold transition text-left cursor-pointer disabled:opacity-30 disabled:pointer-events-none ${
                                      agent1SidebarStep === "tree" 
                                          ? "bg-[#0066FF] text-white shadow-md ring-1 ring-[#0066FF]/50" 
                                          : "bg-slate-950/60 border border-slate-800/80 text-slate-300 hover:bg-slate-850 hover:text-white"
                                  }`}
                              >
                                  <span>5. Clinical Lineage Tree</span>
                                  <span className="text-[9px] font-bold font-mono px-1.5 py-0.2 rounded bg-[#0066FF]/20 text-[#00D2FF]">
                                      L1➔L2➔L3
                                  </span>
                              </button>

                              <button 
                                  disabled={claims.length === 0}
                                  onClick={() => setAgent1SidebarStep("neural")}
                                  className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-semibold transition text-left cursor-pointer disabled:opacity-30 disabled:pointer-events-none ${
                                      agent1SidebarStep === "neural" 
                                          ? "bg-[#0066FF] text-white shadow-md ring-1 ring-[#0066FF]/50" 
                                          : "bg-slate-950/60 border border-slate-800/80 text-slate-300 hover:bg-slate-850 hover:text-white"
                                  }`}
                              >
                                  <span>6. Neural Risk Graph</span>
                                  {claims.length > 0 && <span className="text-[#00D2FF] text-[10px] font-mono">Graph</span>}
                              </button>
                          </nav>
                      </div>

                      {claims.length > 0 ? (
                          <div className="bg-slate-950 p-2.5 rounded-lg border border-emerald-500/30 space-y-1 font-heading">
                              <div className="flex items-center space-x-2">
                                  <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                                  <span className="text-[10px] font-bold text-emerald-400">File Ingested</span>
                              </div>
                              <p className="text-[10px] text-slate-300 font-mono truncate" title={uploadedFileName}>
                                  {uploadedFileName}
                              </p>
                              <div className="text-[9px] text-slate-400 font-mono">
                                  {claims.length} Records • {ingestedColumns.length} Cols
                              </div>
                          </div>
                      ) : (
                          <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-[10px] text-slate-500 italic text-center font-heading">
                              No file inputted yet.
                          </div>
                      )}
                  </aside>
              )}

                      {/* FLOATING EXPAND SIDEBAR BUTTON WHEN COLLAPSED */}
                      {isSidebarCollapsed && (
                          <button 
                              onClick={() => setIsSidebarCollapsed(false)}
                              className="absolute top-2 left-2 z-40 h-8 px-3 rounded-lg bg-slate-900 border border-slate-700 text-slate-200 hover:text-white hover:border-[#00D2FF] shadow-2xl flex items-center space-x-1.5 text-xs font-bold transition cursor-pointer font-heading hover:scale-105"
                              title="Expand Left Navigation Menu"
                          >
                              <span>▶</span>
                              <span className="text-[11px]">Expand Menu</span>
                          </button>
                      )}

                      {/* RIGHT MAIN WORKSPACE FOR AGENT 1 */}
                      <div className="flex-1 flex flex-col min-h-0 bg-slate-950 overflow-hidden relative">
                  
                  {/* STEP 1: FILE INGESTION & DOCUMENT PIPELINE */}

</div></>
);
}