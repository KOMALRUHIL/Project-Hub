import { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Activity,
  BarChart3,
  Database,
  Gauge,
  Layers3,
  Sparkles,
  Users,
  ArrowRight
} from 'lucide-react';

import Sidebar from './components/layout/Sidebar';
import Topbar from './components/layout/Topbar';
import { STATES, YEARS } from './data/mockData';
import { useLiveDashboardData } from './hooks/useLiveDashboardData';
import type { FilterState, NavItem } from './types';

import DashboardHome from './pages/DashboardHome';
import EDAOverview from './pages/EDAOverview';
import ChannelPerformance from './pages/ChannelPerformance';
import Segmentation from './pages/Segmentation';
import ModelInsights from './pages/ModelInsights';
import PredictionStudio from './pages/PredictionStudio';
import AgentAnalytics from './pages/AgentAnalytics';
import InputPage from './pages/InputPage';

const navItems: NavItem[] = [
  { id: 'input', label: 'Input', icon: Database },
  { id: 'model', label: 'Model Insights', icon: BarChart3 },
  { id: 'eda', label: 'EDA Overview', icon: Layers3 },
  { id: 'executive', label: 'CLTV Outcome Summary', icon: Gauge },
  { id: 'channel', label: 'Channel Insights', icon: Activity },
  { id: 'agent-analytics', label: 'Agent Level Analytics', icon: Users },
  { id: 'segmentation', label: 'Segmentation', icon: Users },
  { id: 'prediction', label: 'Prediction Studio', icon: Sparkles }
];

const themeStorageKey = 'clv-intelligence-theme';

const App = () => {
  const [activePage, setActivePage] = useState<string>('input');
  const [visitedPages, setVisitedPages] = useState<string[]>(['input']);
  const [isDataProcessed, setIsDataProcessed] = useState<boolean>(false);
  const [refreshKey, setRefreshKey] = useState<number>(0);
  const [filters, setFilters] = useState<FilterState>({ states: STATES, years: YEARS });

  useEffect(() => {
    if (!visitedPages.includes(activePage)) {
      setVisitedPages((prev) => [...prev, activePage]);
    }
  }, [activePage]);

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    if (typeof window === 'undefined') return true;
    const saved = window.localStorage.getItem(themeStorageKey);
    return saved === 'light' ? false : true;
  });

  useEffect(() => {
    if (typeof document === 'undefined') return;
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    window.localStorage.setItem(themeStorageKey, darkMode ? 'dark' : 'light');
  }, [darkMode]);

  const normalizedFilters = useMemo(
    () => ({
      states: filters.states.length ? filters.states : STATES,
      years: filters.years.length ? filters.years : YEARS
    }),
    [filters.states, filters.years]
  );

  const { data, source, loading, error } = useLiveDashboardData(normalizedFilters, refreshKey);

  const filterSummary = useMemo(() => {
    const stateLabel =
      normalizedFilters.states.length === STATES.length
        ? 'All States'
        : `${normalizedFilters.states.length} State${normalizedFilters.states.length > 1 ? 's' : ''}`;

    const yearLabel =
      normalizedFilters.years.length === YEARS.length
        ? 'All Years'
        : `${normalizedFilters.years.length} Year${normalizedFilters.years.length > 1 ? 's' : ''}`;

    return `${stateLabel} · ${yearLabel}`;
  }, [normalizedFilters.states, normalizedFilters.years]);

  const nextItem = useMemo(() => {
    const currentIndex = navItems.findIndex((item) => item.id === activePage);
    if (currentIndex === -1 || currentIndex === navItems.length - 1) {
      return navItems[0];
    }
    return navItems[currentIndex + 1];
  }, [activePage]);

  const renderPage = () => {
    switch (activePage) {
      case 'input':
        return (
          <InputPage
            data={data}
            onDataProcessed={() => {
              setIsDataProcessed(true);
              setRefreshKey((prev) => prev + 1);
            }}
            onNavigateToPage={setActivePage}
          />
        );
      case 'eda':
        return <EDAOverview data={data} />;
      case 'channel':
        return <ChannelPerformance data={data} />;
      case 'segmentation':
        return <Segmentation data={data} />;
      case 'model':
        return <ModelInsights data={data} />;
      case 'agent-analytics':
        return <AgentAnalytics />;
      case 'prediction':
        return <PredictionStudio data={data} />;
      default:
        return <DashboardHome data={data} />;
    }
  };

  return (
    <div className="min-h-screen bg-black text-slate-100 dark:bg-black dark:text-slate-100">
      <Sidebar
        items={navItems}
        active={activePage}
        onChange={setActivePage}
        disabledItems={isDataProcessed ? [] : ['eda', 'model', 'executive', 'channel', 'agent-analytics', 'segmentation', 'prediction']}
        visitedItems={visitedPages}
      />

      <div className="lg:pl-72">
        <Topbar darkMode={darkMode} onToggleDarkMode={() => setDarkMode((prev) => !prev)} />

        <main className="px-4 pb-8 pt-5 sm:px-6">
          <article className="mb-4 rounded-2xl border border-slate-200 bg-white p-3 shadow-soft lg:hidden dark:border-slate-800 dark:bg-slate-900">
            <label className="text-xs font-semibold uppercase tracking-wide text-slate-500">Navigate Sections</label>
            <select
              className="mt-2 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
              value={activePage}
              onChange={(event) => setActivePage(event.target.value)}
            >
              {navItems.map((item) => {
                const isLocked = !isDataProcessed && item.id !== 'input';
                const isVisited = visitedPages.includes(item.id);
                return (
                  <option key={item.id} value={item.id} disabled={isLocked}>
                    {isVisited ? '✓ ' : ''}{item.label} {isLocked ? ' 🔒' : ''}
                  </option>
                );
              })}
            </select>
          </article>

          <AnimatePresence mode="wait">
            <motion.div
              key={activePage}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.22 }}
              className="space-y-6"
            >
              {renderPage()}
              {isDataProcessed && activePage !== 'input' && (
                <div className="flex justify-end pt-5 border-t border-slate-900 mt-6">
                  <button
                    type="button"
                    onClick={() => setActivePage(nextItem.id)}
                    className="inline-flex items-center gap-2 px-5 py-2.5 bg-brand-500 hover:bg-brand-600 text-white font-extrabold text-xs rounded-xl shadow-lg transition duration-200 transform hover:-translate-y-0.5"
                  >
                    <span>Next Tab: {nextItem.label}</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>
                </div>
              )}
            </motion.div>
          </AnimatePresence>


        </main>
      </div>
    </div>
  );
};

export default App;
