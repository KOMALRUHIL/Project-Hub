import { motion } from 'framer-motion';

interface SectionHeaderProps {
  title: string;
  subtitle: string;
  question?: string;
  takeaway?: string;
}

const SectionHeader = ({ title, subtitle, question, takeaway }: SectionHeaderProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      className="rounded-2xl border border-slate-800 bg-slate-900/40 p-5 shadow-soft"
    >
      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-brand-500">{subtitle}</p>
      <h2 className="mt-1 text-2xl font-bold tracking-tight text-slate-100">{title}</h2>
      {question ? (
        <p className="mt-2 text-sm text-slate-350">
          <span className="font-semibold">Business question:</span> {question}
        </p>
      ) : null}
      {takeaway ? (
        <p className="mt-2 rounded-xl bg-slate-950 px-3 py-2 text-sm text-brand-300 border border-slate-800">
          <span className="font-semibold">Business takeaway:</span> {takeaway}
        </p>
      ) : null}
    </motion.div>
  );
};

export default SectionHeader;
