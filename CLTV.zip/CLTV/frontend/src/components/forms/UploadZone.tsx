import { UploadCloud } from 'lucide-react';

interface UploadZoneProps {
  onFileSelected: (file: File | null) => void;
  fileName?: string;
}

const UploadZone = ({ onFileSelected, fileName }: UploadZoneProps) => {
  return (
    <label className="block cursor-pointer rounded-2xl border-2 border-dashed border-slate-800 bg-slate-950/40 p-8 text-center transition hover:border-brand-500 hover:bg-slate-900/40">
      <UploadCloud className="mx-auto h-8 w-8 text-slate-500" />
      <p className="mt-2 text-sm font-semibold text-slate-200">Drag and drop Excel or CSV portfolio here or click to upload</p>
      <p className="mt-1 text-xs text-slate-500">Supports .xlsx, .xls, and .csv formats.</p>
      {fileName ? <p className="mt-3 text-xs font-semibold text-brand-400">Selected: {fileName}</p> : null}
      <input className="hidden" type="file" accept=".xlsx,.xls,.csv" onChange={(event) => onFileSelected(event.target.files?.[0] || null)} />
    </label>
  );
};

export default UploadZone;
