import { MoonStar, Sun, UserCircle2 } from 'lucide-react';

interface TopbarProps {
  darkMode: boolean;
  onToggleDarkMode: () => void;
}

const Topbar = ({ darkMode, onToggleDarkMode }: TopbarProps) => {
  return (
    <header className="sticky top-0 z-30 border-b border-slate-800 bg-slate-950/95 px-6 py-4 backdrop-blur">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-brand-500">CLTV Analytics Product</p>
          <h1 className="text-xl font-bold text-slate-100">Insurance Portfolio Intelligence Studio</h1>
        </div>

        <div className="flex items-center gap-3 ml-auto">
          <button
            onClick={onToggleDarkMode}
            className="rounded-xl border border-slate-800 bg-slate-900 p-2 text-slate-200 transition hover:bg-slate-800"
            aria-label="Toggle dark mode"
          >
            {darkMode ? <Sun className="h-4 w-4" /> : <MoonStar className="h-4 w-4" />}
          </button>

          <button className="inline-flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-900 p-2 text-sm font-semibold text-slate-200 hover:bg-slate-800">
            <UserCircle2 className="h-4 w-4" />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Topbar;
