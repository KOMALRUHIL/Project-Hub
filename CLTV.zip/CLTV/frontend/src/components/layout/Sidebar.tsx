import { motion } from 'framer-motion';
import { Lock, Check } from 'lucide-react';

import { cn } from '../../utils/cn';
import type { NavItem } from '../../types';

interface SidebarProps {
  items: NavItem[];
  active: string;
  onChange: (id: string) => void;
  disabledItems?: string[];
  visitedItems?: string[];
}

const Sidebar = ({ items, active, onChange, disabledItems = [], visitedItems = [] }: SidebarProps) => {
  return (
    <aside className="fixed inset-y-0 left-0 z-40 hidden w-72 border-r border-slate-800 bg-slate-950/95 px-4 py-6 backdrop-blur lg:block">
      <div className="rounded-2xl border border-slate-800 bg-slate-900 p-4">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-brand-500">CLV Command</p>
        <h1 className="mt-2 text-lg font-bold text-slate-100">Customer Value Intelligence</h1>
        <p className="mt-1 text-xs text-slate-400">Enterprise analytics workspace for insurance portfolio decisions.</p>
      </div>

      <nav className="mt-5 space-y-1">
        {items.map((item, idx) => {
          const Icon = item.icon;
          const isActive = active === item.id;
          const isLocked = disabledItems.includes(item.id);
          const isVisited = visitedItems.includes(item.id);
          return (
            <motion.button
              key={item.id}
              initial={{ opacity: 0, x: -6 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.2, delay: idx * 0.03 }}
              onClick={() => {
                if (!isLocked) onChange(item.id);
              }}
              disabled={isLocked}
              className={cn(
                'flex w-full items-center justify-between rounded-xl px-3 py-2 text-left text-sm font-medium transition',
                isActive
                  ? 'bg-brand-950/40 text-brand-100 shadow-sm'
                  : isLocked
                    ? 'text-slate-600 opacity-60 cursor-not-allowed'
                    : 'text-slate-400 hover:bg-slate-800'
              )}
            >
              <div className="flex items-center gap-3">
                <Icon className="h-4 w-4" />
                <span>{item.label}</span>
              </div>
              {isLocked ? (
                <Lock className="h-3.5 w-3.5 text-slate-600" />
              ) : (
                isVisited && (
                  <div className="h-3.5 w-3.5 rounded border border-emerald-500 bg-emerald-500/10 flex items-center justify-center shrink-0 shadow-sm shadow-emerald-500/10">
                    <Check className="h-2 w-2 text-emerald-400 stroke-[3.5]" />
                  </div>
                )
              )}
            </motion.button>
          );
        })}
      </nav>
    </aside>
  );
};

export default Sidebar;
