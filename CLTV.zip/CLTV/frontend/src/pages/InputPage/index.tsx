import { useState } from 'react';
import { 
  FileCheck, 
  CheckCircle2, 
  Activity, 
  Award, 
  Loader2, 
  AlertTriangle,
  TrendingUp,
  Percent,
  Info,
  Database,
  Layers
} from 'lucide-react';
import { apiClient } from '../../api/client';
import UploadZone from '../../components/forms/UploadZone';

interface InputPageProps {
  data: any;
  onDataProcessed: () => void;
  onNavigateToPage?: (page: string) => void;
}

interface PipelineStage {
  id: number;
  label: string;
  description: string;
  status: 'pending' | 'running' | 'completed';
}

const InputPage = ({ onDataProcessed, onNavigateToPage }: InputPageProps) => {
  const [selectedFileName, setSelectedFileName] = useState<string>('');
  const [pipelineActive, setPipelineActive] = useState<boolean>(false);
  const [pipelineFinished, setPipelineFinished] = useState<boolean>(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  
  const [pipelineStages, setPipelineStages] = useState<PipelineStage[]>([
    { id: 1, label: 'Portfolio Ingestion & Schema Reconciliation', description: 'Performing schema normalization and mapping raw fields into standardized actuarial variables.', status: 'pending' },
    { id: 2, label: 'Data Integrity & Key Constraints Audit', description: 'Executing transaction-level sanity checks. Auditing join integrity and resolving overlapping coordinate keys.', status: 'pending' },
    { id: 3, label: 'Multidimensional Actuarial Feature Extraction', description: 'Computing claim frequencies, rolling 12-month loss ratios, and premium delinquency metrics to establish risk exposure profiles.', status: 'pending' },
    { id: 4, label: 'Champion Machine Learning Selection', description: 'Benchmarking ensemble classifiers (Random Forest, Gradient Boosting, Logistic Regression) on policy renewal outcomes.', status: 'pending' },
    { id: 5, label: 'Survival Probability Decay & Discount Curves', description: 'Projecting 5-year expected cashflows. Simulating survival decay rates and constructing credit-adjusted yield curves.', status: 'pending' },
    { id: 6, label: 'Present Value CLTV Aggregation', description: 'Discounting future expected cashflows back to present value (PV) and writing outputs to dashboard database.', status: 'pending' }
  ]);

  const processPortfolioFile = async (file: File) => {
    setPipelineActive(true);
    setPipelineFinished(false);
    setUploadError(null);
    setSelectedFileName(file.name);

    // Reset stages
    setPipelineStages(prev => prev.map(s => ({ ...s, status: s.id === 1 ? 'running' : 'pending' })));

    const interval = setInterval(() => {
      setPipelineStages(prev => {
        const runningStage = prev.find(s => s.status === 'running');
        if (!runningStage) return prev;
        
        const runningId = runningStage.id;
        if (runningId >= 6) return prev;
        
        return prev.map(s => {
          if (s.id === runningId) {
            return { ...s, status: 'completed' };
          }
          if (s.id === runningId + 1) {
            return { ...s, status: 'running' };
          }
          return s;
        });
      });
    }, 2000);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000').replace(/\/$/, '');
      const response = await fetch(`${API_BASE_URL}/upload-portfolio`, {
        method: 'POST',
        body: formData
      });

      if (!response.ok) {
        const errText = await response.text();
        throw new Error(errText || 'Actuarial pipeline execution failed.');
      }

      const resJson = await response.json();
      console.log('Ingestion success:', resJson);

      clearInterval(interval);
      setPipelineStages(prev => prev.map(s => ({ ...s, status: 'completed' })));
      setPipelineActive(false);
      setPipelineFinished(true);

      setTimeout(() => {
        onDataProcessed();
      }, 500);
    } catch (err: any) {
      console.error(err);
      clearInterval(interval);
      setUploadError(err.message || 'An error occurred during portfolio calculation.');
      setPipelineActive(false);
      setPipelineFinished(false);
    }
  };

  const handleFileSelected = (file: File | null) => {
    if (!file) {
      setSelectedFileName('');
      setPipelineActive(false);
      setPipelineFinished(false);
      setUploadError(null);
      return;
    }
    void processPortfolioFile(file);
  };

  return (
    <section className="space-y-6">
      {/* 1. Ingest Portfolio Card */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-6 shadow-soft space-y-4">
        <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
          <FileCheck className="h-5 w-5 text-brand-500" />
          Ingest Portfolio Dataset
        </h3>
        <p className="text-xs text-slate-400 leading-relaxed">
          Drag and drop your Excel portfolio (`.xlsx` / `.xls`) or CSV file here, or click to browse. The server will run the complete validation and training steps.
        </p>

        <UploadZone onFileSelected={handleFileSelected} fileName={selectedFileName} />

        {selectedFileName && (
          <div className="text-xs bg-slate-950 border border-slate-800 text-brand-300 rounded-xl p-3">
            📁 Selected portfolio: <span className="font-bold">{selectedFileName}</span>
          </div>
        )}

        {uploadError && (
          <div className="text-xs bg-red-950/20 border border-red-900/30 text-red-400 rounded-xl p-3.5 flex items-start gap-2.5">
            <AlertTriangle className="h-4.5 w-4.5 text-red-500 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold block">Calculation Error:</span>
              <span className="block mt-0.5 leading-relaxed">{uploadError}</span>
            </div>
          </div>
        )}
      </div>

      {/* 2. Full-Width Horizontal Pipeline steps */}
      {(pipelineActive || pipelineFinished) && (
        <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6 shadow-soft space-y-6">
          <h4 className="text-sm font-bold text-slate-100 flex items-center gap-2">
            <Activity className="h-4.5 w-4.5 text-brand-500 animate-pulse" />
            CLTV Prediction Pipeline
          </h4>

          <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4 relative">
            <div className="hidden lg:block absolute left-6 right-6 top-[35px] h-0.5 border-t border-dashed border-slate-800 -z-0" />

            {pipelineStages.map((stage, idx) => {
              const getStageIcon = (id: number) => {
                switch (id) {
                  case 1: return <Database className="h-5 w-5" />;
                  case 2: return <AlertTriangle className="h-5 w-5" />;
                  case 3: return <Activity className="h-5 w-5" />;
                  case 4: return <Award className="h-5 w-5" />;
                  case 5: return <TrendingUp className="h-5 w-5" />;
                  default: return <Percent className="h-5 w-5" />;
                }
              };

              const getAgentName = (id: number) => {
                switch (id) {
                  case 1: return 'Ingestion Agent';
                  case 2: return 'Auditor Agent';
                  case 3: return 'Actuary Agent';
                  case 4: return 'ML Engine Agent';
                  case 5: return 'Economist Agent';
                  default: return 'Analyst Agent';
                }
              };

              return (
                <div key={stage.id} className="flex-1 flex flex-col items-center text-center relative z-10">
                  <div className={`flex h-[60px] w-[60px] items-center justify-center rounded-full border-2 transition-all duration-300 ${
                    stage.status === 'completed'
                      ? 'border-emerald-500 bg-slate-950 text-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.2)]'
                      : stage.status === 'running'
                        ? 'border-brand-500 bg-slate-950 text-brand-400 shadow-[0_0_20px_rgba(59,130,246,0.35)] animate-pulse'
                        : 'border-slate-800 bg-slate-950 text-slate-600'
                  }`}>
                    {stage.status === 'completed' ? (
                      <CheckCircle2 className="h-6 w-6 text-emerald-400" />
                    ) : (
                      getStageIcon(stage.id)
                    )}
                  </div>

                  <div className="mt-3 space-y-1">
                    <span className={`text-[9px] uppercase font-extrabold tracking-wider block ${
                      stage.status === 'running'
                        ? 'text-brand-400'
                        : stage.status === 'completed'
                          ? 'text-emerald-400'
                          : 'text-slate-500'
                    }`}>
                      {getAgentName(stage.id)}
                    </span>
                    <h5 className={`text-[11px] font-bold ${
                      stage.status === 'running'
                        ? 'text-slate-100'
                        : stage.status === 'completed'
                          ? 'text-slate-200'
                          : 'text-slate-500'
                    }`}>
                      {stage.label}
                    </h5>
                    <p className="text-[9px] text-slate-500 max-w-[140px] mx-auto leading-normal">
                      {stage.description}
                    </p>
                  </div>

                  {idx < pipelineStages.length - 1 && (
                    <div className="lg:hidden my-2 text-slate-850">↓</div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 3. Below the steps: Outcomes, Flow chart and Benchmarks */}
      {pipelineFinished && (
        <div className="space-y-6">
          {/* Stepper Completed Message */}
          <div className="rounded-2xl border border-emerald-900/30 bg-emerald-950/10 p-5 text-emerald-400">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div className="flex gap-3">
                <CheckCircle2 className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-extrabold text-sm text-emerald-200">
                    Ingestion Pipeline Complete!
                  </h4>
                  <p className="mt-1 text-xs leading-relaxed text-emerald-500">
                    All calculations are complete. Portfolio statistics are aggregated and models have converged successfully. The analytical dashboard tabs in the sidebar are now **unlocked**.
                  </p>
                </div>
              </div>
              <div className="flex flex-wrap gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    window.open(`${apiClient.baseUrl}/business/download-workbook`, '_blank');
                  }}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-brand-400 border border-slate-800 font-extrabold text-xs rounded-xl shadow transition whitespace-nowrap"
                >
                  Download Excel Results 📥
                </button>
                {onNavigateToPage && (
                  <button
                    type="button"
                    onClick={() => onNavigateToPage('model')}
                    className="px-4 py-2 bg-emerald-500 hover:bg-emerald-650 text-slate-950 font-extrabold text-xs rounded-xl shadow transition whitespace-nowrap"
                  >
                    Go to Model Insights →
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default InputPage;
