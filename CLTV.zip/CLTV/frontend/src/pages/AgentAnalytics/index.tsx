import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  LineChart,
  Line
} from 'recharts';
import {
  Users,
  Layers,
  ArrowRight,
  TrendingUp,
  Cpu,
  FileSpreadsheet,
  CheckCircle,
  Database,
  ArrowUpRight,
  Zap
} from 'lucide-react';

import { apiClient } from '../../api/client';
import ChartCard from '../../components/charts/ChartCard';
import DataTable from '../../components/tables/DataTable';
import { formatCurrency } from '../../utils/format';

interface AgentClvRecord {
  agent_id: string;
  agent_name: string;
  avg_clv: number;
  customer_count: number;
}

interface PolicySplit {
  single_policy_avg_clv: number;
  multi_policy_avg_clv: number;
  single_policy_count: number;
  multi_policy_count: number;
}

interface PolicyImpactRecord {
  policy_count: number;
  avg_clv: number;
  customer_count: number;
}

interface ChannelDistributionRecord {
  channel: string;
  avg_clv: number;
  customer_count: number;
}

interface AgentAnalyticsData {
  agent_clv: AgentClvRecord[];
  policy_split: PolicySplit;
  policy_impact: PolicyImpactRecord[];
  channel_distribution: ChannelDistributionRecord[];
}

const COLORS = ['#2563eb', '#0ea5e9', '#059669', '#f59e0b', '#8b5cf6', '#ec4899'];

const AgentAnalytics = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<AgentAnalyticsData | null>(null);

  // Agentic Handoff state
  const [isHandoffOpen, setIsHandoffOpen] = useState(false);
  const [handoffStep, setHandoffStep] = useState(0);
  const [handoffLogs, setHandoffLogs] = useState<string[]>([]);
  const [isHandoffDone, setIsHandoffDone] = useState(false);

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        setLoading(true);
        const result = await apiClient.get<AgentAnalyticsData>('/agent-analytics');
        setData(result);
        setError(null);
      } catch (err) {
        console.error('Failed to load agent analytics', err);
        setError('Could not fetch agent-level analytics from backend. Ensure the server is running and data is trained.');
      } finally {
        setLoading(false);
      }
    };

    void fetchAnalytics();
  }, []);

  const triggerHandoff = async () => {
    setIsHandoffOpen(true);
    setHandoffStep(0);
    setIsHandoffDone(false);
    setHandoffLogs([]);

    const logMessages = [
      '🤖 [Agentic Coordinator] Init workflow handoff...',
      '📈 [CLV Engine] Extracting Customer Lifetime Value metrics at agent grain...',
      '🔍 [CLV Engine] Grouping customer policy portfolio by agent_id...',
      '🔗 [Agentic Gateway] Formulating agent_id mapping profiles...',
      '💾 [CLV Engine] Serializing agent average CLV coordinates...',
      '🚀 [Agentic Gateway] Dispatching CLV profile data to Agent360 environment...',
      '📂 [Agent360 Asset Store] Saved exported_agent_clv.json in backend asset pool.',
      '⚡ [Agentic Coordinator] Agent360 System activated! Awaiting user merge action.'
    ];

    // Export the data to Agent360 backend
    try {
      await apiClient.post('/export-agent-clv', {});
    } catch (err) {
      console.error('API export failed, running simulation fallback', err);
    }

    // Run terminal animation
    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep < logMessages.length) {
        setHandoffLogs((prev) => [...prev, logMessages[currentStep]]);
        setHandoffStep(currentStep + 1);
        currentStep++;
      } else {
        clearInterval(interval);
        setIsHandoffDone(true);
      }
    }, 800);
  };

  if (loading) {
    return (
      <div className="flex h-96 flex-col items-center justify-center space-y-3">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-slate-300 border-t-blue-600"></div>
        <p className="text-sm font-medium text-slate-500">Aggregating agent-level metrics...</p>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="rounded-2xl border border-red-200 bg-red-50 p-6 text-center dark:border-red-900/30 dark:bg-red-950/20">
        <h3 className="text-lg font-semibold text-red-900 dark:text-red-400">Loading Error</h3>
        <p className="mt-2 text-sm text-red-700 dark:text-red-300">{error || 'Something went wrong.'}</p>
        <button
          onClick={() => window.location.reload()}
          className="mt-4 rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-700"
        >
          Retry Load
        </button>
      </div>
    );
  }

  // Pre-process some values
  const { single_policy_avg_clv, multi_policy_avg_clv, single_policy_count, multi_policy_count } = data.policy_split;
  
  const policySplitData = [
    { name: 'Single Policy Customers', value: single_policy_count, avgClv: single_policy_avg_clv },
    { name: 'Multi-Policy Customers', value: multi_policy_count, avgClv: multi_policy_avg_clv }
  ];

  return (
    <section className="space-y-6">


      {/* KPI Cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <article className="rounded-2xl border border-slate-200 bg-white p-4 shadow-soft dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Total Agents Scored</span>
            <Users className="h-5 w-5 text-blue-500" />
          </div>
          <p className="mt-2 text-3xl font-bold text-slate-900 dark:text-slate-100">
            {data.agent_clv.length}
          </p>
          <p className="mt-1 text-xs text-slate-500">Unique sales agent assignments mapped</p>
        </article>

        <article className="rounded-2xl border border-slate-200 bg-white p-4 shadow-soft dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Single-Policy Avg CLV</span>
            <Layers className="h-5 w-5 text-sky-500" />
          </div>
          <p className="mt-2 text-3xl font-bold text-slate-900 dark:text-slate-100">
            {formatCurrency(single_policy_avg_clv)}
          </p>
          <p className="mt-1 text-xs text-slate-500">
            {single_policy_count.toLocaleString()} customers (Single Policy)
          </p>
        </article>

        <article className="rounded-2xl border border-slate-200 bg-white p-4 shadow-soft dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Multi-Policy Avg CLV</span>
            <TrendingUp className="h-5 w-5 text-emerald-500" />
          </div>
          <p className="mt-2 text-3xl font-bold text-slate-900 dark:text-slate-100">
            {formatCurrency(multi_policy_avg_clv)}
          </p>
          <p className="mt-1 text-xs text-slate-500">
            {multi_policy_count.toLocaleString()} customers (&gt;1 Policy)
          </p>
        </article>

        <article className="flex flex-col justify-between rounded-2xl border border-blue-100 bg-gradient-to-br from-blue-500/10 to-indigo-500/5 p-4 shadow-soft dark:border-blue-900/30 dark:from-blue-950/20 dark:to-slate-900">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-blue-600 dark:text-blue-400">Agentic Stitching</span>
            <Zap className="h-5 w-5 text-blue-600 dark:text-blue-400 animate-pulse" />
          </div>
          <div className="mt-3">
            <button
              onClick={triggerHandoff}
              className="group flex w-full items-center justify-center gap-2 rounded-xl bg-blue-600 px-3 py-2 text-xs font-bold text-white transition hover:bg-blue-700 shadow"
            >
              Handoff to Agent360
              <ArrowRight className="h-3 w-3 transition group-hover:translate-x-1" />
            </button>
          </div>
          <p className="mt-2 text-[10px] text-slate-500 dark:text-slate-400">
            Prepares Agent360 database with calculated customer lifetime values.
          </p>
        </article>
      </div>

      {/* Charts Grid */}
      <div className="grid gap-4 xl:grid-cols-2">
        <ChartCard
          title="Average CLV by Sales Agent (Top 12)"
          subtitle="Agent efficiency ranking"
          helperText="Displays average customer lifetime value driven by each agent_id. Helps reward high-performing advisors."
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data.agent_clv.slice(0, 12)}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="agent_id" tick={{ fontSize: 11 }} />
              <YAxis />
              <Tooltip
                formatter={(value: number) => formatCurrency(value)}
                contentStyle={{ borderRadius: '8px', fontSize: '12px' }}
              />
              <Bar dataKey="avg_clv" fill="#2563eb" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard
          title="CLV Effect as Policies Increase"
          subtitle="Customer value density by policy count"
          helperText="Shows how the customer lifetime value scales when a client purchases additional policies."
        >
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data.policy_impact} margin={{ right: 16 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="policy_count" tick={{ fontSize: 11 }} label={{ value: 'Number of Policies', position: 'bottom', offset: -5 }} />
              <YAxis />
              <Tooltip formatter={(value: number) => formatCurrency(value)} />
              <Line type="monotone" dataKey="avg_clv" stroke="#059669" strokeWidth={3} dot={{ r: 5 }} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        <ChartCard
          title="CLV Distribution by Sales Channel"
          subtitle="Marketing and Sales efficiency"
          helperText="Compares policy average CLV driven across different sales channels."
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data.channel_distribution}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="channel" tick={{ fontSize: 11 }} />
              <YAxis />
              <Tooltip formatter={(value: number) => formatCurrency(value)} />
              <Bar dataKey="avg_clv" fill="#0ea5e9" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard
          title="Single vs Multi-Policy Portfolio Share"
          subtitle="Volume vs Average CLV Split"
          helperText="The outer circle shows count of customers. Hover to view the difference in value density between cohorts."
        >
          <div className="flex h-full flex-col sm:flex-row items-center justify-around">
            <ResponsiveContainer width="60%" height="90%">
              <PieChart>
                <Pie
                  data={policySplitData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {policySplitData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value: number, name: any, props: any) => {
                    const avg = props.payload.avgClv;
                    return [`${value.toLocaleString()} Customers (Avg CLV: ${formatCurrency(avg)})`];
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-3">
              {policySplitData.map((item, index) => (
                <div key={item.name} className="flex items-center space-x-2">
                  <span className="h-3 w-3 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }}></span>
                  <div>
                    <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">{item.name}</p>
                    <p className="text-[10px] text-slate-500">Avg CLV: {formatCurrency(item.avgClv)}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </ChartCard>
      </div>

      {/* Agents Detailed Data */}
      <article className="rounded-2xl border border-slate-200 bg-white p-4 shadow-soft dark:border-slate-800 dark:bg-slate-900">
        <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">All Agents CLV Performance</h3>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">
          Ranked list of sales representatives by the average Customer Lifetime Value of policies they sold.
        </p>
        <div className="mt-4">
          <DataTable
            columns={[
              { key: 'rank', label: 'Rank' },
              { key: 'agent_id', label: 'Agent ID' },
              { key: 'agent_name', label: 'Agent Name' },
              {
                key: 'avg_clv',
                label: 'Average CLV',
                render: (row) => formatCurrency(Number(row.avg_clv || 0))
              },
              {
                key: 'customer_count',
                label: 'Policies Sold',
                render: (row) => Number(row.customer_count || 0).toLocaleString()
              }
            ]}
            rows={data.agent_clv.map((row, index) => ({
              rank: index + 1,
              ...row
            }))}
          />
        </div>
      </article>

      {/* Handoff Modal (Agentic Coordination Animation) */}
      <AnimatePresence>
        {isHandoffOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="relative w-full max-w-2xl overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl dark:border-slate-800 dark:bg-slate-900"
            >
              {/* Header */}
              <div className="border-b border-slate-100 px-6 py-4 dark:border-slate-800 flex items-center gap-3">
                <div className="rounded-lg bg-blue-100 p-2 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400">
                  <Cpu className="h-5 w-5 animate-spin" style={{ animationDuration: '3s' }} />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
                    Agentic System Coordination Gateway
                  </h3>
                  <p className="text-xs text-slate-500">Cross-Platform Handoff and Pipeline Activation</p>
                </div>
              </div>

              {/* Console log area */}
              <div className="bg-slate-950 font-mono text-xs text-slate-300 p-5 h-72 overflow-y-auto space-y-2 select-none border-b border-slate-800">
                {handoffLogs.map((log, index) => {
                  let colorClass = 'text-slate-400';
                  if (log.includes('[SUCCESS]')) colorClass = 'text-emerald-400 font-bold';
                  if (log.includes('[ACTION]')) colorClass = 'text-blue-400 font-bold';
                  if (log.includes('🤖')) colorClass = 'text-indigo-400 font-bold';
                  return (
                    <div key={index} className={`flex items-start gap-2 ${colorClass}`}>
                      <span className="text-slate-600">&gt;</span>
                      <span>{log}</span>
                    </div>
                  );
                })}
                {!isHandoffDone && (
                  <div className="flex items-center gap-1.5 text-blue-400">
                    <span className="text-slate-600">&gt;</span>
                    <span className="h-4 w-1 animate-pulse bg-blue-400"></span>
                    <span>Processing mapping routines...</span>
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="bg-slate-50 px-6 py-4 dark:bg-slate-900/60 flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  {isHandoffDone ? (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                      <CheckCircle className="h-4 w-4" /> Ready for Clustering
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1.5 text-xs text-slate-500">
                      <div className="h-2 w-2 animate-ping rounded-full bg-blue-500"></div>
                      Executing pipeline commands
                    </span>
                  )}
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => setIsHandoffOpen(false)}
                    className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700"
                  >
                    Close console
                  </button>
                  {isHandoffDone && (
                    <a
                      href="http://localhost:3000"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 rounded-xl bg-blue-600 px-4 py-2 text-xs font-bold text-white hover:bg-blue-700 shadow"
                    >
                      Open Agent360
                      <ArrowUpRight className="h-3.5 w-3.5" />
                    </a>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
};

export default AgentAnalytics;
