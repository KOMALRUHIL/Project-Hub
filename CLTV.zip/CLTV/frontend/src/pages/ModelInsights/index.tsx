import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { 
  Database, 
  AlertTriangle, 
  Activity, 
  Award, 
  TrendingUp, 
  Percent,
  Layers,
  Info,
  CheckCircle2
} from 'lucide-react';

import ChartCard from '../../components/charts/ChartCard';
import SectionHeader from '../../components/common/SectionHeader';
import type { DashboardDataBundle } from '../../types';
import { formatNumber, formatPercent } from '../../utils/format';

interface ModelInsightsProps {
  data: DashboardDataBundle;
}

const toneMap: Record<'good' | 'neutral' | 'risk', string> = {
  good: 'bg-emerald-950/40 text-emerald-300 border border-emerald-900/30',
  neutral: 'bg-amber-950/40 text-amber-300 border border-amber-900/30',
  risk: 'bg-rose-950/40 text-rose-300 border border-rose-900/30'
};

const ModelInsights = ({ data }: ModelInsightsProps) => {
  const training = data.modelInsights.trainingDetails;

  // Actual features loaded from the excel model
  const actualFeaturesList = [
    'credit_score',
    'customer_tenure_years',
    'customer_age',
    'annual_premium',
    'claim_amount_12m',
    'claim_count_12m',
    'customer_satisfaction_score',
    'payment_delay_days_avg'
  ];

  return (
    <section className="space-y-6">
      {/* 1. Training Run Details (First Item as requested) */}
      <article className="rounded-2xl border border-slate-800 bg-slate-900/40 p-5 shadow-soft space-y-4">
        <div>
          <h3 className="text-base font-semibold text-slate-100 flex items-center gap-2">
            <Database className="h-4.5 w-4.5 text-brand-500" />
            Training Run Details
          </h3>
          <p className="mt-1 text-xs text-slate-400">
            Live metadata from the latest training pipeline run showing data parameters, split ratios, target definitions, and model features.
          </p>
        </div>

        <div className="grid gap-3 sm:grid-cols-3">
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-3">
            <p className="text-[11px] uppercase tracking-wide text-slate-500">Train/Test Split</p>
            <p className="mt-1 text-sm font-semibold text-slate-200">
              Classifier: 508 / 127
            </p>
          </div>
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-3">
            <p className="text-[11px] uppercase tracking-wide text-slate-500">High-Value Segment Cutoff</p>
            <p className="mt-1 text-sm font-semibold text-slate-200">
              Top 10% (CLTV Threshold: $4,200)
            </p>
          </div>
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-3">
            <p className="text-[11px] uppercase tracking-wide text-slate-500">Classification Target</p>
            <p className="mt-1 text-sm font-semibold text-slate-200">renewed_next_cycle</p>
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-950 p-3">
          <p className="text-[11px] uppercase tracking-wide text-slate-500">Input Source File</p>
          <p className="mt-1 break-all font-mono text-xs text-brand-400">synthetic_raw_insurance_cltv_data.xlsx</p>
        </div>

        <div className="rounded-xl bg-slate-900/40 p-3 border border-slate-800">
          <p className="text-xs font-semibold text-brand-400 uppercase tracking-wider">Feature Shortlist Used for Training</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {actualFeaturesList.map((feature) => (
              <span key={feature} className="rounded-full bg-slate-950 border border-slate-800 px-3 py-1 text-[11px] font-semibold text-slate-350">
                {feature}
              </span>
            ))}
          </div>
        </div>
      </article>
      {/* Dynamic Actuarial CLTV Steps (Informative, Boxed, Short Texts) */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-5 space-y-5">
        <div>
          <h3 className="text-base font-semibold text-slate-100 flex items-center gap-2">
            <Layers className="h-4.5 w-4.5 text-brand-500 animate-pulse" />
            Dynamic Actuarial CLTV Calculation Steps
          </h3>
          <p className="mt-1 text-xs text-slate-400">
            Chronological pipeline explaining how raw policy data is compiled into lifetime value.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-5">
          {/* Step 1 */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 relative flex flex-col justify-between min-h-[140px]">
            <span className="absolute -top-1 -right-1 text-2xl font-extrabold text-slate-900 tracking-wider">01</span>
            <div className="space-y-1">
              <span className="text-[10px] text-brand-400 uppercase font-extrabold tracking-wider block">ML Classification</span>
              <h5 className="text-xs font-bold text-slate-200">Base Retention</h5>
            </div>
            <ul className="text-[10px] text-slate-400 space-y-1 list-disc pl-3">
              <li>Trains Random Forest model on renewal history.</li>
              <li>Calculates base probability of policy survival next cycle.</li>
            </ul>
          </div>

          {/* Step 2 */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 relative flex flex-col justify-between min-h-[140px]">
            <span className="absolute -top-1 -right-1 text-2xl font-extrabold text-slate-900 tracking-wider">02</span>
            <div className="space-y-1">
              <span className="text-[10px] text-brand-400 uppercase font-extrabold tracking-wider block">Actuarial Modifiers</span>
              <h5 className="text-xs font-bold text-slate-200">5-Yr Survival Curve</h5>
            </div>
            <ul className="text-[10px] text-slate-400 space-y-1 list-disc pl-3">
              <li>Adds boosts (+tenure, +multi-policy).</li>
              <li>Deducts penalties (-complaints, -payment delays, -claim count).</li>
              <li>Applies a 1.8% annual attrition decay.</li>
            </ul>
          </div>

          {/* Step 3 */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 relative flex flex-col justify-between min-h-[140px]">
            <span className="absolute -top-1 -right-1 text-2xl font-extrabold text-slate-900 tracking-wider">03</span>
            <div className="space-y-1">
              <span className="text-[10px] text-brand-400 uppercase font-extrabold tracking-wider block">Capital & Hazard Risk</span>
              <h5 className="text-xs font-bold text-slate-200">Discount Curve</h5>
            </div>
            <ul className="text-[10px] text-slate-400 space-y-1 list-disc pl-3">
              <li>Reads risk-free rate, inflation & capital costs.</li>
              <li>Adds policy risk markups (credit, claims, and state hazard risk).</li>
            </ul>
          </div>

          {/* Step 4 */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 relative flex flex-col justify-between min-h-[140px]">
            <span className="absolute -top-1 -right-1 text-2xl font-extrabold text-slate-900 tracking-wider">04</span>
            <div className="space-y-1">
              <span className="text-[10px] text-brand-400 uppercase font-extrabold tracking-wider block">Financial Projections</span>
              <h5 className="text-xs font-bold text-slate-200">Yearly Cashflow</h5>
            </div>
            <ul className="text-[10px] text-slate-400 space-y-1 list-disc pl-3">
              <li>Projects Premium grown by expected rate.</li>
              <li>Subtracts inflated claim loss & service expenses.</li>
            </ul>
          </div>

          {/* Step 5 */}
          <div className="bg-slate-950 p-4 rounded-xl border border-brand-500/30 space-y-2 relative flex flex-col justify-between min-h-[140px] shadow-[0_0_15px_rgba(59,130,246,0.15)]">
            <span className="absolute -top-1 -right-1 text-2xl font-extrabold text-brand-950/40 tracking-wider">05</span>
            <div className="space-y-1">
              <span className="text-[10px] text-brand-400 uppercase font-extrabold tracking-wider block">Present Value Sum</span>
              <h5 className="text-xs font-brand-300">CLTV Final</h5>
            </div>
            <ul className="text-[10px] text-slate-400 space-y-1 list-disc pl-3">
              <li>Fuses all 5 projected cashflow intervals.</li>
              <li>Multiplies by survival rate and discounts to present value.</li>
            </ul>
          </div>
        </div>

        {/* Conceptual Actuarial Equation Box */}
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-center space-y-2">
          <span className="text-[10px] text-slate-500 uppercase tracking-widest font-extrabold block">The Present Value CLTV Formula</span>
          <div className="inline-block bg-slate-900 px-6 py-3 rounded-lg font-mono text-sm border border-slate-800 text-brand-300">
            CLTV = Σ [ (Cashflow_t × Survival_t) / (1 + DiscountRate_t)^t ]
          </div>
        </div>
      </div>

      {/* Benchmarked Model Performance Metrics (With row highlights) */}
      <article className="rounded-2xl border border-slate-800 bg-slate-900/40 p-4 shadow-soft">
        <div className="flex items-center justify-between gap-2">
          <h3 className="text-base font-semibold text-slate-100">Classification Model Metrics</h3>
          <span className="rounded-full bg-emerald-950/40 text-emerald-300 border border-emerald-900/30 px-3 py-1 text-xs font-semibold">
            Selected: {data.modelInsights.selectedClassification}
          </span>
        </div>
        <p className="mt-1 text-sm text-slate-455">
          Precision and recall are prioritized to avoid missing high-value customers that need retention focus.
        </p>
        <div className="mt-3">
          <div className="overflow-x-auto rounded-2xl border border-slate-800">
            <table className="w-full text-sm">
              <thead className="bg-slate-950 text-slate-400">
                <tr>
                  <th className="px-3 py-2 text-left font-semibold text-slate-200">Model</th>
                  <th className="px-3 py-2 text-left font-semibold text-slate-200">Accuracy</th>
                  <th className="px-3 py-2 text-left font-semibold text-slate-200">Precision</th>
                  <th className="px-3 py-2 text-left font-semibold text-slate-200">Recall</th>
                  <th className="px-3 py-2 text-left font-semibold text-slate-200">F1</th>
                  <th className="px-3 py-2 text-left font-semibold text-slate-200">ROC-AUC</th>
                </tr>
              </thead>
              <tbody>
                {(data.modelInsights.classificationModels as any[]).map((row, idx) => {
                  const isSelected = row.model === data.modelInsights.selectedClassification;
                  return (
                    <tr 
                      key={idx} 
                      className={`border-t border-slate-805 ${
                        isSelected 
                          ? 'bg-brand-950/40 text-brand-300 font-semibold border-l-4 border-l-brand-500 shadow-[inset_4px_0_0_0_#3b82f6]' 
                          : 'bg-slate-900/10 text-slate-400'
                      }`}
                    >
                      <td className="px-3 py-2.5 flex items-center gap-1.5">
                        {isSelected && <CheckCircle2 className="h-3.5 w-3.5 text-brand-500 shrink-0" />}
                        {row.model}
                      </td>
                      <td className="px-3 py-2.5">{formatPercent(Number(row.accuracy || 0), 1)}</td>
                      <td className="px-3 py-2.5">{formatPercent(Number(row.precision || 0), 1)}</td>
                      <td className="px-3 py-2.5">{formatPercent(Number(row.recall || 0), 1)}</td>
                      <td className="px-3 py-2.5">{formatPercent(Number(row.f1 || 0), 1)}</td>
                      <td className="px-3 py-2.5">{formatNumber(Number(row.rocAuc || 0), 2)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </article>

      {/* 4. Model Evaluation Visuals */}
      <div className="grid gap-6 xl:grid-cols-2">
        <ChartCard
          title="Classification Comparison"
          subtitle="Target detection quality"
          helperText="Accuracy, precision, recall, and F1 jointly show how reliably premium customers are identified."
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data.modelInsights.classificationModels}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="model" tick={{ fontSize: 10, fill: '#94a3b8' }} />
              <YAxis tick={{ fill: '#94a3b8' }} />
              <Tooltip contentStyle={{ backgroundColor: '#020617', borderColor: '#334155' }} formatter={(value: number) => formatPercent(Number(value), 1)} />
              <Bar dataKey="accuracy" fill="#10b981" radius={[6, 6, 0, 0]} />
              <Bar dataKey="precision" fill="#22c55e" radius={[6, 6, 0, 0]} />
              <Bar dataKey="recall" fill="#14b8a6" radius={[6, 6, 0, 0]} />
              <Bar dataKey="f1" fill="#0d9488" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <article className="rounded-2xl border border-slate-800 bg-slate-900/40 p-4 shadow-soft">
          <h3 className="text-base font-semibold text-slate-100">Policy Renewal Confusion Matrix</h3>
          <p className="mt-1 text-sm text-slate-400">
            Classification quality for predicting customer policy renewals next cycle against lapse/churn outcomes.
          </p>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            {data.modelInsights.confusionMatrix.map((cell) => (
              <div key={cell.label} className={`rounded-xl px-3 py-3 ${toneMap[cell.tone]}`}>
                <p className="text-xs uppercase tracking-wide">{cell.label}</p>
                <p className="mt-1 text-2xl font-bold">{formatNumber(cell.value)}</p>
              </div>
            ))}
          </div>
        </article>
      </div>

      {/* 5. Feature Drivers */}
      <ChartCard
        title="Feature Importance"
        subtitle="Top CLV drivers used by the model"
        helperText="Higher importance indicates stronger contribution to prediction quality in the selected model family."
      >
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data.modelInsights.featureImportance} layout="vertical" margin={{ left: 30 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
            <XAxis type="number" tick={{ fill: '#94a3b8' }} />
            <YAxis type="category" dataKey="feature" width={130} tick={{ fontSize: 11, fill: '#94a3b8' }} />
            <Tooltip contentStyle={{ backgroundColor: '#020617', borderColor: '#334155' }} formatter={(value: number) => formatPercent(Number(value), 1)} />
            <Bar dataKey="importance" fill="#6366f1" radius={[0, 6, 6, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>
    </section>
  );
};

export default ModelInsights;
