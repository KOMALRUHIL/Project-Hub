# Explainability Summary

- SHAP status: **generated** (fallback chart is produced when SHAP is unavailable).
- Positive SHAP values indicate a feature contribution that pushes predicted CLV upward.
- Negative SHAP values indicate a feature contribution that pushes predicted CLV downward.

## Key Feature Interpretations
- `netloss_paid_am` is a top driver; higher values generally **decreases** predicted CLV in this portfolio context.
- `monetary` is a top driver; higher values generally **decreases** predicted CLV in this portfolio context.
- `directwrittenpremium_am` is a top driver; higher values generally **decreases** predicted CLV in this portfolio context.
- `complaintcount` is a top driver; higher values generally **decreases** predicted CLV in this portfolio context.
- `commission_expense_am` is a top driver; higher values generally **decreases** predicted CLV in this portfolio context.
- `zip` is a top driver; higher values generally **increases** predicted CLV in this portfolio context.