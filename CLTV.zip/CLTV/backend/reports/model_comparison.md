# Model Comparison

## Regression Models (CLV Prediction)
| model                     |       r2 |     mae |    rmse |     mape |
|:--------------------------|---------:|--------:|--------:|---------:|
| Ridge                     | 0.999944 | 110.925 | 155.022 |  6.17156 |
| LinearRegression          | 0.999944 | 110.92  | 155.023 |  6.22185 |
| Lasso                     | 0.999943 | 112.185 | 156.802 |  9.0075  |
| GradientBoostingRegressor | 0.999568 | 169.158 | 430.13  | 25.4548  |
| RandomForestRegressor     | 0.999376 | 143.781 | 517.273 | 11.9707  |

## Classification Models (High-Value Identification)
| model                      |   accuracy |   precision |   recall |       f1 |   roc_auc |
|:---------------------------|-----------:|------------:|---------:|---------:|----------:|
| GradientBoostingClassifier |     0.9764 |    0.9375   |   0.945  | 0.941235 |  0.996049 |
| RandomForestClassifier     |     0.9754 |    0.937625 |   0.9395 | 0.938561 |  0.997016 |
| LogisticRegression         |     0.9751 |    0.940171 |   0.935  | 0.937578 |  0.995885 |

## Final Model Selection Rationale
- Selected regression model: **Ridge** based on strongest R2 with competitive MAE/RMSE stability.
- Selected classification model: **GradientBoostingClassifier** based on best F1 and recall balance for premium-customer capture.
- Selection prioritized business utility: high-value customer miss rate was treated as costly, so recall and F1 were emphasized.