import numpy as np
import pandas as pd


def derive_continuation_probabilities(retention_output: pd.DataFrame,
                                      policy_base: pd.DataFrame,
                                      projection_years: int) -> pd.DataFrame:
    """
    Derives year-wise continuation probability after retention is calculated.

    This is not raw input.
    This is a calculated output used in the CLTV formula.
    """
    cols_needed = [
        "customer_id", "policy_id", "policy_tenure_years", "number_of_policies",
        "customer_satisfaction_score", "complaint_count_12m", "payment_delay_days_avg",
        "loss_ratio_12m", "digital_engagement_score"
    ]

    available = [c for c in cols_needed if c in policy_base.columns]

    df = retention_output.merge(
        policy_base[available].drop_duplicates(["customer_id", "policy_id"]),
        on=["customer_id", "policy_id"],
        how="left"
    )

    base = df["base_retention_probability"].astype(float)

    tenure_boost = np.minimum(pd.to_numeric(df.get("policy_tenure_years", 0), errors="coerce").fillna(0) * 0.004, 0.050)
    loyalty_boost = np.minimum(pd.to_numeric(df.get("number_of_policies", 1), errors="coerce").fillna(1) * 0.012, 0.050)

    satisfaction = pd.to_numeric(df.get("customer_satisfaction_score", 3), errors="coerce").fillna(3)
    satisfaction_boost = ((satisfaction - satisfaction.mean()) / max(satisfaction.std(), 1)) * 0.015
    satisfaction_boost = satisfaction_boost.clip(-0.04, 0.04)

    complaint_penalty = np.minimum(pd.to_numeric(df.get("complaint_count_12m", 0), errors="coerce").fillna(0) * 0.015, 0.080)
    payment_penalty = np.minimum(pd.to_numeric(df.get("payment_delay_days_avg", 0), errors="coerce").fillna(0) * 0.003, 0.080)
    loss_penalty = np.minimum(pd.to_numeric(df.get("loss_ratio_12m", 0), errors="coerce").fillna(0) * 0.030, 0.100)

    annual_continuation_base = (
        base
        + tenure_boost
        + loyalty_boost
        + satisfaction_boost
        - complaint_penalty
        - payment_penalty
        - loss_penalty
    ).clip(0.30, 0.97)

    out = df[["customer_id", "policy_id", "base_retention_probability"]].copy()

    cumulative = pd.Series(1.0, index=df.index)

    for year in range(1, projection_years + 1):
        time_decay = 0.018 * (year - 1)
        annual_prob = (annual_continuation_base - time_decay).clip(0.20, 0.97)
        cumulative = cumulative * annual_prob
        out[f"continuation_probability_year_{year}"] = cumulative.round(6)

    return out
