import numpy as np
import pandas as pd


def normalize_rate(series: pd.Series) -> pd.Series:
    """
    Handles rates stored as 0.05 or 5.
    If values look like percentages above 1, convert to decimal.
    """
    s = pd.to_numeric(series, errors="coerce")
    if s.dropna().empty:
        return s.fillna(0)
    if s.quantile(0.90) > 1:
        s = s / 100
    return s.fillna(s.median())


def safe_divide(numerator, denominator, default=0):
    numerator = pd.to_numeric(numerator, errors="coerce")
    denominator = pd.to_numeric(denominator, errors="coerce")
    result = numerator / denominator.replace(0, np.nan)
    return result.replace([np.inf, -np.inf], np.nan).fillna(default)


def minmax(series: pd.Series, higher_is_risk=True) -> pd.Series:
    s = pd.to_numeric(series, errors="coerce").fillna(0)
    min_v = s.min()
    max_v = s.max()
    if max_v == min_v:
        out = pd.Series(0.5, index=s.index)
    else:
        out = (s - min_v) / (max_v - min_v)
    if not higher_is_risk:
        out = 1 - out
    return out.clip(0, 1)


def clean_column_names(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    return df


def ensure_output_dir(path):
    path.parent.mkdir(parents=True, exist_ok=True)


def get_existing_columns(df: pd.DataFrame, columns: list) -> list:
    return [c for c in columns if c in df.columns]