import numpy as np
import pandas as pd

from config import UNDERWRITING_RISK_MAP
from utils import minmax, normalize_rate


def calculate_risk_components(policy_base: pd.DataFrame) -> pd.DataFrame:
    """
    Calculates measurable risk components used by discount-rate module.
    """
    df = policy_base.copy()

    out = df[["customer_id", "policy_id"]].copy()

    if "credit_score" in df.columns:
        out["credit_risk_score"] = minmax(850 - pd.to_numeric(df["credit_score"], errors="coerce").fillna(650))
    else:
        out["credit_risk_score"] = 0.5

    claim_base = (
        minmax(df.get("loss_ratio_12m", pd.Series(0, index=df.index))) * 0.60
        + minmax(df.get("claim_count_12m", pd.Series(0, index=df.index))) * 0.20
        + minmax(df.get("claim_amount_12m", pd.Series(0, index=df.index))) * 0.20
    )
    out["claim_risk_score"] = claim_base.clip(0, 1)

    payment_base = (
        minmax(df.get("payment_delay_days_avg", pd.Series(0, index=df.index))) * 0.55
        + minmax(df.get("missed_payment_count_12m", pd.Series(0, index=df.index))) * 0.45
    )
    out["payment_risk_score"] = payment_base.clip(0, 1)

    service_base = (
        minmax(df.get("complaint_count_12m", pd.Series(0, index=df.index))) * 0.35
        + minmax(df.get("customer_service_call_count_12m", pd.Series(0, index=df.index))) * 0.25
        + minmax(df.get("unresolved_ticket_count", pd.Series(0, index=df.index))) * 0.25
        + minmax(df.get("customer_satisfaction_score", pd.Series(3, index=df.index)), higher_is_risk=False) * 0.15
    )
    out["service_risk_score"] = service_base.clip(0, 1)

    if "underwriting_risk_class" in df.columns:
        out["underwriting_risk_score"] = df["underwriting_risk_class"].map(UNDERWRITING_RISK_MAP).fillna(0.45)
    else:
        out["underwriting_risk_score"] = 0.45

    geo_cols = [
        "catastrophe_risk_score",
        "weather_risk_score",
        "economic_risk_score",
        "regulatory_risk_score"
    ]
    available_geo = [c for c in geo_cols if c in df.columns]

    if available_geo:
        geo = pd.DataFrame({c: minmax(df[c]) for c in available_geo})
        out["geography_risk_score"] = geo.mean(axis=1).clip(0, 1)
    else:
        out["geography_risk_score"] = 0.5

    return out


def calculate_policy_risk_score(risk_components: pd.DataFrame) -> pd.DataFrame:
    """
    Combines risk components into policy_risk_score.
    """
    out = risk_components.copy()

    out["policy_risk_score"] = (
        0.20 * out["credit_risk_score"]
        + 0.25 * out["claim_risk_score"]
        + 0.15 * out["payment_risk_score"]
        + 0.15 * out["service_risk_score"]
        + 0.15 * out["underwriting_risk_score"]
        + 0.10 * out["geography_risk_score"]
    ).clip(0, 1)

    return out


def build_discount_rate_curve(policy_risk: pd.DataFrame,
                              macro_df: pd.DataFrame,
                              projection_years: int) -> pd.DataFrame:
    """
    Builds year-wise dynamic discount rate.

    Discount rate =
    risk-free rate
    + inflation component
    + company capital component
    + policy risk premium
    + term premium
    """
    macro = macro_df.copy()

    if "projection_year" not in macro.columns:
        macro["projection_year"] = range(1, len(macro) + 1)

    for col in [
        "risk_free_rate",
        "inflation_rate",
        "company_cost_of_capital",
        "base_term_premium"
    ]:
        if col not in macro.columns:
            macro[col] = 0

        macro[col] = normalize_rate(macro[col])

    out = policy_risk.copy()

    for year in range(1, projection_years + 1):
        row = macro[macro["projection_year"] == year]

        if row.empty:
            row = macro.iloc[[min(year - 1, len(macro) - 1)]]

        risk_free = float(row["risk_free_rate"].iloc[0])
        inflation = float(row["inflation_rate"].iloc[0])
        cost_of_capital = float(row["company_cost_of_capital"].iloc[0])
        term_premium = float(row["base_term_premium"].iloc[0])

        out[f"risk_free_rate_year_{year}"] = risk_free
        out[f"inflation_rate_year_{year}"] = inflation
        out[f"company_cost_of_capital_year_{year}"] = cost_of_capital
        out[f"term_premium_year_{year}"] = term_premium

        out[f"discount_rate_year_{year}"] = (
            risk_free
            + 0.40 * inflation
            + 0.30 * cost_of_capital
            + 0.05 * out["policy_risk_score"]
            + term_premium
        ).clip(0.035, 0.20).round(6)

    return out