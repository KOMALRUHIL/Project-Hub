import pandas as pd
from config import SHEETS
from utils import clean_column_names


def load_raw_data(input_file) -> dict:
    """
    Loads all required raw Excel sheets.
    """
    xls = pd.ExcelFile(input_file)
    available = set(xls.sheet_names)

    data = {}

    for key, sheet_name in SHEETS.items():
        if sheet_name in available:
            data[key] = clean_column_names(pd.read_excel(input_file, sheet_name=sheet_name))
        else:
            data[key] = pd.DataFrame()

    return data
