from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

INPUT_FILE = BASE_DIR / "input" / "synthetic_raw_insurance_cltv_data.xlsx"
OUTPUT_FILE = BASE_DIR / "output" / "dynamic_customer_level_cltv_output.xlsx"

PROJECTION_YEARS = 5
RANDOM_STATE = 42
TEST_SIZE = 0.20

SHEETS = {
    "customers": "Customer_Master",
    "policies": "Policy_Master",
    "payments": "Premium_Payment_History",
    "claims": "Claims_History",
    "expenses": "Expense_Service_Data",
    "agents": "Agent_Channel_Data",
    "macro": "Macro_Finance_Assumptions",
    "geography": "Geography_Risk_Data",
    "renewal": "Renewal_Lapse_History",
    "feature_dictionary": "Feature_Dictionary",
}

SEGMENT_THRESHOLDS = {
    "low": 1500,
    "medium": 5000,
    "high": 10000,
}

RETENTION_BANDS = {
    "low": 0.50,
    "medium": 0.75,
}

UNDERWRITING_RISK_MAP = {
    "Preferred": 0.20,
    "Standard": 0.45,
    "Substandard": 0.75,
    "High Risk": 0.90,
}

POLICY_TYPE_LOSS_FALLBACK = {
    "Auto": 0.55,
    "Home": 0.45,
    "Health": 0.70,
    "Life": 0.30,
    "Annuity": 0.15,
}

