import pandas as pd
from openpyxl.styles import Font, PatternFill, Border, Side
from openpyxl.utils import get_column_letter


def create_executive_summary(data,
                             retention_eval,
                             retention_output,
                             continuation_output,
                             discount_rate_build,
                             customer_actions,
                             best_model_name):
    """
    Creates top-level management summary.
    """
    customers = data["customers"]
    policies = data["policies"]

    total_positive = customer_actions.loc[
        customer_actions["customer_dynamic_cltv"] > 0,
        "customer_dynamic_cltv"
    ].sum()

    total_negative = customer_actions.loc[
        customer_actions["customer_dynamic_cltv"] < 0,
        "customer_dynamic_cltv"
    ].sum()

    best_eval = retention_eval[retention_eval["model_name"] == best_model_name].iloc[0]

    rows = [
        ("Total Customers", len(customers)),
        ("Total Policies", len(policies)),
        ("Average Policies per Customer", round(len(policies) / max(len(customers), 1), 2)),
        ("Best Retention Model", best_model_name),
        ("Retention Model AUC", best_eval.get("auc")),
        ("Retention Model Accuracy", best_eval.get("accuracy")),
        ("Average Base Retention Probability", round(retention_output["base_retention_probability"].mean(), 4)),
        ("Average Year 1 Continuation Probability", round(continuation_output["continuation_probability_year_1"].mean(), 4)),
        ("Average Year 5 Continuation Probability", round(continuation_output["continuation_probability_year_5"].mean(), 4)),
        ("Average Year 1 Discount Rate", round(discount_rate_build["discount_rate_year_1"].mean(), 4)),
        ("Average Year 5 Discount Rate", round(discount_rate_build["discount_rate_year_5"].mean(), 4)),
        ("Average Customer CLTV", round(customer_actions["customer_dynamic_cltv"].mean(), 2)),
        ("Total Portfolio CLTV", round(customer_actions["customer_dynamic_cltv"].sum(), 2)),
        ("Total Positive CLTV", round(total_positive, 2)),
        ("Total Negative CLTV", round(total_negative, 2)),
        ("Negative Value Customers", int((customer_actions["customer_segment"] == "Negative Value").sum())),
        ("Premium Value Customers", int((customer_actions["customer_segment"] == "Premium Value").sum())),
    ]

    return pd.DataFrame(rows, columns=["metric", "value"])


def create_methodology_assumptions() -> pd.DataFrame:
    rows = [
        ("Overall Design", "The pipeline starts from raw measurable customer, policy, claims, payment, expense, service, agent, geography, and finance data."),
        ("Manager Correction Applied", "Survival probability is not used as a raw input. Retention probability is calculated directly from raw measurable features."),
        ("Retention Module", "Uses renewal/lapse history as the target and raw business variables as inputs to calculate base_retention_probability."),
        ("Continuation Probability", "Derived after retention is calculated. It creates year-wise continuation probabilities required by the CLTV formula."),
        ("Discount Rate Module", "Calculated separately using macro-finance assumptions and policy/customer risk factors."),
        ("Cashflow Projection", "Projects premium, loss, expense, and net cashflow for each policy across 5 years."),
        ("Policy-Level CLTV", "Calculated first because one customer can have multiple policies."),
        ("Customer-Level CLTV", "Final target. Policy CLTV values are aggregated by customer_id."),
        ("Segmentation", "Customers are segmented into Negative, Low, Medium, High, and Premium Value based on customer-level CLTV."),
        ("Actions", "Recommended action is assigned using CLTV, retention, risk, and policy count."),
        ("Synthetic Data Note", "Current values are synthetic for POC. With real client data, the same pipeline can be reused after schema mapping."),
    ]

    return pd.DataFrame(rows, columns=["section", "explanation"])


def write_output_excel(output_file, sheets: dict):
    """
    Writes all output sheets to Excel with simple professional formatting.
    """
    with pd.ExcelWriter(output_file, engine="openpyxl") as writer:
        for sheet_name, df in sheets.items():
            if df is None:
                continue

            if not isinstance(df, pd.DataFrame):
                continue

            safe_name = sheet_name[:31]
            df.to_excel(writer, sheet_name=safe_name, index=False)

        workbook = writer.book

        for ws in workbook.worksheets:
            ws.freeze_panes = "A2"

            header_fill = PatternFill("solid", fgColor="1F4E78")
            header_font = Font(color="FFFFFF", bold=True)
            thin = Side(border_style="thin", color="D9E2F3")

            for cell in ws[1]:
                cell.fill = header_fill
                cell.font = header_font
                cell.border = Border(bottom=thin)

            for col in ws.columns:
                max_length = 0
                col_letter = get_column_letter(col[0].column)

                for cell in col:
                    try:
                        max_length = max(max_length, len(str(cell.value)))
                    except Exception:
                        pass

                adjusted_width = min(max(max_length + 2, 12), 45)
                ws.column_dimensions[col_letter].width = adjusted_width

    return output_file
