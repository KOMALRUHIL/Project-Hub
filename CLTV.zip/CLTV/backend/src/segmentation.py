import pandas as pd
from config import SEGMENT_THRESHOLDS


def assign_customer_segments(customer_cltv: pd.DataFrame) -> pd.DataFrame:
    """
    Assigns CLTV customer segments.
    """
    df = customer_cltv.copy()

    def segment(cltv):
        if cltv < 0:
            return "Negative Value"
        if cltv < SEGMENT_THRESHOLDS["low"]:
            return "Low Value"
        if cltv < SEGMENT_THRESHOLDS["medium"]:
            return "Medium Value"
        if cltv < SEGMENT_THRESHOLDS["high"]:
            return "High Value"
        return "Premium Value"

    df["customer_segment"] = df["customer_dynamic_cltv"].apply(segment)
    return df


def assign_recommended_actions(customer_segments: pd.DataFrame) -> pd.DataFrame:
    """
    Assigns business action from customer CLTV, retention, risk, and policies.
    """
    df = customer_segments.copy()

    def action(row):
        cltv = row.get("customer_dynamic_cltv", 0)
        retention = row.get("avg_base_retention_probability", 0)
        risk = row.get("avg_policy_risk_score", 0)
        policies = row.get("number_of_policies", 1)

        if cltv < 0:
            return "Cost control / underwriting review"

        if cltv > 5000 and retention < 0.55:
            return "High-priority retention campaign"

        if cltv > 10000 and policies <= 1:
            return "Premium upsell / cross-sell campaign"

        if risk > 0.70:
            return "Risk-adjusted pricing review"

        if cltv > 5000:
            return "Loyalty / premium servicing"

        return "Standard servicing"

    def reason(row):
        action_value = row["recommended_action"]

        if action_value == "Cost control / underwriting review":
            return "Customer CLTV is negative; expected future loss/expense exceeds value."

        if action_value == "High-priority retention campaign":
            return "Customer has high CLTV but weak retention probability."

        if action_value == "Premium upsell / cross-sell campaign":
            return "Customer has premium CLTV and low policy count."

        if action_value == "Risk-adjusted pricing review":
            return "Customer has elevated risk score."

        if action_value == "Loyalty / premium servicing":
            return "Customer has strong positive CLTV."

        return "Customer has standard value/risk profile."

    df["recommended_action"] = df.apply(action, axis=1)
    df["reason_for_action"] = df.apply(reason, axis=1)

    return df


def create_segment_summary(customer_actions: pd.DataFrame) -> pd.DataFrame:
    """
    Creates summary by customer value segment.
    """
    return customer_actions.groupby("customer_segment").agg(
        customer_count=("customer_id", "count"),
        average_cltv=("customer_dynamic_cltv", "mean"),
        total_cltv=("customer_dynamic_cltv", "sum"),
        average_retention=("avg_base_retention_probability", "mean"),
        average_risk_score=("avg_policy_risk_score", "mean"),
        average_discount_rate_year_1=("avg_discount_rate_year_1", "mean"),
        average_number_of_policies=("number_of_policies", "mean")
    ).reset_index()


def create_action_summary(customer_actions: pd.DataFrame) -> pd.DataFrame:
    """
    Creates summary by recommended business action.
    """
    return customer_actions.groupby("recommended_action").agg(
        customer_count=("customer_id", "count"),
        average_cltv=("customer_dynamic_cltv", "mean"),
        average_retention=("avg_base_retention_probability", "mean"),
        average_risk_score=("avg_policy_risk_score", "mean")
    ).reset_index()