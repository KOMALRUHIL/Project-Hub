import pandas as pd


def calculate_policy_level_cltv(cashflow_df: pd.DataFrame,
                                continuation_df: pd.DataFrame,
                                discount_df: pd.DataFrame,
                                projection_years: int) -> pd.DataFrame:
    """
    Calculates policy-level CLTV using continuation probability and discount rate.
    """
    df = cashflow_df.merge(
        continuation_df,
        on=["customer_id", "policy_id"],
        how="left"
    ).merge(
        discount_df,
        on=["customer_id", "policy_id"],
        how="left"
    )

    out = df[["customer_id", "policy_id", "policy_type"]].copy()

    total = 0

    for year in range(1, projection_years + 1):
        net_cf = pd.to_numeric(df[f"net_cashflow_year_{year}"], errors="coerce").fillna(0)
        cont = pd.to_numeric(df[f"continuation_probability_year_{year}"], errors="coerce").fillna(0)
        disc = pd.to_numeric(df[f"discount_rate_year_{year}"], errors="coerce").fillna(0)

        cltv_year = net_cf * cont / ((1 + disc) ** year)

        out[f"policy_cltv_year_{year}"] = cltv_year.round(2)
        total = total + cltv_year

    out["policy_dynamic_cltv"] = total.round(2)

    return out


def aggregate_customer_level_cltv(policy_cltv: pd.DataFrame,
                                  policy_base: pd.DataFrame,
                                  retention_output: pd.DataFrame,
                                  continuation_output: pd.DataFrame,
                                  discount_df: pd.DataFrame) -> pd.DataFrame:
    """
    Aggregates policy CLTV to customer CLTV.
    """
    customer_financials = policy_base.groupby("customer_id").agg(
        number_of_policies=("policy_id", "count"),
        total_annual_premium=("annual_premium", "sum"),
        total_claim_amount_12m=("claim_amount_12m", "sum"),
        total_expense_12m=("total_expense_12m", "sum")
    ).reset_index()

    policy_value = policy_cltv.groupby("customer_id").agg(
        customer_dynamic_cltv=("policy_dynamic_cltv", "sum")
    ).reset_index()

    retention_summary = retention_output.groupby("customer_id").agg(
        avg_base_retention_probability=("base_retention_probability", "mean")
    ).reset_index()

    cont_cols = [c for c in continuation_output.columns if c.startswith("continuation_probability_year_")]
    cont_summary = continuation_output.groupby("customer_id")[cont_cols].mean().reset_index()
    cont_summary = cont_summary.rename(columns={
        "continuation_probability_year_1": "avg_continuation_probability_year_1",
        "continuation_probability_year_5": "avg_continuation_probability_year_5"
    })

    discount_cols = [c for c in discount_df.columns if c.startswith("discount_rate_year_")]
    discount_summary = discount_df.groupby("customer_id")[discount_cols].mean().reset_index()
    discount_summary = discount_summary.rename(columns={
        "discount_rate_year_1": "avg_discount_rate_year_1",
        "discount_rate_year_5": "avg_discount_rate_year_5"
    })

    risk_summary = discount_df.groupby("customer_id").agg(
        avg_policy_risk_score=("policy_risk_score", "mean")
    ).reset_index()

    out = customer_financials.merge(policy_value, on="customer_id", how="left")
    out = out.merge(retention_summary, on="customer_id", how="left")
    out = out.merge(
        cont_summary[[
            "customer_id",
            "avg_continuation_probability_year_1",
            "avg_continuation_probability_year_5"
        ]],
        on="customer_id",
        how="left"
    )
    out = out.merge(
        discount_summary[[
            "customer_id",
            "avg_discount_rate_year_1",
            "avg_discount_rate_year_5"
        ]],
        on="customer_id",
        how="left"
    )
    out = out.merge(risk_summary, on="customer_id", how="left")

    numeric_cols = [
        c for c in out.columns
        if c != "customer_id"
    ]

    for col in numeric_cols:
        out[col] = pd.to_numeric(out[col], errors="coerce")

    return out