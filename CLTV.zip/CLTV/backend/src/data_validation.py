import pandas as pd


def _add_issue(issues, table, issue_type, detail, severity="Medium"):
    issues.append({
        "table": table,
        "issue_type": issue_type,
        "detail": detail,
        "severity": severity
    })


def validate_raw_data(data: dict):
    """
    Runs core validation checks before modeling.
    """
    issues = []

    customers = data["customers"]
    policies = data["policies"]
    payments = data["payments"]
    claims = data["claims"]
    expenses = data["expenses"]
    agents = data["agents"]
    geography = data["geography"]
    renewal = data["renewal"]

    summary_rows = []

    for key, df in data.items():
        summary_rows.append({
            "table_name": key,
            "row_count": len(df),
            "column_count": len(df.columns),
            "missing_cells": int(df.isna().sum().sum()) if not df.empty else 0,
            "status": "Loaded" if not df.empty else "Missing or empty"
        })

    if not customers.empty and "customer_id" in customers.columns:
        if customers["customer_id"].duplicated().any():
            _add_issue(issues, "Customer_Master", "Duplicate Key", "Duplicate customer_id found", "High")

    if not policies.empty and "policy_id" in policies.columns:
        if policies["policy_id"].duplicated().any():
            _add_issue(issues, "Policy_Master", "Duplicate Key", "Duplicate policy_id found", "High")

    if not customers.empty and not policies.empty:
        if {"customer_id"}.issubset(customers.columns) and {"customer_id"}.issubset(policies.columns):
            missing_customers = set(policies["customer_id"]) - set(customers["customer_id"])
            if missing_customers:
                _add_issue(
                    issues,
                    "Policy_Master",
                    "Join Issue",
                    f"{len(missing_customers)} policy customer_id values not found in Customer_Master",
                    "High"
                )

    for table_name, df in {
        "Premium_Payment_History": payments,
        "Claims_History": claims,
        "Expense_Service_Data": expenses,
        "Renewal_Lapse_History": renewal
    }.items():
        if not df.empty and not policies.empty and "policy_id" in df.columns and "policy_id" in policies.columns:
            missing_policies = set(df["policy_id"]) - set(policies["policy_id"])
            if missing_policies:
                _add_issue(
                    issues,
                    table_name,
                    "Join Issue",
                    f"{len(missing_policies)} policy_id values not found in Policy_Master",
                    "High"
                )

    if not policies.empty and not agents.empty:
        if "agent_id" in policies.columns and "agent_id" in agents.columns:
            missing_agents = set(policies["agent_id"]) - set(agents["agent_id"])
            if missing_agents:
                _add_issue(
                    issues,
                    "Policy_Master",
                    "Join Issue",
                    f"{len(missing_agents)} agent_id values not found in Agent_Channel_Data",
                    "Medium"
                )

    if not policies.empty and not geography.empty:
        if "state" in policies.columns and "state" in geography.columns:
            missing_states = set(policies["state"]) - set(geography["state"])
            if missing_states:
                _add_issue(
                    issues,
                    "Policy_Master",
                    "Join Issue",
                    f"{len(missing_states)} state values not found in Geography_Risk_Data",
                    "Medium"
                )

    if not policies.empty:
        if "annual_premium" in policies.columns:
            bad = (pd.to_numeric(policies["annual_premium"], errors="coerce") <= 0).sum()
            if bad > 0:
                _add_issue(issues, "Policy_Master", "Value Issue", f"{bad} rows have annual_premium <= 0", "High")

        if "coverage_amount" in policies.columns:
            bad = (pd.to_numeric(policies["coverage_amount"], errors="coerce") <= 0).sum()
            if bad > 0:
                _add_issue(issues, "Policy_Master", "Value Issue", f"{bad} rows have coverage_amount <= 0", "Medium")

    if not renewal.empty:
        flag_cols = [c for c in ["renewed_flag", "lapsed_flag", "cancelled_flag", "surrendered_flag"] if c in renewal.columns]
        if flag_cols:
            flag_sum = renewal[flag_cols].fillna(0).sum(axis=1)
            conflicts = (flag_sum > 1).sum()
            if conflicts > 0:
                _add_issue(
                    issues,
                    "Renewal_Lapse_History",
                    "Target Conflict",
                    f"{conflicts} rows have more than one renewal/lapse flag",
                    "High"
                )

    validation_summary = pd.DataFrame(summary_rows)
    data_issues = pd.DataFrame(issues)

    if data_issues.empty:
        data_issues = pd.DataFrame([{
            "table": "All",
            "issue_type": "None",
            "detail": "No major validation issues found",
            "severity": "Info"
        }])

    return validation_summary, data_issues