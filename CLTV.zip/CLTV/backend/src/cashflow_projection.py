import pandas as pd
from utils import normalize_rate


def project_policy_cashflows(policy_base: pd.DataFrame,
                             macro_df: pd.DataFrame,
                             projection_years: int) -> pd.DataFrame:
    """
    Projects policy-level premium, loss, expense, and net cashflow.
    """
    macro = macro_df.copy()

    if "projection_year" not in macro.columns:
        macro["projection_year"] = range(1, len(macro) + 1)

    for col in [
        "expected_premium_growth_rate",
        "expected_expense_growth_rate",
        "expected_claim_inflation_rate"
    ]:
        if col not in macro.columns:
            macro[col] = 0

        macro[col] = normalize_rate(macro[col])

    out = policy_base[["customer_id", "policy_id", "policy_type"]].copy()

    annual_premium = pd.to_numeric(policy_base.get("annual_premium", 0), errors="coerce").fillna(0)
    claim_amount = pd.to_numeric(policy_base.get("claim_amount_12m", 0), errors="coerce").fillna(0)
    total_expense = pd.to_numeric(policy_base.get("total_expense_12m", 0), errors="coerce").fillna(0)

    for year in range(1, projection_years + 1):
        row = macro[macro["projection_year"] == year]

        if row.empty:
            row = macro.iloc[[min(year - 1, len(macro) - 1)]]

        premium_growth = float(row["expected_premium_growth_rate"].iloc[0])
        claim_inflation = float(row["expected_claim_inflation_rate"].iloc[0])
        expense_growth = float(row["expected_expense_growth_rate"].iloc[0])

        premium_y = annual_premium * ((1 + premium_growth) ** year)
        loss_y = claim_amount * ((1 + claim_inflation) ** year)
        expense_y = total_expense * ((1 + expense_growth) ** year)

        out[f"premium_year_{year}"] = premium_y.round(2)
        out[f"loss_year_{year}"] = loss_y.round(2)
        out[f"expense_year_{year}"] = expense_y.round(2)
        out[f"net_cashflow_year_{year}"] = (premium_y - loss_y - expense_y).round(2)

    return out