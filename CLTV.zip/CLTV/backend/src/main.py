from config import INPUT_FILE, OUTPUT_FILE, PROJECTION_YEARS
from utils import ensure_output_dir
from data_loader import load_raw_data
from data_validation import validate_raw_data
from feature_engineering import build_policy_modeling_base, create_retention_target
from retention_model import (
    prepare_retention_features,
    train_retention_models,
    get_feature_importance,
    score_retention_probability
)
from continuation_probability import derive_continuation_probabilities
from discount_rate import (
    calculate_risk_components,
    calculate_policy_risk_score,
    build_discount_rate_curve
)
from cashflow_projection import project_policy_cashflows
from cltv_engine import calculate_policy_level_cltv, aggregate_customer_level_cltv
from segmentation import (
    assign_customer_segments,
    assign_recommended_actions,
    create_segment_summary,
    create_action_summary
)
from reporting import (
    create_executive_summary,
    create_methodology_assumptions,
    write_output_excel
)


def main():
    print("Starting CLTV pipeline...")

    ensure_output_dir(OUTPUT_FILE)

    print("1. Loading raw data...")
    data = load_raw_data(INPUT_FILE)

    print("2. Validating raw data...")
    validation_summary, data_issues = validate_raw_data(data)

    print("3. Building policy-level modeling base...")
    policy_base = build_policy_modeling_base(data)
    policy_base = create_retention_target(policy_base)

    print("4. Training retention model separately...")
    (
        X_train,
        X_test,
        y_train,
        y_test,
        X_all,
        y_all,
        model_df,
        preprocessor,
        numeric_cols,
        categorical_cols
    ) = prepare_retention_features(policy_base)

    best_model, best_model_name, retention_eval = train_retention_models(
        X_train,
        X_test,
        y_train,
        y_test,
        preprocessor
    )

    retention_feature_importance = get_feature_importance(
        best_model,
        best_model_name,
        numeric_cols,
        categorical_cols
    )

    retention_output = score_retention_probability(
        best_model,
        X_all,
        model_df
    )

    print("5. Deriving year-wise continuation probability...")
    continuation_output = derive_continuation_probabilities(
        retention_output,
        policy_base,
        PROJECTION_YEARS
    )

    print("6. Calculating discount rate separately...")
    risk_components = calculate_risk_components(policy_base)
    policy_risk = calculate_policy_risk_score(risk_components)
    discount_rate_build = build_discount_rate_curve(
        policy_risk,
        data["macro"],
        PROJECTION_YEARS
    )

    print("7. Projecting policy cashflows...")
    projected_cashflows = project_policy_cashflows(
        policy_base,
        data["macro"],
        PROJECTION_YEARS
    )

    print("8. Calculating policy-level CLTV...")
    policy_level_cltv = calculate_policy_level_cltv(
        projected_cashflows,
        continuation_output,
        discount_rate_build,
        PROJECTION_YEARS
    )

    print("9. Aggregating customer-level CLTV...")
    customer_level_cltv = aggregate_customer_level_cltv(
        policy_level_cltv,
        policy_base,
        retention_output,
        continuation_output,
        discount_rate_build
    )

    print("10. Creating segments and recommended actions...")
    customer_segments = assign_customer_segments(customer_level_cltv)
    customer_actions = assign_recommended_actions(customer_segments)

    segment_summary = create_segment_summary(customer_actions)
    action_summary = create_action_summary(customer_actions)

    print("11. Creating executive and methodology summaries...")
    executive_summary = create_executive_summary(
        data,
        retention_eval,
        retention_output,
        continuation_output,
        discount_rate_build,
        customer_actions,
        best_model_name
    )

    methodology = create_methodology_assumptions()

    feature_dictionary = data.get("feature_dictionary")

    print("12. Writing final Excel output...")

    output_sheets = {
        "Executive_Summary": executive_summary,
        "Data_Validation_Summary": validation_summary,
        "Data_Issues": data_issues,
        "Policy_Modeling_Base": policy_base,
        "Retention_Model_Output": retention_output,
        "Retention_Model_Evaluation": retention_eval,
        "Retention_Feature_Importance": retention_feature_importance,
        "Continuation_Probability": continuation_output,
        "Discount_Rate_Build": discount_rate_build,
        "Projected_Cashflows": projected_cashflows,
        "Policy_Level_CLTV": policy_level_cltv,
        "Customer_Level_CLTV": customer_level_cltv,
        "Customer_Actions": customer_actions,
        "Segment_Summary": segment_summary,
        "Action_Summary": action_summary,
        "Methodology_Assumptions": methodology,
        "Feature_Dictionary": feature_dictionary,
    }

    write_output_excel(OUTPUT_FILE, output_sheets)

    print("DONE.")
    print(f"Best retention model: {best_model_name}")
    print(f"Output created at: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()

