import numpy as np
import pandas as pd

from sklearn.compose import ColumnTransformer
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from config import RANDOM_STATE, TEST_SIZE
from utils import get_existing_columns


RETENTION_FEATURES = [
    "customer_age",
    "gender",
    "marital_status",
    "income_band",
    "employment_status",
    "credit_score",
    "customer_tenure_years",
    "number_of_policies",
    "customer_segment_raw",
    "preferred_channel",
    "digital_engagement_score",
    "policy_type",
    "policy_tenure_years",
    "coverage_amount",
    "annual_premium",
    "premium_payment_frequency",
    "payment_method",
    "underwriting_risk_class",
    "channel",
    "total_premium_paid_last_12m",
    "total_premium_paid_lifetime",
    "missed_payment_count_12m",
    "payment_delay_days_avg",
    "payment_delay_days_max",
    "auto_pay_flag",
    "premium_increase_percent_last_renewal",
    "billing_issue_count",
    "claim_count_12m",
    "claim_count_lifetime",
    "claim_amount_12m",
    "claim_amount_lifetime",
    "average_claim_amount",
    "largest_claim_amount",
    "claim_denial_count",
    "open_claim_count",
    "days_since_last_claim",
    "loss_ratio_12m",
    "loss_ratio_lifetime",
    "servicing_expense_12m",
    "admin_expense_12m",
    "commission_expense_12m",
    "total_expense_12m",
    "expense_ratio",
    "customer_service_call_count_12m",
    "complaint_count_12m",
    "ticket_count_12m",
    "avg_issue_resolution_days",
    "unresolved_ticket_count",
    "customer_satisfaction_score",
    "net_promoter_score",
    "agent_tenure_years",
    "agent_quality_score",
    "agent_retention_rate",
    "agent_complaint_rate",
    "channel_service_score",
    "catastrophe_risk_score",
    "weather_risk_score",
    "economic_risk_score",
    "regulatory_risk_score",
]


def _make_onehot_encoder():
    try:
        return OneHotEncoder(handle_unknown="ignore", sparse_output=False)
    except TypeError:
        return OneHotEncoder(handle_unknown="ignore", sparse=False)


def prepare_retention_features(policy_base: pd.DataFrame):
    """
    Prepares X/y for retention model using raw measurable features only.
    """
    df = policy_base.copy()

    feature_cols = get_existing_columns(df, RETENTION_FEATURES)

    if "renewed_next_cycle" not in df.columns:
        raise ValueError("renewed_next_cycle target is missing. Run create_retention_target first.")

    required_keys = ["customer_id", "policy_id", "renewed_next_cycle"]
    model_df = df[required_keys + feature_cols].copy()

    y = model_df["renewed_next_cycle"].astype(int)
    X = model_df[feature_cols].copy()

    numeric_cols = X.select_dtypes(include=["number", "bool"]).columns.tolist()
    categorical_cols = [c for c in X.columns if c not in numeric_cols]

    numeric_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])

    categorical_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("encoder", _make_onehot_encoder())
    ])

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", numeric_transformer, numeric_cols),
            ("cat", categorical_transformer, categorical_cols),
        ],
        remainder="drop"
    )

    stratify = y if y.nunique() == 2 and y.value_counts().min() >= 2 else None

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=TEST_SIZE,
        random_state=RANDOM_STATE,
        stratify=stratify
    )

    return X_train, X_test, y_train, y_test, X, y, model_df, preprocessor, numeric_cols, categorical_cols


def _evaluate_model(name, pipeline, X_test, y_test):
    pred = pipeline.predict(X_test)

    if hasattr(pipeline, "predict_proba"):
        proba = pipeline.predict_proba(X_test)[:, 1]
    else:
        proba = pred

    auc = roc_auc_score(y_test, proba) if y_test.nunique() == 2 else np.nan

    tn, fp, fn, tp = confusion_matrix(y_test, pred, labels=[0, 1]).ravel()

    return {
        "model_name": name,
        "auc": round(float(auc), 4) if not pd.isna(auc) else np.nan,
        "accuracy": round(float(accuracy_score(y_test, pred)), 4),
        "precision": round(float(precision_score(y_test, pred, zero_division=0)), 4),
        "recall": round(float(recall_score(y_test, pred, zero_division=0)), 4),
        "f1_score": round(float(f1_score(y_test, pred, zero_division=0)), 4),
        "true_negative": int(tn),
        "false_positive": int(fp),
        "false_negative": int(fn),
        "true_positive": int(tp),
    }


def train_retention_models(X_train, X_test, y_train, y_test, preprocessor):
    """
    Trains multiple retention models and compares them.
    """
    models = {
        "Logistic Regression": LogisticRegression(max_iter=1000, random_state=RANDOM_STATE),
        "Random Forest": RandomForestClassifier(
            n_estimators=300,
            max_depth=7,
            min_samples_leaf=5,
            random_state=RANDOM_STATE,
            class_weight="balanced"
        ),
        "Gradient Boosting": GradientBoostingClassifier(
            n_estimators=250,
            learning_rate=0.035,
            max_depth=3,
            random_state=RANDOM_STATE
        )
    }

    fitted = {}
    eval_rows = []

    for name, model in models.items():
        pipe = Pipeline(steps=[
            ("preprocessor", preprocessor),
            ("model", model)
        ])

        pipe.fit(X_train, y_train)
        fitted[name] = pipe
        eval_rows.append(_evaluate_model(name, pipe, X_test, y_test))

    evaluation_df = pd.DataFrame(eval_rows)

    if evaluation_df["auc"].notna().any():
        best_name = evaluation_df.sort_values(["auc", "f1_score"], ascending=False).iloc[0]["model_name"]
    else:
        best_name = evaluation_df.sort_values(["f1_score", "accuracy"], ascending=False).iloc[0]["model_name"]

    return fitted[best_name], best_name, evaluation_df


def _get_feature_names(best_model, numeric_cols, categorical_cols):
    preprocessor = best_model.named_steps["preprocessor"]
    names = []

    names.extend(numeric_cols)

    if categorical_cols:
        try:
            encoder = preprocessor.named_transformers_["cat"].named_steps["encoder"]
            cat_names = encoder.get_feature_names_out(categorical_cols).tolist()
            names.extend(cat_names)
        except Exception:
            names.extend(categorical_cols)

    return names


def get_feature_importance(best_model, best_name, numeric_cols, categorical_cols):
    """
    Returns feature importance for tree models or coefficients for logistic regression.
    """
    model = best_model.named_steps["model"]
    feature_names = _get_feature_names(best_model, numeric_cols, categorical_cols)

    if hasattr(model, "feature_importances_"):
        importance = model.feature_importances_
        label = "importance"
    elif hasattr(model, "coef_"):
        importance = np.abs(model.coef_[0])
        label = "absolute_coefficient"
    else:
        importance = np.zeros(len(feature_names))
        label = "importance"

    min_len = min(len(feature_names), len(importance))

    out = pd.DataFrame({
        "model_name": best_name,
        "feature": feature_names[:min_len],
        label: importance[:min_len]
    }).sort_values(label, ascending=False)

    return out


def score_retention_probability(best_model, X_all, model_df):
    """
    Scores base retention probability for every policy.
    """
    probability = best_model.predict_proba(X_all)[:, 1]
    prediction = best_model.predict(X_all)

    out = model_df[["customer_id", "policy_id", "renewed_next_cycle"]].copy()
    out["renewed_next_cycle_predicted"] = prediction
    out["base_retention_probability"] = probability.round(6)

    out["retention_risk_band"] = pd.cut(
        out["base_retention_probability"],
        bins=[-0.001, 0.50, 0.75, 1.001],
        labels=["Low Retention", "Medium Retention", "High Retention"]
    ).astype(str)

    return out

