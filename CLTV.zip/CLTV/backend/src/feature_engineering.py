import pandas as pd
import numpy as np
from utils import safe_divide


def _latest_renewal_record(renewal: pd.DataFrame) -> pd.DataFrame:
    """
    Renewal_Lapse_History may have multiple cycles per policy.
    For near-term retention model, use the latest renewal cycle per policy.
    """
    if renewal.empty:
        return renewal

    renewal = renewal.copy()

    if "renewal_cycle_year" in renewal.columns:
        renewal = renewal.sort_values(["policy_id", "renewal_cycle_year"])
        renewal = renewal.groupby("policy_id", as_index=False).tail(1)
    else:
        renewal = renewal.drop_duplicates("policy_id", keep="last")

    return renewal


def build_policy_modeling_base(data: dict) -> pd.DataFrame:
    """
    Creates one policy-level modeling base table.
    """
    customers = data["customers"].copy()
    policies = data["policies"].copy()
    payments = data["payments"].copy()
    claims = data["claims"].copy()
    expenses = data["expenses"].copy()
    agents = data["agents"].copy()
    geography = data["geography"].copy()
    renewal = _latest_renewal_record(data["renewal"].copy())

    df = policies.copy()

    if not customers.empty:
        df = df.merge(customers, on="customer_id", how="left", suffixes=("", "_customer"))

    if not payments.empty:
        df = df.merge(payments, on=["customer_id", "policy_id"], how="left", suffixes=("", "_payment"))

    if not claims.empty:
        df = df.merge(claims, on=["customer_id", "policy_id"], how="left", suffixes=("", "_claims"))

    if not expenses.empty:
        df = df.merge(expenses, on=["customer_id", "policy_id"], how="left", suffixes=("", "_expense"))

    if not agents.empty and "agent_id" in df.columns:
        df = df.merge(agents, on="agent_id", how="left", suffixes=("", "_agent"))

    if not geography.empty and "state" in df.columns:
        df = df.merge(geography, on="state", how="left", suffixes=("", "_geo"))

    if not renewal.empty:
        keep_cols = [
            "customer_id", "policy_id", "renewal_cycle_year", "renewed_flag",
            "lapsed_flag", "cancelled_flag", "surrendered_flag",
            "days_to_renewal_decision", "reason_for_lapse"
        ]
        keep_cols = [c for c in keep_cols if c in renewal.columns]
        df = df.merge(renewal[keep_cols], on=["customer_id", "policy_id"], how="left", suffixes=("", "_renewal"))

    numeric_defaults = [
        "missed_payment_count_12m", "payment_delay_days_avg", "payment_delay_days_max",
        "billing_issue_count", "claim_count_12m", "claim_count_lifetime",
        "claim_amount_12m", "claim_amount_lifetime", "average_claim_amount",
        "largest_claim_amount", "claim_denial_count", "open_claim_count",
        "loss_ratio_12m", "loss_ratio_lifetime", "servicing_expense_12m",
        "admin_expense_12m", "commission_expense_12m", "total_expense_12m",
        "expense_ratio", "customer_service_call_count_12m", "complaint_count_12m",
        "ticket_count_12m", "avg_issue_resolution_days", "unresolved_ticket_count",
        "catastrophe_risk_score", "weather_risk_score", "economic_risk_score",
        "regulatory_risk_score"
    ]

    for col in numeric_defaults:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    if "loss_ratio_12m" not in df.columns and {"claim_amount_12m", "annual_premium"}.issubset(df.columns):
        df["loss_ratio_12m"] = safe_divide(df["claim_amount_12m"], df["annual_premium"])

    if "expense_ratio" not in df.columns and {"total_expense_12m", "annual_premium"}.issubset(df.columns):
        df["expense_ratio"] = safe_divide(df["total_expense_12m"], df["annual_premium"])

    if "number_of_policies" not in df.columns:
        counts = df.groupby("customer_id")["policy_id"].transform("count")
        df["number_of_policies"] = counts

    return df


def create_retention_target(policy_base: pd.DataFrame) -> pd.DataFrame:
    """
    Creates renewed_next_cycle from raw renewal/lapse flags.
    """
    df = policy_base.copy()

    for col in ["renewed_flag", "lapsed_flag", "cancelled_flag", "surrendered_flag"]:
        if col not in df.columns:
            df[col] = 0
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).astype(int)

    non_renewal = (
        (df["lapsed_flag"] == 1) |
        (df["cancelled_flag"] == 1) |
        (df["surrendered_flag"] == 1)
    )

    df["renewed_next_cycle"] = np.where(df["renewed_flag"] == 1, 1, 0)
    df.loc[non_renewal, "renewed_next_cycle"] = 0

    return df
