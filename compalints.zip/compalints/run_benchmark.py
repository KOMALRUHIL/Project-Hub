import os
# Disable HF symlinks on Windows to avoid WinError 1314 permission errors
os.environ["HF_HUB_DISABLE_SYMLINKS"] = "1"
os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"

import time
import pandas as pd
import subprocess
import sys

def main():
    print("=== PII Redaction Pipeline Benchmark ===")
    
    mock_file = "mock_complaints.xlsx"
    masked_file = "mock_complaints_masked.xlsx"
    
    # 1. Check for mock complaints data
    if not os.path.exists(mock_file):
        print(f"Mock data '{mock_file}' not found. Generating mock data...")
        subprocess.check_call([sys.executable, "generate_mock_data.py"])
    
    # 2. Import pipeline and run it
    print("\nImporting pipeline modules...")
    try:
        from redact_pipeline import redact_pipeline
    except ImportError as e:
        print(f"Error importing pipeline: {e}")
        sys.exit(1)
        
    print("\nRunning redaction pipeline on mock dataset (2,000 complaints)...")
    start_time = time.time()
    
    redact_pipeline(
        input_excel_path=mock_file,
        output_excel_path=masked_file,
        text_column="Description of Complaint Issue",
        masked_column="Masked Complaint Issue",
        batch_size=128
    )
    
    end_time = time.time()
    elapsed = end_time - start_time
    
    # 3. Output results and throughput estimations
    print("\n=== Benchmark Results ===")
    df_masked = pd.read_excel(masked_file)
    total_records = len(df_masked)
    
    throughput = total_records / elapsed
    estimated_90k_time_sec = 90000 / throughput
    estimated_90k_time_min = estimated_90k_time_sec / 60
    
    print(f"Processed: {total_records} complaints")
    print(f"Total time elapsed: {elapsed:.2f} seconds")
    print(f"Throughput: {throughput:.2f} complaints/second")
    print(f"Estimated time for 90,000 complaints: {estimated_90k_time_sec:.2f} seconds ({estimated_90k_time_min:.2f} minutes)")
    
    # 4. Print sample results for inspection
    print("\n=== Sample Masked Complaints (First 5 Rows) ===")
    pd.set_option('display.max_colwidth', None)
    for idx, row in df_masked.head(5).iterrows():
        print(f"\n--- Complaint #{idx+1} ---")
        print(f"Original: {row['Description of Complaint Issue']}")
        print(f"Masked:   {row['Masked Complaint Issue']}")

if __name__ == "__main__":
    main()
