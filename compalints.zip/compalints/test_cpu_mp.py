import torch
# Force PyTorch to disable GPU detection to test the CPU Multiprocessing pathway
torch.cuda.is_available = lambda: False

import os
import time
import pandas as pd
from redact_pipeline import redact_pipeline

if __name__ == "__main__":
    print("=== Testing CPU Multiprocessing Pathway ===")
    start_time = time.time()
    
    redact_pipeline(
        input_excel_path="mock_complaints.xlsx",
        output_excel_path="mock_complaints_cpu_masked.xlsx",
        text_column="Description of Complaint Issue",
        masked_column="Masked Complaint Issue",
        batch_size=128
    )
    
    elapsed = time.time() - start_time
    print(f"\nCPU Multiprocessing completed in: {elapsed:.2f} seconds.")
    
    # Verify file was saved and is correct
    if os.path.exists("mock_complaints_cpu_masked.xlsx"):
        df = pd.read_excel("mock_complaints_cpu_masked.xlsx")
        print(f"Verified output file. Processed {len(df)} rows.")
        print("\n--- Sample CPU Masked Outputs ---")
        for idx, row in df.head(3).iterrows():
            print(f"Original: {row['Description of Complaint Issue']}")
            print(f"Masked  : {row['Masked Complaint Issue']}\n")
    else:
        print("ERROR: Output file not created.")
