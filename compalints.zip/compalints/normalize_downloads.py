import os
import glob
import pandas as pd

def normalize_object(obj_name):
    if not obj_name or pd.isna(obj_name):
        return "other / unspecified"
        
    s = str(obj_name).lower().strip()
    
    # 1. Digital Portal, Accounts & Policy Coverage
    if any(k in s for k in ["portal", "account", "login", "website", "online", "app"]):
        return "digital portal & account"
    if any(k in s for k in ["payment", "card", "debit", "premium", "invoice", "refund", "billing"]):
        return "payments & billing"
    if any(k in s for k in ["policy", "cover", "excess", "certificate", "renewal", "contract"]):
        return "policy & coverage"
        
    # 2. Auto / Car / Vehicle
    if any(k in s for k in ["car", "vehicle", "auto", "bumper", "light", "windscreen", "odometer", "registration", "engine", "tire", "tyre", "tow", "wheel"]):
        return "car & auto"
        
    # 3. Jewelry & Valuables
    if any(k in s for k in ["ring", "bracelet", "necklace", "watch", "earring", "gem", "diamond", "jewelry", "jewellery"]):
        return "jewelry & valuables"
        
    # 4. Roof & Gutters
    if any(k in s for k in ["roof", "gutter", "shingle", "parapet"]):
        return "roof & gutters"
        
    # 5. Plumbing & Pipes
    if any(k in s for k in ["pipe", "plumb", "bidet", "leak", "toilet", "tap", "sink", "shower", "hot water", "boiler", "water heater"]):
        return "plumbing & pipes"
        
    # 6. Appliances & Electronics
    if any(k in s for k in ["device", "refrigerator", "fridge", "tv", "television", "washing machine", "washer", "dryer", "dishwasher", "oven", "stove", "microwave", "computer", "phone", "laptop", "electronic", "appliance"]):
        return "appliances & electronics"
        
    # 7. Rooms
    if any(k in s for k in ["kitchen", "bench", "cabinet"]):
        return "kitchen"
    if any(k in s for k in ["bathroom", "bath", "ensuite", "vanity"]):
        return "bathroom"
    if "laundry" in s:
        return "laundry"
        
    # 8. Flooring & Wall/Windows
    if any(k in s for k in ["floor", "carpet", "rug", "timber", "laminate", "tiles"]):
        return "flooring & carpets"
    if any(k in s for k in ["wall", "brick", "cladding", "stair", "door", "window", "glass", "ceiling", "plaster"]):
        return "walls, doors & windows"
        
    # 9. Outdoors & Fences
    if "fence" in s or "fencing" in s:
        return "fence"
    if any(k in s for k in ["pool", "backyard", "garden", "yard", "blind", "driveway", "patio", "pergola", "deck", "verandah", "outdoor"]):
        return "backyard & outdoor"
        
    # 10. Home Contents
    if any(k in s for k in ["content", "belonging", "furniture", "couch", "bed", "table", "clothing", "linen"]):
        return "home contents"
        
    # 11. Maintenance
    if any(k in s for k in ["maintenance", "cleaning", "wear", "tear", "service"]):
        return "maintenance"
        
    # 12. General building/property fallback
    if any(k in s for k in ["house", "building", "property", "dwelling"]):
        return "building structure"
        
    return "other / unspecified"

def normalize_download_files():
    downloads_dir = r"C:\Users\Lenovo\Downloads"
    # Find all classification excel sheets in Downloads
    excel_files = glob.glob(os.path.join(downloads_dir, "*classification*.xlsx"))
    
    if not excel_files:
        print("[ERROR] No classification files found in Downloads.")
        return
        
    for file_path in excel_files:
        print(f"\nProcessing file: {file_path}")
        try:
            df = pd.read_excel(file_path)
            
            # Find the object column name
            col_name = None
            for col in df.columns:
                if col.lower() in ["complaint object", "object", "complaint_object"]:
                    col_name = col
                    break
            
            if not col_name:
                print(f"[WARNING] No 'Complaint Object' column found in {os.path.basename(file_path)}. Skipping.")
                continue
                
            orig_unique_count = df[col_name].nunique()
            
            # Apply the mapping
            df[col_name] = df[col_name].apply(normalize_object)
            
            new_unique_count = df[col_name].nunique()
            new_unique_items = list(df[col_name].unique())
            
            print(f"- Collapsed unique objects from {orig_unique_count} down to {new_unique_count}")
            print(f"- Normalized Categories: {new_unique_items}")
            
            # Save back
            print(f"- Saving cleaned file...")
            df.to_excel(file_path, index=False)
            print("- Completed successfully!")
            
        except Exception as e:
            print(f"[ERROR] Failed to process {file_path}: {e}")

if __name__ == "__main__":
    normalize_download_files()
