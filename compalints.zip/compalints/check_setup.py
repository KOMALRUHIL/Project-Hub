import sys
import subprocess

def install_package(package_name):
    print(f"Installing {package_name}...")
    try:
        args = [sys.executable, "-m", "pip", "install"] + package_name.split()
        subprocess.check_call(args)
        print(f"Successfully installed {package_name}\n")
    except Exception as e:
        print(f"Failed to install {package_name}: {e}\n")

required_libs = {
    "torch": "torch --index-url https://download.pytorch.org/whl/cu121", # Ensure CUDA support for PyTorch 2.x
    "presidio_analyzer": "presidio-analyzer",
    "presidio_anonymizer": "presidio-anonymizer",
    "gliner": "gliner",
    "pandas": "pandas",
    "openpyxl": "openpyxl",
    "spacy": "spacy"
}

print("Checking dependencies...")
for lib_import, pip_name in required_libs.items():
    try:
        __import__(lib_import)
        print(f"[OK] {lib_import} is already installed.")
    except ImportError:
        print(f"[MISSING] {lib_import} is not installed.")
        install_package(pip_name)

# Ensure spacy model is downloaded for Presidio's default NLP engine if it needs it
try:
    import spacy
    if not spacy.util.is_package("en_core_web_sm"):
        print("Downloading spacy model 'en_core_web_sm'...")
        subprocess.check_call([sys.executable, "-m", "spacy", "download", "en_core_web_sm"])
except Exception as e:
    print(f"Failed to check/download spacy model: {e}")

print("\n--- Verifying GPU and CUDA Status ---")
try:
    import torch
    print(f"PyTorch version: {torch.__version__}")
    print(f"CUDA Available: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"GPU Name: {torch.cuda.get_device_name(0)}")
        print(f"CUDA Version: {torch.version.cuda}")
    else:
        print("WARNING: CUDA is not available. Deep learning models will run on CPU, which will be slow.")
except ImportError:
    print("PyTorch not found.")
except Exception as e:
    print(f"Error checking CUDA: {e}")

print("\nSetup verification complete.")
