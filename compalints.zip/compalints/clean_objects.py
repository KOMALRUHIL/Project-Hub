import os
import sys
import pandas as pd

def normalize_object(obj_name):
    if not obj_name or pd.isna(obj_name):
        return "other"
        
    obj_clean = str(obj_name).lower().strip()
    
    # Remove common filler words or punctuation
    obj_clean = obj_clean.replace("the ", "").replace("an ", "").replace("a ", "").strip('.,?!- ')
    
    if not obj_clean or obj_clean == "nan" or obj_clean == "null":
        return "other"

    # Explicit mapping for the user's specific spreadsheet objects
    mapping = {
        # Air conditioning variants -> air conditioner
        "ac": "air conditioner",
        "aircon": "air conditioner",
        "air conditioner": "air conditioner",
        "airconditioner": "air conditioner",
        "air conditioning": "air conditioner",
        "air conditioning unit": "air conditioner",
        "split system": "air conditioner",
        "hvac": "air conditioner",
        
        # Auto/Car components -> car
        "car": "car",
        "front bumper": "car",
        "tail light": "car",
        "hire car": "car",
        "windscreen": "car",
        "odometer": "car",
        "registration": "car",
        
        # Valuables/Jewelry -> jewelry
        "ring": "jewelry",
        "engagement ring": "jewelry",
        "bracelet": "jewelry",
        
        # Contents
        "content": "home contents",
        "home content": "home contents",
        
        # Structural Roof/Gutters
        "roof": "roof & gutters",
        "extension roof": "roof & gutters",
        "box gutter": "roof & gutters",
        "gutters": "roof & gutters",
        
        # Walls & Structure
        "parapet wall": "walls & structure",
        "brickwork and wall": "walls & structure",
        "cladding": "walls & structure",
        "under stair": "walls & structure",
        "window glazing": "windows & doors",
        
        # Kitchen
        "kitchen": "kitchen",
        "kitchen cabinetry": "kitchen",
        "benchtop": "kitchen",
        
        # Rooms
        "bathroom": "bathroom",
        "bathroom subfloor, bedroom, extension roof": "bathroom",
        "laundry": "laundry",
        "floor": "flooring",
        
        # Outdoors
        "backyard": "backyard & outdoor",
        "pool and backyard": "backyard & outdoor",
        "outdoor blind": "backyard & outdoor",
        "driveway": "backyard & outdoor",
        "fence": "fence",
        
        # General Assets
        "damaged device": "appliances & electronics",
        "refrigerator": "appliances & electronics",
        "house": "building structure",
        "maintenance": "maintenance",
        "pipes": "plumbing & pipes"
    }
    
    # Return mapping if match found, else default to cleaned name
    return mapping.get(obj_clean, obj_clean)

def clean_excel_objects(file_path):
    if not os.path.exists(file_path):
        print(f"[ERROR] File not found at: {file_path}")
        return
        
    print(f"Reading spreadsheet from: {file_path}")
    df = pd.read_excel(file_path)
    
    col_name = None
    for col in df.columns:
        if col.lower() in ["complaint object", "object", "complaint_object"]:
            col_name = col
            break
            
    if not col_name:
        print("[ERROR] Could not find a 'Complaint Object' or 'Object' column in this spreadsheet.")
        print(f"Available columns: {list(df.columns)}")
        return
        
    print(f"Found column to clean: '{col_name}'")
    
    # Track metrics
    original_unique = df[col_name].dropna().unique()
    num_original = len(original_unique)
    
    # Apply cleaning
    df[col_name] = df[col_name].apply(normalize_object)
    
    new_unique = df[col_name].replace("other", None).dropna().unique()
    num_new = len(new_unique)
    
    print("\nSummary of merged objects:")
    print(f"- Original unique names count: {num_original}")
    print(f"- Cleaned/Collapsed unique names count: {num_new}")
    print(f"- New unique classes: {list(new_unique)}")
    
    # Save back
    print(f"\nSaving cleaned spreadsheet to: {file_path}")
    df.to_excel(file_path, index=False)
    print("Clean-up finished successfully!")

if __name__ == "__main__":
    target_file = r"D:\Komal\compalints\classified.xlsx"
    if len(sys.argv) > 1:
        target_file = sys.argv[1]
        
    clean_excel_objects(target_file)
