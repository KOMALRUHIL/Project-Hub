import os
# Disable HF symlinks on Windows to avoid WinError 1314 permission errors
os.environ["HF_HUB_DISABLE_SYMLINKS"] = "1"
os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"

import pandas as pd
import torch
import time
from tqdm import tqdm
from gliner import GLiNER
from presidio_analyzer import AnalyzerEngine, Pattern, PatternRecognizer, RecognizerResult
from presidio_anonymizer import AnonymizerEngine
from presidio_anonymizer.entities import OperatorConfig

def setup_presidio_analyzer():
    """Sets up the Presidio Analyzer using the small SpaCy model to save RAM and custom regex recognizers."""
    from presidio_analyzer.nlp_engine import NlpEngineProvider
    
    # Force Presidio to load en_core_web_sm (12MB) instead of en_core_web_lg (400MB) to save massive RAM
    config = {
        "nlp_engine_name": "spacy",
        "models": [{"lang_code": "en", "model_name": "en_core_web_sm"}]
    }
    provider = NlpEngineProvider(nlp_configuration=config)
    nlp_engine = provider.create_engine()
    
    analyzer = AnalyzerEngine(nlp_engine=nlp_engine)
    
    # Remove default spacy/NLP recognizers from the analyzer because we will use GLiNER for NLP.
    # This avoids running spacy NLP on CPU, saving tons of performance.
    nlp_recognizers = ["SpacyRecognizer", "StanzaRecognizer"]
    recognizers_to_keep = [
        rec for rec in analyzer.registry.recognizers
        if rec.name not in nlp_recognizers
    ]
    analyzer.registry.recognizers = recognizers_to_keep

    # 1. Custom Policy Number Recognizer (e.g., 01HOM78860)
    # Alphanumeric between 7 and 15 characters containing at least one digit (matches unconditionally)
    policy_pattern = Pattern(
        name="policy_number_pattern",
        regex=r"\b(?=[0-9A-Z]{7,15}\b)[0-9A-Z]*[0-9][0-9A-Z]*\b",
        score=0.35
    )
    policy_recognizer = PatternRecognizer(
        supported_entity="POLICY_NUMBER",
        patterns=[policy_pattern]
    )
    analyzer.registry.add_recognizer(policy_recognizer)

    # 2. Custom Claim Number Recognizer (matches hyphenated numbers or C-prefixed alphanumeric numbers unconditionally)
    claim_patterns = [
        Pattern(
            name="claim_hyphenated_pattern",
            regex=r"\b[0-9A-Z]{2,6}-[0-9A-Z]{2,6}-[0-9A-Z]{2,6}(?:-[0-9A-Z]{2,6})?\b",
            score=0.35
        ),
        Pattern(
            name="claim_c_prefixed_pattern",
            regex=r"\b[Cc][-/\s]?(?=[0-9A-Z]{5,12}\b)[0-9A-Z]*[0-9][0-9A-Z]*\b",
            score=0.35
        )
    ]
    claim_recognizer = PatternRecognizer(
        supported_entity="CLAIM_NUMBER",
        patterns=claim_patterns
    )
    analyzer.registry.add_recognizer(claim_recognizer)

    # 3. Custom Amount/Currency Recognizer (matches $, aud, usd, decimals unconditionally)
    amount_patterns = [
        Pattern(
            name="amount_currency_symbol",
            regex=r"[\$£€¥]\s?\d+(?:,\d{3})*(?:\.\d{2})?\b",
            score=0.35
        ),
        Pattern(
            name="amount_currency_words",
            regex=r"\b\d+(?:,\d{3})*(?:\.\d{2})?\s?(?:dollars?|cents?|aud|usd|euro?s?|pounds?)\b",
            score=0.35
        ),
        Pattern(
            name="amount_decimals",
            regex=r"\b\d+(?:,\d{3})*\.\d{2}\b",
            score=0.35
        )
    ]
    amount_recognizer = PatternRecognizer(
        supported_entity="AMOUNT",
        patterns=amount_patterns
    )
    analyzer.registry.add_recognizer(amount_recognizer)

    return analyzer

def resolve_overlaps(results):
    """Resolves overlapping entities, keeping the ones with higher score or longer length."""
    sorted_results = sorted(results, key=lambda x: (x.start, -x.end))
    filtered = []
    last_end = -1
    for res in sorted_results:
        if res.start >= last_end:
            filtered.append(res)
            last_end = res.end
        else:
            # Overlap detected. Keep the one with the higher score
            if len(filtered) > 0:
                if res.score > filtered[-1].score:
                    filtered[-1] = res
                    last_end = res.end
                elif res.score == filtered[-1].score and (res.end - res.start) > (filtered[-1].end - filtered[-1].start):
                    filtered[-1] = res
                    last_end = res.end
    return filtered

def chunk_text(text, max_words=150):
    """Splits a long text into chunks of max_words and tracks their character offsets by scanning spaces."""
    chunks = []
    start_idx = 0
    word_count = 0
    for i, char in enumerate(text):
        if char.isspace():
            word_count += 1
            if word_count >= max_words:
                chunks.append((text[start_idx:i], start_idx))
                start_idx = i + 1
                word_count = 0
    if start_idx < len(text):
        chunks.append((text[start_idx:], start_idx))
    return chunks

def redact_pipeline(input_excel_path, output_excel_path, text_column, masked_column, batch_size=128):
    print(f"Loading input file: {input_excel_path}")
    df = pd.read_excel(input_excel_path)
    
    if text_column not in df.columns:
        raise ValueError(f"Column '{text_column}' not found in the Excel file. Available columns: {list(df.columns)}")
    
    device = "cuda" if torch.cuda.is_available() else "cpu"
    start_time = time.time()
    
    print(f"Running single-process pipeline on: {device}")
    
    # 1. Setup Engines (Presidio RAM optimized)
    analyzer = setup_presidio_analyzer()
    anonymizer = AnonymizerEngine()
    
    operators = {
        "PERSON": OperatorConfig("replace", {"new_value": "[CUSTOMER_NAME]"}),
        "INSURANCE_COMPANY": OperatorConfig("replace", {"new_value": "[INSURANCE_COMPANY]"}),
        "ORGANIZATION": OperatorConfig("replace", {"new_value": "[ORGANIZATION]"}),
        "POLICY_NUMBER": OperatorConfig("replace", {"new_value": "[POLICY_NUMBER]"}),
        "CLAIM_NUMBER": OperatorConfig("replace", {"new_value": "[CLAIM_NUMBER]"}),
        "EMAIL_ADDRESS": OperatorConfig("replace", {"new_value": "[EMAIL]"}),
        "PHONE_NUMBER": OperatorConfig("replace", {"new_value": "[PHONE_NUMBER]"}),
        "AMOUNT": OperatorConfig("replace", {"new_value": "[AMOUNT]"}),
        "ADDRESS": OperatorConfig("replace", {"new_value": "[ADDRESS]"}),
    }

    # Load GLiNER model
    gliner_model = GLiNER.from_pretrained("urchade/gliner_small-v2.1")
    gliner_model.to(device)
    
    gliner_labels = ["customer name", "insurance company", "organization", "street address"]
    gliner_label_map = {
        "customer name": "PERSON",
        "insurance company": "INSURANCE_COMPANY",
        "organization": "ORGANIZATION",
        "street address": "ADDRESS"
    }

    # Set batch size depending on hardware
    if device == "cpu":
        # On CPU, a batch size of 16 or 32 is optimal for speed and gives smooth progress updates.
        # Set this to 16, 8, or even 4 if you want the progress bar to update even faster!
        actual_batch_size = 32
        print(f"Using CPU batch size: {actual_batch_size} (avoids RAM channel bottlenecks).")
    else:
        actual_batch_size = batch_size
        print(f"Using GPU batch size: {actual_batch_size}")

    masked_texts = []
    
    # Process complaints in batches with a progress bar
    for i in tqdm(range(0, len(df), actual_batch_size), desc="Processing complaints"):
        batch_df = df.iloc[i : i + actual_batch_size]
        batch_raw_texts = batch_df[text_column].astype(str).tolist()
        batch_raw_texts = [text if text != "nan" else "" for text in batch_raw_texts]
        
        # Step A: Run Presidio Analyzer
        batch_presidio_results = []
        for text in batch_raw_texts:
            if not text.strip():
                batch_presidio_results.append([])
                continue
            res = analyzer.analyze(
                text=text, 
                language="en", 
                entities=["POLICY_NUMBER", "CLAIM_NUMBER", "EMAIL_ADDRESS", "PHONE_NUMBER", "AMOUNT"]
            )
            filtered_res = []
            for r in res:
                if r.entity_type in ["POLICY_NUMBER", "CLAIM_NUMBER", "AMOUNT"]:
                    if r.score >= 0.35:
                        filtered_res.append(r)
                else:
                    filtered_res.append(r)
            batch_presidio_results.append(filtered_res)

        # Step B: Run GLiNER (with chunking)
        flat_chunks = []
        chunk_metadata = []
        
        for idx, text in enumerate(batch_raw_texts):
            if not text.strip():
                continue
            word_count = len(text.split())
            if word_count > 150:
                chunks = chunk_text(text, max_words=150)
                for chunk_str, offset in chunks:
                    flat_chunks.append(chunk_str)
                    chunk_metadata.append((idx, offset))
            else:
                flat_chunks.append(text)
                chunk_metadata.append((idx, 0))
                
        if flat_chunks:
            batch_gliner_raw_results = gliner_model.inference(
                flat_chunks, 
                labels=gliner_labels, 
                threshold=0.4,
                batch_size=actual_batch_size
            )
            
            # Map results back to original texts with offset correction
            for chunk_idx, gliner_entities in enumerate(batch_gliner_raw_results):
                orig_idx, offset = chunk_metadata[chunk_idx]
                for ent in gliner_entities:
                    mapped_entity = gliner_label_map.get(ent["label"])
                    if mapped_entity:
                        rec_res = RecognizerResult(
                            entity_type=mapped_entity,
                            start=ent["start"] + offset,
                            end=ent["end"] + offset,
                            score=float(ent["score"])
                        )
                        batch_presidio_results[orig_idx].append(rec_res)
        
        # Step C: Anonymize
        for idx, text in enumerate(batch_raw_texts):
            if not text.strip():
                masked_texts.append("")
                continue
            
            final_results = resolve_overlaps(batch_presidio_results[idx])
            anonymized = anonymizer.anonymize(
                text=text,
                analyzer_results=final_results,
                operators=operators
            )
            masked_texts.append(anonymized.text)

    df[masked_column] = masked_texts

    # Save results
    print(f"Saving output to: {output_excel_path}")
    df.to_excel(output_excel_path, index=False)
    
    elapsed = time.time() - start_time
    print(f"Completed! Total time: {elapsed:.2f} seconds.")
    print(f"Average throughput: {len(df) / elapsed:.2f} complaints per second.")

if __name__ == "__main__":
    import sys
    infile = "mock_complaints.xlsx"
    outfile = "mock_complaints_masked.xlsx"
    if len(sys.argv) > 1:
        infile = sys.argv[1]
    if len(sys.argv) > 2:
        outfile = sys.argv[2]
        
    redact_pipeline(
        input_excel_path=infile,
        output_excel_path=outfile,
        text_column="Description of Complaint Issue",
        masked_column="Masked Complaint Issue",
        batch_size=128
    )
