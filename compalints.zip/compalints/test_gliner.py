import torch
from gliner import GLiNER

# Load GLiNER model
device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Loading GLiNER on: {device}...")
model = GLiNER.from_pretrained("urchade/gliner_small-v2.1")
model.to(device)

# We will test two different label sets
labels_broad = ["customer name", "insurance company", "organization", "address", "location"]
labels_specific = ["customer name", "insurance company", "organization", "street address"]

test_texts = [
    "Policy Number 59JHX50318, Claim Number 617-41-7796. Storm damage to roof. Insured Komal White states water entered the kitchen. Hollard Insurance builder assessed it as maintenance issue.",
    "Property backyard was damaged by storm over the years. Expected Outcome: Complainant would like AAMI Insurance to reinvestigate and approve the claim. Insured James White advice he has a claim regarding his backyard. Ref policy # 72WGE48242.",
    "Car accident claim was partially approved. Insured Lisa Brown is unhappy with the excess fee charged by QBE Insurance. Please contact customer at 12 Oak Street, Sydney or refer to contract 49TVR62262."
]

print("\n--- Testing Broad Labels (address, location) ---")
for text in test_texts:
    entities = model.inference(text, labels=labels_broad, threshold=0.4)
    print(f"Text: {text}")
    print(f"Detected: {entities}\n")

print("-" * 80)

print("\n--- Testing Specific Labels (street address) ---")
for text in test_texts:
    entities = model.inference(text, labels=labels_specific, threshold=0.4)
    print(f"Text: {text}")
    print(f"Detected: {entities}\n")
