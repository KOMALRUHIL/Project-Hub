import pandas as pd
import random

# Lists of mock details to generate diverse complaints
first_names = ["John", "Jane", "Sarah", "Michael", "Emily", "David", "Jessica", "Robert", "Lisa", "James", "Komal", "Alex", "Chris", "Emma"]
last_names = ["Smith", "Doe", "Jones", "Brown", "Davis", "Miller", "Wilson", "Taylor", "Anderson", "Thomas", "Jackson", "White", "Harris"]
insurers = ["Hollard Insurance", "Allianz Insurance", "QBE Insurance", "Suncorp Insurance", "NRMA Insurance", "AAMI Insurance"]
complaints = [
    "Property backyard was damaged by storm over the years. Expected Outcome: Complainant would like {insurer} to reinvestigate and approve the claim. Insured {name} advice he has a claim regarding his backyard.",
    "Customer {name} called to dispute the cancellation of their policy. They want {insurer} to reinstate the coverage and waive the outstanding fees.",
    "Claim was declined due to pre-existing wear and tear. Insured advice they chased up without council confirmation. Complainant wants {insurer} to review the plumbing report.",
    "Unable to gather information due to system access issues. Insured {name} wants to lodge a formal complaint against {insurer} for delay in settlement.",
    "Storm damage to roof. Insured {name} states water entered the kitchen. {insurer} builder assessed it as maintenance issue. Dispute over decision.",
    "Car accident claim was partially approved. Insured {name} is unhappy with the excess fee charged by {insurer}. Please contact customer."
]

def generate_policy():
    # Example format: 01HOM78860 (digits, letters, digits) or just random 9-11 characters
    prefix = f"{random.randint(10, 99)}"
    letters = "".join(random.choices("ABCDEFGHIJKLMNOPQRSTUVWXYZ", k=3))
    suffix = f"{random.randint(10000, 99999)}"
    return f"{prefix}{letters}{suffix}"

def generate_claim():
    # Example format: 222-02-0766
    return f"{random.randint(100, 999)}-{random.randint(10, 99):02d}-{random.randint(1000, 9999):04d}"

data = []
for i in range(2000):
    name = f"{random.choice(first_names)} {random.choice(last_names)}"
    insurer = random.choice(insurers)
    policy = generate_policy()
    claim = generate_claim()
    
    base_text = random.choice(complaints).format(name=name, insurer=insurer)
    
    # Introduce policy and claim numbers in various ways
    format_choice = random.randint(0, 3)
    if format_choice == 0:
        desc = f"Policy Number {policy}, Claim Number {claim}. {base_text}"
    elif format_choice == 1:
        desc = f"Insured details: {name}. Policy: {policy}. {base_text} Claim: {claim}."
    elif format_choice == 2:
        desc = f"{base_text} Ref policy # {policy}. Claim ref {claim}."
    else:
        desc = f"{base_text} Please refer to contract {policy}."

    data.append({
        "Complaint ID": f"CMP-{100000 + i}",
        "Description of Complaint Issue": desc
    })

df = pd.DataFrame(data)
output_file = "mock_complaints.xlsx"
df.to_excel(output_file, index=False)
print(f"Successfully generated {len(df)} mock complaints in '{output_file}'!")
