import React, { useState, useEffect } from 'react';
import * as XLSX from 'xlsx';
import { 
  ScatterChart, 
  Scatter, 
  ComposedChart,
  Line,
  Bar,
  XAxis, 
  YAxis, 
  ZAxis, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  CartesianGrid,
  PieChart,
  Pie
} from 'recharts';
import { 
  Upload, 
  TrendingUp, 
  Users, 
  AlertTriangle, 
  Database,
  BarChart2,
  Calendar,
  ArrowUpRight,
  ArrowDownRight,
  Sparkles,
  Zap,
  Layers,
  Lightbulb,
  Box,
  PieChart as PieIcon
} from 'lucide-react';

// --- On-the-fly Object Normalizer ---
const normalizeObjectValue = (objName) => {
  if (!objName) return "";
  return String(objName).trim();
};

// --- Heatmap Aggregator ---
// --- Heatmap Aggregator ---
const generateHeatmapData = (data, mode) => {
  const counts = {};
  const yTotals = {};
  const xTotals = {};
  
  data.forEach((row) => {
    // 1. Extract Y values (either Product-Brand combined or normalized Complaint Object)
    let yVals = [];
    if (mode === "object") {
      const val = row["normalised complaint object"] || row["normalised_complaint_object"] || row["Complaint Object"] || row["complaint_object"] || row["Object"] || row["object"] || "";
      yVals = String(val).split(',').map(o => o.trim()).filter(Boolean).map(normalizeObjectValue).filter(v => v && v !== "other / unspecified");
    } else if (mode === "dimension") {
      const productVal = row["Product / Service"] || row["product_service"] || row["Product"] || row["product"] || "";
      const brandVal = row["Brand"] || row["brand"] || "";
      const prod = String(productVal).trim();
      const brand = String(brandVal).trim();
      let key = "";
      if (prod && brand) key = `${prod} - ${brand}`;
      else if (prod) key = prod;
      else if (brand) key = brand;
      
      if (key) yVals = [key];
    }
    
    // 2. Extract X values (always Themes)
    const themeVal = row["Assigned Themes"] || row["assigned_themes"] || row["Themes"] || row["Theme"] || "";
    const xVals = String(themeVal).split(',').map(t => t.trim()).filter(Boolean);
    
    yVals.forEach(y => {
      xVals.forEach(x => {
        if (!counts[y]) counts[y] = {};
        counts[y][x] = (counts[y][x] || 0) + 1;
        
        yTotals[y] = (yTotals[y] || 0) + 1;
        xTotals[x] = (xTotals[x] || 0) + 1;
      });
    });
  });
  
  // Sort and take top 10 axes by unique count/volume descending
  const topY = Object.keys(yTotals).sort((a, b) => yTotals[b] - yTotals[a]).slice(0, 10);
  const topX = Object.keys(xTotals).sort((a, b) => xTotals[b] - xTotals[a]).slice(0, 10);
  
  let maxVal = 0;
  const grid = topY.map(y => {
    return {
      yVal: y,
      xVals: topX.map(x => {
        const val = counts[y]?.[x] || 0;
        if (val > maxVal) maxVal = val;
        return { xVal: x, count: val };
      })
    };
  });
  
  return { topY, topX, grid, maxVal };
};

// --- Sunburst Data Aggregator ---
const getSunburstData = (data) => {
  if (!data || data.length === 0) return { inner: [], middle: [], outer: [] };
  
  // 1. Extract themes and find top 10 themes
  const themeCounts = {};
  data.forEach(row => {
    const val = row["Assigned Themes"] || row["assigned_theme"] || row["assigned_themes"] || row["Themes"] || row["Theme"] || "";
    const themes = String(val).split(',').map(t => t.trim()).filter(Boolean);
    themes.forEach(t => {
      themeCounts[t] = (themeCounts[t] || 0) + 1;
    });
  });
  const top10Themes = Object.keys(themeCounts).sort((a, b) => themeCounts[b] - themeCounts[a]).slice(0, 10);
  
  const inner = [];
  const middle = [];
  const outer = [];
  
  const themeColors = [
    '#6366f1', '#3b82f6', '#10b981', '#f59e0b', '#ef4444',
    '#8b5cf6', '#ec4899', '#14b8a6', '#06b6d4', '#84cc16'
  ];
  
  top10Themes.forEach((theme, tIdx) => {
    const themeColor = themeColors[tIdx % themeColors.length];
    
    const themeRows = data.filter(row => {
      const val = row["Assigned Themes"] || row["assigned_theme"] || row["assigned_themes"] || row["Themes"] || row["Theme"] || "";
      return String(val).includes(theme);
    });
    
    // 2. Top 10 Product-Brands in these rows
    const pbCounts = {};
    themeRows.forEach(row => {
      const productVal = row["Product / Service"] || row["product_service"] || row["Product"] || row["product"] || "";
      const brandVal = row["Brand"] || row["brand"] || "";
      const prod = String(productVal).trim();
      const brand = String(brandVal).trim();
      if (prod || brand) {
        const key = prod && brand ? `${prod} - ${brand}` : (prod || brand);
        pbCounts[key] = (pbCounts[key] || 0) + 1;
      }
    });
    const top10PBs = Object.keys(pbCounts).sort((a, b) => pbCounts[b] - pbCounts[a]).slice(0, 10);
    const pbTotalMatched = top10PBs.reduce((sum, pb) => sum + pbCounts[pb], 0);
    const themeRemainder = themeRows.length - pbTotalMatched;
    
    let themeVisualSum = 0;
    
    top10PBs.forEach((pb, pbIdx) => {
      const pbRows = themeRows.filter(row => {
        const productVal = row["Product / Service"] || row["product_service"] || row["Product"] || row["product"] || "";
        const brandVal = row["Brand"] || row["brand"] || "";
        const key = productVal && brandVal ? `${productVal} - ${brandVal}` : (productVal || brandVal);
        return String(key).trim() === pb;
      });
      
      // 3. Top 5 Complaint Objects in these rows
      const objCounts = {};
      pbRows.forEach(row => {
        const val = row["normalised complaint object"] || row["normalised_complaint_object"] || row["Complaint Object"] || row["complaint_object"] || row["Object"] || row["object"] || "";
        const objects = String(val).split(',').map(o => o.trim()).filter(Boolean).map(normalizeObjectValue).filter(o => o && o !== "other / unspecified");
        objects.forEach(o => {
          objCounts[o] = (objCounts[o] || 0) + 1;
        });
      });
      const top10Objs = Object.keys(objCounts).sort((a, b) => objCounts[b] - objCounts[a]).slice(0, 10);
      const objTotalMatched = top10Objs.reduce((sum, o) => sum + objCounts[o], 0);
      const pbRemainder = pbRows.length - objTotalMatched;
      
      let pbVisualSum = 0;
      
      top10Objs.forEach((obj, oIdx) => {
        const val = objCounts[obj];
        pbVisualSum += val;
        outer.push({
          name: obj,
          value: val,
          color: themeColor,
          opacity: 0.45 + (oIdx / 10) * 0.35,
          level: 'object',
          theme,
          parent: pb
        });
      });
      
      if (pbRemainder > 0) {
        pbVisualSum += pbRemainder;
        outer.push({
          name: 'Other Objects',
          value: pbRemainder,
          color: '#475569',
          opacity: 0.3,
          level: 'object',
          theme,
          parent: pb
        });
      }
      
      themeVisualSum += pbVisualSum;
      middle.push({
        name: pb,
        value: pbVisualSum,
        color: themeColor,
        opacity: 0.65 + (pbIdx / 10) * 0.25,
        level: 'product-brand',
        parent: theme
      });
    });
    
    if (themeRemainder > 0) {
      themeVisualSum += themeRemainder;
      middle.push({
        name: 'Other P+B',
        value: themeRemainder,
        color: '#334155',
        opacity: 0.5,
        level: 'product-brand',
        parent: theme
      });
      outer.push({
        name: 'Other Objects',
        value: themeRemainder,
        color: '#1e293b',
        opacity: 0.2,
        level: 'object',
        theme,
        parent: 'Other P+B'
      });
    }
    
    inner.push({
      name: theme,
      value: themeVisualSum,
      color: themeColor,
      opacity: 1.0,
      level: 'theme'
    });
  });
  
  return { inner, middle, outer };
};

// ==========================================
// DEFAULT MOCK DATASET WITH DATES & BRANDS
// ==========================================
const DEFAULT_MOCK_DATA = [
  // --- Home - LuxShield (IMPROVED) ---
  { "Policy Number": "POL10086", "Claim Number": "222-01-9034", "Assigned Themes": "Repair didn't happen / delayed repairs", "Date Received": "2025-01-12", "Product / Service": "Home", "Brand": "LuxShield" },
  { "Policy Number": "POL10086", "Claim Number": "222-01-9034", "Assigned Themes": "Repair didn't happen / delayed repairs", "Date Received": "2025-01-15", "Product / Service": "Home", "Brand": "LuxShield" },
  { "Policy Number": "POL10086", "Claim Number": "222-01-9034", "Assigned Themes": "Repair didn't happen / delayed repairs", "Date Received": "2025-01-18", "Product / Service": "Home", "Brand": "LuxShield" },
  { "Policy Number": "POL10086", "Claim Number": "222-01-9034", "Assigned Themes": "Repair didn't happen / delayed repairs", "Date Received": "2025-01-20", "Product / Service": "Home", "Brand": "LuxShield" },
  { "Policy Number": "POL10087", "Claim Number": "222-01-9035", "Assigned Themes": "Repair didn't happen / delayed repairs", "Date Received": "2025-01-22", "Product / Service": "Home", "Brand": "LuxShield" },
  
  { "Policy Number": "POL10086", "Claim Number": "222-01-9034", "Assigned Themes": "Repair didn't happen / delayed repairs", "Date Received": "2025-02-05", "Product / Service": "Home", "Brand": "LuxShield" },
  { "Policy Number": "POL10086", "Claim Number": "222-01-9034", "Assigned Themes": "Repair didn't happen / delayed repairs", "Date Received": "2025-02-12", "Product / Service": "Home", "Brand": "LuxShield" },
  { "Policy Number": "POL10088", "Claim Number": "222-01-9036", "Assigned Themes": "Repair didn't happen / delayed repairs", "Date Received": "2025-02-18", "Product / Service": "Home", "Brand": "LuxShield" },
  { "Policy Number": "POL10088", "Claim Number": "222-01-9036", "Assigned Themes": "Repair didn't happen / delayed repairs", "Date Received": "2025-02-22", "Product / Service": "Home", "Brand": "LuxShield" },
  
  { "Policy Number": "POL10089", "Claim Number": "222-01-9037", "Assigned Themes": "Repair didn't happen / delayed repairs", "Date Received": "2025-03-04", "Product / Service": "Home", "Brand": "LuxShield" },
  { "Policy Number": "POL10089", "Claim Number": "222-01-9037", "Assigned Themes": "Repair didn't happen / delayed repairs", "Date Received": "2025-03-15", "Product / Service": "Home", "Brand": "LuxShield" },
  
  { "Policy Number": "POL10090", "Claim Number": "222-01-9038", "Assigned Themes": "Repair didn't happen / delayed repairs", "Date Received": "2025-04-10", "Product / Service": "Home", "Brand": "LuxShield" },
  { "Policy Number": "POL10091", "Claim Number": "222-01-9039", "Assigned Themes": "Repair didn't happen / delayed repairs", "Date Received": "2025-05-12", "Product / Service": "Home", "Brand": "LuxShield" },
  { "Policy Number": "POL10092", "Claim Number": "222-01-9040", "Assigned Themes": "Repair didn't happen / delayed repairs", "Date Received": "2025-06-18", "Product / Service": "Home", "Brand": "LuxShield" },
  { "Policy Number": "POL10093", "Claim Number": "222-01-9041", "Assigned Themes": "Repair didn't happen / delayed repairs", "Date Received": "2025-07-20", "Product / Service": "Home", "Brand": "LuxShield" },
  { "Policy Number": "POL10094", "Claim Number": "222-01-9042", "Assigned Themes": "Repair didn't happen / delayed repairs", "Date Received": "2025-08-11", "Product / Service": "Home", "Brand": "LuxShield" },
  { "Policy Number": "POL10095", "Claim Number": "222-01-9043", "Assigned Themes": "Repair didn't happen / delayed repairs", "Date Received": "2025-09-05", "Product / Service": "Home", "Brand": "LuxShield" },
  
  { "Policy Number": "POL10096", "Claim Number": "222-01-9044", "Assigned Themes": "Repair didn't happen / delayed repairs", "Date Received": "2025-10-15", "Product / Service": "Home", "Brand": "LuxShield" },
  { "Policy Number": "POL10097", "Claim Number": "222-01-9045", "Assigned Themes": "Repair didn't happen / delayed repairs", "Date Received": "2025-11-22", "Product / Service": "Home", "Brand": "LuxShield" },
  { "Policy Number": "POL10098", "Claim Number": "222-01-9046", "Assigned Themes": "Repair didn't happen / delayed repairs", "Date Received": "2025-12-10", "Product / Service": "Home", "Brand": "LuxShield" },

  // --- Motor - SecureAuto (WORSENED) ---
  { "Policy Number": "POL45001", "Claim Number": "222-04-8001", "Assigned Themes": "Communication breakdown / unreturned calls", "Date Received": "2025-01-05", "Product / Service": "Motor", "Brand": "SecureAuto" },
  { "Policy Number": "POL45002", "Claim Number": "222-04-8002", "Assigned Themes": "Communication breakdown / unreturned calls", "Date Received": "2025-02-14", "Product / Service": "Motor", "Brand": "SecureAuto" },
  { "Policy Number": "POL45003", "Claim Number": "222-04-8003", "Assigned Themes": "Communication breakdown / unreturned calls", "Date Received": "2025-03-21", "Product / Service": "Motor", "Brand": "SecureAuto" },
  
  { "Policy Number": "POL45004", "Claim Number": "222-04-8004", "Assigned Themes": "Communication breakdown / unreturned calls", "Date Received": "2025-04-18", "Product / Service": "Motor", "Brand": "SecureAuto" },
  { "Policy Number": "POL45005", "Claim Number": "222-04-8005", "Assigned Themes": "Communication breakdown / unreturned calls", "Date Received": "2025-05-15", "Product / Service": "Motor", "Brand": "SecureAuto" },
  { "Policy Number": "POL45006", "Claim Number": "222-04-8006", "Assigned Themes": "Communication breakdown / unreturned calls", "Date Received": "2025-06-25", "Product / Service": "Motor", "Brand": "SecureAuto" },
  { "Policy Number": "POL45007", "Claim Number": "222-04-8007", "Assigned Themes": "Communication breakdown / unreturned calls", "Date Received": "2025-07-22", "Product / Service": "Motor", "Brand": "SecureAuto" },
  { "Policy Number": "POL45008", "Claim Number": "222-04-8008", "Assigned Themes": "Communication breakdown / unreturned calls", "Date Received": "2025-08-30", "Product / Service": "Motor", "Brand": "SecureAuto" },
  { "Policy Number": "POL45009", "Claim Number": "222-04-8009", "Assigned Themes": "Communication breakdown / unreturned calls", "Date Received": "2025-09-12", "Product / Service": "Motor", "Brand": "SecureAuto" },
  
  { "Policy Number": "POL45091", "Claim Number": "222-04-8902", "Assigned Themes": "Communication breakdown / unreturned calls", "Date Received": "2025-10-05", "Product / Service": "Motor", "Brand": "SecureAuto" },
  { "Policy Number": "POL45091", "Claim Number": "222-04-8902", "Assigned Themes": "Communication breakdown / unreturned calls", "Date Received": "2025-10-10", "Product / Service": "Motor", "Brand": "SecureAuto" },
  { "Policy Number": "POL45092", "Claim Number": "222-04-8903", "Assigned Themes": "Communication breakdown / unreturned calls", "Date Received": "2025-11-04", "Product / Service": "Motor", "Brand": "SecureAuto" },
  { "Policy Number": "POL45092", "Claim Number": "222-04-8903", "Assigned Themes": "Communication breakdown / unreturned calls", "Date Received": "2025-11-12", "Product / Service": "Motor", "Brand": "SecureAuto" },
  { "Policy Number": "POL45092", "Claim Number": "222-04-8903", "Assigned Themes": "Communication breakdown / unreturned calls", "Date Received": "2025-11-20", "Product / Service": "Motor", "Brand": "SecureAuto" },
  { "Policy Number": "POL45093", "Claim Number": "222-04-8904", "Assigned Themes": "Communication breakdown / unreturned calls", "Date Received": "2025-12-05", "Product / Service": "Motor", "Brand": "SecureAuto" },
  { "Policy Number": "POL45093", "Claim Number": "222-04-8904", "Assigned Themes": "Communication breakdown / unreturned calls", "Date Received": "2025-12-10", "Product / Service": "Motor", "Brand": "SecureAuto" },
  { "Policy Number": "POL45093", "Claim Number": "222-04-8904", "Assigned Themes": "Communication breakdown / unreturned calls", "Date Received": "2025-12-15", "Product / Service": "Motor", "Brand": "SecureAuto" },
  { "Policy Number": "POL45093", "Claim Number": "222-04-8904", "Assigned Themes": "Communication breakdown / unreturned calls", "Date Received": "2025-12-20", "Product / Service": "Motor", "Brand": "SecureAuto" },

  // --- Landlord - BudgetInsure (STABLE) ---
  { "Policy Number": "POL30045", "Claim Number": "222-03-1256", "Assigned Themes": "Rude staff or poor customer service", "Date Received": "2025-02-10", "Product / Service": "Landlord", "Brand": "BudgetInsure" },
  { "Policy Number": "POL30045", "Claim Number": "222-03-1256", "Assigned Themes": "Rude staff or poor customer service", "Date Received": "2025-02-18", "Product / Service": "Landlord", "Brand": "BudgetInsure" },
  { "Policy Number": "POL30046", "Claim Number": "222-03-1257", "Assigned Themes": "Rude staff or poor customer service", "Date Received": "2025-06-05", "Product / Service": "Landlord", "Brand": "BudgetInsure" },
  { "Policy Number": "POL30046", "Claim Number": "222-03-1257", "Assigned Themes": "Rude staff or poor customer service", "Date Received": "2025-06-12", "Product / Service": "Landlord", "Brand": "BudgetInsure" },
  { "Policy Number": "POL30047", "Claim Number": "222-03-1258", "Assigned Themes": "Rude staff or poor customer service", "Date Received": "2025-11-20", "Product / Service": "Landlord", "Brand": "BudgetInsure" },
  
  // --- Home - BudgetInsure ---
  { "Policy Number": "POL20078", "Claim Number": "222-02-4567", "Assigned Themes": "Claim decline dispute / decision review", "Date Received": "2025-03-10", "Product / Service": "Home", "Brand": "BudgetInsure" },
  { "Policy Number": "POL20078", "Claim Number": "222-02-4567", "Assigned Themes": "Claim decline dispute / decision review", "Date Received": "2025-04-12", "Product / Service": "Home", "Brand": "BudgetInsure" },
  { "Policy Number": "POL90011", "Claim Number": "222-09-1111", "Assigned Themes": "Claim decline dispute / decision review", "Date Received": "2025-05-18", "Product / Service": "Home", "Brand": "BudgetInsure" },
  { "Policy Number": "POL90022", "Claim Number": "222-09-2222", "Assigned Themes": "Claim decline dispute / decision review", "Date Received": "2025-07-25", "Product / Service": "Home", "Brand": "BudgetInsure" }
];

const MONTHS_ORDER = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

const COLORS = [
  '#6366f1', // Indigo
  '#06b6d4', // Cyan
  '#10b981', // Emerald
  '#f59e0b', // Amber
  '#ec4899', // Pink
  '#8b5cf6', // Purple
  '#3b82f6', // Blue
  '#ef4444'  // Red
];

const parseMonthFromRow = (row, index) => {
  const dateVal = row["Date Received"] || row["date_received"] || row["Resolved Date"] || row["resolved_date"] || row["Date"] || row["Month"] || row["month"] || "";
  
  if (!dateVal) {
    return MONTHS_ORDER[index % 12];
  }

  if (dateVal instanceof Date && !isNaN(dateVal.getTime())) {
    return MONTHS_ORDER[dateVal.getMonth()];
  }

  if (typeof dateVal === 'number' && dateVal > 20000) {
    const date = new Date((dateVal - 25569) * 86400 * 1000);
    if (!isNaN(date.getTime())) {
      return MONTHS_ORDER[date.getMonth()];
    }
  }

  const str = String(dateVal).trim().toLowerCase();
  if (!str || str === 'nan') return MONTHS_ORDER[index % 12];

  for (let i = 0; i < MONTHS_ORDER.length; i++) {
    const mName = MONTHS_ORDER[i].toLowerCase();
    if (str.includes(mName)) {
      return MONTHS_ORDER[i];
    }
  }

  const matchISO = str.match(/\b\d{4}[-/](\d{1,2})[-/]\d{1,2}\b/);
  if (matchISO) {
    const monthIdx = parseInt(matchISO[1], 10) - 1;
    if (monthIdx >= 0 && monthIdx < 12) return MONTHS_ORDER[monthIdx];
  }

  const matchSlash = str.match(/\b\d{1,2}[-/](\d{1,2})[-/]\d{4}\b/);
  if (matchSlash) {
    const monthIdx = parseInt(matchSlash[1], 10) - 1;
    if (monthIdx >= 0 && monthIdx < 12) return MONTHS_ORDER[monthIdx];
  }

  const parsedDate = new Date(dateVal);
  if (!isNaN(parsedDate.getTime())) {
    return MONTHS_ORDER[parsedDate.getMonth()];
  }

  return MONTHS_ORDER[index % 12];
};

const ScatterTooltip = ({ active, payload }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="chart-tooltip" style={{ minWidth: '270px' }}>
        <div className="tooltip-title">{data.name}</div>
        <div className="tooltip-item">Unique Claim+Policy: <span>{data.x}</span></div>
        <div className="tooltip-item">Avg Repeats per P+C: <span>{data.y.toFixed(2)}x</span></div>
        <div className="tooltip-item">Total Complaints: <span>{data.z}</span></div>
        
        {/* Render Primary Product-Brand Driver */}
        {data.driverName && (
          <div style={{ marginTop: '8px', borderTop: '1px solid rgba(255,255,255,0.1)', paddingTop: '6px' }}>
            <div style={{ fontSize: '0.72rem', color: '#f59e0b', textTransform: 'uppercase', fontWeight: '800', letterSpacing: '0.05em' }}>
              {data.driverObjName ? 'Primary Product & Brand Driver' : data.isConcentrated ? '⚠️ High Concentration Driver' : 'Primary Driver Analysis'}
            </div>
            <div style={{ fontSize: '0.8rem', fontWeight: '600', color: '#e2e8f0', marginTop: '2px' }}>
              {data.driverName}
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.72rem', color: '#94a3b8', marginTop: '2px' }}>
              <span>Share: <strong style={{ color: '#cbd5e1' }}>{data.driverPct.toFixed(0)}%</strong></span>
              <span>Driver Avg: <strong style={{ color: '#38bdf8' }}>{data.driverAvg.toFixed(2)}x</strong></span>
            </div>
          </div>
        )}

        {/* Render Primary Object Driver (Only if available in Theme tab) */}
        {data.driverObjName && (
          <div style={{ marginTop: '8px', borderTop: '1px solid rgba(255,255,255,0.1)', paddingTop: '6px' }}>
            <div style={{ fontSize: '0.72rem', color: '#10b981', textTransform: 'uppercase', fontWeight: '800', letterSpacing: '0.05em' }}>
              Primary Complaint Object Driver
            </div>
            <div style={{ fontSize: '0.8rem', fontWeight: '600', color: '#e2e8f0', marginTop: '2px' }}>
              {data.driverObjName}
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.72rem', color: '#94a3b8', marginTop: '2px' }}>
              <span>Share: <strong style={{ color: '#cbd5e1' }}>{data.driverObjPct.toFixed(0)}%</strong></span>
              <span>Driver Avg: <strong style={{ color: '#38bdf8' }}>{data.driverObjAvg.toFixed(2)}x</strong></span>
            </div>
          </div>
        )}

        {data.isConcentrated && (
          <div style={{ fontSize: '0.68rem', color: '#fb7185', marginTop: '6px', fontStyle: 'italic', borderTop: '1px solid rgba(255,255,255,0.05)', paddingTop: '4px' }}>
            * One of the drivers represents &gt;40% of the volume.
          </div>
        )}
      </div>
    );
  }
  return null;
};

const SunburstTooltip = ({ active, payload }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="chart-tooltip" style={{ minWidth: '220px' }}>
        <div className="tooltip-title" style={{ color: data.color, borderBottom: '1px solid rgba(255,255,255,0.1)', paddingBottom: '4px', marginBottom: '6px' }}>
          {data.name}
        </div>
        <div className="tooltip-item">Level: <span style={{ textTransform: 'capitalize' }}>{data.level}</span></div>
        {data.parent && <div className="tooltip-item">Parent: <span>{data.parent}</span></div>}
        <div className="tooltip-item">Complaints: <span style={{ color: '#818cf8', fontWeight: '700' }}>{data.value}</span></div>
      </div>
    );
  }
  return null;
};

// --- Helper to calculate median of an array ---
const getMedian = (values) => {
  if (!values || values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const half = Math.floor(sorted.length / 2);
  if (sorted.length % 2 !== 0) {
    return sorted[half];
  }
  return (sorted[half - 1] + sorted[half]) / 2.0;
};

// --- Helper to filter data for the latest 3 months ---
const getLatestThreeMonthsData = (data) => {
  let maxDate = null;
  const parsed = data.map((row, index) => {
    const dateObj = parseDateFromRow(row, index);
    if (dateObj) {
      if (!maxDate || dateObj > maxDate) {
        maxDate = dateObj;
      }
    }
    return { row, dateObj };
  });

  if (!maxDate) return data;

  const threshold = new Date(maxDate);
  threshold.setMonth(threshold.getMonth() - 3);

  return parsed
    .filter((item) => item.dateObj && item.dateObj >= threshold)
    .map((item) => item.row);
};

// --- Helper to parse date from a row ---
const parseDateFromRow = (row, index) => {
  const dateVal = row["Date Received"] || row["date_received"] || row["Resolved Date"] || row["resolved_date"] || row["Date"] || row["Month"] || row["month"] || "";
  let dateObj = null;
  
  if (dateVal instanceof Date && !isNaN(dateVal.getTime())) {
    dateObj = dateVal;
  } else if (typeof dateVal === 'number' && dateVal > 20000) {
    const date = new Date((dateVal - 25569) * 86400 * 1000);
    if (!isNaN(date.getTime())) dateObj = date;
  } else if (dateVal) {
    const d = new Date(dateVal);
    if (!isNaN(d.getTime())) dateObj = d;
  }
  
  if (dateObj) {
    const year = dateObj.getFullYear();
    // Exclude system placeholders/outliers (e.g. 1983)
    if (year >= 2024 && year <= 2028) {
      return dateObj;
    }
  }
  return null;
};

// --- Helper to find max date across dataset ---
const getMaxDateFromData = (data) => {
  let maxDate = null;
  data.forEach((row, index) => {
    const dateObj = parseDateFromRow(row, index);
    if (dateObj) {
      if (!maxDate || dateObj > maxDate) {
        maxDate = dateObj;
      }
    }
  });
  return maxDate || new Date("2025-12-31"); // Default fallback
};

// --- Helper to generate last 12 chronological month-year objects ---
const getChronological12Months = (maxDate) => {
  const months = [];
  const date = new Date(maxDate);
  date.setDate(1); // Set to first day to avoid calendar overflows
  for (let i = 11; i >= 0; i--) {
    const d = new Date(date);
    d.setMonth(d.getMonth() - i);
    const monthLabel = MONTHS_ORDER[d.getMonth()];
    const yearLabel = String(d.getFullYear()).slice(-2);
    months.push({
      label: `${monthLabel}-${yearLabel}`, // e.g. "Jan-26"
      month: d.getMonth(),
      year: d.getFullYear()
    });
  }
  return months;
};

// --- Helper to get date range string ---
const getDateRangeString = (data) => {
  if (!data || data.length === 0) return "";
  let minD = null;
  let maxD = null;
  data.forEach((row, index) => {
    const d = parseDateFromRow(row, index);
    if (d) {
      if (!minD || d < minD) minD = d;
      if (!maxD || d > maxD) maxD = d;
    }
  });
  if (!minD || !maxD) return "";
  
  const minMonth = MONTHS_ORDER[minD.getMonth()];
  const minYear = String(minD.getFullYear()).slice(-2);
  const maxMonth = MONTHS_ORDER[maxD.getMonth()];
  const maxYear = String(maxD.getFullYear()).slice(-2);
  
  return `${minMonth}-${minYear} to ${maxMonth}-${maxYear}`;
};

// --- Helper to get Jan, Feb, Mar aggregated unique P+C count & median repeats ---
const getJanFebMarData = (data, selectedItems, getRowItems) => {
  const maxDate = getMaxDateFromData(data);
  const targetYear = maxDate.getFullYear();
  
  const targetMonths = [
    { label: `Jan-${String(targetYear).slice(-2)}`, month: 0, year: targetYear },
    { label: `Feb-${String(targetYear).slice(-2)}`, month: 1, year: targetYear },
    { label: `Mar-${String(targetYear).slice(-2)}`, month: 2, year: targetYear }
  ];
  
  return targetMonths.map(m => {
    const clientCounts = {};
    data.forEach((row, index) => {
      const items = getRowItems(row);
      const hasSelected = items.some(item => selectedItems.includes(item));
      if (!hasSelected) return;
      
      const rowDate = parseDateFromRow(row, index);
      if (!rowDate) return;
      
      if (rowDate.getMonth() === m.month && rowDate.getFullYear() === m.year) {
        const policyVal = row["Policy Number"] || row["policy_number"] || "";
        const claimVal = row["Claim Number"] || row["claim_number"] || "";
        const clientKey = `${String(policyVal).trim()}_${String(claimVal).trim()}`;
        clientCounts[clientKey] = (clientCounts[clientKey] || 0) + 1;
      }
    });
    
    const repeatCounts = Object.values(clientCounts);
    const uniqueCount = repeatCounts.length;
    const medianVal = repeatCounts.length > 0 ? getMedian(repeatCounts) : 0;
    
    return {
      month: m.label,
      count: uniqueCount,
      median: medianVal
    };
  });
};

const ComposedTooltip = ({ active, payload }) => {
  if (active && payload && payload.length) {
    return (
      <div className="chart-tooltip">
        <div className="tooltip-title" style={{ borderColor: '#475569' }}>{payload[0].payload.month}</div>
        <div className="tooltip-item" style={{ color: '#a5b4fc' }}>
          Complaint Count (Bar): <span style={{ color: '#a5b4fc' }}>{payload[0].value}</span>
        </div>
      </div>
    );
  }
  return null;
};

// --- Helper to calculate 95th percentile outliers by P+C and Theme ---
const calculateOutliersData = (data) => {
  if (!data || data.length === 0) {
    return {
      pcLevel: {
        p95Threshold: 0,
        totalOutlierPCs: 0,
        pctOutlierPCs: 0,
        themeOutliers: [],
        pbOutliers: [],
        objectOutliers: []
      },
      pcthemeLevel: {
        p95Threshold: 0,
        totalOutlierCombinations: 0,
        pctOutlierCombinations: 0,
        themeOutliers: [],
        pbOutliers: [],
        objectOutliers: []
      }
    };
  }

  // ==========================================
  // SECTION 1: CUSTOMER (P+C) LEVEL OUTLIERS
  // ==========================================
  const pcGlobalCounts = {};
  const pcRows = {};

  data.forEach(row => {
    const policyVal = row["Policy Number"] || row["policy_number"] || "";
    const claimVal = row["Claim Number"] || row["claim_number"] || "";
    if (!policyVal && !claimVal) return;
    const pcKey = `${String(policyVal).trim()}_${String(claimVal).trim()}`;
    
    pcGlobalCounts[pcKey] = (pcGlobalCounts[pcKey] || 0) + 1;
    if (!pcRows[pcKey]) {
      pcRows[pcKey] = [];
    }
    pcRows[pcKey].push(row);
  });

  const pcCountsArray = Object.values(pcGlobalCounts);
  let pcP95Threshold = 0;
  let pcOutlierPCKeys = [];
  let pctOutlierPCs = 0;

  if (pcCountsArray.length > 0) {
    const sortedPcCounts = [...pcCountsArray].sort((a, b) => a - b);
    const idx95 = Math.ceil(0.95 * sortedPcCounts.length) - 1;
    pcP95Threshold = sortedPcCounts[Math.max(0, idx95)];
    pcOutlierPCKeys = Object.keys(pcGlobalCounts).filter(pcKey => pcGlobalCounts[pcKey] > pcP95Threshold);
    pctOutlierPCs = (pcOutlierPCKeys.length / pcCountsArray.length) * 100;
  }

  const themeCountsPC = {};
  const pbCountsPC = {};
  const objectCountsPC = {};

  pcOutlierPCKeys.forEach(pcKey => {
    const rows = pcRows[pcKey];

    // Themes
    const localThemes = {};
    rows.forEach(row => {
      const themesField = row["Assigned Themes"] || row["assigned_theme"] || row["assigned_themes"] || row["Themes"] || row["Theme"] || "";
      const themes = String(themesField).split(',').map(t => t.trim()).filter(Boolean);
      themes.forEach(t => {
        localThemes[t] = (localThemes[t] || 0) + 1;
      });
    });
    const themeVals = Object.values(localThemes);
    if (themeVals.length > 0) {
      const maxThemeVal = Math.max(...themeVals);
      Object.keys(localThemes).forEach(t => {
        if (localThemes[t] === maxThemeVal) {
          themeCountsPC[t] = (themeCountsPC[t] || 0) + 1;
        }
      });
    }

    // Product & Brand
    const localPBs = {};
    rows.forEach(row => {
      const productVal = row["Product / Service"] || row["product_service"] || row["Product"] || row["product"] || "";
      const brandVal = row["Brand"] || row["brand"] || "";
      const prod = String(productVal).trim();
      const brand = String(brandVal).trim();
      const pbKey = prod && brand ? `${prod} - ${brand}` : (prod || brand || "Unspecified Product & Brand");
      localPBs[pbKey] = (localPBs[pbKey] || 0) + 1;
    });
    const pbVals = Object.values(localPBs);
    if (pbVals.length > 0) {
      const maxPBVal = Math.max(...pbVals);
      Object.keys(localPBs).forEach(pb => {
        if (localPBs[pb] === maxPBVal) {
          pbCountsPC[pb] = (pbCountsPC[pb] || 0) + 1;
        }
      });
    }

    // Objects
    const localObjects = {};
    rows.forEach(row => {
      const objectVal = row["normalised complaint object"] || row["normalised_complaint_object"] || row["Complaint Object"] || row["complaint_object"] || row["Object"] || row["object"] || "";
      const objects = String(objectVal).split(',').map(o => o.trim()).filter(Boolean).map(normalizeObjectValue).filter(v => v);
      objects.forEach(obj => {
        localObjects[obj] = (localObjects[obj] || 0) + 1;
      });
    });
    const objVals = Object.values(localObjects);
    if (objVals.length > 0) {
      const maxObjVal = Math.max(...objVals);
      Object.keys(localObjects).forEach(obj => {
        if (localObjects[obj] === maxObjVal) {
          objectCountsPC[obj] = (objectCountsPC[obj] || 0) + 1;
        }
      });
    }
  });

  const pcThemeOutliers = Object.keys(themeCountsPC).map(theme => ({
    theme,
    count: themeCountsPC[theme],
    pct: pcOutlierPCKeys.length > 0 ? (themeCountsPC[theme] / pcOutlierPCKeys.length) * 100 : 0
  })).sort((a, b) => b.count - a.count);

  const pcPbOutliers = Object.keys(pbCountsPC).map(pb => ({
    name: pb,
    count: pbCountsPC[pb],
    pct: pcOutlierPCKeys.length > 0 ? (pbCountsPC[pb] / pcOutlierPCKeys.length) * 100 : 0
  })).sort((a, b) => b.count - a.count);

  const pcObjectOutliers = Object.keys(objectCountsPC).map(obj => ({
    name: obj,
    count: objectCountsPC[obj],
    pct: pcOutlierPCKeys.length > 0 ? (objectCountsPC[obj] / pcOutlierPCKeys.length) * 100 : 0
  })).sort((a, b) => b.count - a.count);

  // ==========================================
  // SECTION 2: CUSTOMER-THEME (P+C + THEME) LEVEL OUTLIERS
  // ==========================================
  const pctCounts = {};
  const pctRows = {};

  data.forEach(row => {
    const policyVal = row["Policy Number"] || row["policy_number"] || "";
    const claimVal = row["Claim Number"] || row["claim_number"] || "";
    if (!policyVal && !claimVal) return;
    const pcKey = `${String(policyVal).trim()}_${String(claimVal).trim()}`;

    const themesField = row["Assigned Themes"] || row["assigned_theme"] || row["assigned_themes"] || row["Themes"] || row["Theme"] || "";
    const themes = String(themesField).split(',').map(t => t.trim()).filter(Boolean);

    themes.forEach(theme => {
      const pctKey = `${pcKey}|||${theme}`;
      pctCounts[pctKey] = (pctCounts[pctKey] || 0) + 1;
      if (!pctRows[pctKey]) {
        pctRows[pctKey] = [];
      }
      pctRows[pctKey].push(row);
    });
  });

  const pctCountsArray = Object.values(pctCounts);
  let pctP95Threshold = 0;
  let pctOutlierKeys = [];
  let pctOutlierCombinations = 0;

  if (pctCountsArray.length > 0) {
    const sortedPctCounts = [...pctCountsArray].sort((a, b) => a - b);
    const idx95 = Math.ceil(0.95 * sortedPctCounts.length) - 1;
    pctP95Threshold = sortedPctCounts[Math.max(0, idx95)];
    pctOutlierKeys = Object.keys(pctCounts).filter(pctKey => pctCounts[pctKey] > pctP95Threshold);
    pctOutlierCombinations = (pctOutlierKeys.length / pctCountsArray.length) * 100;
  }

  // Count primary category drivers for outlier combinations
  const themeCountsPCT = {};
  const pbCountsPCT = {};
  const objectCountsPCT = {};

  pctOutlierKeys.forEach(pctKey => {
    const rows = pctRows[pctKey];
    // Each pctKey is `pcKey|||theme`
    const [, theme] = pctKey.split("|||");

    // Themes
    themeCountsPCT[theme] = (themeCountsPCT[theme] || 0) + 1;

    // Product & Brand (Majority vote in this combination)
    const localPBs = {};
    rows.forEach(row => {
      const productVal = row["Product / Service"] || row["product_service"] || row["Product"] || row["product"] || "";
      const brandVal = row["Brand"] || row["brand"] || "";
      const prod = String(productVal).trim();
      const brand = String(brandVal).trim();
      const pbKey = prod && brand ? `${prod} - ${brand}` : (prod || brand || "Unspecified Product & Brand");
      localPBs[pbKey] = (localPBs[pbKey] || 0) + 1;
    });
    const pbVals = Object.values(localPBs);
    if (pbVals.length > 0) {
      const maxPBVal = Math.max(...pbVals);
      Object.keys(localPBs).forEach(pb => {
        if (localPBs[pb] === maxPBVal) {
          pbCountsPCT[pb] = (pbCountsPCT[pb] || 0) + 1;
        }
      });
    }

    // Objects (Majority vote in this combination)
    const localObjects = {};
    rows.forEach(row => {
      const objectVal = row["normalised complaint object"] || row["normalised_complaint_object"] || row["Complaint Object"] || row["complaint_object"] || row["Object"] || row["object"] || "";
      const objects = String(objectVal).split(',').map(o => o.trim()).filter(Boolean).map(normalizeObjectValue).filter(v => v);
      objects.forEach(obj => {
        localObjects[obj] = (localObjects[obj] || 0) + 1;
      });
    });
    const objVals = Object.values(localObjects);
    if (objVals.length > 0) {
      const maxObjVal = Math.max(...objVals);
      Object.keys(localObjects).forEach(obj => {
        if (localObjects[obj] === maxObjVal) {
          objectCountsPCT[obj] = (objectCountsPCT[obj] || 0) + 1;
        }
      });
    }
  });

  const pctThemeOutliers = Object.keys(themeCountsPCT).map(theme => ({
    theme,
    count: themeCountsPCT[theme],
    pct: pctOutlierKeys.length > 0 ? (themeCountsPCT[theme] / pctOutlierKeys.length) * 100 : 0
  })).sort((a, b) => b.count - a.count);

  const pctPbOutliers = Object.keys(pbCountsPCT).map(pb => ({
    name: pb,
    count: pbCountsPCT[pb],
    pct: pctOutlierKeys.length > 0 ? (pbCountsPCT[pb] / pctOutlierKeys.length) * 100 : 0
  })).sort((a, b) => b.count - a.count);

  const pctObjectOutliers = Object.keys(objectCountsPCT).map(obj => ({
    name: obj,
    count: objectCountsPCT[obj],
    pct: pctOutlierKeys.length > 0 ? (objectCountsPCT[obj] / pctOutlierKeys.length) * 100 : 0
  })).sort((a, b) => b.count - a.count);

  return {
    pcLevel: {
      p95Threshold: pcP95Threshold,
      totalUniquePCs: pcCountsArray.length,
      totalOutlierPCs: pcOutlierPCKeys.length,
      pctOutlierPCs,
      themeOutliers: pcThemeOutliers,
      pbOutliers: pcPbOutliers,
      objectOutliers: pcObjectOutliers
    },
    pcthemeLevel: {
      p95Threshold: pctP95Threshold,
      totalUniqueCombinations: pctCountsArray.length,
      totalOutlierCombinations: pctOutlierKeys.length,
      pctOutlierCombinations,
      themeOutliers: pctThemeOutliers,
      pbOutliers: pctPbOutliers,
      objectOutliers: pctObjectOutliers
    }
  };
};

export default function App() {
  const [rawData, setRawData] = useState(DEFAULT_MOCK_DATA);
  const [analysisMode, setAnalysisMode] = useState("theme"); // "theme" or "dimension" (Product + Brand)
  const [processedStats, setProcessedStats] = useState([]);
  const [dropdownList, setDropdownList] = useState([]);
  const [selectedItems, setSelectedItems] = useState([]); // Multi-select array
  const [trendData, setTrendData] = useState([]);
  const [trendSummary, setTrendSummary] = useState({ status: "STABLE", percentChange: 0, text: "" });
  const [extremeTrends, setExtremeTrends] = useState({ mostImproved: null, mostWorsened: null });
  const [kpis, setKpis] = useState({ totalComplaints: 0, uniqueClients: 0, avgOverallRepeats: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [fileName, setFileName] = useState("Preloaded Mock Data");
  const [showLegend, setShowLegend] = useState(false);
  const [topOverall, setTopOverall] = useState([]);
  const [top3Months, setTop3Months] = useState([]);
  const [isSelectorExpanded, setIsSelectorExpanded] = useState(false);
  const [outliersData, setOutliersData] = useState(null);

  // Re-run analysis on data or mode change
  useEffect(() => {
    processData(rawData);
  }, [rawData, analysisMode]);

  // Re-run trends when selectedItems or rawData changes
  useEffect(() => {
    calculateTrend(rawData, selectedItems);
  }, [selectedItems, rawData, analysisMode]);

  // Helper to extract keys based on selected mode
  const getRowItems = (row) => {
    if (analysisMode === "theme") {
      const themesField = row["Assigned Themes"] || row["assigned_themes"] || row["Themes"] || row["Theme"] || "";
      return String(themesField).split(',').map(t => t.trim()).filter(Boolean);
    } else if (analysisMode === "object") {
      const objectField = row["normalised complaint object"] || row["normalised_complaint_object"] || row["Complaint Object"] || row["complaint_object"] || row["Object"] || row["object"] || "";
      return String(objectField).split(',').map(o => o.trim()).filter(Boolean).map(normalizeObjectValue).filter(v => v && v !== "other / unspecified");
    } else {
      // Dimension mode: Combine Product / Service + Brand
      const productVal = row["Product / Service"] || row["product_service"] || row["Product"] || row["product"] || "";
      const brandVal = row["Brand"] || row["brand"] || "";
      
      const prod = String(productVal).trim();
      const brand = String(brandVal).trim();
      
      if (prod && brand) return [`${prod} - ${brand}`];
      if (prod) return [prod];
      if (brand) return [brand];
      return [];
    }
  };

  const processData = (data) => {
    try {
      const statsMap = {};
      const globalUniqueClients = new Set();
      const extractedItems = new Set();
      
      data.forEach(row => {
        const policyVal = row["Policy Number"] || row["policy_number"] || row["Policy"] || "";
        const claimVal = row["Claim Number"] || row["claim_number"] || row["Claim"] || "";
        
        if (!policyVal && !claimVal) return;
        
        const clientKey = `${String(policyVal).trim()}_${String(claimVal).trim()}`;
        globalUniqueClients.add(clientKey);
        
        const items = getRowItems(row);
        items.forEach(itemName => {
          extractedItems.add(itemName);
          if (!statsMap[itemName]) {
            statsMap[itemName] = {
              total: 0,
              clientCounts: {}
            };
          }
          
          statsMap[itemName].total += 1;
          statsMap[itemName].clientCounts[clientKey] = (statsMap[itemName].clientCounts[clientKey] || 0) + 1;
        });
      });
      
      const formattedStats = Object.keys(statsMap).map((itemName, idx) => {
        const totalCount = statsMap[itemName].total;
        const countsArray = Object.values(statsMap[itemName].clientCounts);
        const uniqueCount = countsArray.length;
        const avgRepeats = uniqueCount > 0 ? (totalCount / uniqueCount) : 1;
        const medianRepeats = getMedian(countsArray);
        
        // --- Calculate Driver Analysis ---
        let driverName = "";
        let driverPct = 0;
        let driverAvg = 1;
        let driverCount = 0;
        let driverObjName = "";
        let driverObjPct = 0;
        let driverObjAvg = 1;
        let driverObjCount = 0;
        let isConcentrated = false;

        // Filter rows matching this item
        const matchingRows = data.filter(row => {
          const items = getRowItems(row);
          return items.includes(itemName);
        });

        if (matchingRows.length > 0) {
          if (analysisMode === "theme") {
            const pbGroups = {};
            const objGroups = {};

            matchingRows.forEach(row => {
              // 1. Group by Product-Brand
              const productVal = row["Product / Service"] || row["product_service"] || row["Product"] || row["product"] || "";
              const brandVal = row["Brand"] || row["brand"] || "";
              const prod = String(productVal).trim();
              const brand = String(brandVal).trim();
              const pbKey = prod && brand ? `${prod} - ${brand}` : (prod || brand || "Unspecified P+B");

              if (!pbGroups[pbKey]) {
                pbGroups[pbKey] = { count: 0, clients: {} };
              }
              pbGroups[pbKey].count += 1;

              // 2. Group by Complaint Object (split & normalized)
              const objectVal = row["normalised complaint object"] || row["normalised_complaint_object"] || row["Complaint Object"] || row["complaint_object"] || row["Object"] || row["object"] || "";
              const objects = String(objectVal).split(',').map(o => o.trim()).filter(Boolean).map(normalizeObjectValue).filter(v => v && v !== "other / unspecified");

              objects.forEach(objKey => {
                if (!objGroups[objKey]) {
                  objGroups[objKey] = { count: 0, clients: {} };
                }
                objGroups[objKey].count += 1;
              });

              // Add client keys for repeat averages
              const policyVal = row["Policy Number"] || row["policy_number"] || row["Policy"] || "";
              const claimVal = row["Claim Number"] || row["claim_number"] || row["Claim"] || "";
              if (policyVal || claimVal) {
                const cKey = `${String(policyVal).trim()}_${String(claimVal).trim()}`;
                pbGroups[pbKey].clients[cKey] = (pbGroups[pbKey].clients[cKey] || 0) + 1;
                objects.forEach(objKey => {
                  objGroups[objKey].clients[cKey] = (objGroups[objKey].clients[cKey] || 0) + 1;
                });
              }
            });

            // Top Product-Brand Group
            const sortedPBs = Object.keys(pbGroups).sort((a, b) => pbGroups[b].count - pbGroups[a].count);
            if (sortedPBs.length > 0) {
              const topPBKey = sortedPBs[0];
              driverName = topPBKey;
              driverCount = pbGroups[topPBKey].count;
              driverPct = (driverCount / totalCount) * 100;
              const pbUnique = Object.keys(pbGroups[topPBKey].clients).length;
              driverAvg = pbUnique > 0 ? (driverCount / pbUnique) : 1;
            }

            // Top Complaint Object Group
            const sortedObjs = Object.keys(objGroups).sort((a, b) => objGroups[b].count - objGroups[a].count);
            if (sortedObjs.length > 0) {
              const topObjKey = sortedObjs[0];
              driverObjName = topObjKey;
              driverObjCount = objGroups[topObjKey].count;
              driverObjPct = (driverObjCount / totalCount) * 100;
              const objUnique = Object.keys(objGroups[topObjKey].clients).length;
              driverObjAvg = objUnique > 0 ? (driverObjCount / objUnique) : 1;
            }

            isConcentrated = (driverPct > 40.0) || (driverObjPct > 40.0);
          } else {
            // Group by Theme (split, trim)
            const driverGroups = {};
            matchingRows.forEach(row => {
              const themesField = row["Assigned Themes"] || row["assigned_theme"] || row["assigned_themes"] || row["Themes"] || row["Theme"] || "";
              const themes = String(themesField).split(',').map(t => t.trim()).filter(Boolean);
              const key = themes[0] || "Unspecified Theme";

              if (!driverGroups[key]) {
                driverGroups[key] = { count: 0, clients: {} };
              }
              driverGroups[key].count += 1;

              const policyVal = row["Policy Number"] || row["policy_number"] || row["Policy"] || "";
              const claimVal = row["Claim Number"] || row["claim_number"] || row["Claim"] || "";
              if (policyVal || claimVal) {
                const cKey = `${String(policyVal).trim()}_${String(claimVal).trim()}`;
                driverGroups[key].clients[cKey] = (driverGroups[key].clients[cKey] || 0) + 1;
              }
            });

            const sortedGroups = Object.keys(driverGroups).sort((a, b) => driverGroups[b].count - driverGroups[a].count);
            if (sortedGroups.length > 0) {
              const topGroupKey = sortedGroups[0];
              driverName = topGroupKey;
              driverCount = driverGroups[topGroupKey].count;
              driverPct = (driverCount / totalCount) * 100;
              const groupUnique = Object.keys(driverGroups[topGroupKey].clients).length;
              driverAvg = groupUnique > 0 ? (driverCount / groupUnique) : 1;
              isConcentrated = driverPct > 40.0;
            }
          }
        }

        return {
          name: itemName,
          x: uniqueCount,
          y: avgRepeats, // Scatter plot Y-axis (avg complaints / P+C)
          yMedian: medianRepeats, // Scatter plot Y-axis (median repeats)
          z: totalCount,
          color: COLORS[idx % COLORS.length],
          driverName,
          driverPct,
          driverAvg,
          driverCount,
          driverObjName,
          driverObjPct,
          driverObjAvg,
          driverObjCount,
          isConcentrated
        };
      });
      
      // Sort overall descending by total complaints (z)
      const sortedStats = [...formattedStats].sort((a, b) => b.z - a.z);
      setProcessedStats(sortedStats);
      
      const itemsArray = Array.from(extractedItems);
      setDropdownList(itemsArray);

      // Default selected items to top 5 overall by total complaints
      const top5Names = sortedStats.slice(0, 5).map(s => s.name);
      setSelectedItems(top5Names);

      // Sort formattedStats by total volume (z) for Top 5 Overall
      setTopOverall(sortedStats.slice(0, 5));
      
      // Calculate top 5 of the last 3 months
      const last3MonthsData = getLatestThreeMonthsData(data);
      const statsMap3M = {};
      last3MonthsData.forEach(row => {
        const policyVal = row["Policy Number"] || row["policy_number"] || row["Policy"] || "";
        const claimVal = row["Claim Number"] || row["claim_number"] || row["Claim"] || "";
        if (!policyVal && !claimVal) return;
        
        const clientKey = `${String(policyVal).trim()}_${String(claimVal).trim()}`;
        const items = getRowItems(row);
        items.forEach(itemName => {
          if (!statsMap3M[itemName]) {
            statsMap3M[itemName] = { total: 0, clientCounts: {} };
          }
          statsMap3M[itemName].total += 1;
          statsMap3M[itemName].clientCounts[clientKey] = (statsMap3M[itemName].clientCounts[clientKey] || 0) + 1;
        });
      });
      const formattedStats3M = Object.keys(statsMap3M).map((itemName, idx) => {
        const totalCount = statsMap3M[itemName].total;
        const countsArray = Object.values(statsMap3M[itemName].clientCounts);
        const uniqueCount = countsArray.length;
        const avgRepeats = uniqueCount > 0 ? (totalCount / uniqueCount) : 1;
        return {
          name: itemName,
          x: uniqueCount,
          y: avgRepeats,
          z: totalCount,
          color: COLORS[idx % COLORS.length]
        };
      });
      const sortedByVolume3M = [...formattedStats3M].sort((a, b) => b.z - a.z).slice(0, 5);
      setTop3Months(sortedByVolume3M);

      // --- Calculate Jan vs Mar Trends for ALL items to find Extremes ---
      let mostImproved = null;
      let mostWorsened = null;
      let minPct = 0; // Most negative (Improved)
      let maxPct = 0; // Most positive (Worsened)

      const refMaxDate = getMaxDateFromData(data);
      const targetYear = refMaxDate.getFullYear();

      itemsArray.forEach(itemName => {
        const janClients = new Set();
        const marClients = new Set();

        data.forEach((row, index) => {
          const items = getRowItems(row);
          if (!items.includes(itemName)) return;

          const rowDate = parseDateFromRow(row, index);
          if (!rowDate) return;

          if (rowDate.getFullYear() === targetYear) {
            const policyVal = row["Policy Number"] || row["policy_number"] || "";
            const claimVal = row["Claim Number"] || row["claim_number"] || "";
            const clientKey = `${String(policyVal).trim()}_${String(claimVal).trim()}`;

            if (rowDate.getMonth() === 0) janClients.add(clientKey);
            if (rowDate.getMonth() === 2) marClients.add(clientKey);
          }
        });

        const janCount = janClients.size;
        const marCount = marClients.size;

        if (janCount > 0) {
          const pct = ((marCount - janCount) / janCount) * 100;
          if (pct < minPct) {
            minPct = pct;
            mostImproved = { item: itemName, pct, q1Total: janCount, q4Total: marCount };
          }
          if (pct > maxPct) {
            maxPct = pct;
            mostWorsened = { item: itemName, pct, q1Total: janCount, q4Total: marCount };
          }
        }
      });

      setExtremeTrends({ mostImproved, mostWorsened });
      
      const totalComplaints = data.length;
      const uniqueClients = globalUniqueClients.size;
      
      // Calculate overall median repeats
      const globalClientCounts = {};
      data.forEach(row => {
        const policyVal = row["Policy Number"] || row["policy_number"] || "";
        const claimVal = row["Claim Number"] || row["claim_number"] || "";
        if (!policyVal && !claimVal) return;
        const clientKey = `${String(policyVal).trim()}_${String(claimVal).trim()}`;
        globalClientCounts[clientKey] = (globalClientCounts[clientKey] || 0) + 1;
      });
      const medianOverallRepeats = getMedian(Object.values(globalClientCounts));
      
      setKpis({
        totalComplaints,
        uniqueClients,
        avgOverallRepeats: medianOverallRepeats
      });

      const computedOutliers = calculateOutliersData(data);
      setOutliersData(computedOutliers);

      setErrorMsg("");
    } catch (err) {
      console.error(err);
      setErrorMsg("Error parsing file structure. Verify column headers.");
    }
  };

  const calculateTrend = (data, itemsList) => {
    if (!itemsList || itemsList.length === 0) {
      setTrendData([]);
      setTrendSummary({ status: "STABLE", percentChange: 0, text: "No items selected." });
      return;
    }

    const formattedTrend = getJanFebMarData(data, itemsList, getRowItems);
    setTrendData(formattedTrend);

    const janCount = formattedTrend[0]?.count || 0;
    const marCount = formattedTrend[2]?.count || 0;

    let status = "STABLE";
    let text = "";
    if (janCount > 0) {
      const diff = marCount - janCount;
      const pct = (diff / janCount) * 100;
      
      const targetLabel = analysisMode === "theme" ? "themes" : analysisMode === "object" ? "complaint objects" : "Product & Brands";
      if (pct < -5) {
        status = "IMPROVED";
        text = `Aggregated unique claims (P+C) for selected ${targetLabel} decreased from ${janCount} in Jan to ${marCount} in Mar, representing a ${Math.abs(pct).toFixed(0)}% decrease.`;
      } else if (pct > 5) {
        status = "WORSENED";
        text = `Aggregated unique claims (P+C) for selected ${targetLabel} increased from ${janCount} in Jan to ${marCount} in Mar, representing a ${pct.toFixed(0)}% increase.`;
      } else {
        status = "STABLE";
        text = `Aggregated unique claims (P+C) remained stable between Jan (${janCount}) and Mar (${marCount}), changing by ${pct.toFixed(0)}%.`;
      }
      setTrendSummary({ status, percentChange: pct, text });
    } else {
      setTrendSummary({ status: "STABLE", percentChange: 0, text: "No baseline data in January to compute trend." });
    }
  };

  // --- Dynamic Insights Generator ---
  const generateDynamicInsights = () => {
    const insights = [];
    const targetNoun = analysisMode === "theme" ? "Theme" : "Product & Brand";

    if (processedStats.length > 0) {
      const topOutlier = processedStats[0];
      const hasRepeats = topOutlier.y > 1;
      if (hasRepeats) {
        insights.push({
          type: "danger",
          title: `Worst Callback Outlier`,
          text: `"${topOutlier.name}" exhibits the highest customer friction. A small subset of ${topOutlier.x} claims generated ${topOutlier.z} complaints, averaging ${topOutlier.y.toFixed(2)}x callbacks per Claim+Policy.`
        });
      }
    }

    if (extremeTrends.mostWorsened) {
      insights.push({
        type: "worse",
        title: `Top Trend Escalation`,
        text: `"${extremeTrends.mostWorsened.item}" is deteriorating rapidly. Total unique claims rose by +${extremeTrends.mostWorsened.pct.toFixed(0)}% between Jan and Mar (Jan: ${extremeTrends.mostWorsened.q1Total} → Mar: ${extremeTrends.mostWorsened.q4Total}).`
      });
    }

    if (extremeTrends.mostImproved) {
      insights.push({
        type: "success",
        title: `Top Service Improvement`,
        text: `Customer complaints for "${extremeTrends.mostImproved.item}" are resolving, with unique claims dropping by ${Math.abs(extremeTrends.mostImproved.pct).toFixed(0)}% between Jan and Mar (Jan: ${extremeTrends.mostImproved.q1Total} → Mar: ${extremeTrends.mostImproved.q4Total}).`
      });
    }

    return insights;
  };

  const activeInsights = generateDynamicInsights();

  const handleFileUpload = (file) => {
    if (!file) return;
    setFileName(file.name);
    
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const binaryStr = e.target.result;
        const workbook = XLSX.read(binaryStr, { type: 'binary' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);
        
        if (jsonData.length === 0) {
          setErrorMsg("The uploaded Excel sheet contains no rows of data.");
          return;
        }
        
        setRawData(jsonData);
      } catch (err) {
        console.error(err);
        setErrorMsg("Failed to read the Excel file. Please upload a valid .xlsx spreadsheet.");
      }
    };
    reader.readAsBinaryString(file);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  const totalRows = rawData.length;
  const last3MRows = getLatestThreeMonthsData(rawData).length;
  const pctLast3M = totalRows > 0 ? ((last3MRows / totalRows) * 100).toFixed(0) : 0;
  const dateRangeText = getDateRangeString(rawData);

  // Compute heatmap data dynamically
  const heatmapData = (() => {
    if (analysisMode === 'theme') return null;
    if (analysisMode === 'dimension') {
      return generateHeatmapData(rawData, 'dimension');
    }
    return generateHeatmapData(rawData, 'object');
  })();

  // Compute sunburst hierarchical data
  const sunburstData = (() => {
    if (analysisMode !== 'theme') return null;
    return getSunburstData(rawData);
  })();

  return (
    <div className="app-container">
      {/* Title Header */}
      <header className="dashboard-header animate-fade-in">
        <div className="header-title-section">
          <h1>Insurance Complaints Analytics Portal</h1>
          <p>Analyzing PII Masked Data & Repeated Complaint Metrics</p>
        </div>

        {/* Global Context Switcher */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '1.5rem' }}>
          <div style={{ display: 'flex', gap: '0.25rem', background: 'rgba(30, 41, 59, 0.6)', padding: '0.25rem', borderRadius: '10px', border: '1px solid rgba(51, 65, 85, 0.4)' }}>
            <button 
              onClick={() => setAnalysisMode('theme')}
              style={{
                padding: '0.5rem 1.1rem',
                borderRadius: '8px',
                fontSize: '0.85rem',
                fontWeight: '600',
                border: 'none',
                cursor: 'pointer',
                fontFamily: 'Outfit',
                background: analysisMode === 'theme' ? '#6366f1' : 'transparent',
                color: analysisMode === 'theme' ? '#ffffff' : '#94a3b8',
                transition: 'all 0.2s',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem'
              }}
            >
              <Zap size={14} />
              Theme Analysis
            </button>
            <button 
              onClick={() => setAnalysisMode('dimension')}
              style={{
                padding: '0.5rem 1.1rem',
                borderRadius: '8px',
                fontSize: '0.85rem',
                fontWeight: '600',
                border: 'none',
                cursor: 'pointer',
                fontFamily: 'Outfit',
                background: analysisMode === 'dimension' ? '#6366f1' : 'transparent',
                color: analysisMode === 'dimension' ? '#ffffff' : '#94a3b8',
                transition: 'all 0.2s',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem'
              }}
            >
              <Layers size={14} />
              Product & Brand
            </button>
            <button 
              onClick={() => setAnalysisMode('object')}
              style={{
                padding: '0.5rem 1.1rem',
                borderRadius: '8px',
                fontSize: '0.85rem',
                fontWeight: '600',
                border: 'none',
                cursor: 'pointer',
                fontFamily: 'Outfit',
                background: analysisMode === 'object' ? '#6366f1' : 'transparent',
                color: analysisMode === 'object' ? '#ffffff' : '#94a3b8',
                transition: 'all 0.2s',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem'
              }}
            >
              <Box size={14} />
              Complaint Objects
            </button>
            <button 
              onClick={() => setAnalysisMode('outliers')}
              style={{
                padding: '0.5rem 1.1rem',
                borderRadius: '8px',
                fontSize: '0.85rem',
                fontWeight: '600',
                border: 'none',
                cursor: 'pointer',
                fontFamily: 'Outfit',
                background: analysisMode === 'outliers' ? '#6366f1' : 'transparent',
                color: analysisMode === 'outliers' ? '#ffffff' : '#94a3b8',
                transition: 'all 0.2s',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem'
              }}
            >
              <AlertTriangle size={14} />
              Outlier Analysis
            </button>
          </div>
          <div className="badge">
            <Database size={14} style={{ display: 'inline', marginRight: '4px', verticalAlign: 'middle' }} />
            Active: {fileName}
          </div>
        </div>
      </header>

      {/* Executive Insights Panel */}
      {analysisMode !== 'outliers' && activeInsights.length > 0 && (
        <section className="card grid-full-width animate-fade-in" style={{ padding: '1.25rem 1.75rem', gap: '1rem', borderLeft: '4px solid #6366f1' }}>
          <div style={{ fontSize: '1.1rem', fontWeight: '600', color: '#f8fafc', display: 'flex', alignItems: 'center', gap: '0.5rem', borderBottom: '1px solid rgba(51, 65, 85, 0.2)', paddingBottom: '0.5rem' }}>
            <Lightbulb size={16} style={{ color: '#fbbf24' }} />
            Dynamic Executive Insights & Recommendations ({analysisMode === 'theme' ? 'Themes' : analysisMode === 'object' ? 'Complaint Objects' : 'Product & Brands'})
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.25rem' }}>
            {activeInsights.map((insight, idx) => (
              <div 
                key={idx}
                onClick={() => {
                  const matchedName = processedStats.find(s => s.name.toLowerCase() === insight.text.split('"')[1]?.toLowerCase());
                  if (matchedName) {
                    setSelectedItems([matchedName.name]);
                  }
                }}
                style={{
                  background: 'rgba(15, 23, 42, 0.3)',
                  border: `1px solid ${
                    insight.type === 'danger' ? 'rgba(244, 63, 94, 0.2)' : insight.type === 'worse' ? 'rgba(245, 158, 11, 0.2)' : 'rgba(16, 185, 129, 0.2)'
                  }`,
                  padding: '1rem',
                  borderRadius: '10px',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '0.4rem',
                  cursor: 'pointer',
                  transition: 'all 0.2s'
                }}
                className="insight-card-hover"
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <span 
                    style={{
                      width: '8px',
                      height: '8px',
                      borderRadius: '50%',
                      backgroundColor: insight.type === 'danger' ? '#f43f5e' : insight.type === 'worse' ? '#f59e0b' : '#10b981'
                    }}
                  />
                  <h4 style={{
                    fontSize: '0.85rem',
                    fontWeight: '700',
                    color: insight.type === 'danger' ? '#fb7185' : insight.type === 'worse' ? '#fbbf24' : '#34d399'
                  }}>
                    {insight.title}
                  </h4>
                </div>
                <p style={{ fontSize: '0.82rem', color: '#cbd5e1', lineHeight: '1.4' }}>
                  {insight.text}
                </p>
                <span style={{ fontSize: '0.7rem', color: '#64748b', marginTop: 'auto', textAlign: 'right' }}>
                  Click to plot trend →
                </span>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Main Grid */}
      <div className="dashboard-grid">
        
        {/* Sidebar */}
        <aside className="animate-fade-in" style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
          <div className="card">
            <div className="card-title">
              <Upload size={18} />
              Import Classified Data
            </div>
            
            <div 
              className={`upload-zone ${isDragging ? 'dragover' : ''}`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => document.getElementById('excel-file-input').click()}
            >
              <Upload className="upload-icon" />
              <div className="upload-text">
                <h3>Drag & Drop Excel File</h3>
                <p>or click to browse your local computer</p>
              </div>
              <input 
                id="excel-file-input" 
                type="file" 
                accept=".xlsx, .xls" 
                style={{ display: 'none' }} 
                onChange={(e) => handleFileUpload(e.target.files[0])} 
              />
            </div>
            {errorMsg && (
              <div style={{ color: '#fb7185', fontSize: '0.85rem', display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                <AlertTriangle size={16} style={{ flexShrink: 0 }} />
                <span>{errorMsg}</span>
              </div>
            )}
            <p style={{ fontSize: '0.8rem', color: '#64748b', lineHeight: '1.4' }}>
              Expects columns: <strong>Policy Number</strong>, <strong>Claim Number</strong>, <strong>Assigned Themes</strong>, <strong>Product / Service</strong>, and <strong>Brand</strong>.
            </p>
          </div>

          <div className="card">
            <div className="card-title">
              <BarChart2 size={18} />
              Dashboard KPIs
            </div>
            <div className="kpi-container">
              <div className="kpi-card">
                <span className="kpi-label">Total Complaint Rows</span>
                <span className="kpi-value accent-purple">{kpis.totalComplaints}</span>
              </div>
              <div className="kpi-card">
                <span className="kpi-label">Unique Claim+Policy</span>
                <span className="kpi-value accent-blue">{kpis.uniqueClients}</span>
              </div>
              <div className="kpi-card">
                <span className="kpi-label">Overall Median Rate</span>
                <span className="kpi-value accent-emerald">{kpis.avgOverallRepeats.toFixed(1)}x</span>
              </div>
            </div>
          </div>
        </aside>

        {/* Visualizations */}
        <main className="animate-fade-in" style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
          
          {analysisMode !== 'outliers' ? (
            <>
              {/* Table Card 1: Themes by Total Complaints */}
              <div className="card grid-full-width">
            <div className="card-title" style={{ display: 'flex', flexDirection: 'column', gap: '0.2rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Users size={18} />
                {analysisMode === 'theme' ? 'Theme Analysis by Total Complaints' : analysisMode === 'object' ? 'Complaint Object Analysis by Total Complaints' : 'Product & Brand Analysis by Total Complaints'}
              </div>
              <div style={{ fontSize: '0.82rem', fontWeight: '500', color: '#64748b', display: 'flex', gap: '1rem' }}>
                <span>Date Range: {dateRangeText || "N/A"}</span>
                <span style={{ color: '#818cf8' }}>{pctLast3M}% of the complaints are coming from the last three months.</span>
              </div>
            </div>
            
            <div className="table-container" style={{ maxHeight: '380px', overflowY: 'auto' }}>
              <table>
                <thead>
                  <tr>
                    <th>Rank</th>
                    <th>Name</th>
                    <th style={{ textAlign: 'center' }}>Unique Claim+Policy</th>
                    <th style={{ textAlign: 'center' }}>Total Complaints</th>
                  </tr>
                </thead>
                <tbody>
                  {processedStats.map((stat, idx) => {
                    const pctUnique = kpis.uniqueClients > 0 ? ((stat.x / kpis.uniqueClients) * 100).toFixed(1) : '0.0';
                    const pctTotal = kpis.totalComplaints > 0 ? ((stat.z / kpis.totalComplaints) * 100).toFixed(1) : '0.0';
                    return (
                      <tr key={idx} className={selectedItems.includes(stat.name) ? 'highlight-row' : ''}>
                        <td style={{ fontWeight: '700', color: idx < 3 ? '#fbbf24' : '#64748b', width: '80px' }}>
                          #{idx + 1}
                        </td>
                        <td 
                          style={{ cursor: 'pointer', fontWeight: '600' }}
                          onClick={() => {
                            if (selectedItems.includes(stat.name)) {
                              setSelectedItems(selectedItems.filter(x => x !== stat.name));
                            } else {
                              setSelectedItems([...selectedItems, stat.name]);
                            }
                          }}
                        >
                          {stat.name}
                        </td>
                        <td style={{ textAlign: 'center', color: '#cbd5e1' }}>
                          {stat.x} <span style={{ fontSize: '0.75rem', color: '#64748b' }}>({pctUnique}%)</span>
                        </td>
                        <td style={{ textAlign: 'center', fontWeight: '700', color: '#f8fafc' }}>
                          {stat.z} <span style={{ fontSize: '0.75rem', color: '#64748b' }}>({pctTotal}%)</span>
                        </td>
                      </tr>
                    );
                  })}
                  {processedStats.length === 0 && (
                    <tr>
                      <td colSpan={4} style={{ textAlign: 'center', color: '#64748b' }}>No data available</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            <p style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.5rem' }}>
              💡 Click on any name in the table to toggle its selection on the trend chart below.
            </p>
          </div>

          {/* Block 2: Average Scatter Plot */}
          <div className="card">
            <div className="card-title">
              <TrendingUp size={18} />
              Outlier Analysis: Average Repeats vs. Volume
            </div>
            <p style={{ fontSize: '0.9rem', color: '#94a3b8', marginTop: '-0.75rem', lineHeight: '1.4' }}>
              Visualizing the relation between unique Claim+Policy count (X-axis) and average complaints per Claim+Policy (Y-axis) grouped by {analysisMode === 'theme' ? 'Themes' : analysisMode === 'object' ? 'Complaint Objects' : 'Product & Brand'}.
              Bubble size represents total volume. <span style={{ color: '#fb7185' }}>🔴 Red-bordered glowing bubbles indicate high internal variance.</span>
            </p>
            
            <div className="chart-container-inner">
              {processedStats.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <ScatterChart margin={{ top: 20, right: 30, bottom: 20, left: 10 }}>
                    <CartesianGrid stroke="#334155" strokeDasharray="3 3" opacity={0.3} />
                    <XAxis 
                      type="number" 
                      dataKey="x" 
                      name="Unique Claim+Policy" 
                      stroke="#475569" 
                      tick={{ fill: '#94a3b8', fontSize: 12 }}
                      label={{ value: 'Unique Claim+Policy Count', position: 'insideBottom', offset: -5, fill: '#94a3b8', fontSize: 13 }}
                    />
                    <YAxis 
                      type="number" 
                      dataKey="y" 
                      name="avg complain/p+c" 
                      stroke="#475569" 
                      tick={{ fill: '#94a3b8', fontSize: 12 }}
                      domain={[1, 'auto']}
                      label={{ value: 'Avg complaints per Claim+Policy', angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 13 }}
                    />
                    <ZAxis 
                      type="number" 
                      dataKey="z" 
                      range={[150, 1200]} 
                      name="Total Volume" 
                    />
                    <Tooltip content={<ScatterTooltip />} cursor={{ strokeDasharray: '3 3' }} />
                    <Scatter name="DataPoints" data={processedStats} dataKey="y">
                      {processedStats.map((entry, index) => (
                        <Cell 
                          key={`cell-avg-${index}`} 
                          fill={entry.color} 
                          stroke={entry.isConcentrated ? '#f43f5e' : 'none'} 
                          strokeWidth={entry.isConcentrated ? 2.5 : 0}
                          style={{ 
                            filter: entry.isConcentrated 
                              ? 'drop-shadow(0 0 12px rgba(244, 63, 94, 0.7))' 
                              : 'drop-shadow(0 0 8px rgba(99, 102, 241, 0.3))',
                            cursor: 'pointer'
                          }} 
                        />
                      ))}
                    </Scatter>
                  </ScatterChart>
                </ResponsiveContainer>
              ) : (
                <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#64748b' }}>
                  No data available to plot.
                </div>
              )}
            </div>

            {/* Show/Hide Legend Control */}
            <div style={{ display: 'flex', justifyContent: 'center', marginTop: '0.5rem' }}>
              <button
                onClick={() => setShowLegend(!showLegend)}
                style={{
                  background: 'rgba(30, 41, 59, 0.6)',
                  color: '#94a3b8',
                  border: '1px solid rgba(51, 65, 85, 0.4)',
                  borderRadius: '8px',
                  padding: '0.4rem 1rem',
                  fontSize: '0.8rem',
                  fontWeight: '600',
                  fontFamily: 'Outfit',
                  cursor: 'pointer',
                  outline: 'none',
                  transition: 'all 0.2s',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.5rem'
                }}
                className="insight-card-hover"
              >
                <Layers size={12} />
                {showLegend ? 'Hide Color Legend' : `Show Color Legend (${processedStats.length} items)`}
              </button>
            </div>

            {showLegend && (
              <div className="legend-container" style={{ maxHeight: '180px', overflowY: 'auto', padding: '0.75rem', border: '1px solid rgba(51, 65, 85, 0.2)', borderRadius: '8px', background: 'rgba(15, 23, 42, 0.2)' }}>
                {processedStats.map((item, idx) => (
                  <div className="legend-item" key={idx}>
                    <span className="legend-dot" style={{ backgroundColor: item.color }} />
                    <span>{item.name}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Block 2b: Median Scatter Plot */}
          <div className="card">
            <div className="card-title">
              <TrendingUp size={18} />
              Outlier Analysis: Median Repeats vs. Volume
            </div>
            <p style={{ fontSize: '0.9rem', color: '#94a3b8', marginTop: '-0.75rem', lineHeight: '1.4' }}>
              Visualizing the relation between unique Claim+Policy count (X-axis) and median repeats per Claim+Policy (Y-axis) grouped by {analysisMode === 'theme' ? 'Themes' : analysisMode === 'object' ? 'Complaint Objects' : 'Product & Brand'}.
              Bubble size represents total volume. <span style={{ color: '#fb7185' }}>🔴 Red-bordered glowing bubbles indicate high internal variance.</span>
            </p>
            
            <div className="chart-container-inner">
              {processedStats.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <ScatterChart margin={{ top: 20, right: 30, bottom: 20, left: 10 }}>
                    <CartesianGrid stroke="#334155" strokeDasharray="3 3" opacity={0.3} />
                    <XAxis 
                      type="number" 
                      dataKey="x" 
                      name="Unique Claim+Policy" 
                      stroke="#475569" 
                      tick={{ fill: '#94a3b8', fontSize: 12 }}
                      label={{ value: 'Unique Claim+Policy Count', position: 'insideBottom', offset: -5, fill: '#94a3b8', fontSize: 13 }}
                    />
                    <YAxis 
                      type="number" 
                      dataKey="yMedian" 
                      name="median repeats/p+c" 
                      stroke="#475569" 
                      tick={{ fill: '#94a3b8', fontSize: 12 }}
                      domain={[1, 'auto']}
                      label={{ value: 'Median complaints per Claim+Policy', angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 13 }}
                    />
                    <ZAxis 
                      type="number" 
                      dataKey="z" 
                      range={[150, 1200]} 
                      name="Total Volume" 
                    />
                    <Tooltip content={<ScatterTooltip />} cursor={{ strokeDasharray: '3 3' }} />
                    <Scatter name="DataPoints" data={processedStats} dataKey="yMedian">
                      {processedStats.map((entry, index) => (
                        <Cell 
                          key={`cell-med-${index}`} 
                          fill="transparent" 
                          stroke={entry.color} 
                          strokeWidth={entry.isConcentrated ? 3.5 : 2}
                          style={{ 
                            filter: entry.isConcentrated 
                              ? 'drop-shadow(0 0 12px rgba(244, 63, 94, 0.7))' 
                              : 'drop-shadow(0 0 8px rgba(99, 102, 241, 0.3))',
                            cursor: 'pointer'
                          }} 
                        />
                      ))}
                    </Scatter>
                  </ScatterChart>
                </ResponsiveContainer>
              ) : (
                <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#64748b' }}>
                  No data available to plot.
                </div>
              )}
            </div>
          </div>

          {/* Block 3: 12-Month Performance Trend Chart (Jan, Feb, Mar) */}
          <div className="card grid-full-width">
            <div className="card-title" style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', borderBottom: '1px solid rgba(51, 65, 85, 0.2)', paddingBottom: '0.75rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                  <Calendar size={18} />
                  Performance & Trend Analysis (Jan, Feb, Mar)
                </div>
                
                <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
                  {/* Collapsible Dropdown Toggle Button */}
                  <button
                    onClick={() => setIsSelectorExpanded(!isSelectorExpanded)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.4rem',
                      background: 'rgba(30, 41, 59, 0.6)',
                      color: '#f8fafc',
                      border: '1px solid rgba(51, 65, 85, 0.4)',
                      borderRadius: '8px',
                      padding: '0.4rem 1rem',
                      fontSize: '0.8rem',
                      fontWeight: '600',
                      cursor: 'pointer',
                      fontFamily: 'Outfit',
                      transition: 'all 0.2s'
                    }}
                    className="insight-card-hover"
                  >
                    <Layers size={12} />
                    {isSelectorExpanded ? 'Close Selector' : `Select Categories (${selectedItems.length} active)`}
                  </button>

                  <span style={{ color: 'rgba(51, 65, 85, 0.3)' }}>|</span>

                  <button
                    onClick={() => {
                      const top5 = [...processedStats].sort((a,b) => b.z - a.z).slice(0, 5).map(s => s.name);
                      setSelectedItems(top5);
                    }}
                    style={{ fontSize: '0.75rem', fontWeight: '700', color: '#818cf8', background: 'transparent', border: 'none', cursor: 'pointer', fontFamily: 'Outfit' }}
                  >
                    Reset to Top 5
                  </button>
                  <span style={{ color: 'rgba(51, 65, 85, 0.4)' }}>|</span>
                  <button
                    onClick={() => setSelectedItems([])}
                    style={{ fontSize: '0.75rem', fontWeight: '700', color: '#94a3b8', background: 'transparent', border: 'none', cursor: 'pointer', fontFamily: 'Outfit' }}
                  >
                    Clear All
                  </button>
                </div>
              </div>

              {/* Tag-based Multi-select checklist (Collapsible) */}
              {isSelectorExpanded && (
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', maxHeight: '110px', overflowY: 'auto', padding: '0.5rem', background: 'rgba(15, 23, 42, 0.3)', borderRadius: '8px', border: '1px solid rgba(51, 65, 85, 0.2)', marginTop: '0.25rem' }}>
                  {dropdownList.map((item, idx) => {
                    const isSelected = selectedItems.includes(item);
                    return (
                      <button
                        key={idx}
                        onClick={() => {
                          if (isSelected) {
                            setSelectedItems(selectedItems.filter(x => x !== item));
                          } else {
                            setSelectedItems([...selectedItems, item]);
                          }
                        }}
                        style={{
                          padding: '0.25rem 0.75rem',
                          borderRadius: '20px',
                          fontSize: '0.72rem',
                          fontWeight: '600',
                          border: '1px solid',
                          borderColor: isSelected ? '#6366f1' : 'rgba(51, 65, 85, 0.3)',
                          background: isSelected ? 'rgba(99, 102, 241, 0.15)' : 'transparent',
                          color: isSelected ? '#818cf8' : '#94a3b8',
                          cursor: 'pointer',
                          transition: 'all 0.15s',
                          fontFamily: 'Outfit'
                        }}
                      >
                        {item}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem', marginTop: '1rem' }}>
              <div className="trend-layout-grid">
                
                {/* Left Side: Chart */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                  {trendSummary.text && (
                    <div 
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '1rem',
                        padding: '0.75rem 1.25rem',
                        borderRadius: '10px',
                        background: trendSummary.status === "IMPROVED" 
                          ? 'rgba(16, 185, 129, 0.08)' 
                          : trendSummary.status === "WORSENED"
                          ? 'rgba(244, 63, 94, 0.08)' 
                          : 'rgba(71, 85, 105, 0.1)',
                        border: `1px solid ${
                          trendSummary.status === "IMPROVED" 
                            ? 'rgba(16, 185, 129, 0.25)' 
                            : trendSummary.status === "WORSENED"
                            ? 'rgba(244, 63, 94, 0.25)' 
                            : 'rgba(71, 85, 105, 0.2)'
                        }`
                      }}
                    >
                      {trendSummary.status === "IMPROVED" ? (
                        <div style={{ background: '#10b981', color: '#0b0f19', padding: '6px', borderRadius: '50%', display: 'flex' }}>
                          <ArrowDownRight size={16} />
                        </div>
                      ) : trendSummary.status === "WORSENED" ? (
                        <div style={{ background: '#f43f5e', color: '#0b0f19', padding: '6px', borderRadius: '50%', display: 'flex' }}>
                          <ArrowUpRight size={16} />
                        </div>
                      ) : null}
                      <div>
                        <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                          <span 
                            style={{ 
                              fontWeight: '700', 
                              fontSize: '0.85rem',
                              color: trendSummary.status === "IMPROVED" ? '#34d399' : trendSummary.status === "WORSENED" ? '#fb7185' : '#94a3b8'
                            }}
                          >
                            Aggregated Selected {analysisMode === 'theme' ? 'Themes' : analysisMode === 'object' ? 'Complaint Objects' : 'Product & Brands'} ({trendSummary.status})
                          </span>
                        </div>
                        <p style={{ fontSize: '0.85rem', color: '#cbd5e1', marginTop: '0.1rem', lineHeight: '1.4' }}>
                          {trendSummary.text}
                        </p>
                      </div>
                    </div>
                  )}

                  <div className="chart-container-inner" style={{ height: '330px' }}>
                    {trendData.length > 0 ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <ComposedChart data={trendData} margin={{ top: 20, right: 10, bottom: 20, left: 10 }}>
                          <CartesianGrid stroke="#334155" strokeDasharray="3 3" opacity={0.3} />
                          <XAxis 
                            dataKey="month" 
                            stroke="#475569" 
                            tick={{ fill: '#94a3b8', fontSize: 12 }} 
                          />
                          <YAxis 
                            stroke="#818cf8"
                            tick={{ fill: '#94a3b8', fontSize: 12 }}
                            label={{ value: 'Unique Claim+Policy Count', angle: -90, position: 'insideLeft', fill: '#818cf8', fontSize: 13 }}
                          />
                          <Tooltip content={<ComposedTooltip />} />
                          <Bar 
                            dataKey="count" 
                            barSize={55} 
                            fill="url(#colorBar)" 
                            radius={[4, 4, 0, 0]}
                          />
                          <defs>
                            <linearGradient id="colorBar" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#818cf8" stopOpacity={0.6}/>
                              <stop offset="95%" stopColor="#6366f1" stopOpacity={0.05}/>
                            </linearGradient>
                          </defs>
                        </ComposedChart>
                      </ResponsiveContainer>
                    ) : (
                      <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#64748b' }}>
                        No data selected. Please select one or more categories above.
                      </div>
                    )}
                  </div>
                </div>

                {/* Right Side: Global Trend Insights */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem', borderLeft: '1px solid rgba(51, 65, 85, 0.4)', paddingLeft: '1.5rem' }} className="insights-panel-inner">
                  <div style={{ fontSize: '1rem', fontWeight: '600', color: '#f8fafc', display: 'flex', alignItems: 'center', gap: '0.5rem', paddingBottom: '0.5rem', borderBottom: '1px solid rgba(51, 65, 85, 0.2)' }}>
                    <Sparkles size={16} className="upload-icon" style={{ width: '28px', height: '28px', padding: '5px' }} />
                    Historical Insights (Jan vs. Mar)
                  </div>

                  {/* Top Escalation */}
                  {extremeTrends.mostWorsened ? (
                    <div 
                      onClick={() => setSelectedItems([extremeTrends.mostWorsened.item])}
                      style={{
                        background: 'rgba(244, 63, 94, 0.04)',
                        border: '1px solid rgba(244, 63, 94, 0.2)',
                        borderRadius: '10px',
                        padding: '1rem',
                        cursor: 'pointer',
                        transition: 'all 0.2s ease'
                      }}
                      className="insight-card-hover"
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.5rem' }}>
                        <span style={{ fontSize: '0.75rem', fontWeight: '700', color: '#fb7185', background: 'rgba(244, 63, 94, 0.15)', padding: '0.2rem 0.5rem', borderRadius: '4px' }}>
                          TOP ESCALATION
                        </span>
                        <span style={{ fontSize: '0.9rem', fontWeight: '700', color: '#fb7185', display: 'flex', alignItems: 'center' }}>
                          +{extremeTrends.mostWorsened.pct.toFixed(0)}% <ArrowUpRight size={14} />
                        </span>
                      </div>
                      <h4 style={{ fontSize: '0.85rem', fontWeight: '600', color: '#e2e8f0', marginBottom: '0.25rem' }}>
                        {extremeTrends.mostWorsened.item}
                      </h4>
                      <p style={{ fontSize: '0.8rem', color: '#94a3b8' }}>
                        Claims: {extremeTrends.mostWorsened.q1Total} → {extremeTrends.mostWorsened.q4Total}
                      </p>
                    </div>
                  ) : (
                    <div style={{ fontSize: '0.8rem', color: '#64748b' }}>No escalation trend data.</div>
                  )}

                  {/* Top Improvement */}
                  {extremeTrends.mostImproved ? (
                    <div 
                      onClick={() => setSelectedItems([extremeTrends.mostImproved.item])}
                      style={{
                        background: 'rgba(16, 185, 129, 0.04)',
                        border: '1px solid rgba(16, 185, 129, 0.2)',
                        borderRadius: '10px',
                        padding: '1rem',
                        cursor: 'pointer',
                        transition: 'all 0.2s ease'
                      }}
                      className="insight-card-hover"
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.5rem' }}>
                        <span style={{ fontSize: '0.75rem', fontWeight: '700', color: '#34d399', background: 'rgba(16, 185, 129, 0.15)', padding: '0.2rem 0.5rem', borderRadius: '4px' }}>
                          TOP IMPROVEMENT
                        </span>
                        <span style={{ fontSize: '0.9rem', fontWeight: '700', color: '#34d399', display: 'flex', alignItems: 'center' }}>
                          -{Math.abs(extremeTrends.mostImproved.pct).toFixed(0)}% <ArrowDownRight size={14} />
                        </span>
                      </div>
                      <h4 style={{ fontSize: '0.85rem', fontWeight: '600', color: '#e2e8f0', marginBottom: '0.25rem' }}>
                        {extremeTrends.mostImproved.item}
                      </h4>
                      <p style={{ fontSize: '0.8rem', color: '#94a3b8' }}>
                        Claims: {extremeTrends.mostImproved.q1Total} → {extremeTrends.mostImproved.q4Total}
                      </p>
                    </div>
                  ) : (
                    <div style={{ fontSize: '0.8rem', color: '#64748b' }}>No improvement trend data.</div>
                  )}
                  
                  <div style={{ fontSize: '0.75rem', color: '#64748b', lineHeight: '1.4', marginTop: 'auto' }}>
                    <Zap size={12} style={{ display: 'inline', marginRight: '4px', verticalAlign: 'middle', color: '#fbbf24' }} />
                    Click an insight card to isolate its specific history on the chart.
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Block 4 (Theme Mode): Concentric Sunburst Chart */}
          {analysisMode === 'theme' && sunburstData && (
            <div className="card grid-full-width animate-fade-in" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              <div className="card-title">
                <PieIcon size={18} />
                Themes Hierarchy Sunburst Analysis
              </div>
              <p style={{ fontSize: '0.9rem', color: '#94a3b8', marginTop: '-0.75rem' }}>
                Visualizing hierarchical relationships: <strong>Themes</strong> (inner ring) &rarr; <strong>Product & Brand</strong> (middle ring) &rarr; <strong>Complaint Objects</strong> (outer ring). Slices represent proportional volumes; hover over any slice to see details.
              </p>
              
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: '2rem', alignItems: 'center' }}>
                {/* Sunburst concentric donut plot */}
                <div style={{ position: 'relative', width: '100%', height: '420px', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Tooltip content={<SunburstTooltip />} />
                      
                      {/* Level 1: Themes */}
                      <Pie
                        data={sunburstData.inner}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        innerRadius="0%"
                        outerRadius="38%"
                        stroke="#0f172a"
                        strokeWidth={1}
                      >
                        {sunburstData.inner.map((entry, index) => (
                          <Cell 
                            key={`cell-inner-${index}`} 
                            fill={entry.color} 
                            style={{ fillOpacity: entry.opacity, cursor: 'pointer' }} 
                          />
                        ))}
                      </Pie>

                      {/* Level 2: Product & Brand */}
                      <Pie
                        data={sunburstData.middle}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        innerRadius="41%"
                        outerRadius="68%"
                        stroke="#0f172a"
                        strokeWidth={1}
                      >
                        {sunburstData.middle.map((entry, index) => (
                          <Cell 
                            key={`cell-middle-${index}`} 
                            fill={entry.color} 
                            style={{ fillOpacity: entry.opacity, cursor: 'pointer' }} 
                          />
                        ))}
                      </Pie>

                      {/* Level 3: Normalized Objects */}
                      <Pie
                        data={sunburstData.outer}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        innerRadius="71%"
                        outerRadius="95%"
                        stroke="#0f172a"
                        strokeWidth={1}
                      >
                        {sunburstData.outer.map((entry, index) => (
                          <Cell 
                            key={`cell-outer-${index}`} 
                            fill={entry.color} 
                            style={{ fillOpacity: entry.opacity, cursor: 'pointer' }} 
                          />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>

                  {/* Visual Center Indicator */}
                  <div style={{
                    position: 'absolute',
                    top: '50%',
                    left: '50%',
                    transform: 'translate(-50%, -50%)',
                    width: '30px',
                    height: '30px',
                    borderRadius: '50%',
                    background: '#0b0f19',
                    boxShadow: '0 0 10px rgba(0, 0, 0, 0.5)',
                    pointerEvents: 'none'
                  }} />
                </div>

                {/* Legend / Key info */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', background: 'rgba(15, 23, 42, 0.3)', padding: '1.25rem', borderRadius: '10px', border: '1px solid rgba(51, 65, 85, 0.2)' }}>
                  <div style={{ fontSize: '0.82rem', fontWeight: '700', color: '#f8fafc', textTransform: 'uppercase', tracking: '0.05em', borderBottom: '1px solid rgba(51, 65, 85, 0.4)', paddingBottom: '0.4rem' }}>
                    Ring Hierarchy
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                      <span style={{ width: '12px', height: '12px', borderRadius: '2px', background: '#6366f1' }} />
                      <div style={{ display: 'flex', flexDirection: 'column' }}>
                        <span style={{ fontSize: '0.8rem', fontWeight: '600', color: '#cbd5e1' }}>Inner Ring</span>
                        <span style={{ fontSize: '0.7rem', color: '#64748b' }}>Top 10 Themes</span>
                      </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                      <span style={{ width: '12px', height: '12px', borderRadius: '2px', background: '#6366f1', opacity: 0.75 }} />
                      <div style={{ display: 'flex', flexDirection: 'column' }}>
                        <span style={{ fontSize: '0.8rem', fontWeight: '600', color: '#cbd5e1' }}>Middle Ring</span>
                        <span style={{ fontSize: '0.7rem', color: '#64748b' }}>Top 10 Product-Brands</span>
                      </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                      <span style={{ width: '12px', height: '12px', borderRadius: '2px', background: '#6366f1', opacity: 0.5 }} />
                      <div style={{ display: 'flex', flexDirection: 'column' }}>
                        <span style={{ fontSize: '0.8rem', fontWeight: '600', color: '#cbd5e1' }}>Outer Ring</span>
                        <span style={{ fontSize: '0.7rem', color: '#64748b' }}>Top 10 Objects</span>
                      </div>
                    </div>
                  </div>
                  <div style={{ fontSize: '0.72rem', color: '#94a3b8', lineHeight: '1.4', borderTop: '1px solid rgba(51, 65, 85, 0.2)', paddingTop: '0.75rem', marginTop: '0.5rem' }}>
                    💡 Colors match by theme. Outer segments represent objects normalized in-browser.
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Block 4: Intersectional Heatmap */}
          {analysisMode !== 'theme' && heatmapData && (
            <div className="card grid-full-width animate-fade-in">
              <div className="card-title">
                <Layers size={18} />
                {analysisMode === 'dimension' ? 'Product & Brand vs. Themes Heatmap' : 'Complaint Object vs. Themes Heatmap'}
              </div>
              <p style={{ fontSize: '0.9rem', color: '#94a3b8', marginTop: '-0.75rem', marginBottom: '1.5rem' }}>
                Visualizing complaint volume distribution intersections. The labels are ordered by total volume descending, showing the top 10 axes. Colors scale by volume intensity.
              </p>
              
              <div style={{ overflowX: 'auto', paddingBottom: '1rem' }}>
                <div style={{ minWidth: '800px' }}>
                  {/* Header Row */}
                  <div style={{ display: 'grid', gridTemplateColumns: '200px repeat(10, 1fr)', gap: '4px', marginBottom: '4px' }}>
                    <div style={{ fontSize: '0.78rem', fontWeight: '800', color: '#818cf8', display: 'flex', alignItems: 'center', padding: '0.5rem', background: 'rgba(99, 102, 241, 0.05)', borderRadius: '4px' }}>
                      {analysisMode === 'dimension' ? 'Product & Brand \u2192' : 'Complaint Object \u2192'}
                    </div>
                    {heatmapData.topX.map((xName, idx) => (
                      <div 
                        key={idx} 
                        style={{ 
                          fontSize: '0.72rem', 
                          fontWeight: '700', 
                          color: '#94a3b8', 
                          textAlign: 'center', 
                          padding: '0.5rem 0.25rem',
                          background: 'rgba(30, 41, 59, 0.4)',
                          borderRadius: '4px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          wordBreak: 'break-word',
                          lineHeight: '1.2'
                        }}
                        title={xName}
                      >
                        {xName}
                      </div>
                    ))}
                  </div>
                  
                  {/* Grid Rows */}
                  {heatmapData.grid.map((rowObj, rIdx) => (
                    <div key={rIdx} style={{ display: 'grid', gridTemplateColumns: '200px repeat(10, 1fr)', gap: '4px', marginBottom: '4px' }}>
                      {/* Y label */}
                      <div 
                        style={{ 
                          fontSize: '0.75rem', 
                          fontWeight: '600', 
                          color: '#cbd5e1', 
                          display: 'flex', 
                          alignItems: 'center', 
                          padding: '0.5rem 0.75rem', 
                          background: 'rgba(30, 41, 59, 0.4)', 
                          borderRadius: '4px',
                          wordBreak: 'break-word',
                          lineHeight: '1.3'
                        }}
                      >
                        {rowObj.yVal}
                      </div>
                      
                      {/* Cells */}
                      {rowObj.xVals.map((cell, cIdx) => {
                        const hasVal = cell.count > 0;
                        const opacity = heatmapData.maxVal > 0 ? (cell.count / heatmapData.maxVal) : 0;
                        const bg = hasVal 
                          ? `rgba(99, 102, 241, ${0.12 + opacity * 0.88})` 
                          : 'rgba(30, 41, 59, 0.15)';
                        const fg = hasVal ? '#ffffff' : 'rgba(148, 163, 184, 0.15)';
                        
                        return (
                          <div 
                            key={cIdx} 
                            style={{
                              background: bg,
                              color: fg,
                              fontSize: '0.8rem',
                              fontWeight: '700',
                              height: '50px',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              borderRadius: '4px',
                              boxShadow: hasVal ? 'inset 0 0 4px rgba(255, 255, 255, 0.08)' : 'none',
                              transition: 'all 0.15s'
                            }}
                            title={`${rowObj.yVal} x ${cell.xVal}: ${cell.count} complaints`}
                          >
                            {hasVal ? cell.count : '-'}
                          </div>
                        );
                      })}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </>
      ) : (
            /* Outlier Analysis View */
            <div style={{ display: 'flex', flexDirection: 'column', gap: '2.5rem' }} className="animate-fade-in">
              
              {/* SECTION 1: CUSTOMER (P+C) LEVEL OUTLIERS */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                <div style={{ fontSize: '1.25rem', fontWeight: '700', color: '#f8fafc', borderBottom: '2px solid rgba(99, 102, 241, 0.4)', paddingBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <Users size={22} style={{ color: '#818cf8' }} />
                  1. Outlier Analysis at Customer Account (P+C) Level
                </div>

                {/* Educational banner explaining what Customer Level Outlier is */}
                <div className="card" style={{ borderLeft: '4px solid #f59e0b', background: 'rgba(245, 158, 11, 0.02)', padding: '1.25rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', fontSize: '1.05rem', fontWeight: '700', color: '#fbbf24', marginBottom: '0.5rem' }}>
                    <AlertTriangle size={18} />
                    What does Customer Level mean?
                  </div>
                  <div style={{ fontSize: '0.88rem', color: '#cbd5e1', lineHeight: '1.5' }}>
                    <p style={{ margin: '0 0 0.5rem 0' }}>
                      This analyzes the total complaints filed by unique policyholders (Claims/Policies) across all themes combined. It pinpoints customers with the highest overall friction.
                    </p>
                    <p style={{ margin: 0 }}>
                      💡 <strong>95th Percentile Baseline:</strong> 95% of policyholders file at most <strong>{outliersData?.pcLevel?.p95Threshold.toFixed(0)} complaint(s)</strong> globally. Customers with <strong>more than {outliersData?.pcLevel?.p95Threshold.toFixed(0)} complaints</strong> total are flagged as outlier accounts.
                    </p>
                  </div>
                </div>

                {/* KPI Grid */}
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1.25rem' }}>
                  <div className="card" style={{ padding: '1.25rem', background: 'rgba(30, 41, 59, 0.4)' }}>
                    <span style={{ fontSize: '0.8rem', fontWeight: '700', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                      Total Customers (Claims/Policies)
                    </span>
                    <span style={{ fontSize: '1.75rem', fontWeight: '800', color: '#818cf8', marginTop: '0.5rem', display: 'block' }}>
                      {outliersData?.pcLevel?.totalUniquePCs} accounts
                    </span>
                    <span style={{ fontSize: '0.72rem', color: '#64748b', marginTop: '0.25rem', display: 'block' }}>
                      Total unique customer accounts in the dataset
                    </span>
                  </div>

                  <div className="card" style={{ padding: '1.25rem', background: 'rgba(30, 41, 59, 0.4)' }}>
                    <span style={{ fontSize: '0.8rem', fontWeight: '700', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                      Normal Limit (95th Percentile)
                    </span>
                    <span style={{ fontSize: '1.75rem', fontWeight: '800', color: '#f59e0b', marginTop: '0.5rem', display: 'block' }}>
                      {outliersData?.pcLevel?.p95Threshold.toFixed(0)} complaint(s)
                    </span>
                    <span style={{ fontSize: '0.72rem', color: '#64748b', marginTop: '0.25rem', display: 'block' }}>
                      Cutoff complaints count per customer account
                    </span>
                  </div>

                  <div className="card" style={{ padding: '1.25rem', background: 'rgba(30, 41, 59, 0.4)' }}>
                    <span style={{ fontSize: '0.8rem', fontWeight: '700', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                      Total Outlier Customers
                    </span>
                    <span style={{ fontSize: '1.75rem', fontWeight: '800', color: '#f43f5e', marginTop: '0.5rem', display: 'block' }}>
                      {outliersData?.pcLevel?.totalOutlierPCs} claims/policies
                    </span>
                    <span style={{ fontSize: '0.72rem', color: '#64748b', marginTop: '0.25rem', display: 'block' }}>
                      Unique accounts exceeding the normal limit
                    </span>
                  </div>

                  <div className="card" style={{ padding: '1.25rem', background: 'rgba(30, 41, 59, 0.4)' }}>
                    <span style={{ fontSize: '0.8rem', fontWeight: '700', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                      Outlier Customer Rate
                    </span>
                    <span style={{ fontSize: '1.75rem', fontWeight: '800', color: '#10b981', marginTop: '0.5rem', display: 'block' }}>
                      {outliersData?.pcLevel?.pctOutlierPCs.toFixed(1)}%
                    </span>
                    <span style={{ fontSize: '0.72rem', color: '#64748b', marginTop: '0.25rem', display: 'block' }}>
                      Outlier customers as a share of all customer accounts
                    </span>
                  </div>
                </div>

                {/* Summary Bulletin */}
                {outliersData && outliersData.pcLevel?.themeOutliers?.length > 0 && (
                  <div className="card" style={{ borderLeft: '4px solid #f43f5e', background: 'rgba(244, 63, 94, 0.02)', padding: '1.25rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', fontSize: '1rem', fontWeight: '700', color: '#fb7185', marginBottom: '0.75rem', borderBottom: '1px solid rgba(244, 63, 94, 0.1)', paddingBottom: '0.4rem' }}>
                      <Lightbulb size={18} />
                      Primary Outlier Customer Drivers
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.25rem' }} className="insights-panel-inner">
                      {outliersData.pcLevel.themeOutliers[0] && (
                        <div style={{ background: 'rgba(15, 23, 42, 0.3)', padding: '0.75rem 1rem', borderRadius: '8px', border: '1px solid rgba(244, 63, 94, 0.15)' }}>
                          <div style={{ color: '#fb7185', fontWeight: '700', fontSize: '0.8rem', textTransform: 'uppercase', marginBottom: '0.25rem' }}>
                            Top Theme Driver
                          </div>
                          <p style={{ fontSize: '0.82rem', color: '#cbd5e1', margin: 0, lineHeight: '1.4' }}>
                            <strong>"{outliersData.pcLevel.themeOutliers[0].theme}"</strong> primarily drives <strong>{outliersData.pcLevel.themeOutliers[0].count}</strong> outlier customers (<strong>{outliersData.pcLevel.themeOutliers[0].pct.toFixed(1)}%</strong>).
                          </p>
                        </div>
                      )}
                      {outliersData.pcLevel.pbOutliers[0] && (
                        <div style={{ background: 'rgba(15, 23, 42, 0.3)', padding: '0.75rem 1rem', borderRadius: '8px', border: '1px solid rgba(244, 63, 94, 0.15)' }}>
                          <div style={{ color: '#fb7185', fontWeight: '700', fontSize: '0.8rem', textTransform: 'uppercase', marginBottom: '0.25rem' }}>
                            Top Product & Brand
                          </div>
                          <p style={{ fontSize: '0.82rem', color: '#cbd5e1', margin: 0, lineHeight: '1.4' }}>
                            Outliers are most concentrated in <strong>"{outliersData.pcLevel.pbOutliers[0].name}"</strong>, representing <strong>{outliersData.pcLevel.pbOutliers[0].count}</strong> outlier accounts (<strong>{outliersData.pcLevel.pbOutliers[0].pct.toFixed(1)}%</strong>).
                          </p>
                        </div>
                      )}
                      {outliersData.pcLevel.objectOutliers[0] && (
                        <div style={{ background: 'rgba(15, 23, 42, 0.3)', padding: '0.75rem 1rem', borderRadius: '8px', border: '1px solid rgba(244, 63, 94, 0.15)' }}>
                          <div style={{ color: '#fb7185', fontWeight: '700', fontSize: '0.8rem', textTransform: 'uppercase', marginBottom: '0.25rem' }}>
                            Top Complaint Object
                          </div>
                          <p style={{ fontSize: '0.82rem', color: '#cbd5e1', margin: 0, lineHeight: '1.4' }}>
                            The primary object driver is <strong>"{outliersData.pcLevel.objectOutliers[0].name}"</strong>, representing <strong>{outliersData.pcLevel.objectOutliers[0].count}</strong> outlier accounts (<strong>{outliersData.pcLevel.objectOutliers[0].pct.toFixed(1)}%</strong>).
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Themes Table (PC Level) */}
                <div className="card grid-full-width">
                  <div className="card-title">
                    <Users size={16} />
                    Themes Driven by Outlier Customers
                  </div>
                  <div className="table-container" style={{ maxHeight: '250px', overflowY: 'auto' }}>
                    <table>
                      <thead>
                        <tr>
                          <th>Theme Name</th>
                          <th style={{ textAlign: 'center' }}>Primary Driver for (Outlier P+Cs)</th>
                          <th style={{ textAlign: 'center' }}>Share of Outlier Customers (%)</th>
                        </tr>
                      </thead>
                      <tbody>
                        {outliersData?.pcLevel?.themeOutliers.map((row, idx) => (
                          <tr key={idx}>
                            <td style={{ fontWeight: '600', color: '#cbd5e1' }}>{row.theme}</td>
                            <td style={{ textAlign: 'center', color: '#f8fafc', fontWeight: '700' }}>{row.count}</td>
                            <td style={{ width: '220px' }}>
                              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', justifyContent: 'center' }}>
                                <span style={{ color: '#10b981', fontWeight: '700', width: '45px', textAlign: 'right' }}>{row.pct.toFixed(1)}%</span>
                                <div style={{ flexGrow: 1, height: '6px', background: 'rgba(16, 185, 129, 0.1)', borderRadius: '3px', position: 'relative', width: '100px' }}>
                                  <div style={{ position: 'absolute', left: 0, top: 0, height: '100%', background: '#10b981', borderRadius: '3px', width: `${Math.min(100, row.pct)}%` }} />
                                </div>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Split Products & Objects (PC Level) */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }} className="insights-panel-inner">
                  <div className="card" style={{ display: 'flex', flexDirection: 'column' }}>
                    <div className="card-title"><Layers size={16} />Top Outliers by Product & Brand</div>
                    <div className="table-container" style={{ maxHeight: '250px', overflowY: 'auto' }}>
                      <table>
                        <thead>
                          <tr>
                            <th>Product & Brand</th>
                            <th style={{ textAlign: 'center' }}>Outlier P+C Count</th>
                            <th style={{ textAlign: 'center' }}>Share (%)</th>
                          </tr>
                        </thead>
                        <tbody>
                          {outliersData?.pcLevel?.pbOutliers.map((row, idx) => (
                            <tr key={idx}>
                              <td style={{ fontSize: '0.8rem', fontWeight: '600', color: '#cbd5e1' }}>{row.name}</td>
                              <td style={{ textAlign: 'center', fontWeight: '700', color: '#f8fafc' }}>{row.count}</td>
                              <td style={{ width: '120px' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', justifyContent: 'center' }}>
                                  <span style={{ color: '#f59e0b', fontWeight: '700', width: '40px', textAlign: 'right' }}>{row.pct.toFixed(1)}%</span>
                                  <div style={{ width: '50px', height: '6px', background: 'rgba(245, 158, 11, 0.1)', borderRadius: '3px', position: 'relative' }}>
                                    <div style={{ position: 'absolute', left: 0, top: 0, height: '100%', background: '#f59e0b', borderRadius: '3px', width: `${Math.min(100, row.pct)}%` }} />
                                  </div>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <div className="card" style={{ display: 'flex', flexDirection: 'column' }}>
                    <div className="card-title"><Box size={16} />Top Outliers by Complaint Object</div>
                    <div className="table-container" style={{ maxHeight: '250px', overflowY: 'auto' }}>
                      <table>
                        <thead>
                          <tr>
                            <th>Complaint Object</th>
                            <th style={{ textAlign: 'center' }}>Outlier P+C Count</th>
                            <th style={{ textAlign: 'center' }}>Share (%)</th>
                          </tr>
                        </thead>
                        <tbody>
                          {outliersData?.pcLevel?.objectOutliers.map((row, idx) => (
                            <tr key={idx}>
                              <td style={{ fontSize: '0.8rem', fontWeight: '600', color: '#cbd5e1', textTransform: 'capitalize' }}>{row.name}</td>
                              <td style={{ textAlign: 'center', fontWeight: '700', color: '#f8fafc' }}>{row.count}</td>
                              <td style={{ width: '120px' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', justifyContent: 'center' }}>
                                  <span style={{ color: '#10b981', fontWeight: '700', width: '40px', textAlign: 'right' }}>{row.pct.toFixed(1)}%</span>
                                  <div style={{ width: '50px', height: '6px', background: 'rgba(16, 185, 129, 0.1)', borderRadius: '3px', position: 'relative' }}>
                                    <div style={{ position: 'absolute', left: 0, top: 0, height: '100%', background: '#10b981', borderRadius: '3px', width: `${Math.min(100, row.pct)}%` }} />
                                  </div>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>

              <div style={{ height: '1px', background: 'rgba(51, 65, 85, 0.4)', margin: '1rem 0' }} />

              {/* SECTION 2: CUSTOMER-THEME (P+C + THEME) LEVEL OUTLIERS */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                <div style={{ fontSize: '1.25rem', fontWeight: '700', color: '#f8fafc', borderBottom: '2px solid rgba(99, 102, 241, 0.4)', paddingBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <AlertTriangle size={22} style={{ color: '#fb7185' }} />
                  2. Outlier Analysis at Customer-Theme (P+C + Theme) Joint Level
                </div>

                {/* Educational banner explaining what Customer-Theme Level Outlier is */}
                <div className="card" style={{ borderLeft: '4px solid #f43f5e', background: 'rgba(244, 63, 94, 0.02)', padding: '1.25rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', fontSize: '1.05rem', fontWeight: '700', color: '#fb7185', marginBottom: '0.5rem' }}>
                    <AlertTriangle size={18} />
                    What does Customer-Theme Level mean?
                  </div>
                  <div style={{ fontSize: '0.88rem', color: '#cbd5e1', lineHeight: '1.5' }}>
                    <p style={{ margin: '0 0 0.5rem 0' }}>
                      This analyzes complaint repetition at a <strong>topic-specific level</strong>. It maps out customer-theme pairs, focusing on policyholders who filed repeat complaints about a <strong>single specific issue</strong>.
                    </p>
                    <p style={{ margin: 0 }}>
                      💡 <strong>95th Percentile Baseline:</strong> 95% of customer-theme combinations have at most <strong>{outliersData?.pcthemeLevel?.p95Threshold.toFixed(0)} complaint(s)</strong>. Pairs with <strong>more than {outliersData?.pcthemeLevel?.p95Threshold.toFixed(0)} complaint(s)</strong> are flagged as outlier hotspots.
                    </p>
                  </div>
                </div>

                {/* KPI Grid */}
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1.25rem' }}>
                  <div className="card" style={{ padding: '1.25rem', background: 'rgba(30, 41, 59, 0.4)' }}>
                    <span style={{ fontSize: '0.8rem', fontWeight: '700', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                      Total Combinations (P+C + Theme)
                    </span>
                    <span style={{ fontSize: '1.75rem', fontWeight: '800', color: '#818cf8', marginTop: '0.5rem', display: 'block' }}>
                      {outliersData?.pcthemeLevel?.totalUniqueCombinations} combinations
                    </span>
                    <span style={{ fontSize: '0.72rem', color: '#64748b', marginTop: '0.25rem', display: 'block' }}>
                      Total unique customer+theme pairs detected
                    </span>
                  </div>

                  <div className="card" style={{ padding: '1.25rem', background: 'rgba(30, 41, 59, 0.4)' }}>
                    <span style={{ fontSize: '0.8rem', fontWeight: '700', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                      Normal Limit (95th Percentile)
                    </span>
                    <span style={{ fontSize: '1.75rem', fontWeight: '800', color: '#f59e0b', marginTop: '0.5rem', display: 'block' }}>
                      {outliersData?.pcthemeLevel?.p95Threshold.toFixed(0)} complaint(s)
                    </span>
                    <span style={{ fontSize: '0.72rem', color: '#64748b', marginTop: '0.25rem', display: 'block' }}>
                      Cutoff complaints count per customer-theme combination
                    </span>
                  </div>

                  <div className="card" style={{ padding: '1.25rem', background: 'rgba(30, 41, 59, 0.4)' }}>
                    <span style={{ fontSize: '0.8rem', fontWeight: '700', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                      Total Outlier Hotspots
                    </span>
                    <span style={{ fontSize: '1.75rem', fontWeight: '800', color: '#f43f5e', marginTop: '0.5rem', display: 'block' }}>
                      {outliersData?.pcthemeLevel?.totalOutlierCombinations} combinations
                    </span>
                    <span style={{ fontSize: '0.72rem', color: '#64748b', marginTop: '0.25rem', display: 'block' }}>
                      Customer-theme groups exceeding the normal limit
                    </span>
                  </div>

                  <div className="card" style={{ padding: '1.25rem', background: 'rgba(30, 41, 59, 0.4)' }}>
                    <span style={{ fontSize: '0.8rem', fontWeight: '700', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                      Outlier Hotspot Rate
                    </span>
                    <span style={{ fontSize: '1.75rem', fontWeight: '800', color: '#10b981', marginTop: '0.5rem', display: 'block' }}>
                      {outliersData?.pcthemeLevel?.pctOutlierCombinations.toFixed(1)}%
                    </span>
                    <span style={{ fontSize: '0.72rem', color: '#64748b', marginTop: '0.25rem', display: 'block' }}>
                      Friction hotspots as a share of all customer-theme combinations
                    </span>
                  </div>
                </div>

                {/* Summary Bulletin */}
                {outliersData && outliersData.pcthemeLevel?.themeOutliers?.length > 0 && (
                  <div className="card" style={{ borderLeft: '4px solid #fb7185', background: 'rgba(244, 63, 94, 0.02)', padding: '1.25rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', fontSize: '1rem', fontWeight: '700', color: '#fb7185', marginBottom: '0.75rem', borderBottom: '1px solid rgba(244, 63, 94, 0.1)', paddingBottom: '0.4rem' }}>
                      <Lightbulb size={18} />
                      Primary Outlier Hotspot Drivers
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.25rem' }} className="insights-panel-inner">
                      {outliersData.pcthemeLevel.themeOutliers[0] && (
                        <div style={{ background: 'rgba(15, 23, 42, 0.3)', padding: '0.75rem 1rem', borderRadius: '8px', border: '1px solid rgba(244, 63, 94, 0.15)' }}>
                          <div style={{ color: '#fb7185', fontWeight: '700', fontSize: '0.8rem', textTransform: 'uppercase', marginBottom: '0.25rem' }}>
                            Top Hotspot Theme
                          </div>
                          <p style={{ fontSize: '0.82rem', color: '#cbd5e1', margin: 0, lineHeight: '1.4' }}>
                            <strong>"{outliersData.pcthemeLevel.themeOutliers[0].theme}"</strong> drives the highest outlier hotspots, affecting <strong>{outliersData.pcthemeLevel.themeOutliers[0].count}</strong> combinations (<strong>{outliersData.pcthemeLevel.themeOutliers[0].pct.toFixed(1)}%</strong>).
                          </p>
                        </div>
                      )}
                      {outliersData.pcthemeLevel.pbOutliers[0] && (
                        <div style={{ background: 'rgba(15, 23, 42, 0.3)', padding: '0.75rem 1rem', borderRadius: '8px', border: '1px solid rgba(244, 63, 94, 0.15)' }}>
                          <div style={{ color: '#fb7185', fontWeight: '700', fontSize: '0.8rem', textTransform: 'uppercase', marginBottom: '0.25rem' }}>
                            Top Hotspot Product & Brand
                          </div>
                          <p style={{ fontSize: '0.82rem', color: '#cbd5e1', margin: 0, lineHeight: '1.4' }}>
                            Hotspots are most concentrated in <strong>"{outliersData.pcthemeLevel.pbOutliers[0].name}"</strong>, representing <strong>{outliersData.pcthemeLevel.pbOutliers[0].count}</strong> combinations (<strong>{outliersData.pcthemeLevel.pbOutliers[0].pct.toFixed(1)}%</strong>).
                          </p>
                        </div>
                      )}
                      {outliersData.pcthemeLevel.objectOutliers[0] && (
                        <div style={{ background: 'rgba(15, 23, 42, 0.3)', padding: '0.75rem 1rem', borderRadius: '8px', border: '1px solid rgba(244, 63, 94, 0.15)' }}>
                          <div style={{ color: '#fb7185', fontWeight: '700', fontSize: '0.8rem', textTransform: 'uppercase', marginBottom: '0.25rem' }}>
                            Top Hotspot Object
                          </div>
                          <p style={{ fontSize: '0.82rem', color: '#cbd5e1', margin: 0, lineHeight: '1.4' }}>
                            The primary object driver is <strong>"{outliersData.pcthemeLevel.objectOutliers[0].name}"</strong>, representing <strong>{outliersData.pcthemeLevel.objectOutliers[0].count}</strong> combinations (<strong>{outliersData.pcthemeLevel.objectOutliers[0].pct.toFixed(1)}%</strong>).
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Themes Table (Customer-Theme Level) */}
                <div className="card grid-full-width">
                  <div className="card-title">
                    <Users size={16} />
                    Themes Driven by Outlier Hotspots
                  </div>
                  <div className="table-container" style={{ maxHeight: '250px', overflowY: 'auto' }}>
                    <table>
                      <thead>
                        <tr>
                          <th>Theme Name</th>
                          <th style={{ textAlign: 'center' }}>Outlier Hotspots Affected</th>
                          <th style={{ textAlign: 'center' }}>Share of Outlier Hotspots (%)</th>
                        </tr>
                      </thead>
                      <tbody>
                        {outliersData?.pcthemeLevel?.themeOutliers.map((row, idx) => (
                          <tr key={idx}>
                            <td style={{ fontWeight: '600', color: '#cbd5e1' }}>{row.theme}</td>
                            <td style={{ textAlign: 'center', color: '#f8fafc', fontWeight: '700' }}>{row.count}</td>
                            <td style={{ width: '220px' }}>
                              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', justifyContent: 'center' }}>
                                <span style={{ color: '#10b981', fontWeight: '700', width: '45px', textAlign: 'right' }}>{row.pct.toFixed(1)}%</span>
                                <div style={{ flexGrow: 1, height: '6px', background: 'rgba(16, 185, 129, 0.1)', borderRadius: '3px', position: 'relative', width: '100px' }}>
                                  <div style={{ position: 'absolute', left: 0, top: 0, height: '100%', background: '#10b981', borderRadius: '3px', width: `${Math.min(100, row.pct)}%` }} />
                                </div>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Split Products & Objects (Customer-Theme Level) */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }} className="insights-panel-inner">
                  <div className="card" style={{ display: 'flex', flexDirection: 'column' }}>
                    <div className="card-title"><Layers size={16} />Top Hotspots by Product & Brand</div>
                    <div className="table-container" style={{ maxHeight: '250px', overflowY: 'auto' }}>
                      <table>
                        <thead>
                          <tr>
                            <th>Product & Brand</th>
                            <th style={{ textAlign: 'center' }}>Outlier Hotspots Count</th>
                            <th style={{ textAlign: 'center' }}>Share (%)</th>
                          </tr>
                        </thead>
                        <tbody>
                          {outliersData?.pcthemeLevel?.pbOutliers.map((row, idx) => (
                            <tr key={idx}>
                              <td style={{ fontSize: '0.8rem', fontWeight: '600', color: '#cbd5e1' }}>{row.name}</td>
                              <td style={{ textAlign: 'center', fontWeight: '700', color: '#f8fafc' }}>{row.count}</td>
                              <td style={{ width: '120px' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', justifyContent: 'center' }}>
                                  <span style={{ color: '#f59e0b', fontWeight: '700', width: '40px', textAlign: 'right' }}>{row.pct.toFixed(1)}%</span>
                                  <div style={{ width: '50px', height: '6px', background: 'rgba(245, 158, 11, 0.1)', borderRadius: '3px', position: 'relative' }}>
                                    <div style={{ position: 'absolute', left: 0, top: 0, height: '100%', background: '#f59e0b', borderRadius: '3px', width: `${Math.min(100, row.pct)}%` }} />
                                  </div>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <div className="card" style={{ display: 'flex', flexDirection: 'column' }}>
                    <div className="card-title"><Box size={16} />Top Hotspots by Complaint Object</div>
                    <div className="table-container" style={{ maxHeight: '250px', overflowY: 'auto' }}>
                      <table>
                        <thead>
                          <tr>
                            <th>Complaint Object</th>
                            <th style={{ textAlign: 'center' }}>Outlier Hotspots Count</th>
                            <th style={{ textAlign: 'center' }}>Share (%)</th>
                          </tr>
                        </thead>
                        <tbody>
                          {outliersData?.pcthemeLevel?.objectOutliers.map((row, idx) => (
                            <tr key={idx}>
                              <td style={{ fontSize: '0.8rem', fontWeight: '600', color: '#cbd5e1', textTransform: 'capitalize' }}>{row.name}</td>
                              <td style={{ textAlign: 'center', fontWeight: '700', color: '#f8fafc' }}>{row.count}</td>
                              <td style={{ width: '120px' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', justifyContent: 'center' }}>
                                  <span style={{ color: '#10b981', fontWeight: '700', width: '40px', textAlign: 'right' }}>{row.pct.toFixed(1)}%</span>
                                  <div style={{ width: '50px', height: '6px', background: 'rgba(16, 185, 129, 0.1)', borderRadius: '3px', position: 'relative' }}>
                                    <div style={{ position: 'absolute', left: 0, top: 0, height: '100%', background: '#10b981', borderRadius: '3px', width: `${Math.min(100, row.pct)}%` }} />
                                  </div>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          )}
        </main>
      </div>
    </div>
  );
}
