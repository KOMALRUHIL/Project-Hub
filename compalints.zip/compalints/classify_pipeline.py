import os
import json
import time
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm
from openai import OpenAI, AzureOpenAI

# =====================================================================
# 1. USER CONFIGURATION: ENTER YOUR COMPLAINT THEMES HERE
# =====================================================================
THEME_LIST = [
    "Repair didn't happen / delayed repairs",
    "Rude staff or poor customer service",
    "Claim decline dispute / decision review",
    "Communication breakdown / unreturned calls",
    "Plumbing / leak assessment dispute",
    "Storm / weather damage dispute",
    # ---> ADD YOUR OWN CUSTOM THEMES HERE! <---
]

# =====================================================================
# 2. USER CONFIGURATION: LLM API SETTINGS
# =====================================================================
# Set to True if using Azure OpenAI. Set to False for Standard OpenAI / Ollama.
USE_AZURE_OPENAI = True

# Your API key (Azure API key or standard OpenAI key)
API_KEY = "your-api-key-here"

# In Azure, MODEL_NAME MUST match your "Deployment Name" (e.g. "gpt-4.1-mini")
# In Standard OpenAI, it is the model identifier (e.g. "gpt-4o-mini")
MODEL_NAME = "gpt-4.1-mini"  

# --- Standard OpenAI / Local Ollama Settings ---
BASE_URL = "https://api.openai.com/v1"

# --- Azure OpenAI Settings ---
AZURE_ENDPOINT = "https://your-resource-name.openai.azure.com/"  # Your Azure endpoint
AZURE_API_VERSION = "2024-02-15-preview"  # Azure API version (e.g. 2024-02-15-preview or 2024-06-01)

# =====================================================================
# 3. PARALLEL THREADS CONFIGURATION (Adjust based on rate limits)
# =====================================================================
MAX_WORKERS = 20  # Number of concurrent API requests. Reduce if you hit rate limits.

def normalize_object(obj_name):
    if not obj_name:
        return None
    obj_clean = str(obj_name).lower().strip()
    
    # Remove common filler words or punctuation
    obj_clean = obj_clean.replace("the ", "").replace("an ", "").replace("a ", "").strip('.,?!- ')
    
    # Define standard mappings (singular, standardized)
    mapping = {
        # Air conditioning variants
        "ac": "air conditioner",
        "aircon": "air conditioner",
        "air conditioner": "air conditioner",
        "airconditioner": "air conditioner",
        "air conditioning": "air conditioner",
        "air conditioning unit": "air conditioner",
        "split system": "air conditioner",
        "hvac": "air conditioner",
        
        # Hot water system variants
        "hot water system": "hot water system",
        "hot water service": "hot water system",
        "hot water unit": "hot water system",
        "hot water cylinder": "hot water system",
        "water heater": "hot water system",
        "heater": "hot water system",
        "boiler": "hot water system",
        
        # Roof variants
        "roofing": "roof",
        "roof tiles": "roof",
        "roof tile": "roof",
        "roofs": "roof",
        "tile": "roof",
        "shingles": "roof",
        
        # Plumbing/Pipes
        "pipes": "pipes",
        "pipe": "pipes",
        "plumbing": "pipes",
        "leak": "pipes",
        "water pipe": "pipes",
        
        # Ceilings
        "ceilings": "ceiling",
        "plasterboard": "ceiling",
        
        # Fences
        "fences": "fence",
        "fencing": "fence",
        
        # Gutters
        "gutters": "gutters",
        "guttering": "gutters",
        
        # Appliances
        "fridge": "refrigerator",
        "refrigerator": "refrigerator",
        "refrigerators": "refrigerator",
        "tv": "television",
        "televisions": "television",
        "washer": "washing machine",
        "washing machine": "washing machine",
        "dishwasher": "dishwasher",
        "dryer": "dryer",
        "oven": "oven",
        "stove": "stove",
        
        # Vehicles
        "vehicle": "car",
        "motor vehicle": "car",
        "cars": "car",
        
        # Floors/Carpet
        "carpet": "carpet",
        "carpets": "carpet",
        "flooring": "floor",
        "floors": "floor",
        "tiles": "floor"
    }
    
    # Check direct mapping
    if obj_clean in mapping:
        return mapping[obj_clean]
        
    # Check substring matches to catch things like "air conditioning remote" or "hot water service leak"
    for key, value in mapping.items():
        if len(key) > 3 and (key in obj_clean or obj_clean in key):
            return value
            
    # Fallback to singular conversion of simple plurals (e.g. "walls" -> "wall", "doors" -> "door")
    if obj_clean.endswith("s") and not obj_clean.endswith("ss") and len(obj_clean) > 3:
        stripped = obj_clean[:-1]
        if stripped in mapping:
            return mapping[stripped]
        return stripped
        
    return obj_clean


def get_analysis_prompt(complaint_text, themes):
    """Generates the prompt instructing the LLM to return structured JSON classification and rationales."""
    # We number the themes to make matching 100% bulletproof
    themes_str = "\n".join([f"{idx}: {theme}" for idx, theme in enumerate(themes)])
    return f"""You are an expert AI assistant specialized in analyzing insurance customer complaints.
Analyze the customer complaint description provided below and do two things:
1. Assign relevant themes from the Allowed Themes list. You can assign multiple themes if applicable. Identify them by their index number.
2. Identify the specific physical object or property item (e.g., "roof", "backyard", "car", "plumbing", "fence", "kitchen") that the complaint is centered around.

Allowed Themes (Choose by Index Number):
{themes_str}

For each theme you assign, you must provide:
- The "theme_index" (the integer number corresponding to the theme).
- A self-assessed confidence score between 0 and 100.
- A short, one-sentence rationale explaining why this theme applies.

For the object/property item you identify, you must provide:
- The item name. Standardize it to a lowercase, singular noun (e.g., "air conditioner" instead of "AC" or "air conditioners", "pipes" instead of "plumbing" or "pipe", "roof" instead of "roofing").
- A self-assessed confidence score between 0 and 100.
- A short, one-sentence rationale explaining why this object was selected. If no specific object is mentioned, return null for both item and rationale.

You must return your output ONLY as a valid JSON object matching the schema below. Do not include any markdown formatting, backticks, or extra text.

JSON Schema:
{{
  "assigned_themes": [
    {{
      "theme_index": 0, 
      "confidence": 95,
      "rationale": "One sentence explaining why this theme was selected."
    }}
  ],
  "object": {{
    "item": "object_name_or_null", 
    "confidence": 95,
    "rationale": "One sentence explaining why this object was selected."
  }}
}}

Complaint Description:
"{complaint_text}"
"""

def analyze_single_complaint(client, text, themes):
    """Calls the LLM API to analyze a single complaint, with retries and logging."""
    if not isinstance(text, str) or not text.strip() or text == "nan":
        return [], [], None, None
        
    prompt = get_analysis_prompt(text, themes)
    
    max_retries = 3
    for attempt in range(max_retries):
        try:
            response = client.chat.completions.create(
                model=MODEL_NAME,
                messages=[
                    {"role": "system", "content": "You are a helpful assistant that outputs only raw JSON matching the requested schema. No conversation, no markdown."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.0,
                response_format={"type": "json_object"}  # Forces JSON output
            )
            
            raw_content = response.choices[0].message.content.strip()
            data = json.loads(raw_content)
            
            # 1. Process and filter themes where confidence >= 90%
            matched_themes = []
            themes_rationales = []
            all_returned_themes = []
            
            for item in data.get("assigned_themes", []):
                try:
                    theme_idx = int(item.get("theme_index"))
                    confidence = int(item.get("confidence", 0))
                    rationale = item.get("rationale", "")
                    
                    if 0 <= theme_idx < len(themes):
                        theme_name = themes[theme_idx]
                        all_returned_themes.append((theme_name, confidence, rationale))
                        if confidence >= 90:
                            matched_themes.append(theme_name)
                            themes_rationales.append(f"- {theme_name}: {rationale}")
                except (ValueError, TypeError):
                    continue
                        
            # Fallback: If no theme met the >=90% threshold, select the single highest confidence theme
            if not matched_themes and all_returned_themes:
                # Sort by confidence descending
                all_returned_themes.sort(key=lambda x: x[1], reverse=True)
                best_theme, best_conf, best_rat = all_returned_themes[0]
                matched_themes.append(best_theme)
                themes_rationales.append(f"- {best_theme}: {best_rat} (Confidence: {best_conf}%)")
                    
            # 2. Extract object if confidence >= 90%
            obj_data = data.get("object", {})
            obj_item = obj_data.get("item")
            obj_confidence = obj_data.get("confidence", 0)
            obj_rationale = obj_data.get("rationale", "")
            
            final_object = None
            final_obj_rationale = None
            if obj_item and obj_item.lower() != "null" and obj_confidence >= 90:
                final_object = normalize_object(obj_item)
                final_obj_rationale = obj_rationale
                
            return matched_themes, themes_rationales, final_object, final_obj_rationale
            
        except Exception as e:
            if attempt == max_retries - 1:
                # Log error on the final failed attempt to help user diagnose (e.g. rate limits, keys)
                print(f"\n[ERROR] Complaint analysis failed permanently: {e}")
                return [], [], None, None
            # Exponential backoff sleep (1s, 2s)
            time.sleep(2 ** attempt)

def run_classification_pipeline(input_excel, output_excel, text_column):
    print(f"Loading masked dataset from: {input_excel}")
    df = pd.read_excel(input_excel)
    
    if text_column not in df.columns:
        raise ValueError(f"Column '{text_column}' not found. Did you run the masking pipeline first?")
        
    if USE_AZURE_OPENAI:
        print(f"Initializing Azure OpenAI Client (Endpoint: {AZURE_ENDPOINT})...")
        client = AzureOpenAI(
            api_key=API_KEY,
            api_version=AZURE_API_VERSION,
            azure_endpoint=AZURE_ENDPOINT
        )
    else:
        print(f"Initializing Standard OpenAI Client (Base URL: {BASE_URL})...")
        client = OpenAI(
            api_key=API_KEY,
            base_url=BASE_URL
        )
    
    # Initialize output containers
    themes_results = [None] * len(df)
    themes_rationale_results = [None] * len(df)
    object_results = [None] * len(df)
    object_rationale_results = [None] * len(df)
    
    rows_to_process = []
    for idx, row in df.iterrows():
        text = str(row[text_column])
        rows_to_process.append((idx, text))
        
    start_time = time.time()
    print(f"Starting parallel LLM classification on {len(df)} rows with {MAX_WORKERS} workers...")
    
    # Run API calls concurrently using a ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        # Submit tasks
        future_to_idx = {
            executor.submit(analyze_single_complaint, client, text, THEME_LIST): idx 
            for idx, text in rows_to_process
        }
        
        # Track progress
        with tqdm(total=len(rows_to_process), desc="LLM Classification") as pbar:
            for future in as_completed(future_to_idx):
                idx = future_to_idx[future]
                try:
                    matched_themes, themes_rationales, final_object, final_obj_rationale = future.result()
                    
                    # Convert themes list to a comma-separated string for Excel (or empty string if none)
                    themes_results[idx] = ", ".join(matched_themes) if matched_themes else ""
                    themes_rationale_results[idx] = "\n".join(themes_rationales) if themes_rationales else ""
                    object_results[idx] = final_object if final_object else ""
                    object_rationale_results[idx] = final_obj_rationale if final_obj_rationale else ""
                except Exception as e:
                    themes_results[idx] = ""
                    themes_rationale_results[idx] = ""
                    object_results[idx] = ""
                    object_rationale_results[idx] = ""
                    print(f"Row {idx} failed during result processing: {e}")
                
                pbar.update(1)
                
    # Assign new columns to the dataframe
    df["Assigned Themes"] = themes_results
    df["Themes Rationale"] = themes_rationale_results
    df["Complaint Object"] = object_results
    df["Object Rationale"] = object_rationale_results
    
    print(f"Saving classified dataset to: {output_excel}")
    df.to_excel(output_excel, index=False)
    
    elapsed = time.time() - start_time
    print(f"Completed! Total time: {elapsed:.2f} seconds.")
    print(f"Average throughput: {len(df) / elapsed:.2f} complaints per second.")

if __name__ == "__main__":
    import sys
    infile = "mock_complaints_masked.xlsx"
    outfile = "mock_complaints_classified.xlsx"
    
    if len(sys.argv) > 1:
        infile = sys.argv[1]
    if len(sys.argv) > 2:
        outfile = sys.argv[2]
        
    run_classification_pipeline(
        input_excel=infile,
        output_excel=outfile,
        text_column="Masked Complaint Issue"
    )
