import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

try {
  // Execute git log to get the last 15 commits (hash, author email, date, commit message)
  const logOutput = execSync('git log -15 --format="%h:::%ae:::%cI:::%s"', { stdio: ['pipe', 'pipe', 'ignore'] }).toString().trim();
  
  if (logOutput) {
    const commits = logOutput.split('\n').map((line, idx) => {
      const parts = line.split(':::');
      const hash = parts[0];
      const email = parts[1];
      const date = parts[2];
      const msg = parts.slice(3).join(':::');
      const verNumber = 15 - idx;
      return {
        version: `1.4.${verNumber}-prod`,
        changedBy: email ? email.trim() : "unknown@abc.service.in",
        changedAt: date ? new Date(date.trim()).toISOString() : new Date().toISOString(),
        commitHash: hash ? hash.trim() : "unknown",
        commitMessage: msg ? msg.trim() : "No message",
        deployedBy: "Azure DevOps Pipeline",
        environment: "Production-Azure-US"
      };
    });

    if (commits.length > 0) {
      // 1. Generate version.json (last commit)
      const versionPath = path.join(__dirname, 'public', 'version.json');
      fs.writeFileSync(versionPath, JSON.stringify(commits[0], null, 2), 'utf-8');
      console.log(`[BUILD] Generated version.json`);

      // 2. Generate/Update audit_history.json with all commits
      const historyPath = path.join(__dirname, 'public', 'audit_history.json');
      fs.writeFileSync(historyPath, JSON.stringify(commits, null, 2), 'utf-8');
      console.log(`[BUILD] Generated audit_history.json with ${commits.length} commits`);
    }
  } else {
    console.log(`[BUILD] No commits found in Git repository.`);
  }
} catch (e) {
  // If git fails, do not write anything new. It will stay empty.
  console.log(`[BUILD] Git execution failed, leaving history empty.`);
}
