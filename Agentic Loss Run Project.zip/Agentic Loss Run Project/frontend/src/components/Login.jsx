import React, { useState } from 'react';

export function Login({ onLoginSuccess }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isDemoLoading, setIsDemoLoading] = useState(false);

  const handleLogin = (e) => {
    if (e) e.preventDefault();
    setError('');

    const trimmedEmail = email.trim();
    if (!trimmedEmail.endsWith('@abc.service.in')) {
      setError("Access denied: Email address must belong to the @abc.service.in domain.");
      return;
    }

    if (password !== 'abc@1234') {
      setError("Incorrect password. Please try again or use the demo account option below.");
      return;
    }

    // Success! Save session and call callback
    sessionStorage.setItem('isAuthenticated', 'true');
    onLoginSuccess();
  };

  const handleDemoLogin = () => {
    setIsDemoLoading(true);
    setError('');
    
    // Typewriter effect simulation to populate fields beautifully before logging in!
    let emailTarget = "demo@abc.service.in";
    let passTarget = "abc@1234";
    let currEmail = "";
    let currPass = "";
    
    let i = 0;
    const emailInterval = setInterval(() => {
      if (i < emailTarget.length) {
        currEmail += emailTarget[i];
        setEmail(currEmail);
        i++;
      } else {
        clearInterval(emailInterval);
        
        let j = 0;
        const passInterval = setInterval(() => {
          if (j < passTarget.length) {
            currPass += passTarget[j];
            setPassword(currPass);
            j++;
          } else {
            clearInterval(passInterval);
            setIsDemoLoading(false);
          }
        }, 50);
      }
    }, 30);
  };

  return (
    <div style={styles.container}>
      {/* Background Animated Spheres */}
      <div style={styles.sphere1} />
      <div style={styles.sphere2} />
      
      <div style={styles.card} className="glass-panel">
        <div style={styles.header}>
          <div style={styles.iconContainer}>
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="var(--accent-color)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
          </div>
          <h1 style={styles.title}>Multi-Agent Loss Run Intelligence Analytics</h1>
          <p style={styles.subtitle}>Secure Enterprise Portal</p>
        </div>

        <form onSubmit={handleLogin} style={styles.form}>
          <div style={styles.inputGroup}>
            <label style={styles.label}>Corporate Email</label>
            <input 
              type="email" 
              placeholder="username@abc.service.in"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              style={styles.input}
              className="login-input"
            />
          </div>

          <div style={styles.inputGroup}>
            <label style={styles.label}>Password</label>
            <input 
              type="password" 
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              style={styles.input}
              className="login-input"
            />
          </div>

          {error && (
            <div style={styles.errorContainer}>
              <span style={{ fontSize: '0.85rem' }}>{error}</span>
            </div>
          )}

          <button 
            type="submit" 
            className="btn-primary" 
            style={styles.loginButton}
            disabled={isDemoLoading}
          >
            {isDemoLoading ? 'Authenticating...' : 'Sign In'}
          </button>
        </form>

        <div style={styles.divider}>
          <div style={styles.dividerLine} />
          <span style={styles.dividerText}>or</span>
          <div style={styles.dividerLine} />
        </div>

        <button 
          onClick={handleDemoLogin} 
          style={styles.demoButton}
          disabled={isDemoLoading}
          type="button"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ marginRight: '6px' }}>
            <circle cx="12" cy="12" r="10"/>
            <path d="M10 8l6 4-6 4V8z"/>
          </svg>
          <span>Use Demo Account</span>
        </button>

        {/* AI Governance & Disclosure Notice */}
        <div style={{ marginTop: '20px', padding: '12px 14px', background: 'rgba(255, 255, 255, 0.02)', border: '1px solid rgba(255, 255, 255, 0.08)', borderRadius: '8px', textAlign: 'left' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '4px' }}>
            <span style={{ fontSize: '0.9rem' }}>🛡️</span>
            <span style={{ fontSize: '0.75rem', fontWeight: 700, color: '#93c5fd', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
              Responsible AI & Governance Notice
            </span>
          </div>
          <p style={{ margin: 0, fontSize: '0.72rem', color: 'var(--text-muted)', lineHeight: '1.4' }}>
            This platform uses Artificial Intelligence models and deterministic actuarial rules for commercial loss run processing. All extractions are advisory aids and require Human-in-the-Loop (HITL) underwriting verification before binding.
          </p>
        </div>
      </div>

      <style dangerouslySetInnerHTML={{__html: `
        .login-input {
          outline: none;
          transition: all 0.3s ease;
        }
        .login-input:focus {
          border-color: var(--accent-color) !important;
          box-shadow: 0 0 12px rgba(255, 85, 0, 0.25) !important;
          background: rgba(255, 255, 255, 0.04) !important;
        }
        @keyframes float {
          0% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-20px) rotate(180deg); }
          100% { transform: translateY(0px) rotate(360deg); }
        }
      `}} />
    </div>
  );
}

const styles = {
  container: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: '100vh',
    width: '100vw',
    position: 'fixed',
    top: 0,
    left: 0,
    background: 'radial-gradient(circle at 50% 50%, #0d0f14 0%, #040406 100%)',
    zIndex: 99999,
    overflow: 'hidden',
    fontFamily: "var(--font-family)",
  },
  sphere1: {
    position: 'absolute',
    width: '450px',
    height: '450px',
    borderRadius: '50%',
    background: 'radial-gradient(circle, rgba(255, 85, 0, 0.08) 0%, rgba(255, 85, 0, 0) 70%)',
    top: '-10%',
    left: '10%',
    animation: 'float 15s infinite ease-in-out',
    pointerEvents: 'none',
  },
  sphere2: {
    position: 'absolute',
    width: '550px',
    height: '550px',
    borderRadius: '50%',
    background: 'radial-gradient(circle, rgba(225, 29, 72, 0.06) 0%, rgba(225, 29, 72, 0) 70%)',
    bottom: '-10%',
    right: '10%',
    animation: 'float 18s infinite ease-in-out alternate',
    pointerEvents: 'none',
  },
  card: {
    width: '90%',
    maxWidth: '440px',
    padding: '40px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'stretch',
    background: 'rgba(255, 255, 255, 0.015)',
    border: '1px solid rgba(255, 255, 255, 0.08)',
    borderRadius: '16px',
    backdropFilter: 'blur(30px)',
    boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)',
    zIndex: 10,
  },
  header: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    marginBottom: '32px',
    textAlign: 'center',
  },
  iconContainer: {
    width: '64px',
    height: '64px',
    borderRadius: '16px',
    background: 'rgba(255, 85, 0, 0.1)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: '20px',
    border: '1px solid rgba(255, 85, 0, 0.2)',
  },
  title: {
    fontSize: '1.4rem',
    fontWeight: '700',
    color: 'var(--text-main)',
    marginBottom: '8px',
    lineHeight: '1.3',
  },
  subtitle: {
    fontSize: '0.85rem',
    color: 'var(--text-muted)',
    textTransform: 'uppercase',
    letterSpacing: '1.5px',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '20px',
  },
  inputGroup: {
    display: 'flex',
    flexDirection: 'column',
    gap: '8px',
  },
  label: {
    fontSize: '0.75rem',
    fontWeight: '600',
    color: 'var(--text-muted)',
    textTransform: 'uppercase',
    letterSpacing: '0.5px',
  },
  input: {
    background: 'rgba(255, 255, 255, 0.02)',
    border: '1px solid rgba(255, 255, 255, 0.1)',
    borderRadius: '8px',
    padding: '12px 16px',
    color: '#fff',
    fontSize: '0.95rem',
  },
  errorContainer: {
    background: 'rgba(239, 68, 68, 0.1)',
    border: '1px solid var(--status-red)',
    color: 'var(--status-red)',
    padding: '10px 14px',
    borderRadius: '8px',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
  },
  loginButton: {
    width: '100%',
    padding: '12px',
    marginTop: '8px',
  },
  divider: {
    display: 'flex',
    alignItems: 'center',
    margin: '24px 0',
    gap: '12px',
  },
  dividerLine: {
    flex: 1,
    height: '1px',
    background: 'rgba(255, 255, 255, 0.08)',
  },
  dividerText: {
    fontSize: '0.8rem',
    color: 'var(--text-muted)',
    textTransform: 'uppercase',
  },
  demoButton: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '12px',
    borderRadius: '8px',
    background: 'rgba(255, 255, 255, 0.03)',
    border: '1px solid rgba(255, 255, 255, 0.08)',
    color: 'var(--text-main)',
    fontWeight: '500',
    fontSize: '0.9rem',
    transition: 'all 0.2s ease',
    cursor: 'pointer',
    width: '100%',
    borderStyle: 'solid',
    borderWidth: '1px',
    borderColor: 'rgba(255, 255, 255, 0.08)',
  }
};
