import React, { useState } from 'react';
import * as LucideIcons from 'lucide-react';
import * as XLSX from 'xlsx';
import { transformationData, validationData, rollupSummaryData, finalTableData, DEMO_MODE } from '../mockData';

export function TransformationView({ backendResult }) {
  const [page, setPage] = useState(0);
  const itemsPerPage = 5;
  
  let dataToUse = backendResult?.transformationMappings || (DEMO_MODE && !backendResult ? transformationData : []);

  console.log("Transformation props:", { backendResult });

  const totalPages = Math.ceil(dataToUse.length / itemsPerPage);
  const currentItems = dataToUse.slice(page * itemsPerPage, (page + 1) * itemsPerPage);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div className="section-title">
        <LucideIcons.Wand2 color="var(--accent-color)" /> Business Transformation Layer
      </div>
      <p className="section-subtitle">
        {backendResult ? "Derived from backend output schema" : "Real business mappings converting non-standard carrier data into conforming schemas."}
      </p>
      
      {dataToUse.length === 0 ? (
         <div style={{ padding: '40px', textAlign: 'center', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {console.log("Transformation: Rendering 'Awaiting backend output' because dataToUse is:", dataToUse)}
            <h3 style={{ color: 'var(--text-main)', fontSize: '1.1rem' }}>Awaiting backend output</h3>
         </div>
      ) : (
      <div className="glass-panel" style={{ marginTop: '16px', display: 'flex', flexDirection: 'column', flex: 1, overflow: 'hidden' }}>
        <div className="table-container" style={{ overflowY: 'auto', flex: 1, padding: '0 8px' }}>
          <table className="data-table" style={{ width: '100%' }}>
            <thead>
              <tr>
                <th>Raw Extracted Value</th>
                <th>Standardized Schema Mapping</th>
                <th>Transformation Type</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {currentItems.map((t, i) => (
                <tr key={i}>
                  <td style={{ fontFamily: 'monospace', color: 'var(--text-muted)', fontSize: '0.85rem' }}>"{t.raw}"</td>
                  <td style={{ fontWeight: 600, color: 'var(--text-main)' }}>{t.std}</td>
                  <td>
                    <span style={{ background: 'rgba(255,255,255,0.05)', color: 'var(--text-main)', padding: '6px 12px', borderRadius: '16px', fontSize: '0.75rem', fontWeight: 600, border: '1px solid var(--border-color)' }}>
                      {t.type}
                    </span>
                  </td>
                  <td>
                    {t.status === 'success' ? 
                      <div style={{ display: 'inline-flex', padding: '4px 10px', background: 'rgba(16,185,129,0.15)', borderRadius: '12px', border: '1px solid rgba(16,185,129,0.3)', color: 'var(--status-green)', gap: '6px', alignItems: 'center', fontSize: '0.75rem', fontWeight: 700 }}>
                        <LucideIcons.CheckCircle2 size={14} /> MAPPED
                      </div> :
                      <div style={{ display: 'inline-flex', padding: '4px 10px', background: 'rgba(245,158,11,0.15)', borderRadius: '12px', border: '1px solid rgba(245,158,11,0.3)', color: 'var(--status-yellow)', gap: '6px', alignItems: 'center', fontSize: '0.75rem', fontWeight: 700 }}>
                        <LucideIcons.AlertTriangle size={14} /> PENDING
                      </div>
                    }
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {totalPages > 1 && (
          <div style={{ padding: '16px', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '16px', borderTop: '1px solid var(--border-color)', background: 'var(--bg-card-hover)' }}>
            <button className="btn-secondary" disabled={page === 0} onClick={() => setPage(p => p - 1)} style={{ padding: '4px 12px' }}>Previous</button>
            <span style={{ fontSize: '0.9rem', color: 'var(--text-muted)' }}>Page {page + 1} of {totalPages}</span>
            <button className="btn-secondary" disabled={page === totalPages - 1} onClick={() => setPage(p => p + 1)} style={{ padding: '4px 12px' }}>Next</button>
          </div>
        )}
      </div>
      )}
    </div>
  );
}

export function ValidationView({ backendResult }) {
  const dataToUse = backendResult?.validationChecks || (DEMO_MODE && !backendResult ? validationData : []);
  console.log("Validation props:", { backendResult });

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div className="section-title">
        <LucideIcons.ShieldCheck color="var(--accent-color)" /> Business Validation Rules
      </div>
      <p className="section-subtitle">
        {backendResult ? "Calculated from extracted claims" : "Automated checks ensuring data integrity before final reporting."}
      </p>
      
      {dataToUse.length === 0 ? (
         <div style={{ padding: '40px', textAlign: 'center', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <h3 style={{ color: 'var(--text-main)', fontSize: '1.1rem' }}>Awaiting backend output</h3>
         </div>
      ) : (
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '20px', marginTop: '16px', overflowY: 'auto', paddingBottom: '20px', paddingRight: '10px' }}>
        {dataToUse.map((v, i) => {
          const isSuccess = v.status === 'success';
          const glowColor = isSuccess ? '16, 185, 129' : '245, 158, 11';
          return (
            <div key={i} className="glass-panel glass-panel-hover" style={{ padding: '24px', display: 'flex', alignItems: 'flex-start', gap: '16px', borderTop: `2px solid rgba(${glowColor}, 0.5)`, boxShadow: `0 8px 32px rgba(0,0,0,0.4), inset 0 1px 1px rgba(${glowColor}, 0.1)` }}>
              <div style={{ padding: '12px', borderRadius: '12px', background: `rgba(${glowColor}, 0.1)`, boxShadow: `inset 0 1px 0 rgba(255,255,255,0.1), 0 0 20px rgba(${glowColor}, 0.2)` }}>
                {isSuccess ? <LucideIcons.CheckCircle2 color="var(--status-green)" size={24} /> : <LucideIcons.AlertTriangle color="var(--status-yellow)" size={24} />}
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                <h4 style={{ fontSize: '1.1rem', color: 'var(--text-main)', fontWeight: 700, letterSpacing: '-0.5px' }}>{v.check}</h4>
                <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', lineHeight: '1.5' }}>{v.detail}</p>
              </div>
            </div>
          );
        })}
      </div>
      )}
    </div>
  );
}

export function RollupView({ backendResult }) {
  const [showYearModal, setShowYearModal] = useState(false);
  const [showMethodologyModal, setShowMethodologyModal] = useState(false);

  // Check if we have backend result
  const hasRealData = !!backendResult && !!backendResult.rollupSummary;
  
  // High level KPIs
  const totalIncurred = hasRealData ? (backendResult.totalIncurred || '$0') : "$37,705,321";
  const totalClaims = hasRealData ? (backendResult.claimsExtracted || 0) : 348;
  const totalPaid = hasRealData ? (backendResult.totalPaid || '$0') : "$22,410,195";
  const totalReserve = hasRealData ? (backendResult.totalReserve || '$0') : "$15,295,126";

  const byLob = hasRealData && backendResult.rollupSummary.lobSummary ? 
    backendResult.rollupSummary.lobSummary : 
    (DEMO_MODE ? rollupSummaryData.byLob : []);

  const byYear = hasRealData && backendResult.rollupSummary.yearWiseSummary ?
    backendResult.rollupSummary.yearWiseSummary :
    (DEMO_MODE ? yearWiseRollupData : []);

  if (!backendResult) {
     return (
       <div style={{ display: 'flex', flexDirection: 'column', height: '100%', position: 'relative' }}>
         <div className="section-title"><LucideIcons.Layers color="var(--accent-color)" /> Business Rollup & Consolidation</div>
         <p className="section-subtitle">Awaiting backend output</p>
         <div style={{ padding: '40px', textAlign: 'center', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <h3 style={{ color: 'var(--text-main)', fontSize: '1.1rem' }}>Awaiting backend output</h3>
         </div>
       </div>
     );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', position: 'relative' }}>
      <div className="section-title"><LucideIcons.Layers color="var(--accent-color)" /> Business Rollup & Consolidation</div>
      <p className="section-subtitle">Cross-claim reconciliation, occurrence-level aggregation, and policy year summary.</p>

      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: '24px', flex: 1, marginTop: '16px', minHeight: 0 }}>
        {/* Left Column: Totals & Summary Metrics */}
        <div className="glass-panel" style={{ padding: '28px', display: 'flex', flexDirection: 'column', gap: '24px', justifyContent: 'space-between', border: '1px solid rgba(255,255,255,0.08)' }}>
          <div>
            <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '1px', fontWeight: 600 }}>Total Pipeline Value</span>
            <div style={{ fontSize: '2.8rem', fontWeight: 800, color: 'var(--status-green)', letterSpacing: '-1.5px', marginTop: '4px', textShadow: '0 0 30px rgba(16, 185, 129, 0.3)' }}>
              {totalIncurred}
            </div>
            <div style={{ fontSize: '0.9rem', color: 'var(--text-muted)', marginTop: '4px', display: 'flex', alignItems: 'center', gap: '6px' }}>
              <LucideIcons.CheckCircle2 size={16} color="var(--status-green)" /> Across {totalClaims.toLocaleString()} Total Claims
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', background: 'rgba(0,0,0,0.2)', padding: '16px', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.03)' }}>
            <div>
              <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Total Paid</span>
              <span style={{ fontSize: '1.4rem', fontWeight: 700, color: 'var(--text-main)' }}>{totalPaid}</span>
            </div>
            <div>
              <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '4px' }}>Total Reserve</span>
              <span style={{ fontSize: '1.4rem', fontWeight: 700, color: 'var(--text-main)' }}>{totalReserve}</span>
            </div>
          </div>

          <div style={{ display: 'flex', gap: '12px' }}>
            <button className="btn-secondary" style={{ flex: 1, padding: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', fontSize: '0.85rem', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.1)' }} onClick={() => setShowYearModal(true)}>
              <LucideIcons.Calendar size={16} color="var(--accent-color)" /> View Year-wise Details
            </button>
            <button className="btn-secondary" style={{ flex: 1, padding: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', fontSize: '0.85rem', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.1)' }} onClick={() => setShowMethodologyModal(true)}>
              <LucideIcons.FileText size={16} color="var(--accent-color)" /> Duplicate Methodology
            </button>
          </div>
        </div>

        {/* Right Column: LOB Breakdown */}
        <div className="glass-panel" style={{ padding: '24px', display: 'flex', flexDirection: 'column', border: '1px solid rgba(255,255,255,0.08)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <h4 style={{ fontSize: '1rem', color: 'var(--text-main)', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '8px' }}>
              <LucideIcons.PieChart size={18} color="var(--accent-color)" /> Line of Business Breakdown
            </h4>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{byLob.length} active lines</span>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', overflowY: 'auto', flex: 1, paddingRight: '4px' }}>
            {byLob.map((l, i) => (
              <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', background: 'rgba(255,255,255,0.02)', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.04)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: i % 2 === 0 ? 'var(--accent-color)' : 'var(--status-green)' }}></div>
                  <span style={{ fontSize: '0.9rem', color: 'var(--text-main)', fontWeight: 500 }}>{l.lob}</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                  <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', background: 'rgba(255,255,255,0.05)', padding: '2px 8px', borderRadius: '12px' }}>
                    {l.count} claims
                  </span>
                  <span style={{ fontSize: '0.9rem', color: 'var(--status-green)', fontWeight: 600, minWidth: '80px', textAlign: 'right' }}>
                    {l.paid}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Year-wise Breakdown Modal */}
      {showYearModal && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(5px)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div className="glass-panel" style={{ width: '600px', maxHeight: '80vh', display: 'flex', flexDirection: 'column', padding: '24px', border: '1px solid rgba(255,255,255,0.1)', boxShadow: '0 20px 50px rgba(0,0,0,0.5)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', borderBottom: '1px solid var(--border-color)', paddingBottom: '12px' }}>
              <h3 style={{ fontSize: '1.2rem', color: 'var(--text-main)', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <LucideIcons.Calendar color="var(--accent-color)" size={20} /> Policy Year Loss Distribution
              </h3>
              <button className="btn-secondary" style={{ padding: '4px 8px' }} onClick={() => setShowYearModal(false)}>
                <LucideIcons.X size={16} />
              </button>
            </div>
            <div className="table-container" style={{ flex: 1, overflowY: 'auto' }}>
              <table className="data-table" style={{ width: '100%' }}>
                <thead>
                  <tr>
                    <th>Year</th>
                    <th>Claims</th>
                    <th>Paid</th>
                    <th>Reserve</th>
                    <th>Total Incurred</th>
                  </tr>
                </thead>
                <tbody>
                  {byYear.map((y, i) => (
                    <tr key={i}>
                      <td style={{ fontWeight: 600 }}>{y.year}</td>
                      <td>{y.claimCount || y.count}</td>
                      <td>{y.totalPaid || y.paid}</td>
                      <td>{y.totalReserve || y.reserve}</td>
                      <td style={{ fontWeight: 600, color: 'var(--status-green)' }}>{y.totalIncurred || y.incurred}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Duplicate Methodology Modal */}
      {showMethodologyModal && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(5px)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div className="glass-panel" style={{ width: '550px', display: 'flex', flexDirection: 'column', padding: '24px', border: '1px solid rgba(255,255,255,0.1)', boxShadow: '0 20px 50px rgba(0,0,0,0.5)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', borderBottom: '1px solid var(--border-color)', paddingBottom: '12px' }}>
              <h3 style={{ fontSize: '1.2rem', color: 'var(--text-main)', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <LucideIcons.HelpCircle color="var(--accent-color)" size={20} /> Duplicate Matching Methodology
              </h3>
              <button className="btn-secondary" style={{ padding: '4px 8px' }} onClick={() => setShowMethodologyModal(false)}>
                <LucideIcons.X size={16} />
              </button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', fontSize: '0.9rem', color: 'var(--text-muted)' }}>
              <div>
                <h4 style={{ color: 'var(--text-main)', marginBottom: '4px' }}>1. Claimant / Incident Matching</h4>
                <p>Identifies claims with matching loss date, state, line of business, and claimant name/incident description within high similarity thresholds.</p>
              </div>
              <div>
                <h4 style={{ color: 'var(--text-main)', marginBottom: '4px' }}>2. Base Claim ID Variation</h4>
                <p>Strips sub-claim suffixes (-01, -02, -A, /B) and bundles related coverage sub-claims into single consolidated occurrences.</p>
              </div>
              <div style={{ padding: '12px', background: 'rgba(16, 185, 129, 0.1)', borderRadius: '8px', border: '1px solid rgba(16, 185, 129, 0.2)', color: 'var(--status-green)' }}>
                <strong>Strict Null Safety Guard:</strong> Missing/blank values are assigned unique standalone keys and are never merged on blank-to-blank matches.
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export function FinalOutputView({ backendResult }) {
  const [toastMessage, setToastMessage] = useState(null);
  const [isExporting, setIsExporting] = useState(false);

  const hasRealData = !!backendResult && !!backendResult.rawRows;
  const rawDataPreview = hasRealData ? backendResult.rawRows : [];

  const metricsData = hasRealData ? [
    { metric: 'Files Processed', value: backendResult.filesUploaded || 1 },
    { metric: 'Total Claims Extracted', value: backendResult.claimsExtracted || rawDataPreview.length },
    { metric: 'Processing Errors', value: backendResult.validationIssues || 0 },
    { metric: 'Processing Time', value: backendResult.processingTime || 'N/A' }
  ] : (DEMO_MODE ? metricsExportData : []);

  if (!backendResult) {
     return (
       <div style={{ display: 'flex', flexDirection: 'column', height: '100%', position: 'relative' }}>
         <div className="section-title"><LucideIcons.Download color="var(--accent-color)" /> Export & Downstream Integration</div>
         <p className="section-subtitle">Awaiting backend output</p>
         <div style={{ padding: '40px', textAlign: 'center', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <h3 style={{ color: 'var(--text-main)', fontSize: '1.1rem' }}>Awaiting backend output</h3>
         </div>
       </div>
     );
  }

  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:8000';

  const fetchFullData = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/download/csv`);
      if (!response.ok) throw new Error("Failed to fetch CSV");
      const csvText = await response.text();
      return csvText;
    } catch (e) {
      console.error(e);
      return null;
    }
  };

  const handleDownloadJSON = async () => {
    if (!hasRealData) {
      alert("No real backend output available. Please process files first.");
      return;
    }
    setIsExporting(true);
    const csvText = await fetchFullData();
    if (csvText) {
      const wb = XLSX.read(csvText, { type: 'string' });
      const jsonData = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]);
      const dataStr = JSON.stringify(jsonData, null, 2);
      const blob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `loss_run_output.json`;
      a.click();
      URL.revokeObjectURL(url);
      showToast(`Downloaded JSON successfully`);
    } else {
      alert("Failed to download real data from backend.");
    }
    setIsExporting(false);
  };

  const handleDownloadCSV = async () => {
    if (!hasRealData) {
      alert("No real backend output available. Please process files first.");
      return;
    }
    setIsExporting(true);
    const csvText = await fetchFullData();
    if (csvText) {
      const blob = new Blob([csvText], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `loss_run_output.csv`;
      a.click();
      URL.revokeObjectURL(url);
      showToast(`Downloaded CSV successfully`);
    } else {
      alert("Failed to download real data from backend.");
    }
    setIsExporting(false);
  };

  const handleExportExcel = async () => {
    if (!hasRealData) {
      alert("No real backend output available. Please process files first.");
      return;
    }
    setIsExporting(true);
    try {
      const response = await fetch(`${API_BASE}/api/download/excel`);
      if (!response.ok) throw new Error("Failed to download Excel from backend.");
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `loss_run_output.xlsx`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
      
      showToast('Exported Full Excel Package successfully');
    } catch (e) {
      console.error(e);
      alert("Failed to download real data from backend.");
    }
    setIsExporting(false);
  };

  const [showTablePreview, setShowTablePreview] = useState(true);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', position: 'relative', overflow: 'hidden' }}>
      {toastMessage && (
        <div style={{
          position: 'absolute', top: '16px', right: '16px', background: 'var(--status-green)', color: 'var(--bg-main)',
          padding: '12px 24px', borderRadius: '8px', fontSize: '1rem', display: 'flex', alignItems: 'center', gap: '8px',
          animation: 'fadeIn 0.3s ease-out', boxShadow: '0 4px 12px rgba(16, 185, 129, 0.3)', zIndex: 100
        }}>
          <LucideIcons.CheckCircle2 size={20} /> {toastMessage}
        </div>
      )}
      
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', flexShrink: 0 }}>
        <div>
          <div className="section-title"><LucideIcons.Download color="var(--accent-color)" /> Standardized 23-Field Client Export</div>
          <p className="section-subtitle">23-Column Schema conforming to casualty, financial hierarchy, and closed-claim zero-reserve rules.</p>
        </div>
        <div style={{ display: 'flex', gap: '12px' }}>
          <button onClick={handleDownloadJSON} className="btn-secondary" style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 16px' }}>
            <LucideIcons.FileJson size={16} /> JSON
          </button>
          <button onClick={handleDownloadCSV} className="btn-secondary" style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 16px' }}>
            <LucideIcons.FileText size={16} /> CSV
          </button>
          <button onClick={handleExportExcel} className="btn-primary" style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 20px', background: 'linear-gradient(135deg, #ea580c 0%, #c2410c 100%)', color: '#fff', border: 'none', borderRadius: '8px', fontWeight: 700, cursor: 'pointer' }}>
            <LucideIcons.FileSpreadsheet size={16} /> Master Excel Package
          </button>
        </div>
      </div>

      {/* 23-Column Interactive Table Preview */}
      <div className="glass-panel" style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', border: '1px solid var(--border-color)' }}>
        <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--border-color)', background: 'var(--bg-card-hover)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '0.9rem', color: 'var(--text-main)', fontWeight: 600 }}>
            <LucideIcons.Table size={16} color="var(--accent-color)" /> Standardized Claims Output Preview ({rawDataPreview.length} records)
          </div>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>23 Columns • Gross Financial Basis • Zero-Reserve Closed Claims</span>
        </div>
        
        <div className="table-container" style={{ flex: 1, overflow: 'auto', padding: '0 8px' }}>
          <table className="data-table" style={{ width: '100%', fontSize: '0.8rem', whiteSpace: 'nowrap' }}>
            <thead style={{ position: 'sticky', top: 0, zIndex: 10, background: 'var(--bg-main)' }}>
              <tr>
                <th>#</th>
                <th>Claim ID</th>
                <th>Loss Date</th>
                <th>Date Reported</th>
                <th>Date Closed</th>
                <th>State</th>
                <th>Status</th>
                <th>Cause of Loss</th>
                <th>Nature of Injury</th>
                <th>Body Part</th>
                <th>Incurred Indemnity</th>
                <th>Incurred Medical</th>
                <th>Incurred Expense</th>
                <th>Paid Indemnity</th>
                <th>Paid Medical</th>
                <th>Paid Expense</th>
                <th>Recovery</th>
                <th>Coverage Subtype</th>
                <th>Department</th>
                <th>Risk Class</th>
                <th>Country</th>
                <th>Litigated</th>
                <th>Carrier</th>
                <th>Claim Description</th>
              </tr>
            </thead>
            <tbody>
              {rawDataPreview.map((row, idx) => (
                <tr key={idx}>
                  <td style={{ color: 'var(--text-muted)', fontWeight: 600 }}>{idx + 1}</td>
                  <td style={{ fontWeight: 700, color: 'var(--text-main)' }}>{row.claim_id || row.id}</td>
                  <td>{row.date_of_loss || row.date}</td>
                  <td>{row.date_reported || row.repDate}</td>
                  <td>{row.date_closed || row.closed || '-'}</td>
                  <td><span style={{ padding: '2px 6px', background: 'rgba(255,255,255,0.05)', borderRadius: '4px', fontWeight: 600 }}>{row.state || '-'}</span></td>
                  <td>
                    <span style={{
                      padding: '2px 8px', borderRadius: '12px', fontSize: '0.75rem', fontWeight: 700,
                      background: (row.claim_status || row.status || '').toLowerCase().includes('c') ? 'rgba(16,185,129,0.15)' : 'rgba(59,130,246,0.15)',
                      color: (row.claim_status || row.status || '').toLowerCase().includes('c') ? 'var(--status-green)' : '#60a5fa'
                    }}>
                      {row.claim_status || row.status}
                    </span>
                  </td>
                  <td>{row.cause_of_loss || row.cause}</td>
                  <td>{row.nature_of_injury || row.injury}</td>
                  <td>{row.body_part || '-'}</td>
                  <td style={{ textAlign: 'right', fontWeight: 600, color: 'var(--text-main)' }}>{row.incurred_indemnity || row.indemnity}</td>
                  <td style={{ textAlign: 'right', color: 'var(--text-muted)' }}>{row.incurred_medical || row.medical}</td>
                  <td style={{ textAlign: 'right', color: 'var(--text-muted)' }}>{row.incurred_expense || row.exp}</td>
                  <td style={{ textAlign: 'right', fontWeight: 600, color: 'var(--status-green)' }}>{row.paid_indemnity || row.paid}</td>
                  <td style={{ textAlign: 'right', color: 'var(--text-muted)' }}>{row.paid_medical || '-'}</td>
                  <td style={{ textAlign: 'right', color: 'var(--text-muted)' }}>{row.paid_expense || '-'}</td>
                  <td style={{ textAlign: 'right', color: 'var(--text-muted)' }}>{row.recovery || '$0'}</td>
                  <td><span style={{ padding: '2px 6px', background: 'rgba(255,255,255,0.05)', borderRadius: '4px' }}>{row.coverage_subtype || row.lob}</span></td>
                  <td>{row.operating_department || '-'}</td>
                  <td>{row.risk_class || '-'}</td>
                  <td>{row.country || 'USA'}</td>
                  <td>{row.litigated || 'No'}</td>
                  <td>{row.carrier || '-'}</td>
                  <td style={{ maxWidth: '280px', overflow: 'hidden', textOverflow: 'ellipsis', color: 'var(--text-muted)' }}>{row.claim_description || row.claimant}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
