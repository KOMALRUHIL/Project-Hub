import os
import io
import re
import json
import time
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
from concurrent.futures import ThreadPoolExecutor

from dotenv import load_dotenv

# Load .env
for candidate in [
    Path(__file__).resolve().parent.parent / ".env",
    Path(__file__).resolve().parent.parent.parent / ".env",
    Path.cwd() / "backend" / ".env",
    Path.cwd() / ".env"
]:
    if candidate.is_file():
        load_dotenv(dotenv_path=candidate)

load_dotenv()


def is_document_intelligence_available() -> bool:
    """Check if Azure Document Intelligence credentials are configured and SDK is installed."""
    endpoint = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT", "").strip()
    key = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_KEY", "").strip()
    if not (endpoint and key):
        return False
    try:
        from azure.core.credentials import AzureKeyCredential
        from azure.ai.documentintelligence import DocumentIntelligenceClient
        return True
    except ImportError:
        return False


def gpt_chat_call(
    prompt: str,
    system_prompt: str = "You are an expert actuarial auditor and insurance data extraction specialist.",
    model_name: Optional[str] = None,
    api_version: Optional[str] = None,
    temperature: float = 0.0
) -> str:
    """
    Direct Chat Completion call to Azure OpenAI (or standard OpenAI).
    Fast, reliable, and lightweight without image payload overhead.
    """
    import requests

    azure_key = os.getenv("AZURE_OPENAI_API_KEY")
    azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    azure_deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o")
    azure_api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview")

    deployment_to_call = model_name or azure_deployment
    version_to_call = api_version or azure_api_version

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": prompt}
    ]
    data = {
        "messages": messages,
        "temperature": temperature
    }

    # 1. Try Azure OpenAI
    if azure_key and azure_endpoint:
        base_endpoint = azure_endpoint.rstrip("/")
        url = f"{base_endpoint}/openai/deployments/{deployment_to_call}/chat/completions?api-version={version_to_call}"
        headers = {
            "Content-Type": "application/json",
            "api-key": azure_key
        }
        for attempt in range(4):
            try:
                resp = requests.post(url, headers=headers, json=data, timeout=120)
                resp.raise_for_status()
                resp_json = resp.json() or {}
                return resp_json.get("choices", [{}])[0].get("message", {}).get("content", "")
            except Exception as e:
                print(f"[Azure Chat Call Warning] Attempt {attempt+1}/4: {e}")
                time.sleep(2 * (attempt + 1))
        return ""

    # 2. Try Direct OpenAI
    openai_key = os.getenv("OPENAI_API_KEY")
    if openai_key:
        url = "https://api.openai.com/v1/chat/completions"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {openai_key}"
        }
        data_openai = dict(data)
        data_openai["model"] = "gpt-4o"
        try:
            resp = requests.post(url, headers=headers, json=data_openai, timeout=120)
            resp.raise_for_status()
            resp_json = resp.json() or {}
            return resp_json.get("choices", [{}])[0].get("message", {}).get("content", "")
        except Exception as e:
            print(f"[OpenAI Chat Call Error] {e}")
            return ""

    return ""


def _normalize_azure_endpoint(endpoint: str) -> str:
    """Ensure endpoint has https:// prefix and no trailing path segments."""
    ep = str(endpoint or "").strip()
    if not ep:
        return ""
    if not ep.startswith("http://") and not ep.startswith("https://"):
        ep = "https://" + ep
    from urllib.parse import urlparse
    parsed = urlparse(ep)
    base = f"{parsed.scheme}://{parsed.netloc}"
    return base


def _analyze_with_direct_rest(endpoint: str, key: str, file_bytes: bytes) -> Optional[str]:
    """Direct REST API analyzer that bypasses SDK transport issues/EOF errors."""
    import requests
    url = f"{endpoint}/documentintelligence/documentModels/prebuilt-layout:analyze?api-version=2024-11-30&outputContentFormat=markdown"
    headers = {
        "Ocp-Apim-Subscription-Key": key,
        "Content-Type": "application/pdf"
    }
    try:
        resp = requests.post(url, headers=headers, data=file_bytes, timeout=90)
        if resp.status_code == 202:
            op_location = resp.headers.get("Operation-Location")
            if not op_location:
                return None
            for _ in range(60):
                time.sleep(2)
                poll_resp = requests.get(op_location, headers={"Ocp-Apim-Subscription-Key": key}, timeout=30)
                if poll_resp.status_code == 200:
                    data = poll_resp.json()
                    status = data.get("status")
                    if status == "succeeded":
                        return data.get("analyzeResult", {}).get("content", "")
                    elif status in ["failed", "canceled"]:
                        return None
        elif resp.status_code == 200:
            return resp.json().get("analyzeResult", {}).get("content", "")
    except Exception as e:
        print(f"[AZURE DOCUMENT INTELLIGENCE REST ERROR] {e}")
    return None


def extract_tables_with_document_intelligence(
    file_path: Path,
    filename: str
) -> Tuple[List[Dict[str, Any]], str]:
    """
    Extract structured claim tables from multi-page PDFs using Azure Document Intelligence (prebuilt-layout).
    Returns (raw_claims_list, full_markdown_text).
    """
    raw_endpoint = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT", "").strip()
    key = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_KEY", "").strip()
    endpoint = _normalize_azure_endpoint(raw_endpoint)

    if not endpoint or not key:
        print("[INFO] Azure Document Intelligence credentials not found. Skipping to Vision OCR...")
        return [], ""

    print(f"[AZURE DOCUMENT INTELLIGENCE] Analyzing '{filename}' with prebuilt-layout engine ({endpoint})...")
    start_time = time.time()

    with open(file_path, "rb") as f:
        file_bytes = f.read()

    full_markdown = ""

    # 1. Try via Azure Document Intelligence SDK Client
    try:
        from azure.core.credentials import AzureKeyCredential
        from azure.ai.documentintelligence import DocumentIntelligenceClient
        from azure.ai.documentintelligence.models import DocumentContentFormat

        client = DocumentIntelligenceClient(
            endpoint=endpoint,
            credential=AzureKeyCredential(key)
        )

        poller = client.begin_analyze_document(
            model_id="prebuilt-layout",
            body=file_bytes,
            output_content_format=DocumentContentFormat.MARKDOWN
        )
        result = poller.result()
        full_markdown = result.content or ""
    except Exception as sdk_err:
        print(f"[AZURE DOCUMENT INTELLIGENCE] SDK connection note: {sdk_err}. Trying direct REST API...")
        full_markdown = _analyze_with_direct_rest(endpoint, key, file_bytes) or ""

    if not full_markdown:
        print("[AZURE DOCUMENT INTELLIGENCE] Unable to connect. Falling back to Multimodal Vision OCR...")
        return [], ""

    elapsed = time.time() - start_time
    print(f"[AZURE DOCUMENT INTELLIGENCE] Document analysis completed in {elapsed:.2f}s.")

    # Build page-to-content map
    page_chunks: List[Tuple[int, str]] = []
    if "<!-- PageBreak -->" in full_markdown:
        splits = full_markdown.split("<!-- PageBreak -->")
        for p_idx, s in enumerate(splits):
            if s.strip():
                page_chunks.append((p_idx + 1, s.strip()))
    else:
        page_chunks.append((1, full_markdown))

        print(f"[AZURE DOCUMENT INTELLIGENCE] Extracted {len(page_chunks)} page layout section(s) with {len(result.tables or [])} table(s).")

        # Actuarial parsing prompt for structured markdown tables
        page_table_prompt_template = """# Role & Core Objective
You are an expert actuarial auditor and claims database engineer.
You are analyzing a high-precision OCR table layout extracted from Page {page_num} of a commercial insurance loss run report.
Your objective is to extract EVERY SINGLE itemized claim row visible in this table/page into a structured JSON array with 100% precision.

# Page {page_num} Layout & Tables:
```markdown
{content}
```

# Critical Extraction Rules:
1. **Exhaustive Row Transcribing**:
   - Extract every individual claim row present in the table(s).
   - If a claim has narrative descriptions or financial breakdowns spanning multiple visual lines, combine them into that single claim record.
   - Do NOT omit any rows.

2. **Date Identification & Standard Formatting**:
   - **Date of Loss / Accident Date** (`accident_date`): Look for "Date of Loss", "Loss Date", "Accident Date", "Event Date", "D/L", "DL", "D.O.L.", "DOL". Format as "MM/DD/YYYY".
   - **Date Reported / Notice Date** (`report_date`): Look for "Date Reported", "Report Date", "Notice Date", "D/R", "DR", "D.O.R.", "DOR". Format as "MM/DD/YYYY".
   - **Date Closed** (`date_closed`): Look for "Date Closed", "Closed Date", "D/C", "DC", "D.O.C.". Format as "MM/DD/YYYY".

3. **Status**:
   - "Closed" / "C" if closed date is present or marked closed.
   - "Open" / "O" if open or no closed date.
   - "Reopened" / "R" if marked reopened.

4. **Financial Buckets (Parse as clean float numbers, e.g. 12500.50)**:
   - `paid_indemnity`: Paid Loss / Paid Indemnity / Paid Property Damage
   - `paid_medical`: Paid Medical / Paid Bodily Injury
   - `paid_expense`: Paid Expense / Paid ALAE / Legal Paid
   - `reserve_indemnity`: Outstanding Loss / Reserve Loss / Reserve Indemnity
   - `reserve_medical`: Outstanding Medical / Reserve Medical
   - `reserve_expense`: Outstanding Expense / Reserve ALAE
   - `total_incurred`: Total Incurred / Net Incurred / Gross Incurred
   - `total_paid`: Total Paid / Net Paid / Gross Paid
   - `total_recoveries`: Recoveries / Subrogation / Salvage (positive number)

5. **Rejection Rules (CRITICAL)**:
   - NEVER extract a "Grand Total", "Total", or "Subtotal" summary row as a claim!
   - NEVER treat column legends or footnote definitions as claims!

6. **Output Format**:
Return ONLY a valid JSON array of claim objects:
[
  {{
    "claim_id": "string or null",
    "claimant": "string or null",
    "policy_number": "string or null",
    "accident_date": "MM/DD/YYYY or null",
    "report_date": "MM/DD/YYYY or null",
    "date_closed": "MM/DD/YYYY or null",
    "claim_status": "Open / Closed / Reopened",
    "state": "2-letter US state or null",
    "line_of_business": "string or null",
    "coverage_subtype": "string or null",
    "cause_of_loss": "string or null",
    "claim_description": "detailed description string",
    "paid_indemnity": 0.0,
    "paid_medical": 0.0,
    "paid_expense": 0.0,
    "reserve_indemnity": 0.0,
    "reserve_medical": 0.0,
    "reserve_expense": 0.0,
    "total_incurred": 0.0,
    "total_paid": 0.0,
    "total_recoveries": 0.0,
    "carrier": "string or null"
  }}
]
If there are no claim rows in this section, return: []
"""

        raw_claims: List[Dict[str, Any]] = []

        def _process_page_chunk(item: Tuple[int, str]) -> Tuple[int, List[Dict[str, Any]]]:
            p_num, content = item
            if not content.strip() or len(content.strip()) < 30:
                return p_num, []
            
            prompt = page_table_prompt_template.format(page_num=p_num, content=content)
            response_text = gpt_chat_call(prompt)
            
            clean_json = response_text.strip()
            if "```json" in clean_json:
                clean_json = clean_json.split("```json")[-1].split("```")[0].strip()
            elif "```" in clean_json:
                clean_json = clean_json.split("```")[-1].split("```")[0].strip()
                
            try:
                parsed = json.loads(clean_json)
                if isinstance(parsed, dict):
                    for k in ["claims", "data", "results", "records"]:
                        if k in parsed and isinstance(parsed[k], list):
                            parsed = parsed[k]
                            break
                    else:
                        parsed = [parsed]
                
                page_records = []
                if isinstance(parsed, list):
                    for claim_item in parsed:
                        if isinstance(claim_item, dict):
                            # Map alternate keys
                            if "accident_date" in claim_item and "date_of_loss" not in claim_item:
                                claim_item["date_of_loss"] = claim_item["accident_date"]
                            if "report_date" in claim_item and "date_reported" not in claim_item:
                                claim_item["date_reported"] = claim_item["report_date"]
                            if "incurred_alae" in claim_item and "incurred_expense" not in claim_item:
                                claim_item["incurred_expense"] = claim_item["incurred_alae"]
                            if "paid_alae" in claim_item and "paid_expense" not in claim_item:
                                claim_item["paid_expense"] = claim_item["paid_alae"]
                            if "total_recoveries" in claim_item and "recovery" not in claim_item:
                                claim_item["recovery"] = claim_item["total_recoveries"]
                            if "status" in claim_item and "claim_status" not in claim_item:
                                claim_item["claim_status"] = claim_item["status"]
                            if "line_of_business" in claim_item and "coverage_subtype" not in claim_item:
                                claim_item["coverage_subtype"] = claim_item["line_of_business"]

                            claim_item["page_number"] = f"Page {p_num}"
                            page_records.append(claim_item)
                return p_num, page_records
            except Exception as je:
                print(f"[WARN] Error parsing JSON for page {p_num}: {je}")
                return p_num, []

        max_workers = min(5, len(page_chunks)) if page_chunks else 1
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            chunk_results = list(executor.map(_process_page_chunk, page_chunks))

        # Re-sort in page sequence
        chunk_results.sort(key=lambda x: x[0])
        for p_num, p_recs in chunk_results:
            raw_claims.extend(p_recs)

        print(f"[AZURE DOCUMENT INTELLIGENCE] Successfully parsed {len(raw_claims)} claim(s) across {len(page_chunks)} page(s).")
        return raw_claims, full_markdown

    except Exception as e:
        print(f"[AZURE DOCUMENT INTELLIGENCE ERROR] {e}")
        return [], ""
