import ast
import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
import utils_gpt

#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#


def call_api_with_retries(model_name, params, headers, json, max_attempts=5):
    try:
        return utils_gpt.call_api_with_retries(model_name, params, headers, json, max_attempts)
    except Exception:
        pass
    return "", 0, 0


def gpt_call(
    prompt,
    model_name,
    api_version,
    temperature=0,
    reasoning_effort=None
):
    cortex_token = os.getenv('CORTEX_TOKEN')

    headers = {
        'accept': '*/*',
        'Authorization': f'Bearer {cortex_token}',
    }

    params = {
        'api-version': api_version,
    }

    json_data = {
        'messages': [
            {
                'content': prompt,
                'role': 'user',
            },
        ],
        'use_case': "testing", # Limited to 255 characters
    }

    # Only set temperature if model is NOT a gpt-5 variant (matches utils_gpt_vision behavior)
    if "gpt-5" not in model_name:
        json_data['temperature'] = temperature

    # Set reasoning level if provided
    if reasoning_effort is not None:
        json_data['reasoning_effort'] = reasoning_effort

    output, input_tokens, output_tokens = call_api_with_retries(
        model_name=model_name,
        params=params,
        headers=headers,
        json=json_data
    )

    return output, input_tokens, output_tokens


def safe_string_to_list(string_data):
    try:
        result = ast.literal_eval(string_data)
        if isinstance(result, list):
            return result
        else:
            return []
    except:
        return []
