import os
import pandas as pd

from docx_to_pdf import convert_docx_to_pdf
from pdf_to_images import turn_pdf_to_images
from ocr import run_ocr
from detect_loss_runs import detect_loss_runs

from determine_pdf_cutoff import determine_page_cutoffs
from extract import extract_claims, extract_policies_no_claims

from clean_extraction_output import process_claims_df, process_claim_free_policies_df
from detect_occurrence_and_duplicate import find_occurrences_and_duplicates
from aggregate_extraction_output import aggregate_by_occurrence
from augment_extraction_output import augment_extraction_output

from generate_templates import generate_templates
from metrics import save_metrics_json

def _is_truly_empty(df: pd.DataFrame) -> bool:
    # "empty without any columns or headers"
    return df is None or (isinstance(df, pd.DataFrame) and df.empty and len(df.columns) == 0)

def _sort_claims_for_output(df: pd.DataFrame) -> pd.DataFrame:
    """
    Sort by AccountName, file_path, then page_num_or_sheet_name:
    - numeric pages first (ascending)
    - then sheet names (alphabetical)
    """
    out = df.copy()

    if "page_num_or_sheet_name" in out.columns:
        out["page_num_sort"] = pd.to_numeric(out["page_num_or_sheet_name"], errors="coerce")
        out["is_numeric"] = out["page_num_sort"].notna()
        sort_cols = [c for c in ["AccountName", "file_path", "is_numeric", "page_num_sort", "page_num_or_sheet_name"] if c in out.columns]
        ascending = [True, True, False, True, True][:len(sort_cols)]
        out = out.sort_values(by=sort_cols, ascending=ascending, na_position="last").drop(
            columns=["page_num_sort", "is_numeric"], errors="ignore"
        )
    else:
        sort_cols = [c for c in ["AccountName", "file_path"] if c in out.columns]
        if sort_cols:
            out = out.sort_values(by=sort_cols, kind="stable")

    return out


def main():
    input_data_dir = "pilot_input_data"
    output_data_dir = "output_data"
    extraction_data_dir = "extraction_output"
    template_data_dir = "templates"

    # Companies to Process & experiment prefix for the extraction outputs
    company_names = ["Connector Castings"]
    experiment_prefix = "TESTING"

    # Create experiment subfolder under extraction_output
    experiment_dir = os.path.join(extraction_data_dir, experiment_prefix)
    os.makedirs(experiment_dir, exist_ok=True)

    # Helper to force files to sort in pipeline order (alphabetical == step order)
    def step_path(step: int, name: str, ext: str = "csv") -> str:
        # Example: TESTING_01_claims_raw_sorted.csv
        filename = f"{experiment_prefix}_{step:02d}_{name}.{ext}"
        return os.path.join(experiment_dir, filename)

    # Convert all DOCX to PDF
    print("\nConverting DOCX to PDF....\n")
    convert_docx_to_pdf(input_data_dir, company_names)

    # Convert PDF pages to images and store output
    print("\nCreating images of each PDF page...\n")
    turn_pdf_to_images(company_names, input_data_dir, output_data_dir)

    # Run OCR and store output (page response - OCR text)
    print("\nBeginning OCR of PDFs....\n")
    run_ocr(company_names, input_data_dir, output_data_dir, use_cached=True)

    # Detect which documents are a loss run or not
    print("\nDetecting which input files are loss runs....\n")
    is_file_loss_run_dict = detect_loss_runs(output_data_dir, company_names)

    # Detect context limits for PDFs --> stores which pages to process together for each file
    print("\nDetermining PDF page groupings based on context limits...")
    pages_to_join_dict = determine_page_cutoffs(output_data_dir, company_names, is_file_loss_run_dict, use_llm_chunking=False)

    # Begin Loss Run Extraction
    print("\nBeginning Loss Run Extraction....\n")

    # 1) Raw extraction
    print("\n Extracting Key Claim-Level Details....")
    claims_df = extract_claims(output_data_dir, company_names, pages_to_join_dict, is_file_loss_run_dict)

    # If extraction produced a totally headerless DF, stop early (downstream steps require columns)
    if _is_truly_empty(claims_df):
        print("                 ⚠️ Extraction returned an empty DataFrame with no columns. Skipping cleaning/dedupe/augment/aggregate.")
        raw_sorted_path = step_path(1, "claims_raw_sorted")
        pd.DataFrame().to_csv(raw_sorted_path, index=False)
        print(f"                 Saved: {raw_sorted_path}")

        # still emit metrics JSON
        metrics_output_path = step_path(9, "metrics", ext="json")
        save_metrics_json(metrics_output_path)
        return

    # Save raw extracted output (sorted nicely)
    claims_raw_sorted = _sort_claims_for_output(claims_df)
    raw_sorted_path = step_path(1, "claims_raw_sorted")
    claims_raw_sorted.to_csv(raw_sorted_path, index=False)
    print(f"                 Saved: {raw_sorted_path}")

    ## CLAIMS POST-PROCESSING BEGINS (AGGREGATION-WRAPPER)

    # 2) Clean claim-level output with programatic logic
    print("\n Cleaning Claims Dataframe and Implementing Logic")
    claims_clean_df = process_claims_df(claims_raw_sorted)

    claims_clean_sorted = _sort_claims_for_output(claims_clean_df)
    clean_path = step_path(2, "claims_clean_sorted")
    claims_clean_sorted.to_csv(clean_path, index=False)
    print(f"                 Saved: {clean_path}")

    # 3) Augment claim-level output with header-like metadata .
    print("\n Augmenting Clean Claim-Level Output")
    claims_clean_aug_df = augment_extraction_output(claims_clean_sorted)

    claims_clean_aug_sorted = _sort_claims_for_output(claims_clean_aug_df)
    clean_aug_path = step_path(3, "claims_clean_augmented")
    claims_clean_aug_sorted.to_csv(clean_aug_path, index=False)
    print(f"                 Saved: {clean_aug_path}")

    # Drop augmentation audit column so it doesn't affect downstream outputs
    if "augmentation" in claims_clean_aug_sorted.columns:
        claims_clean_aug_sorted = claims_clean_aug_sorted.drop(columns=["augmentation"])

    # 4) Occurrence + duplicate detection (deterministic; no LLM)
    print("\n Detecting Occurrences + Duplicates")
    claims_deduped_df = find_occurrences_and_duplicates(claims_clean_aug_sorted)
    claims_deduped_sorted = _sort_claims_for_output(claims_deduped_df)

    deduped_path = step_path(4, "claims_deduped")
    claims_deduped_sorted.to_csv(deduped_path, index=False)
    print(f"                 Saved: {deduped_path}")

    ## SKIP THIS FOR DEPLOYING INTO DOC-INSIGHTS
    # # Generate templates from deduped row-level data (before any aggregation)
    # print("\n Generating Excel Templates")
    # generate_templates(
    #     claims_deduped_sorted,
    #     template_data_dir,
    #     experiment_prefix,
    #     output_folder=experiment_dir,
    # )

    # 5) Aggregate to occurrence-level
    print("\n Aggregating to Occurrence Level")
    occ_agg_df = aggregate_by_occurrence(claims_deduped_sorted)

    occ_agg_path = step_path(5, "claims_occurrence_aggregated")
    occ_agg_df.to_csv(occ_agg_path, index=False)
    print(f"                 Saved: {occ_agg_path}")

    # Drop merged_updates after saving aggregated output
    if "merged_updates" in occ_agg_df.columns:
        claims_final_df = occ_agg_df.drop(columns=["merged_updates"])

    # 6) Final output without extra columns (keeps AccountName, file_path, and all extracted columns)
    print("\n Saving Final Output")
    claims_final_path = step_path(6, "claims_final")
    claims_final_df.to_csv(claims_final_path, index=False)
    print(f"                 Saved: {claims_final_path}")

    # 7) Extract policies without claims
    print("\n Extracting Policies Without Claims....")
    no_claims_df = extract_policies_no_claims(output_data_dir, company_names, pages_to_join_dict, is_file_loss_run_dict)

    if not _is_truly_empty(no_claims_df):
        # Save raw no-claims output
        no_claims_raw_path = step_path(7, "no_claims_raw")
        no_claims_df.to_csv(no_claims_raw_path, index=False)
        print(f"                 Saved: {no_claims_raw_path}")

        ## POLICIES NO CLAIMS POST-PROCESSING BEGINS (AGGREGATION-WRAPPER)
        # 8) Clean no-claims output
        print("\n Cleaning Policies Without Claims")
        no_claims_clean_df = process_claim_free_policies_df(no_claims_df)
        no_claims_clean_path = step_path(8, "no_claims_clean")
        no_claims_clean_df.to_csv(no_claims_clean_path, index=False)
        print(f"                 Saved: {no_claims_clean_path}")
    else:
        print("                 ⚠️ No policies without claims found.")

    # Save metrics JSON summarizing all stages (time, cost, etc.)
    metrics_output_path = step_path(9, "metrics", ext="json")
    save_metrics_json(metrics_output_path)


if __name__ == "__main__":
    main()
