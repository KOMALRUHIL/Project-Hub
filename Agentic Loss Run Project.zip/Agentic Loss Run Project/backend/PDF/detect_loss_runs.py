import os
import re
import json
import time
import asyncio
from prompts import LOSS_RUN_DETECTION_PROMPT
from utils_gpt import gpt_call
import models
from metrics import record_stage


def _long_path(path: str) -> str:
    """Prefix path with \\\\?\\ on Windows to support paths longer than 260 characters."""
    path = os.path.abspath(path)
    if os.name == 'nt' and not path.startswith('\\\\?\\'):
        path = '\\\\?\\' + path
    return path


_det_name = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o-mini")
LOSS_RUN_DETECTION_MODEL = {
    "model_name": _det_name,
    "api_version": os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21"),
    "input_costs": 0.50,
    "output_costs": 1.50
}

import warnings
warnings.filterwarnings(
    "ignore",
    message="Data Validation extension is not supported and will be removed",
    category=UserWarning,
)


def _is_loss_run_filename(filename: str) -> bool:
    """
    Heuristic detection based only on the filename (no path, no extension).

    Rules:
    - Case-insensitive.
    - 'lr' / 'lrs' etc. must be whole tokens, not substrings
      inside other words, e.g. 'color' should NOT match.
    """

    name_no_ext = os.path.splitext(filename)[0].lower()

    # Normalize common separators to spaces
    normalized = re.sub(r"[\-_\.\+]+", " ", name_no_ext)

    # 1) Simple substring match for the multi-word or concatenated forms
    phrase_like_keywords = [
        "loss run",
        "loss runs",
        "lossrun",
        "lossruns",
        "lrun",
        "loss summary",
        "loss summaries"
    ]
    if any(kw in normalized for kw in phrase_like_keywords):
        return True

    # 2) Token-based match for short forms that must be whole tokens
    tokens = re.split(r"[^a-z0-9]+", normalized)
    tokens = [t for t in tokens if t]

    token_keywords = {"lr", "lrs"}
    if any(t in token_keywords for t in tokens):
        return True

    return False


def _score_text_by_keywords(text: str) -> int:
    """
    Very simple scoring: for each keyword, if present in the lowercased text,
    add 1 to the score. You can later add weights if you want.
    """
    keywords = [
        # Core loss-run document identifiers
        "loss run",
        "loss runs",
        "loss history",
        "loss summary",
        "loss schedule",
        "schedule of losses",
        "loss information",
        "loss experience",
        "loss development",
        "loss detail",
        "loss detail report",
        "loss report",
        "losses valued as of",
        "loss run valued as of",
        "valuation date",
        "valuation as of",
        "valued as of",
        "claims experience",
        "claims summary",
        "summary of losses",
        "loss summary by year",
        "loss summary by policy year",
        "loss summary by location",
        "summary of claims",
        "claims by year",
        "claims by policy year",
        "no claims",
        "no losses",

        # Claim table / field labels
        "claim number",
        "claim no",
        "claim #",
        "claim id",
        "claim reference",
        "claim ref",
        "date of loss",
        "loss date",
        "reported date",
        "report date",
        "date reported",
        "status",
        "open date",
        "close date",
        "closed date",
        "report date",
        "claimant",
        "claimant name",
        "description of loss",
        "loss description",
        "claim description",
        "accident description",
        "injury description",
        "location of loss",
        "occurrence id",
        "policy number",
        "policy no",
        "policy #",

        # Loss / financial metric labels typical of loss runs
        "total incurred",
        "net incurred",
        "incurred loss",
        "gross incurred",
        "incurred amount",
        "loss incurred",
        "total paid",
        "paid loss",
        "loss paid",
        "paid to date",
        "paid to-date",
        "paid amount",
        "outstanding reserve",
        "case reserve",
        "loss reserve",
        "outstanding loss",
        "remaining reserve",
        "reserve amount",
        "total claim cost",
        "unpaid loss",
        "unpaid amount",
        "incurred alae",
        "alae incurred",
        "allocated loss adjustment expense",
        "allocated loss adj expense",
        "paid alae",
        "alae paid",
        "total alae",
        "expense incurred",
        "expense paid",
        "total expense",
        "expense reserve",
        "total recoveries",
        "recoveries",
        "subrogation recoveries",
        "subrogation",
        "salvage",
        "deductible",
        "loss amount",
        "claim amount",
        "large loss",
        "major loss",

        # Aggregation / count indicators within loss runs
        "number of claims",
        "claim count",
        "claims count",
        "total number of claims",
        "incurred by year",
        "paid by year",
        "total incurred by year",
        "total paid by year",
    ]
    if not text:
        return 0
    text = str(text)
    text_l = text.lower()
    score = 0
    for kw in keywords:
        if kw in text_l:
            score += 1
    return score


def get_top_ocr_pages_for_detection(page_text_map: dict, top_n: int = 5):
    """
    Given page_text_map = {"1": "page 1 text", "2": "page 2 text", ...},
    return a list of (page_number_str, page_text) for the top_n most likely
    loss-run pages by keyword hits.

    If no pages have any hits, return the first top_n pages in page-number order.
    """
    # Score each page
    page_scores = []
    for page_str, text in page_text_map.items():
        score = _score_text_by_keywords(text)
        page_scores.append((page_str, text, score))

    # Any hits at all?
    max_score = max((s for (_, _, s) in page_scores), default=0)
    if max_score > 0:
        # Sort by score desc, then by page number asc
        page_scores.sort(key=lambda x: (-x[2], int(x[0]) if x[0].isdigit() else 999999))
        selected = page_scores[:top_n]
    else:
        # No hits -> default to first N pages by page number
        page_scores.sort(key=lambda x: int(x[0]) if x[0].isdigit() else 999999)
        selected = page_scores[:top_n]

    # Return list of (page_number_str, page_text)
    return [(p, t) for (p, t, _) in selected]


def _truncate_chunks_for_detection(chunks: list, max_words_per_sheet: int = 500) -> list:
    """
    Take every chunk of excel/csv and truncates its content to the first
    `max_words_per_sheet` words. No keyword scoring / ranking.
    """
    if not chunks:
        return []

    truncated_chunks = []
    for ch in chunks:
        content = (str(ch.get("content")) or "").strip()
        words = content.split()
        if len(words) > max_words_per_sheet:
            words = words[:max_words_per_sheet]
            truncated_content = " ".join(words)
        else:
            truncated_content = content

        ch_copy = dict(ch)
        ch_copy["content"] = truncated_content
        truncated_chunks.append(ch_copy)

    return truncated_chunks


_detection_token_usage = {}  # key: (company, filename) -> {"input": int, "output": int}
_detection_time_usage = {}   # key: (company, filename) -> float seconds


def _log_detection_decision(company: str, filename: str, info: dict):
    """
    Print per-file detection decision and LLM cost in a readable format.
    """
    is_loss_run = bool(info.get("is_loss_run"))
    elapsed = _detection_time_usage.get((company, filename), 0.0)

    emoji = "✅" if is_loss_run else "❌"
    print(f"       Company: {company}")
    print(f"                {emoji} Loss Run Detection: {filename}")
    print(f"                ⏱️ Filtering Time: {elapsed:.2f} seconds")
    usage = _detection_token_usage.get((company, filename), {"input": 0, "output": 0})

    if usage["input"] or usage["output"]:
        cost = models.compute_cost(
            usage["input"],
            usage["output"],
            LOSS_RUN_DETECTION_MODEL,
        )
    else:
        cost = 0.0
    print(f"                💲 Filtering Cost: ${cost:.6f}")

    record_stage(
        company,
        filename,
        stage="loss_run_detection",
        time_seconds=elapsed,
        input_tokens=usage["input"],
        output_tokens=usage["output"],
        cost=cost,
    )


def _call_llm_detection(input_payload: dict, max_retries: int = 5, account_name: str = None, file_name: str = None) -> bool:
    """
    Calls the loss-run detection LLM with retry + strict JSON parsing.

    input_payload: dict or list that will be JSON-serialized and inserted into LOSS_RUN_DETECTION_PROMPT
                   via the {input} placeholder.
    Returns:
        bool: True if LLM decides it is a loss run, else False.
    """
    # The detection prompt expects the Input section to be JSON text,
    # which is substituted into {input}.
    input_json_str = json.dumps(input_payload, ensure_ascii=False)

    for attempt in range(1, max_retries + 1):
        try:
            prompt = LOSS_RUN_DETECTION_PROMPT.format(input=input_json_str)

            # gpt_call is assumed to return the raw model text response
            raw_output, input_tokens, output_tokens = gpt_call(
                prompt,
                LOSS_RUN_DETECTION_MODEL["model_name"],
                LOSS_RUN_DETECTION_MODEL["api_version"],
            )

            # --- track token usage for this file (for cost reporting) ---
            if account_name is not None and file_name is not None:
                key = (account_name, file_name)
                usage = _detection_token_usage.setdefault(key, {"input": 0, "output": 0})
                usage["input"] += input_tokens or 0
                usage["output"] += output_tokens or 0

            # Response must be a single JSON object per the prompt spec
            parsed = json.loads(raw_output)

            if not isinstance(parsed, dict):
                raise ValueError("LLM response is not a JSON object")

            if "is_loss_run" not in parsed or "reason" not in parsed:
                raise ValueError("LLM response missing required keys")

            parsed["is_loss_run"] = bool(parsed["is_loss_run"])

            return parsed["is_loss_run"]

        except Exception as e:
            print(f"        ⚠️ LLM detection attempt {attempt} failed: {e}")
            if attempt == max_retries:
                return False


async def _call_llm_detection_async(input_payload: dict, max_retries: int = 5, account_name: str = None, file_name: str = None) -> bool:
    """
    Async wrapper for _call_llm_detection to enable parallel LLM calls.
    """
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(
        None,  # Uses default ThreadPoolExecutor
        _call_llm_detection,
        input_payload,
        max_retries,
        account_name,
        file_name
    )


async def detect_loss_runs_async(output_data_dir, company_folders, max_concurrent: int = 7):
    """
    Async version that parallelizes only the LLM detection calls.
    File I/O remains synchronous.
    """
    loss_run_detection_dict = {}
    semaphore = asyncio.Semaphore(max_concurrent)

    async def process_file_with_semaphore(task_info):
        async with semaphore:
            return await process_single_file(task_info)

    async def process_single_file(task_info):
        """Process a single PDF file with async LLM call."""
        company_folder = task_info["company_folder"]
        file = task_info["file"]
        file_path = task_info["file_path"]

        dict_key = (company_folder, file)

        # File-name based check (synchronous)
        file_name_check = _is_loss_run_filename(file)

        if file_name_check:
            result = {
                "is_loss_run": bool(file_name_check),
                "method": "Filename"
            }
            _log_detection_decision(company_folder, file, result)
            return dict_key, result

        # Prepare data for LLM call (synchronous I/O)
        json_path = _long_path(task_info["json_path"])
        if not os.path.isfile(json_path):
            result = {"is_loss_run": False, "method": None}
            _log_detection_decision(company_folder, file, result)
            return dict_key, result

        try:
            with open(json_path, "r", encoding="utf-8") as f:
                page_text_map = json.load(f)
        except json.JSONDecodeError as e:
            print(f"        ❌ Failed to load JSON in {json_path}: {e}")
            result = {"is_loss_run": False, "method": None}
            _log_detection_decision(company_folder, file, result)
            return dict_key, result

        top_pages = get_top_ocr_pages_for_detection(page_text_map, top_n=5)
        input_payload = top_pages

        # LLM call (async parallelized)
        start_time = time.time()
        llm_check = await _call_llm_detection_async(
            input_payload,
            account_name=company_folder,
            file_name=file,
        )
        _detection_time_usage[(company_folder, file)] = time.time() - start_time

        result = {
            "is_loss_run": bool(llm_check) if llm_check else False,
            "method": "GPT" if llm_check else None
        }
        _log_detection_decision(company_folder, file, result)
        return dict_key, result

    # Collect all tasks (synchronous file discovery)
    tasks_info = []

    for company_folder in company_folders:
        company_path = _long_path(os.path.join(output_data_dir, company_folder))
        if not os.path.isdir(company_path):
            continue

        for subfolder in os.listdir(company_path):
            subfolder_path = os.path.join(company_path, subfolder)
            if not os.path.isdir(subfolder_path):
                continue

            # Only process PDF subfolders
            if subfolder.lower().endswith(".pdf"):
                json_path = os.path.join(subfolder_path, "page_response.json")
                tasks_info.append({
                    "company_folder": company_folder,
                    "file": subfolder,
                    "file_path": subfolder_path,
                    "json_path": json_path
                })

    # Process all files with parallelized LLM calls
    tasks = [process_file_with_semaphore(task_info) for task_info in tasks_info]
    results = await asyncio.gather(*tasks)

    for dict_key, result in results:
        loss_run_detection_dict[dict_key] = result

    return loss_run_detection_dict


def detect_loss_runs(output_data_dir, company_folders):
    """
    Wrapper to run async version synchronously.
    """
    return asyncio.run(detect_loss_runs_async(output_data_dir, company_folders))


if __name__ == "__main__":
    GROUND_TRUTH = {
        ('AAA_DOCX_TEST', 'TEST_LOSS.pdf'): {'is_loss_run': True, 'method': 'groundtruth'},
        ('Acosta Tractors', 'LRUN 2020-2021 IM Liberty val 051525.pdf'): {'is_loss_run': True, 'method': 'groundtruth'},
        ('Acosta Tractors', 'LRUN 2020-2023 Auto AL Liberty val 05152...'): {'is_loss_run': True, 'method': 'groundtruth'},
    }

    output_data_dir = "output_data"

    # Build list of company folders from immediate subdirectories of output_data
    company_folders = [
        name
        for name in os.listdir(output_data_dir)
        if os.path.isdir(os.path.join(output_data_dir, name))
    ]
    # # TEMP: only run on a single company subfolder
    # company_folders = ["AAA_TEST_NO_LOSS_RUNS"]

    # Run the detection
    loss_run_detection_dict = detect_loss_runs(output_data_dir, company_folders)

    # Summarize counts of True / False
    true_count = sum(
        1 for v in loss_run_detection_dict.values()
        if v.get("is_loss_run") is True
    )
    false_count = sum(
        1 for v in loss_run_detection_dict.values()
        if v.get("is_loss_run") is False
    )

    print(f"Total entries: {len(loss_run_detection_dict)}")
    print(f"is_loss_run=True: {true_count}")
    print(f"is_loss_run=False: {false_count}")

    # --- Count detected loss runs by method ---
    method_counts = {}
    for info in loss_run_detection_dict.values():
        if info.get("is_loss_run") is True:
            method = info.get("method") or "unknown"
            method_counts[method] = method_counts.get(method, 0) + 1

    print("\nDetected loss runs by method:")
    for method, count in sorted(method_counts.items()):
        print(f"  {method}: {count}")

    # --- Evaluation vs GROUND_TRUTH ---
    # Ground truth rule:
    # - If key is in GROUND_TRUTH -> actual is_loss_run = True
    # - If key is NOT in GROUND_TRUTH -> actual is_loss_run = False
    def gt_label(key):
        return key in GROUND_TRUTH

    tp = fp = tn = fn = 0

    for key, pred_info in loss_run_detection_dict.items():
        pred = bool(pred_info.get("is_loss_run"))
        actual = gt_label(key)

        if pred and actual:
            tp += 1
        elif pred and not actual:
            fp += 1
        elif not pred and not actual:
            tn += 1
        elif not pred and actual:
            fn += 1

    # Extra recall checks: ensure every ground-truth file is predicted and True
    missing_gt = []
    false_gt = []

    for gt_key in GROUND_TRUTH.keys():
        if gt_key not in loss_run_detection_dict:
            missing_gt.append(gt_key)
        else:
            if not bool(loss_run_detection_dict[gt_key].get("is_loss_run")):
                false_gt.append(gt_key)

    # For a strict recall definition on ground-truth positives only:
    strict_tp = len(GROUND_TRUTH) - len(missing_gt) - len(false_gt)
    strict_fn = len(missing_gt) + len(false_gt)
    strict_recall = strict_tp / (strict_tp + strict_fn) if (strict_tp + strict_fn) else 0.0

    precision = tp / (tp + fp) if (tp + fp) else 0.0
    accuracy = (tp + tn) / (tp + tn + fp + fn) if (tp + tn + fp + fn) else 0.0

    print("\nEvaluation vs GROUND_TRUTH:")
    print(f"TP={tp}, FP={fp}, TN={tn}, FN={fn}")
    print(f"Accuracy : {accuracy:.3f}")
    print(f"Precision: {precision:.3f}")
    print(f"Recall: {strict_recall:.3f}")

    # --- Detailed mistakes printout (FP and FN) ---
    print("\nMistakes (pred != actual):")
    for key, pred_info in loss_run_detection_dict.items():
        pred = bool(pred_info.get("is_loss_run"))
        actual = gt_label(key)  # True if in GROUND_TRUTH, else False
        if pred != actual:
            company, filename = key
            print(f"Company: {company} | File: {filename} | Pred: {pred} | Actual: {actual}")
