def _compute_cost(input_tokens, output_tokens, model_cfg):
    """
    Compute detection cost in dollars using model's per 1M token prices.
    """
    if not isinstance(model_cfg, dict):
        return 0.0
    input_millions = input_tokens / 1_000_000.0
    output_millions = output_tokens / 1_000_000.0
    return (
        input_millions * model_cfg.get("input_costs", 1.0)
        + output_millions * model_cfg.get("output_costs", 2.0)
    )

compute_cost = _compute_cost


# LibertyAIR Models
GPT_4_1 = {
    "model_name": "gpt-4.1-2025-04-14-us-data-zone",
    "api_version": "2024-10-21",
    "input_costs": 2.20,  # cost per 1M input tokens
    "output_costs": 8.80, # cost per 1M output tokens
}

GPT_4_1_MINI = {
    "model_name": "gpt-4.1-mini-2025-04-14-us-data-zone",
    "api_version": "2024-10-21",
    "input_costs": 0.44,  # cost per 1M input tokens
    "output_costs": 1.76, # cost per 1M output tokens
}

GPT_5 = {
    "model_name": "gpt-5-2025-08-07-us-data-zone",
    "api_version": "2024-12-01-preview",
    "input_costs": 1.38,  # cost per 1M input tokens
    "output_costs": 11.00, # cost per 1M output tokens
}

GPT_5_MINI = {
    "model_name": "gpt-5-mini-2025-08-07-us-data-zone",
    "api_version": "2024-12-01-preview",
    "input_costs": 0.28,  # cost per 1M input tokens
    "output_costs": 2.20,  # cost per 1M output tokens
}

GPT_5_NANO = {
    "model_name": "gpt-5-nano-2025-08-07-us-data-zone",
    "api_version": "2024-12-01-preview",
    "input_costs": 0.06,  # cost per 1M input tokens
    "output_costs": 0.44,  # cost per 1M output tokens
}

GPT_5_1 = {
    "model_name": "gpt-5.1-2025-11-13-us-data-zone",
    "api_version": "2024-10-21",
    "input_costs": 1.38,  # cost per 1M input tokens
    "output_costs": 11.00, # cost per 1M output tokens
}

GPT_5_2 = {
    "model_name": "gpt-5.2-2025-12-11-us-data-zone",
    "api_version": "2024-10-21",
    "input_costs": 1.925,  # cost per 1M input tokens
    "output_costs": 15.40, # cost per 1M output tokens
}

GPT_5_4 = {
    "model_name": "gpt-5.4-2026-03-05-us-data-zone",
    "api_version": "2024-10-21",
    "input_costs": 2.5,
    "output_costs": 15.00,
}

GEMINI_2_5_FLASH = {
    "model_name": "gemini-2.5-flash",
    "api_version": None,
    "input_costs": 0.30,  # cost per 1M input tokens
    "output_costs": 2.50,  # cost per 1M output tokens
}

GEMINI_2_5_FLASH_LITE = {
    "model_name": "gemini-2.5-flash-lite",
    "api_version": None,
    "input_costs": 0.10,  # cost per 1M input tokens
    "output_costs": 0.30,  # cost per 1M output tokens
}

GEMINI_2_5_PRO = {
    "model_name": "gemini-2.5-pro",
    "api_version": None,
    "input_costs": 1.25,  # cost per 1M input tokens
    "output_costs": 10.00, # cost per 1M output tokens
}

GEMINI_3_PRO_PREVIEW = {
    "model_name": "gemini-3-pro-preview",
    "api_version": None,
    "input_costs": 2.00,  # cost per 1M input tokens
    "output_costs": 12.00, # cost per 1M output tokens
}

GEMINI_3_FLASH_PREVIEW = {
    "model_name": "gemini-3-flash-preview",
    "api_version": None,
    "input_costs": 0.50,  # cost per 1M input tokens
    "output_costs": 3.00,  # cost per 1M output tokens
}
