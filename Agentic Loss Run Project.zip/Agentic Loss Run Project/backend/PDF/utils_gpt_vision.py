import os
from typing import List, Dict, Tuple, Any
import requests
import time
import random
import json
import base64
from mimetypes import guess_type
from dotenv import load_dotenv

def _long_path(path: str) -> str:
    """Prefix path with \\\\?\\ on Windows to support paths longer than 260 characters."""
    path = os.path.abspath(path)
    if os.name == 'nt' and not path.startswith('\\\\?\\'):
        path = '\\\\?\\' + path
    return path

try:
    import certifi  # type: ignore
except Exception:  # pragma: no cover - optional
    certifi = None  # type: ignore[assignment]

from pathlib import Path

# Load .env from backend/ or project root
for candidate in [
    Path(__file__).resolve().parent.parent / ".env",
    Path(__file__).resolve().parent.parent.parent / ".env",
    Path.cwd() / "backend" / ".env",
    Path.cwd() / ".env"
]:
    if candidate.is_file():
        load_dotenv(dotenv_path=candidate)

load_dotenv()

# Use system CA bundle or certifi if available
if 'REQUESTS_CA_BUNDLE' not in os.environ and certifi:
    try:
        os.environ['REQUESTS_CA_BUNDLE'] = certifi.where()
    except Exception:
        pass
AUTH_CLIENT_ID = os.getenv('AUTH_CLIENT_ID')
AUTH_CLIENT_SECRET = os.getenv('AUTH_CLIENT_SECRET')
TROUX_ID = os.getenv('TROUX_ID')
AUTH_GRANT_TYPE = "client_credentials"
SCOPE_URL = "87d1c382-6128-4150-aacf-bb624a9f2748/.default"
TOKEN_URL = "https://login.microsoftonline.com/08a83339-90e7-49bf-9075-957ccd561bf1/oauth2/v2.0/token"
USER = os.getenv('USER')

# NEW: Vertex/Gemini endpoint (kept configurable)
VERTEXAI_BASE_URL = os.getenv(
    "VERTEXAI_BASE_URL",
    "https://lm-cf-openai-api-tst01.apim.lmig.com/use-cases/vertexai/deployments",
)

def exponential_backoff(base_delay=2, max_delay=60, factor=2, jitter=True):
    delay = base_delay
    while True:
        yield delay
        if jitter:
            delay = min(max_delay, delay * factor) * (0.5 + random.random() / 2)
        else:
            delay = min(max_delay, delay * factor)

_TOKEN_CACHE: Dict[str, Any] = {}  # Stores {'access_token': str, 'expires_at': float}

def _resolve_ca_bundle() -> Any:
    """Return CA bundle path or boolean for requests verify parameter.
    
    Precedence:
    1. TRIAGE_CA_BUNDLE env (explicit path)
    2. REQUESTS_CA_BUNDLE env (standard requests override)
    3. certifi.where() if certifi installed
    4. True (system default)
    
    If TRIAGE_INSECURE_SKIP_TLS_VERIFY=true -> returns False (NOT recommended).
    """
    if os.getenv('TRIAGE_INSECURE_SKIP_TLS_VERIFY', '').lower() in {'1', 'true', 'yes', 'on'}:
        return False
    triage_bundle = os.getenv('TRIAGE_CA_BUNDLE')
    if triage_bundle and os.path.exists(triage_bundle):
        return triage_bundle
    req_bundle = os.getenv('REQUESTS_CA_BUNDLE')
    if req_bundle and os.path.exists(req_bundle):
        return req_bundle
    if certifi:
        try:
            return certifi.where()
        except Exception:
            pass
    return True  # fall back to system defaults

def _build_payload() -> str:
    return (
        f"client_id={AUTH_CLIENT_ID}&"
        f"client_secret={AUTH_CLIENT_SECRET}&"
        f"grant_type={AUTH_GRANT_TYPE}&"
        f"scope={SCOPE_URL}"
    )

def _fetch_token(force_refresh: bool = False) -> str:
    """Obtain and cache bearer token with expiration tracking.
    
    Args:
        force_refresh: If True, bypass cache and fetch new token
        
    Raises RuntimeError on irrecoverable auth issues.
    """
    # Check cache if not forcing refresh
    if not force_refresh and 'access_token' in _TOKEN_CACHE and 'expires_at' in _TOKEN_CACHE:
        # Check if token is still valid (with 5 min buffer)
        if time.time() < _TOKEN_CACHE['expires_at'] - 300:
            return _TOKEN_CACHE['access_token']
            
    if not AUTH_CLIENT_ID or not AUTH_CLIENT_SECRET:
        raise RuntimeError("Missing AUTH_CLIENT_ID or AUTH_CLIENT_SECRET environment variables for token retrieval.")
    payload = _build_payload()
    verify = _resolve_ca_bundle()
    try:
        resp = requests.post(TOKEN_URL, data=payload, timeout=15, verify=verify)
    except requests.exceptions.SSLError as ssl_err:  # surface guidance
        msg = (
            f"SSL certificate verification failed obtaining token: {ssl_err}. "
            "Provide a valid CA bundle via TRIAGE_CA_BUNDLE or set TRIAGE_INSECURE_SKIP_TLS_VERIFY=true (NOT recommended)."
        )
        raise RuntimeError(msg) from ssl_err
    except Exception as e:
        raise RuntimeError(f"Auth request failed: {e}") from e
    if resp.status_code >= 400:
        raise RuntimeError(f"Auth request error status={resp.status_code} body={resp.text[:300]}")
    try:
        data = resp.json()
    except Exception as e:
        raise RuntimeError(f"Failed to parse auth JSON: {e} body={resp.text[:300]}") from e
    token = data.get('access_token')
    if not token:
        raise RuntimeError("Auth response missing access_token")
        
    # Cache token with expiration (default to 3600 seconds if not provided)
    expires_in = data.get('expires_in', 3600)
    _TOKEN_CACHE['access_token'] = token
    _TOKEN_CACHE['expires_at'] = time.time() + expires_in
    
    return token

def gpt_vision_call(
    prompt,
    folder_with_images_path,
    model_name,
    api_version,
    messages=None,
    temperature=0,
    reasoning_effort=None
):

    if messages:
        data = {
            "user": USER,
            "messages": messages,
        }
    else:
        # Helper to extract page number from filename
        def get_page_num(fname):
            try:
                return int(os.path.basename(fname).split('-')[-1].split('.')[0])
            except Exception:
                return 0
                
        # Sort the image paths by page number
        folder_with_images_path = sorted(folder_with_images_path, key=get_page_num)
        
        # Encodes image to format for prompt
        def encode_image(image_path):
            mime_type, _ = guess_type(image_path)
            if mime_type is None:
                mime_type = 'application/octet-stream'
                
            with open(_long_path(image_path), "rb") as image_file:
                base64_encoded_data = base64.b64encode(image_file.read()).decode('utf-8')
                
            return f"data:{mime_type};base64,{base64_encoded_data}"
            
        image_contents = []
        for i, image_path in enumerate(folder_with_images_path):
            image_contents.append({"type": "text", "text": f"Below is Page. No.{i + 1}"})
            image_contents.append({
                "type": "image_url",
                "image_url": {
                    "url": encode_image(image_path),
                    "detail": "high"
                }
            })
            
    data = {
        "messages": [
            {"role": "system", "content": "You are a helpful underwriter tasked with extracting information from insurance documents."},
            {"role": "user", "content": [{"type": "text", "text": prompt}, *image_contents]},
        ]
    }
    if USER:
        data["user"] = USER
    
    # Only set temperature if model is NOT an o-series or gpt-5 model
    is_reasoning_model = any(m in str(model_name).lower() for m in ["o1", "o3", "reasoning"])
    if not is_reasoning_model and "gpt-5" not in str(model_name).lower():
        data["temperature"] = temperature
        
    # Set reasoning level ONLY for reasoning models (o1/o3)
    if reasoning_effort is not None and is_reasoning_model:
        data["reasoning_effort"] = reasoning_effort
        
    azure_key = os.getenv("AZURE_OPENAI_API_KEY")
    azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    azure_deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
    azure_api_version = os.getenv("AZURE_OPENAI_API_VERSION") or api_version or "2024-10-21"
    
    deployment_to_call = azure_deployment if azure_deployment else model_name
    
    if azure_key and azure_endpoint:
        base_endpoint = azure_endpoint.rstrip("/")
        url = f"{base_endpoint}/openai/deployments/{deployment_to_call}/chat/completions?api-version={azure_api_version}"
        headers = {
            "Content-Type": "application/json",
            "api-key": azure_key
        }
        retries = exponential_backoff(base_delay=3, max_delay=30)
        max_azure_attempts = 4
        for attempt in range(max_azure_attempts):
            try:
                ca_bundle = _resolve_ca_bundle()
                response = requests.post(url, headers=headers, json=data, verify=ca_bundle, timeout=180)
                response.raise_for_status()
                resp_json = response.json() or {}
                usage = resp_json.get("usage", {}) or {}
                in_tok = usage.get("prompt_tokens", 0) or 0
                out_tok = usage.get("completion_tokens", 0) or 0
                out_text = resp_json.get("choices", [{}])[0].get("message", {}).get("content", "")
                return out_text, in_tok, out_tok
            except requests.exceptions.HTTPError as e:
                status_code = e.response.status_code if e.response is not None else None
                err_details = e.response.text if e.response is not None else str(e)
                print(f"[Azure Vision Call HTTP {status_code}] Attempt {attempt+1}/{max_azure_attempts}: {err_details[:200]}")
                if attempt < max_azure_attempts - 1 and (status_code in [429, 500, 502, 503, 504] or status_code is None):
                    delay = next(retries)
                    print(f"[Azure Retry] Transient error {status_code}. Retrying in {delay:.1f}s...")
                    time.sleep(delay)
                    continue
                return "", 0, 0
            except (requests.exceptions.Timeout, requests.exceptions.ConnectionError) as e:
                print(f"[Azure Vision Call Warning] Timeout/Connection error on attempt {attempt+1}/{max_azure_attempts}: {e}")
                if attempt < max_azure_attempts - 1:
                    delay = next(retries)
                    print(f"[Azure Retry] Retrying connection in {delay:.1f}s...")
                    time.sleep(delay)
                    continue
                return "", 0, 0
            except Exception as e:
                print(f"[Azure Vision Call Error] {e}")
                return "", 0, 0
        return "", 0, 0

    # Standard direct OpenAI API Key support
    openai_key = os.getenv("OPENAI_API_KEY")
    if openai_key:
        url = "https://api.openai.com/v1/chat/completions"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {openai_key}"
        }
        std_model = "gpt-4o"
        data_openai = dict(data)
        data_openai["model"] = std_model
        data_openai.pop("user", None)
        try:
            ca_bundle = _resolve_ca_bundle()
            response = requests.post(url, headers=headers, json=data_openai, verify=ca_bundle, timeout=180)
            response.raise_for_status()
            resp_json = response.json() or {}
            usage = resp_json.get("usage", {}) or {}
            in_tok = usage.get("prompt_tokens", 0) or 0
            out_tok = usage.get("completion_tokens", 0) or 0
            out_text = resp_json.get("choices", [{}])[0].get("message", {}).get("content", "")
            return out_text, in_tok, out_tok
        except Exception as e:
            print(f"[Direct OpenAI Vision Call Error] {e}")
            return "", 0, 0
            
    url = f"https://test-libertyair.lmig.com/use-cases/openai/deployments/{model_name}/chat/completions?api-version={api_version}"
    
    retries = exponential_backoff()
    token_refreshed = False
    
    for attempt in range(5):
        # Lazy token retrieval (avoids failing at import time)
        try:
            token = _fetch_token(force_refresh=token_refreshed)
        except Exception as e:
            raise RuntimeError(f"Unable to obtain auth token: {e}")
            
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
            "user": TROUX_ID
        }
        
        try:
            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()
            resp_json = response.json() or {}
            
            usage = resp_json.get("usage", {}) or {}
            input_tokens = usage.get("prompt_tokens", 0) or 0
            output_tokens = usage.get("completion_tokens", 0) or 0
            
            output = (
                resp_json.get("choices", [{}])[0]
                .get("message", {})
                .get("content", "")
            )
            
            return output, input_tokens, output_tokens
            
        except requests.exceptions.HTTPError as e:
            status = e.response.status_code if e.response is not None else None
            
            # On 403 or 500-series, try refreshing token once
            if status in (403, 500) and not token_refreshed:
                print(f"Vision API call failed with error: {e}. Refreshing token and retrying...")
                token_refreshed = True
                continue
                
            delay = next(retries)
            print(f"Vision API call failed with HTTP {status}: {e}. Retrying in {delay:.2f} seconds...")
            time.sleep(delay)
        except (requests.exceptions.ConnectionError, ConnectionResetError) as e:
            # Handle connection issues specially - try token refresh if not done yet
            if not token_refreshed:
                print(f"[{gpt_vision_call.__name__}] Connection error: {e}. Refreshing token and retrying...")
                token_refreshed = True
                continue
                
            delay = next(retries)
            print(f"Vision API call failed with connection error: {e}. Retrying in {delay:.2f} seconds...")
            time.sleep(delay)
        except requests.exceptions.Timeout as e:
            delay = next(retries)
            print(f"Vision API call timed out: {e}. Retrying in {delay:.2f} seconds...")
            time.sleep(delay)
        except Exception as e:
            delay = next(retries)
            print(f"Vision API call failed with error: {e}. Retrying in {delay:.2f} seconds...")
            time.sleep(delay)
            
    print(f"Vision API call failed after {5} attempts")
    return "", 0, 0
    
def gemini_vision_call(
    prompt,
    folder_with_images_path,
    model,
    api_version=None,
    image_detail='high',
    thinking_budget=None,
    thinking_level=None,
):
    """
    Call the Gemini vision model with a textual prompt and an ordered list of image files.
    
    Parameters
    ----------
    prompt : str
        The user instruction or question describing what to extract from the images.
    folder_with_images_path : list[str]
        List of paths to image files that represent pages of the document.
    model : str
        Name of the Gemini model deployment to call (e.g., "gemini-2.5-flash").
    api_version : str, optional
        API version string (not used for Gemini but kept for interface consistency).
    image_detail : str
        How detailed the image processing will be: 'high' or 'low'. (not used for Gemini)
    thinking_budget : int, optional
        Token budget for thinking (used by Gemini 2.5 models): e.g., 1000, 3000, 10000.
    thinking_level : str, optional
        Thinking level for Gemini 3+ models: 'LOW', 'MEDIUM', or 'HIGH'.
        Takes precedence over thinking_budget if both are provided.
        
    Returns
    -------
    tuple[str, int, int]
        A tuple of (output_text, input_tokens, output_tokens).
        If all retries fail, returns ("", 0, 0).
    """
    # ...existing code...
    
    # Helper to extract page number from filename
    def get_page_num(fname):
        try:
            return int(os.path.basename(fname).split('-')[-1].split('.')[0])
        except Exception:
            return 0
            
    # Sort the image paths by page number
    folder_with_images_path = sorted(folder_with_images_path, key=get_page_num)
    
    # Build image parts for Gemini (inline base64 image data)
    image_parts = []
    for image_path in folder_with_images_path:
        mime_type, _ = guess_type(image_path)
        if mime_type is None:
            mime_type = 'application/octet-stream'
        with open(_long_path(image_path), "rb") as image_file:
            b64_data = base64.b64encode(image_file.read()).decode('utf-8')
        image_parts.append({
            "inline_data": {
                "mime_type": mime_type,
                "data": b64_data,
            }
        })
        
    # Full contents: text prompt + all images as parts
    data = {
        "contents": [
            {
                "role": "user",
                "parts": [
                    {"text": prompt},
                    *image_parts,
                ],
            }
        ]
    }
    
    # Add thinking config based on model type:
    # - Gemini 3+ models use thinking_level ("LOW", "MEDIUM", "HIGH")
    # - Gemini 2.5 models use thinking_budget (integer token budget)
    if thinking_level:
        data["generationConfig"] = {
            "thinkingConfig": {
                "thinking_level": thinking_level
            }
        }
    elif thinking_budget is not None:
        data["generationConfig"] = {
            "thinkingConfig": {
                "thinking_budget": thinking_budget
            }
        }
        
    url = f"{VERTEXAI_BASE_URL}/{model}"
    
    def _parse_gemini_response(resp_json):
        output_text = ""
        try:
            candidates = resp_json.get("candidates", [])
            if candidates:
                parts = (
                    candidates[0]
                    .get("content", {})
                    .get("parts", [])
                )
                output_text = "".join(
                    p.get("text", "") for p in parts if isinstance(p, dict)
                )
        except Exception:
            output_text = str(resp_json)
            
        usage = resp_json.get("usageMetadata", {}) or {}
        input_tokens = usage.get("promptTokenCount", 0) or 0
        candidates_tokens = usage.get("candidatesTokenCount", 0) or 0
        thoughts_tokens = usage.get("thoughtsTokenCount", 0) or 0
        output_tokens = candidates_tokens + thoughts_tokens
        
        return output_text, input_tokens, output_tokens

    # Standard Google Gemini API Key support
    gemini_key = os.getenv("GEMINI_API_KEY")
    if gemini_key:
        std_model = "gemini-1.5-flash"
        if "pro" in str(model).lower() or "2.5" in str(model).lower():
            std_model = "gemini-1.5-pro"
        direct_gemini_url = f"https://generativelanguage.googleapis.com/v1beta/models/{std_model}:generateContent?key={gemini_key}"
        headers = {"Content-Type": "application/json"}
        try:
            ca_bundle = _resolve_ca_bundle()
            response = requests.post(direct_gemini_url, headers=headers, json=data, verify=ca_bundle, timeout=120)
            response.raise_for_status()
            resp_json = response.json() or {}
            return _parse_gemini_response(resp_json)
        except Exception as e:
            print(f"[Direct Gemini API Call Error] {e}")

    retries = exponential_backoff()
    token_refreshed = False
    max_attempts = 5
    
    for attempt in range(max_attempts):
        # Reuse existing OAuth token flow
        try:
            token = _fetch_token(force_refresh=token_refreshed)
        except Exception as e:
            raise RuntimeError(f"Unable to obtain auth token for Gemini call: {e}")
            
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
            "user": TROUX_ID,
        }
        
        try:
            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()
            resp_json = response.json() or {}
            output_text, input_tokens, output_tokens = _parse_gemini_response(resp_json)
            return output_text, input_tokens, output_tokens
            
        except requests.exceptions.HTTPError as e:
            status = e.response.status_code if e.response is not None else None
            
            # mirror gpt_vision_call behavior: refresh token once on 403/5xx
            if status in (403, 500) and not token_refreshed:
                print(f"Gemini Vision API call failed with error: {e}. Refreshing token and retrying...")
                token_refreshed = True
                continue
                
            if attempt == max_attempts - 1:
                break
                
            delay = next(retries)
            print(f"Gemini Vision API call failed with HTTP {status}: {e}. Retrying in {delay:.2f} seconds...")
            time.sleep(delay)
        except (requests.exceptions.ConnectionError, ConnectionResetError) as e:
            if not token_refreshed:
                print(f"[{gemini_vision_call.__name__}] Connection error: {e}. Refreshing token and retrying...")
                token_refreshed = True
                continue
                
            if attempt == max_attempts - 1:
                break
                
            delay = next(retries)
            print(f"Gemini Vision API call failed with connection error: {e}. Retrying in {delay:.2f} seconds...")
            time.sleep(delay)
        except requests.exceptions.Timeout as e:
            if attempt == max_attempts - 1:
                break
                
            delay = next(retries)
            print(f"Gemini Vision API call timed out: {e}. Retrying in {delay:.2f} seconds...")
            time.sleep(delay)
        except Exception as e:
            if attempt == max_attempts - 1:
                break
                
            delay = next(retries)
            print(f"Gemini Vision API call failed with error: {e}. Retrying in {delay:.2f} seconds...")
            time.sleep(delay)
            
    print(f"Gemini Vision API call failed after {max_attempts} attempts")
    return "", 0, 0
