import os
import json
import pandas as pd
import time
import tiktoken
import asyncio
from tqdm import tqdm
from prompts import CHUNK_DETECTION_PROMPT
from utils_gpt import gpt_call
import models
from metrics import record_stage


def _long_path(path: str) -> str:
    """Prefix path with \\\\?\\ on Windows to support paths longer than 260 characters."""
    path = os.path.abspath(path)
    if os.name == 'nt' and not path.startswith('\\\\?\\'):
        path = '\\\\?\\' + path
    return path


CHUNK_DETECTION_MODEL = models.GPT_5_MINI

_chunk_token_usage = {}  # key: (company, pdf_name) -> {"input": int, "output": int}
_chunk_time_usage = {}  # key: (company, pdf_name) -> float seconds


def image_token_calc(width: int, height: int, detail: str = "high") -> int:
    """
    Function to calculate how many tokens an image will use for GPT-4.1 VLM
    """
    if detail == "low":
        return 85

    # Scale down to fit within a 2048 x 2048 square if necessary
    if width > 2048 or height > 2048:
        max_size = 2048
        aspect_ratio = width / height
        if aspect_ratio > 1:
            width = max_size
            height = int(max_size / aspect_ratio)
        else:
            height = max_size
            width = int(max_size * aspect_ratio)

    # Resize such that the shortest side is 768px if the original dimensions exceed 768px
    min_size = 768
    aspect_ratio = width / height
    if width > min_size and height > min_size:
        if aspect_ratio > 1:
            height = min_size
            width = int(min_size * aspect_ratio)
        else:
            width = min_size
            height = int(min_size / aspect_ratio)

    tiles_width = -(-width // 512) # Ceiling division
    tiles_height = -(-height // 512)
    return 85 + 170 * (tiles_width * tiles_height)


def text_token_calc(text: str, model_name: str = "gpt-4.1") -> int:
    """Function to calculate how many tokens a text will use for a given model."""
    try:
        encoding = tiktoken.encoding_for_model(model_name)
    except KeyError:
        encoding = tiktoken.get_encoding("cl100k_base")
        print(f"Warning: Model '{model_name}' not found. Using 'cl100k_base' encoding as a fallback.")

    num_tokens = len(encoding.encode(text))
    return num_tokens


def _load_page_texts(pdf_subfolder: str) -> dict:
    """Load OCR text mapping from page_response.json: {page_num:int -> text:str}"""
    pdf_subfolder = _long_path(pdf_subfolder)
    page_texts = {}
    page_response_path = os.path.join(pdf_subfolder, "page_response.json")
    if not os.path.exists(page_response_path):
        return page_texts

    with open(page_response_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    for k, v in data.items():
        try:
            page_num = int(k)
        except ValueError:
            continue
        if v is None or (isinstance(v, float) and pd.isna(v)):
            v = ""
        page_texts[page_num] = str(v)
    return page_texts


def _llm_choose_chunk_end_page(
    *,
    candidate_end_pages: list[int],
    page_texts: dict,
    end_page: int,
    usage_key: tuple | None = None,  # (company, pdf_name)
) -> int:
    """
    Ask LLM to select the best chunk end page among candidates.
    Provide OCR context for end_page and up to 4 pages before it (or fewer).
    """
    if not candidate_end_pages:
        raise ValueError("candidate_end_pages cannot be empty")

    # Provide only the pages the prompt needs: end page + up to 4 pages before
    start_context_page = max(1, end_page - 4)
    context_pages = {
        str(p): page_texts.get(p, "")
        for p in range(start_context_page, end_page + 1)
    }

    prompt = CHUNK_DETECTION_PROMPT.format(
        candidate_end_pages=candidate_end_pages,
        pages_ocr_json=json.dumps(context_pages, ensure_ascii=False),
    )

    raw, input_tokens, output_tokens = gpt_call(prompt,
                                                CHUNK_DETECTION_MODEL['model_name'],
                                                CHUNK_DETECTION_MODEL['api_version'])

    # Track token usage if key provided
    if usage_key is not None:
        usage = _chunk_token_usage.setdefault(usage_key, {"input": 0, "output": 0})
        usage["input"] += input_tokens or 0
        usage["output"] += output_tokens or 0

    try:
        parsed = json.loads(raw)
        chosen = int(parsed["chunk_end_page"])
    except Exception:
        # On any parse/format failure, fall back conservatively to the latest page (max tokens utilization)
        return max(candidate_end_pages)

    if chosen not in candidate_end_pages:
        return max(candidate_end_pages)

    return chosen


def find_context_limit_page(
    pdf_subfolder, start_page=1, prompt_tokens=2500, token_limit=10000, max_images=50
):
    """
    Find the maximum page number that can be processed without exceeding token_limit or max_images.
    """
    pdf_subfolder = _long_path(pdf_subfolder)

    def get_page_num(fname):
        try:
            return int(fname.split('-')[-1].split('.')[0])
        except Exception:
            return 0

    all_image_paths = [
        os.path.join(pdf_subfolder, fname)
        for fname in sorted(
            [f for f in os.listdir(pdf_subfolder) if f.lower().endswith(('.jpg', '.jpeg', '.png'))],
            key=get_page_num
        )
    ]

    if not all_image_paths:
        print(f"No images found in {pdf_subfolder}")
        return None, 0

    image_paths = [path for path in all_image_paths if get_page_num(os.path.basename(path)) >= start_page]

    if not image_paths:
        print(f"No images found from page {start_page} onwards in {pdf_subfolder}")
        return None, 0

    page_texts = _load_page_texts(pdf_subfolder)

    total_tokens = prompt_tokens
    last_valid_page = None
    images_processed = 0

    for image_path in image_paths:
        page_num = get_page_num(os.path.basename(image_path))

        images_processed += 1
        if images_processed > max_images:
            break

        from PIL import Image
        with Image.open(image_path) as img:
            width, height = img.size
            image_tokens = image_token_calc(width, height, detail="high")

        text = page_texts.get(page_num, "")
        if text is None or (isinstance(text, float) and pd.isna(text)):
            text = ""
        else:
            text = str(text)
        text_tokens = text_token_calc(text) if text else 0

        page_total_tokens = image_tokens + text_tokens
        if total_tokens + page_total_tokens > token_limit:
            break

        total_tokens += page_total_tokens
        last_valid_page = page_num

    return last_valid_page, total_tokens


def find_context_limit_page_refined(
    pdf_subfolder: str,
    start_page: int = 1,
    prompt_tokens: int = 2500,
    token_limit: int = 10000,
    max_images: int = 50,
    candidate_backoff: int = 4,
    usage_key: tuple | None = None,  # (company, pdf_name)
):
    """
    1) Compute the max end page by token/image budget (existing logic).
    2) Ask LLM to choose the BEST chunk boundary among nearby candidate pages,
       using OCR context for [end_page-4 .. end_page].
    """
    max_page, total_tokens = find_context_limit_page(
        pdf_subfolder,
        start_page=start_page,
        prompt_tokens=prompt_tokens,
        token_limit=token_limit,
        max_images=max_images,
    )

    if max_page is None:
        return None, total_tokens

    def get_page_num(fname):
        try:
            return int(fname.split("-")[-1].split(".")[0])
        except Exception:
            return 0

    all_image_pages = [
        get_page_num(f)
        for f in os.listdir(pdf_subfolder)
        if f.lower().endswith((".jpg", ".jpeg", ".png"))
    ]
    last_doc_page = max(all_image_pages) if all_image_pages else None

    if last_doc_page is not None and max_page >= last_doc_page:
        return max_page, total_tokens

    # Can't choose an end page earlier than start_page
    low = max(start_page, max_page - candidate_backoff)
    candidate_end_pages = list(range(low, max_page + 1))

    # If we only have one candidate, no need to call LLM
    if len(candidate_end_pages) == 1:
        return max_page, total_tokens

    page_texts = _load_page_texts(pdf_subfolder)
    chosen_end_page = _llm_choose_chunk_end_page(
        candidate_end_pages=candidate_end_pages,
        page_texts=page_texts,
        end_page=max_page,
        usage_key=usage_key,
    )

    return chosen_end_page, total_tokens


def _format_chunk_decision(company: str, pdf_name: str, pages_to_join: list[list[int]]) -> str:
    """
    Build the same output as _log_chunk_decision, but return as a string.
    (We still call record_stage here to keep side-effects identical.)
    """
    key = (company, pdf_name)
    elapsed = _chunk_time_usage.get(key, 0.0)
    usage = _chunk_token_usage.get(key, {"input": 0, "output": 0})

    if usage["input"] or usage["output"]:
        cost = models._compute_cost(
            usage["input"],
            usage["output"],
            CHUNK_DETECTION_MODEL,
        )
    else:
        cost = 0.0

    record_stage(
        company,
        pdf_name,
        stage="chunk_detection",
        time_seconds=elapsed,
        input_tokens=usage["input"],
        output_tokens=usage["output"],
        cost=cost,
    )

    lines = [
        f"    Company: {company}",
        f"    ✅ Chunking: {pdf_name}",
        f"      Page groups: {pages_to_join}",
        f"      ⏱️ Chunking Time: {elapsed:.2f} seconds",
        f"      💲 Chunking Cost: ${cost:.6f}",
    ]
    return "\n".join(lines)


def _is_pdf_subfolder_eligible(
    *,
    company_path: str,
    company_folder: str,
    subfolder: str,
    is_file_loss_run_dict: dict,
) -> bool:
    if subfolder in ["csvs", "Excel_sheets"]:
        return False

    key = (company_folder, subfolder)
    if key in is_file_loss_run_dict:
        info = is_file_loss_run_dict[key]
        if info.get("is_loss_run") is False:
            return False

    subfolder_path = os.path.join(company_path, subfolder)
    if not os.path.isdir(subfolder_path):
        return False

    image_files = [
        f for f in os.listdir(subfolder_path)
        if f.lower().endswith((".jpg", ".jpeg", ".png"))
    ]
    if not image_files:
        return False

    return True


def _process_single_pdf_subfolder(
    *,
    company_path: str,
    company_folder: str,
    subfolder: str,
    use_llm_chunking: bool = True,
):
    """
    Synchronous worker: process one PDF subfolder and return (key, pages_to_join, log_text) or None.
    """
    subfolder_path = _long_path(os.path.join(company_path, subfolder))

    image_files = [
        f for f in os.listdir(subfolder_path)
        if f.lower().endswith((".jpg", ".jpeg", ".png"))
    ]
    total_pages = len(image_files)

    pages_to_join = []
    current_start_page = 1

    usage_key = (company_folder, subfolder)
    _chunk_token_usage.setdefault(usage_key, {"input": 0, "output": 0})
    start_time = time.time()

    while current_start_page <= total_pages:
        if use_llm_chunking:
            max_page, _total_tokens = find_context_limit_page_refined(
                subfolder_path,
                start_page=current_start_page,
                usage_key=usage_key,
            )
        else:
            max_page, _total_tokens = find_context_limit_page(
                subfolder_path,
                start_page=current_start_page,
            )

        if max_page is None:
            # Keep the warning, but return it to be printed later (avoids interleaving).
            warn = f"          ⚠️ Warning: Could not process any pages starting from page {current_start_page}"
            _chunk_time_usage[usage_key] = time.time() - start_time
            log_text = "\n".join([f"    Company: {company_folder}", warn])
            return (company_folder, subfolder), pages_to_join, log_text

        pages_to_join.append(list(range(current_start_page, max_page + 1)))

        if max_page >= total_pages:
            break

        current_start_page = max_page + 1

    _chunk_time_usage[usage_key] = time.time() - start_time

    if pages_to_join:
        log_text = _format_chunk_decision(company_folder, subfolder, pages_to_join)
        return (company_folder, subfolder), pages_to_join, log_text

    return None


async def _process_company_async(
    *,
    output_data_dir: str,
    company_folder: str,
    is_file_loss_run_dict: dict,
    max_workers: int = 8,
    use_llm_chunking: bool = True,
):
    """
    Returns:
      pages_to_join_dict_part: dict[(company,pdf)] -> pages_to_join
      logs: list[str] (one per processed pdf, printed after company completes)
    """
    company_path = os.path.join(output_data_dir, company_folder)
    if not os.path.isdir(company_path):
        return {}, []

    eligible = [
        sf for sf in os.listdir(company_path)
        if _is_pdf_subfolder_eligible(
            company_path=company_path,
            company_folder=company_folder,
            subfolder=sf,
            is_file_loss_run_dict=is_file_loss_run_dict,
        )
    ]

    pages_part = {}
    logs = []

    sem = asyncio.Semaphore(max_workers)

    async def run_one(subfolder: str):
        async with sem:
            return await asyncio.to_thread(
                _process_single_pdf_subfolder,
                company_path=company_path,
                company_folder=company_folder,
                subfolder=subfolder,
                use_llm_chunking=use_llm_chunking,
            )

    tasks = [asyncio.create_task(run_one(sf)) for sf in eligible]

    with tqdm(total=len(tasks), desc=f"Chunking PDFs | {company_folder}", unit="pdf") as pbar:
        for fut in asyncio.as_completed(tasks):
            item = await fut
            pbar.update(1)
            if item is None:
                continue
            k, pages_to_join, log_text = item
            if pages_to_join:
                pages_part[k] = pages_to_join
            if log_text:
                logs.append(log_text)

    return pages_part, logs


def determine_page_cutoffs(output_data_dir, company_folders, is_file_loss_run_dict, use_llm_chunking=True):
    """
    Detect if any PDF pages need to be split based on token/image limits and store which pages need to be joined.

    Parallelizes per-company PDF processing (max 8 concurrent) and shows a tqdm bar per company.
    Prints per-PDF results only after the company's PDFs are fully processed.
    """
    pages_to_join_dict = {}

    async def runner():
        for company_folder in company_folders:
            pages_part, logs = await _process_company_async(
                output_data_dir=output_data_dir,
                company_folder=company_folder,
                is_file_loss_run_dict=is_file_loss_run_dict,
                max_workers=8,
                use_llm_chunking=use_llm_chunking,
            )
            pages_to_join_dict.update(pages_part)

            # Print company results after progress bar completes
            for block in logs:
                print(block)

    # Keep sync API unchanged
    try:
        asyncio.run(runner())
    except RuntimeError:
        loop = asyncio.get_event_loop()
        loop.run_until_complete(runner())

    return pages_to_join_dict
