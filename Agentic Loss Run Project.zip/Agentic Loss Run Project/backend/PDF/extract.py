import os
import time
import json
import pandas as pd
from tqdm import tqdm
import asyncio
from utils_gpt import gpt_call
from utils_gpt_vision import gpt_vision_call
from prompts import (
    CLAIM_LEVEL_PDF_DOCX_PROMPT_BACKGROUND,
    CLAIM_LEVEL_EXTRACTION_PROMPT,
    NO_CLAIMS_PDF_DOCX_PROMPT_BACKGROUND,
    NO_CLAIMS_EXTRACTION_PROMPT
)
import models
from metrics import record_stage
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from Post_Processing.constants import CLAIM_LEVEL_VALID_JSON_FIELDS, NO_CLAIMS_VALID_JSON_FIELDS


def _long_path(path: str) -> str:
    """Prefix path with \\\\?\\ on Windows to support paths longer than 260 characters."""
    path = os.path.abspath(path)
    if os.name == 'nt' and not path.startswith('\\\\?\\'):
        path = '\\\\?\\' + path
    return path

# Models to use for extraction
_dep_name = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o")
PDF_DOCX_EXTRACTION_MODEL = {
    "model_name": _dep_name,
    "api_version": os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21"),
    "input_costs": 2.50,
    "output_costs": 10.00
}
PDF_DOCX_EXTRACTION_MODEL_REASONING = 'medium'

# Max Concurrency
MAX_CONCURRENCY = 8


def _all_required_fields_present(records, required_fields):
    return all(
        isinstance(r, dict) and all(field in r for field in required_fields)
        for r in records
    )


def _null_record(required_fields):
    """
    Build a single placeholder record containing all required fields set to None.
    This ensures pandas creates the expected columns even when the model returns [].
    """
    return {field: None for field in required_fields}


def _extract_json_with_retries(call_fn, required_fields, max_attempts=5):
    """
    call_fn: () -> (str, int, int) (returns model text output and token counts)
    Returns:
        (list[dict] | None, int, int) -> (records, total_input_tokens, total_output_tokens)
    """
    total_input_tokens = 0
    total_output_tokens = 0

    for attempt in range(max_attempts):
        result, input_tokens, output_tokens = call_fn()
        total_input_tokens += input_tokens or 0
        total_output_tokens += output_tokens or 0

        try:
            parsed = json.loads(result)

            # If model indicates "no records", return one empty record with required fields as nulls
            if parsed == []:
                return [_null_record(required_fields)], total_input_tokens, total_output_tokens

            if isinstance(parsed, dict):
                parsed = [parsed]

            if isinstance(parsed, list) and _all_required_fields_present(parsed, required_fields):
                return parsed, total_input_tokens, total_output_tokens

        except json.JSONDecodeError:
            print(f"            [ERROR] OUTPUT NOT JSON (attempt {attempt+1}/{max_attempts})")

    return None, total_input_tokens, total_output_tokens


def _append_records(outputs, records, company_folder, file_path, extra_fields=None):
    """
    Mutates outputs by appending enriched records.
    """
    extra_fields = extra_fields or {}
    for r in records:
        r["AccountName"] = company_folder
        r["file_path"] = file_path
        r.update(extra_fields)
        outputs.append(r)


async def _process_pdf_page_group_async(group, output_dir, page_text_map, subfolder, PDF_DOCX_PROMPT_BACKGROUND, EXTRACTION_PROMPT, VALID_EXTRACTION_JSON_FIELDS):
    """Process a single PDF page group asynchronously"""
    if not (group and isinstance(group, list)):
        return None, 0, 0

    image_paths = []
    input_json = {}

    for page_num in group:
        img_path = [
            f for f in os.listdir(_long_path(output_dir))
            if f.lower().endswith((".jpg", ".jpeg", ".png")) and f"-{page_num}." in f
        ]
        if img_path:
            image_paths.append(_long_path(os.path.join(output_dir, img_path[0])))

        page_key = str(page_num)
        if page_key in page_text_map and page_text_map[page_key]:
            input_json[page_key] = page_text_map[page_key]

    if not image_paths:
        print(f"         X No images found for joined pages {group} in {subfolder}")
        return None, 0, 0

    background = PDF_DOCX_PROMPT_BACKGROUND.format(file_name=subfolder)
    prompt_instance = EXTRACTION_PROMPT.format(
        background=background,
        input=json.dumps(input_json)
    )

    # Run the blocking API call in a thread pool
    loop = asyncio.get_event_loop()
    json_result, in_toks, out_toks = await loop.run_in_executor(
        None,
        lambda: _extract_json_with_retries(
            call_fn=lambda: gpt_vision_call(
                prompt_instance,
                image_paths,
                PDF_DOCX_EXTRACTION_MODEL['model_name'],
                PDF_DOCX_EXTRACTION_MODEL['api_version'],
                reasoning_effort=PDF_DOCX_EXTRACTION_MODEL_REASONING
            ),
            required_fields=VALID_EXTRACTION_JSON_FIELDS,
            max_attempts=5
        )
    )

    return json_result, in_toks, out_toks


def extract_loss_runs(output_data_dir,
                      company_folders,
                      pages_to_join_dict,
                      is_file_loss_run_dict,
                      PDF_DOCX_PROMPT_BACKGROUND,
                      EXTRACTION_PROMPT,
                      VALID_EXTRACTION_JSON_FIELDS,
                      max_concurrent_tasks=MAX_CONCURRENCY):
    """
    Extract structured data from insurance loss run PDF/DOCX documents.
    Uses async processing for parallel page processing.

    Parameters
    ----------
    ...existing parameters...
    max_concurrent_tasks : int, optional
        Maximum number of concurrent API calls (default: 10)
    """
    # Wrapper to run async code
    return asyncio.run(_extract_loss_runs_async(
        output_data_dir,
        company_folders,
        pages_to_join_dict,
        is_file_loss_run_dict,
        PDF_DOCX_PROMPT_BACKGROUND,
        EXTRACTION_PROMPT,
        VALID_EXTRACTION_JSON_FIELDS,
        max_concurrent_tasks
    ))


async def _extract_loss_runs_async(output_data_dir,
                                   company_folders,
                                   pages_to_join_dict,
                                   is_file_loss_run_dict,
                                   PDF_DOCX_PROMPT_BACKGROUND,
                                   EXTRACTION_PROMPT,
                                   VALID_EXTRACTION_JSON_FIELDS,
                                   max_concurrent_tasks):
    """Async implementation of extract_loss_runs"""
    outputs = []
    outputs_lock = asyncio.Lock()  # protect shared list during concurrent appends

    semaphore = asyncio.Semaphore(max_concurrent_tasks)

    async def process_with_semaphore(coro):
        async with semaphore:
            return await coro

    def _company_file_plan(company_folder: str):
        """
        Returns a list of work items:
        ("pdf", subfolder, subfolder_path)
        Only includes PDF items not filtered out by is_file_loss_run_dict.
        """
        company_path = os.path.join(output_data_dir, company_folder)
        items = []
        if not os.path.isdir(_long_path(company_path)):
            return items

        for subfolder in os.listdir(_long_path(company_path)):
            subfolder_path = os.path.join(company_path, subfolder)
            if not os.path.isdir(_long_path(subfolder_path)):
                continue

            # Skip non-PDF folders (csvs, Excel_sheets, etc.)
            if not subfolder.lower().endswith(".pdf"):
                continue

            det_info = is_file_loss_run_dict.get((company_folder, subfolder))
            if det_info and det_info.get("is_loss_run") is False:
                continue

            items.append(("pdf", subfolder, subfolder_path))

        return items

    async def _process_pdf_folder(company_folder: str, subfolder: str, subfolder_path: str):
        start_time = time.time()
        pdf_input_tokens = 0
        pdf_output_tokens = 0
        status = "ok"
        err = None

        pages_to_join = pages_to_join_dict.get((company_folder, subfolder), [])

        json_path = _long_path(os.path.join(subfolder_path, "page_response.json"))
        if not os.path.isfile(json_path):
            status = "error"
            err = "page_response.json not found"
            pages_to_join = []

        page_text_map = None
        if status != "error":
            try:
                with open(json_path, "r", encoding="utf-8") as f:
                    page_text_map = json.load(f)
            except json.JSONDecodeError as e:
                status = "error"
                err = f"Failed to load JSON: {e}"
                pages_to_join = []

        if pages_to_join and page_text_map is not None:
            output_dir = subfolder_path

            tasks = [
                process_with_semaphore(
                    _process_pdf_page_group_async(
                        group, output_dir, page_text_map, subfolder,
                        PDF_DOCX_PROMPT_BACKGROUND,
                        EXTRACTION_PROMPT,
                        VALID_EXTRACTION_JSON_FIELDS
                    )
                )
                for group in pages_to_join
            ]

            for coro in asyncio.as_completed(tasks):
                json_result, in_toks, out_toks = await coro
                pdf_input_tokens += in_toks
                pdf_output_tokens += out_toks

                if json_result is None:
                    status = "partial"
                    if err is None:
                        err = "Some page groups returned invalid JSON"
                else:
                    async with outputs_lock:
                        _append_records(outputs, json_result, company_folder, subfolder)

        elapsed_seconds = time.time() - start_time
        pdf_cost = models.compute_cost(pdf_input_tokens, pdf_output_tokens, PDF_DOCX_EXTRACTION_MODEL)

        record_stage(
            company_folder,
            subfolder,
            stage="extraction_pdf_docx",
            time_seconds=elapsed_seconds,
            input_tokens=pdf_input_tokens,
            output_tokens=pdf_output_tokens,
            cost=pdf_cost,
        )

        return {
            "kind": "pdf",
            "name": subfolder,
            "path": subfolder_path,
            "status": status,
            "time_seconds": elapsed_seconds,
            "cost": pdf_cost,
            "input_tokens": pdf_input_tokens,
            "output_tokens": pdf_output_tokens,
            "error": err,
        }

    for company_folder in company_folders:
        company_path = os.path.join(output_data_dir, company_folder)
        if not os.path.isdir(_long_path(company_path)):
            continue

        plan = _company_file_plan(company_folder)
        company_summaries = []

        # Parallelize across files: create one task per PDF folder in the plan.
        file_tasks = []
        for item_type, name, path in plan:
            if item_type == "pdf":
                file_tasks.append(asyncio.create_task(_process_pdf_folder(company_folder, name, path)))

        # Progress: update as each file completes.
        with tqdm(
            total=len(file_tasks),
            desc=f"{company_folder} files",
            unit="file",
            leave=True,
            dynamic_ncols=True
        ) as company_pbar:
            for fut in asyncio.as_completed(file_tasks):
                summary = await fut
                if summary:
                    company_summaries.append(summary)
                company_pbar.update(1)

        # Print one clean company summary at the end
        if company_summaries:
            print(f"\n{company_folder} extraction summary ({len(company_summaries)} files):")
            for s in company_summaries:
                elapsed_min = int(s["time_seconds"] // 60)
                elapsed_sec = int(s["time_seconds"] % 60)

                mark = "✅" if s["status"] == "ok" else ("⚠️" if s["status"] == "partial" else "❌")
                extra = f" | {s['error']}" if s.get("error") else ""

                print(
                    f"  {mark} [{s['kind']}] {s['name']} "
                    f"  {elapsed_min}m {elapsed_sec}s "
                    f"  | ${s['cost']:.6f}"
                    f"{extra}"
                )
            print("")
        else:
            print(f"\n{company_folder}: no eligible files found.\n")

    return pd.DataFrame(outputs)


def extract_claims(output_data_dir, company_folders, pages_to_join_dict, is_file_loss_run_dict):
    """
    """

    # Extract individual claims from loss runs using the respective prompt backgrounds, extraction prompts, and JSON fields
    claims_df = extract_loss_runs(output_data_dir,
                                  company_folders,
                                  pages_to_join_dict,
                                  is_file_loss_run_dict,
                                  CLAIM_LEVEL_PDF_DOCX_PROMPT_BACKGROUND,
                                  CLAIM_LEVEL_EXTRACTION_PROMPT,
                                  CLAIM_LEVEL_VALID_JSON_FIELDS)

    return claims_df


def extract_policies_no_claims(output_data_dir, company_folders, pages_to_join_dict, is_file_loss_run_dict):
    """
    """

    # Extract policies that had no claims from loss runs using the respective prompt backgrounds, extraction prompts, and JSON fields
    no_claims_df = extract_loss_runs(output_data_dir,
                                     company_folders,
                                     pages_to_join_dict,
                                     is_file_loss_run_dict,
                                     NO_CLAIMS_PDF_DOCX_PROMPT_BACKGROUND,
                                     NO_CLAIMS_EXTRACTION_PROMPT,
                                     NO_CLAIMS_VALID_JSON_FIELDS)

    return no_claims_df
