import pandas as pd
import openpyxl
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.formatting.rule import FormulaRule
from openpyxl.comments import Comment
from pathlib import Path
from rapidfuzz import process, fuzz
import warnings
import time
from metrics import record_stage
warnings.filterwarnings('ignore')

def _add_header_with_comment(ws, cell_addr: str, title: str, comment_text: str | None = None):
    cell = ws[cell_addr]
    cell.value = title
    cell.fill = PatternFill(start_color='002060', end_color='002060', fill_type='solid')
    cell.font = Font(color='FFFFFF', bold=False)
    cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)

    if comment_text:
        c = Comment(text=comment_text, author='System')
        c.width = 500
        c.height = 100
        cell.comment = c

def _next_column_letter(ws, min_col_letter: str = "A") -> str:
    """
    Return the next empty column letter to the right of the current max column.
    This is used to append new columns ("far right") without hard-coding.
    """
    next_idx = max(ws.max_column, openpyxl.utils.column_index_from_string(min_col_letter)) + 1
    return get_column_letter(next_idx)

def copy_all_data_validations_to_rows(ws, source_row, target_rows):
    """
    Copy ALL data validations from a source row to target rows
    This ensures all dropdowns remain functional after writing values

    Args:
        ws: worksheet object
        source_row: row number to copy validations from (e.g., 11 or 121)
        target_rows: list of row numbers to copy validations to
    """

    # Find all data validations that apply to the source row
    validations_by_column = {}

    # Check each column in the source row
    for col_idx in range(1, ws.max_column + 1):
        col_letter = get_column_letter(col_idx)
        source_cell = f'{col_letter}{source_row}'

        # Check if this cell has a data validation
        for dv in list(ws.data_validations.dataValidation):
            # Check if the validation range includes this cell
            for cell_range in dv.cells:
                # Parse the range to see if it includes our source cell
                if ':' in cell_range.coord:
                    # Range like "E11:E110"
                    start_cell, end_cell = cell_range.coord.split(':')
                    start_col = ''.join(filter(str.isalpha, start_cell))
                    start_row_num = int(''.join(filter(str.isdigit, start_cell)))
                    end_col = ''.join(filter(str.isalpha, end_cell))
                    end_row_num = int(''.join(filter(str.isdigit, end_cell)))

                    # Check if source row falls within this range
                    if (start_col == col_letter == end_col and
                            start_row_num <= source_row <= end_row_num):
                        validations_by_column[col_letter] = dv
                        break
                else:
                    # Single cell reference
                    if cell_range.coord == source_cell:
                        validations_by_column[col_letter] = dv
                        break

    # Create new data validation rules for target rows
    for col_letter, original_dv in validations_by_column.items():
        # Create a new data validation with the same properties
        new_dv = DataValidation(
            type=original_dv.type,
            formula1=original_dv.formula1,
            formula2=original_dv.formula2,
            allow_blank=original_dv.allow_blank,
            showDropDown=original_dv.showDropDown,
            showErrorMessage=original_dv.showErrorMessage,
            showInputMessage=original_dv.showInputMessage,
            errorTitle=original_dv.errorTitle,
            error=original_dv.error,
            promptTitle=original_dv.promptTitle,
            prompt=original_dv.prompt
        )

        # Add all target cells to the new validation
        for target_row in target_rows:
            new_dv.add(f'{col_letter}{target_row}')

        # Add the new validation to the worksheet
        ws.add_data_validation(new_dv)

    return len(validations_by_column)  # Return number of validations copied

def get_refdata_values(workbook, column_letter):
    """Extract reference data values from the hidden RefData sheet"""
    try:
        ref_sheet = workbook['RefData']
        values = []
        for cell in ref_sheet[column_letter]:
            if cell.value:  # Only add non-empty cells
                values.append(str(cell.value).strip())
        return values
    except KeyError:
        return []
    except Exception as e:
        return []

def get_validated_values(sheet, cell_range):
    """Extract validated values from a cell's data validation"""
    validation = sheet.data_validations
    for dv in validation.dataValidation:
        if cell_range in dv.sqref:
            if dv.formula1:
                # Remove quotes and split by comma
                values = dv.formula1.strip('"').split(',')
                return [v.strip() for v in values]
    return []

def fuzzy_match_distinct(values_series, valid_values, default="Other"):
    """
    Efficiently fuzzy match distinct values with exact match preference
    Returns a mapping dictionary
    """

    # Get distinct values
    distinct_values = values_series.dropna().unique()

    # Create lowercase mapping for exact match checking
    valid_values_lower = {v.lower(): v for v in valid_values}

    mapping = {}
    for value in distinct_values:
        value_str = str(value).strip()

        # Skip empty strings
        if not value_str:
            continue

        value_lower = value_str.lower()

        # Check for exact match first (case-insensitive)
        if value_lower in valid_values_lower:
            mapping[value_str] = valid_values_lower[value_lower]
        else:
            # Use partial_ratio for better substring matching
            result = process.extractOne(
                value_str,
                valid_values,
                scorer=fuzz.partial_ratio,  # Changed from fuzz.ratio
                score_cutoff=80  # Increased threshold for better matches
            )
            mapping[value_str] = result[0] if result else default

    return mapping

def map_status(status_code):
    """Map status codes to full status names"""
    status_map = {
        'O': 'OPEN',
        'C': 'CLOSED',
        'R': 'REOPEN',
        'S': 'SUBROGATION'
    }
    if pd.isna(status_code):
        return None
    return status_map.get(str(status_code).strip().upper(), None)

def assign_policy_periods(df):
    """Assign policy row IDs based on policy periods (most recent = 1)"""
    # Group by policy period
    policy_periods = df.groupby(['policy_effective_date', 'policy_expiration_date']).first().reset_index()

    # Sort by policy_effective_date descending (most recent first)
    policy_periods = policy_periods.sort_values('policy_effective_date', ascending=False).reset_index(drop=True)

    # Assign Policy Row IDs (1 for most recent)
    policy_periods['policy_row_id'] = range(1, len(policy_periods) + 1)

    # Merge back to original dataframe
    df = df.merge(
        policy_periods[['policy_effective_date', 'policy_expiration_date', 'policy_row_id']],
        on=['policy_effective_date', 'policy_expiration_date'],
        how='left'
    )

    return df, policy_periods

def normalize_lob(lob_value):
    """
    Normalize line of business values to standardized codes

    Args:
        lob_value: Raw LOB string from data

    Returns:
        Standardized LOB code (AUTO, PROP, WC, GL) or None
    """
    if pd.isna(lob_value):
        return None

    lob_str = str(lob_value).upper().strip()

    # Define mapping patterns
    lob_patterns = {
        'AUTO': ['AUTO', 'AUTOMOBILE', 'VEHICLE'],
        'PROP': ['PROP', 'PROPERTY'],
        'WC': ['WC', 'WORK', 'COMP', 'WORKERS'],
        'GL': ['GL', 'GENERAL', 'LIABILITY']
    }

    # Check each pattern
    for lob_code, patterns in lob_patterns.items():
        if any(pattern in lob_str for pattern in patterns):
            return lob_code

    return None

def expand_auto_policy_periods(policy_periods_df, claims_df):
    """
    Expand AUTO policy periods to include both AL and APD sublines

    Args:
        policy_periods_df: DataFrame with policy periods
        claims_df: DataFrame with claims data (filtered for this policy period)

    Returns:
        DataFrame with expanded policy periods for AUTO
    """
    expanded_periods = []

    for idx, period in policy_periods_df.iterrows():
        # Get claims for this policy period
        period_claims = claims_df[
            (claims_df['policy_effective_date'] == period['policy_effective_date']) &
            (claims_df['policy_expiration_date'] == period['policy_expiration_date']) &
            (claims_df['prior_carrier'] == period['prior_carrier'])
        ]

        # Get unique sublines in this period
        sublines_present = period_claims['subline'].dropna().unique()

        # Always create both AL and APD entries
        for subline in ['AL', 'APD']:
            period_copy = period.copy()
            period_copy['subline'] = subline
            # Mark if this subline has claims
            period_copy['has_claims'] = subline in sublines_present
            expanded_periods.append(period_copy)

    return pd.DataFrame(expanded_periods)

def assign_policy_periods_by_lob(df, lob):
    """
    Assign policy row IDs based on policy periods and LOB-specific logic

    Args:
        df: DataFrame with claims data
        lob: Line of business code (AUTO, PROP, WC, GL)

    Returns:
        Tuple of (claims_df with policy_row_id, policy_periods_df)
    """
    # Split into claims with and without valid policy dates
    valid_policy_mask = df['policy_effective_date'].notna() & df['policy_expiration_date'].notna()
    df_with_policy = df[valid_policy_mask].copy()
    df_without_policy = df[~valid_policy_mask].copy()

    # Set policy_row_id to None for claims without policy dates
    df_without_policy['policy_row_id'] = None

    if len(df_with_policy) == 0:
        return df, pd.DataFrame()

    if lob == 'AUTO':
        # Group by policy period and carrier
        base_periods = df_with_policy.groupby([
            'policy_effective_date',
            'policy_expiration_date',
            'prior_carrier'
        ]).first().reset_index()

        # Expand to include both AL and APD for each period
        policy_periods = expand_auto_policy_periods(base_periods, df_with_policy)

        # Sort by policy_effective_date descending, carrier, then subline
        policy_periods = policy_periods.sort_values(
            ['policy_effective_date', 'prior_carrier', 'subline'],
            ascending=[False, True, True]
        ).reset_index(drop=True)

        # Assign Policy Row IDs
        policy_periods['policy_row_id'] = range(1, len(policy_periods) + 1)

        # Merge back to claims with all matching keys
        df_with_policy = df_with_policy.merge(
            policy_periods[[
                'policy_effective_date',
                'policy_expiration_date',
                'prior_carrier',
                'subline',
                'policy_row_id'
            ]],
            on=[
                'policy_effective_date',
                'policy_expiration_date',
                'prior_carrier',
                'subline'
            ],
            how='left'
        )
    else:
        # Standard logic for WC, GL, PROP - include carrier
        policy_periods = df_with_policy.groupby([
            'policy_effective_date',
            'policy_expiration_date',
            'prior_carrier'
        ]).first().reset_index()

        # Sort by policy_effective_date descending, then carrier
        policy_periods = policy_periods.sort_values(
            ['policy_effective_date', 'prior_carrier'],
            ascending=[False, True]
        ).reset_index(drop=True)

        # Assign Policy Row IDs
        policy_periods['policy_row_id'] = range(1, len(policy_periods) + 1)

        # Merge back to claims with all matching keys
        df_with_policy = df_with_policy.merge(
            policy_periods[[
                'policy_effective_date',
                'policy_expiration_date',
                'prior_carrier',
                'policy_row_id'
            ]],
            on=[
                'policy_effective_date',
                'policy_expiration_date',
                'prior_carrier'
            ],
            how='left'
        )

    # Combine back with claims without policy dates
    result_df = pd.concat([df_with_policy, df_without_policy], ignore_index=True)

    return result_df, policy_periods

def populate_missing_lob_sheet(ws, unknown_claims_df, wb, carrier_mapping, status_mapping, state_mapping):
    """
    Populate the Missing_LOB sheet with unknown claims

    Args:
        ws: Missing_LOB worksheet object
        unknown_claims_df: DataFrame with unknown LOB claims
        wb: Workbook object (for reference data)
        carrier_mapping: Dictionary for carrier fuzzy matching
        status_mapping: Dictionary for status fuzzy matching
        state_mapping: Dictionary for state fuzzy matching
    """
    if len(unknown_claims_df) == 0:
        return

    # Assign policy periods for unknown claims
    unknown_claims_df, unknown_policy_periods = assign_policy_periods_by_lob(
        unknown_claims_df.copy(),
        'PROP'  # Use PROP logic (no subline expansion)
    )

    # Populate Policy Section (starting at Row 11)
    policy_start_row = 11

    # Copy data validations for policy rows
    policy_rows = [policy_start_row + i for i in range(len(unknown_policy_periods))]
    copy_all_data_validations_to_rows(ws, policy_start_row, policy_rows)

    for idx, policy in unknown_policy_periods.iterrows():
        row = policy_start_row + idx

        # Column A: Policy Row ID
        ws[f'A{row}'] = policy['policy_row_id']

        # Column B: Policy Effective Date
        if pd.notna(policy['policy_effective_date']):
            ws[f'B{row}'] = policy['policy_effective_date'].strftime('%m/%d/%Y')

        # Column C: Policy Expiration Date
        if pd.notna(policy['policy_expiration_date']):
            ws[f'C{row}'] = policy['policy_expiration_date'].strftime('%m/%d/%Y')

        # Column E: Carrier
        carrier = policy.get('prior_carrier', '')
        if carrier and pd.notna(carrier) and str(carrier).strip():
            if carrier_mapping:
                carrier = carrier_mapping.get(str(carrier).strip(), "Other Competitor")
            else:
                carrier = "Other Competitor"
        else:
            carrier = ''
        ws[f'E{row}'] = carrier

        # Column F: Policy Number
        ws[f'F{row}'] = policy.get('policy_number', '')

        # Column Q: Evaluation Date
        if pd.notna(policy.get('evaluation_date')):
            ws[f'Q{row}'] = policy['evaluation_date'].strftime('%m/%d/%Y')

        # Column X: File Name
        ws[f'X{row}'] = policy.get('file_path', '')

    # Populate Claims Section (starting at Row 121)
    claims_start_row = 121

    # Sort claims by policy_row_id and accident_date
    claims_sorted = unknown_claims_df.sort_values(
        ['policy_row_id', 'accident_date'],
        ascending=[True, False]
    ).reset_index(drop=True)

    # Copy data validations for claim rows
    claim_rows = [claims_start_row + i for i in range(len(claims_sorted))]
    num_validations = copy_all_data_validations_to_rows(ws, claims_start_row, claim_rows)

    # Existing headers
    _add_header_with_comment(
        ws,
        'X120',
        'Duplicate Report',
        'This is a new column from the internal process which attempts to detect claims that may have been reported multiple times. For example, if two files contain the same claim, this is trying to flag that to avoid double counting.'
    )
    _add_header_with_comment(
        ws,
        'W120',
        'Source (Page Num or Sheet)',
        'This is a new column from the internal solution that cites the page number or sheet name that the claim was found in the file.'
    )

    # NEW: Remove header on far right (append)
    remove_col = _next_column_letter(ws, min_col_letter="X")
    _add_header_with_comment(
        ws,
        f'{remove_col}120',
        'Remove',
        '1 = row should be excluded based on occurrence/duplicate logic. Blank/0 = keep.'
    )

    for idx, claim in claims_sorted.iterrows():
        row = claims_start_row + idx

        # Column A: Policy Row ID
        ws[f'A{row}'] = claim['policy_row_id']

        # Column B: Accident Date
        if pd.notna(claim.get('accident_date')):
            ws[f'B{row}'] = claim['accident_date'].strftime('%m/%d/%Y')

        # Column D: Subline (leave empty for unknown)
        ws[f'D{row}'] = claim.get('subline', '')

        # Column E: Report Date
        if pd.notna(claim.get('report_date')):
            ws[f'E{row}'] = claim['report_date'].strftime('%m/%d/%Y')

        # Column F: Total Incurred
        ws[f'F{row}'] = round(claim.get('total_incurred', 0))

        # Column G: Total Paid
        ws[f'G{row}'] = round(claim.get('total_paid', 0))

        # Column H: Incurred ALAE
        ws[f'H{row}'] = round(claim.get('incurred_alae', 0))

        # Column I: Paid ALAE
        ws[f'I{row}'] = round(claim.get('paid_alae', 0))

        # Column J: Total Recoveries
        ws[f'J{row}'] = round(claim.get('total_recoveries', 0))

        # Column K: Status
        status = map_status(claim.get('status'))
        if status and status_mapping:
            status = status_mapping.get(status, None)
        if status:
            ws[f'K{row}'] = status

        # Column L: Claimant
        ws[f'L{row}'] = claim.get('claimant', '')

        # Column N: Description
        ws[f'N{row}'] = claim.get('claim_description', '')

        # Column O: Occurrence Number
        ws[f'O{row}'] = claim.get('occurrence_number', '')

        # Column P: Number of Claims
        ws[f'P{row}'] = 1

        # Column Q: Claim Number
        ws[f'Q{row}'] = claim.get('claim_id', '')

        # Column R: Accident State
        accident_state = claim.get('accident_state', '')
        if accident_state and state_mapping:
            accident_state = state_mapping.get(str(accident_state).strip(), accident_state)
        ws[f'R{row}'] = accident_state

        # Column S: Garage State/Coverage State
        garage_or_coverage_state = claim.get('garage_state', '') or claim.get('coverage_state', '')
        if garage_or_coverage_state and state_mapping:
            garage_or_coverage_state = state_mapping.get(str(garage_or_coverage_state).strip(), garage_or_coverage_state)
        ws[f'S{row}'] = garage_or_coverage_state

        # Column V: File Name
        ws[f'V{row}'] = claim.get('file_path', '')

        # Column W: Source (page_num_or_sheet_name)
        page_num_or_sheet_name = claim.get('page_num_or_sheet_name')
        if page_num_or_sheet_name is None or pd.isna(page_num_or_sheet_name):
            ws[f'W{row}'] = ''
        else:
            # Try to convert to number if possible
            try:
                ws[f'W{row}'] = int(page_num_or_sheet_name)
            except (ValueError, TypeError):
                ws[f'W{row}'] = str(page_num_or_sheet_name)

        # Column X: Duplicate Report
        duplicate_report = claim.get('duplicate_number')
        ws[f'X{row}'] = '' if duplicate_report is None or pd.isna(duplicate_report) else str(duplicate_report)

        # NEW: Remove (from detect_occurrence_and_duplicate -> "remove")
        remove_val = claim.get('remove')

        # normalize: allow None/NA/''/' ' -> blank; allow 0/1/'0'/'1' -> int
        if remove_val is None or pd.isna(remove_val) or (isinstance(remove_val, str) and not remove_val.strip()):
            ws[f'{remove_col}{row}'] = ''
        else:
            try:
                ws[f'{remove_col}{row}'] = int(remove_val)
            except (ValueError, TypeError):
                # If upstream sends unexpected text, don't crash template generation
                ws[f'{remove_col}{row}'] = ''

def populate_template_by_lob(claims_df, lob, template_path, output_path, unknown_claims_df=None, carrier_mapping=None, status_mapping=None, state_mapping=None):
    """
    Populate template for a specific LOB

    Args:
        claims_df: DataFrame with claims data (single account, single LOB)
        lob: Line of business code (AUTO, PROP, WC, GL)
        template_path: Path to the template file
        output_path: Output path for the populated template
        unknown_claims_df: DataFrame with unknown LOB claims (optional)
        carrier_mapping: Pre-computed carrier mapping (optional)
        status_mapping: Pre-computed status mapping (optional)
        state_mapping: Pre-computed state mapping (optional)

    Returns:
        Path to the populated template
    """

    # Convert pd.NA to empty strings for Excel compatibility
    # NOTE: don't blanket fillna('') across Int64/Float/datetime columns (raises on Int64).
    obj_cols = claims_df.select_dtypes(include=["object", "string"]).columns
    claims_df[obj_cols] = claims_df[obj_cols].fillna("")

    if unknown_claims_df is not None:
        obj_cols_u = unknown_claims_df.select_dtypes(include=["object", "string"]).columns
        unknown_claims_df[obj_cols_u] = unknown_claims_df[obj_cols_u].fillna("")

    # Load workbook preserving macros and formatting
    wb = openpyxl.load_workbook(template_path, keep_vba=True)

    # Rename the LOB sheet
    if 'LOB' in wb.sheetnames:
        ws = wb['LOB']
        #ws.title = lob
    else:
        raise ValueError(f"Template must contain a 'LOB' sheet")

    # Get account name
    account_name = claims_df['AccountName'].iloc[0]

    # Update A1 with Account Name
    ws['A1'] = account_name

    # Update A2 with LOB-specific header
    ws['A2'] = f"{lob} - Prior Carrier Policies/Claims Template"

    # Convert date columns to datetime
    date_columns = ['policy_effective_date', 'policy_expiration_date', 'evaluation_date',
                    'accident_date', 'report_date']
    for col in date_columns:
        if col in claims_df.columns:
            claims_df[col] = pd.to_datetime(claims_df[col], errors='coerce')

    # Assign policy periods based on LOB
    claims_df, policy_periods = assign_policy_periods_by_lob(claims_df, lob)

    # Get reference data (only if not provided)
    if carrier_mapping is None or status_mapping is None or state_mapping is None:
        carrier_valid_values = get_refdata_values(wb, 'A')
        status_valid_values = get_validated_values(ws, 'K121:K9999') or get_validated_values(ws, 'K:K')
        state_valid_values = get_refdata_values(wb, 'G')

        # Create fuzzy match mappings
        if carrier_mapping is None:
            carrier_mapping = {}
            if carrier_valid_values:
                carrier_mapping = fuzzy_match_distinct(
                    policy_periods['prior_carrier'],
                    carrier_valid_values,
                    default="Other Competitor"
                )

        if status_mapping is None:
            status_mapping = {}
            if status_valid_values:
                mapped_status = claims_df['status'].apply(map_status)
                status_mapping = fuzzy_match_distinct(
                    mapped_status,
                    status_valid_values,
                    default=None
                )

        if state_mapping is None:
            state_mapping = {}
            if state_valid_values:
                all_states = pd.concat([
                    claims_df['accident_state'],
                    claims_df.get('garage_state', pd.Series()),
                    claims_df.get('coverage_state', pd.Series())
                ])
                state_mapping = fuzzy_match_distinct(
                    all_states,
                    state_valid_values,
                    default=None
                )

    # Populate Policy Section (starting at Row 11)
    policy_start_row = 11

    policy_rows = [policy_start_row + i for i in range(len(policy_periods))]
    copy_all_data_validations_to_rows(ws, policy_start_row, policy_rows)

    for idx, policy in policy_periods.iterrows():
        row = policy_start_row + idx

        # Column A: Policy Row ID
        ws[f'A{row}'] = policy['policy_row_id']

        # Column B: Policy Effective Date
        if pd.notna(policy['policy_effective_date']):
            ws[f'B{row}'] = policy['policy_effective_date'].strftime('%m/%d/%Y')

        # Column C: Policy Expiration Date
        if pd.notna(policy['policy_expiration_date']):
            ws[f'C{row}'] = policy['policy_expiration_date'].strftime('%m/%d/%Y')

        # Column E: Carrier
        carrier = policy.get('prior_carrier', '')
        if carrier and pd.notna(carrier) and str(carrier).strip():
            if carrier_mapping:
                carrier = carrier_mapping.get(str(carrier).strip(), "Other Competitor")
            else:
                carrier = "Other Competitor"
        else:
            carrier = ''
        ws[f'E{row}'] = carrier

        # Column F: Policy Number
        ws[f'F{row}'] = policy.get('policy_number', '')

        # Column H: Subline (AUTO only)
        if lob == 'AUTO':
            ws[f'H{row}'] = policy.get('subline', '')

        # Column Q: Evaluation Date
        if pd.notna(policy.get('evaluation_date')):
            ws[f'Q{row}'] = policy['evaluation_date'].strftime('%m/%d/%Y')

        # Column X: File Name
        ws[f'X{row}'] = policy.get('file_path', '')

    # Populate Claims Section (starting at Row 121)
    claims_start_row = 121

    # Sort claims - check if policy_row_id exists first
    if 'policy_row_id' not in claims_df.columns:
        # If policy_row_id is missing, add it as None
        claims_df['policy_row_id'] = None

    if lob == 'AUTO':
        claims_sorted = claims_df.sort_values(
            ['policy_row_id', 'accident_date'],
            ascending=[True, False],
            na_position='last'  # Put rows without policy_row_id at the end
        ).reset_index(drop=True)
    else:
        claims_sorted = claims_df.sort_values(
            ['policy_row_id', 'accident_date'],
            ascending=[True, False],
            na_position='last'  # Put rows without policy_row_id at the end
        ).reset_index(drop=True)

    # Copy data validations
    claim_rows = [claims_start_row + i for i in range(len(claims_sorted))]
    num_validations = copy_all_data_validations_to_rows(ws, claims_start_row, claim_rows)

    _add_header_with_comment(
        ws,
        'X120',
        'Duplicate Report',
        'This is a new column from the internal process which attempts to detect claims that may have been reported multiple times. ' \
        'For example, if two files contain the same claim, this is trying to flag that to avoid double counting.'
    )
    _add_header_with_comment(
        ws,
        'W120',
        'Source Location',
        'This is a new column from the internal solution that cites the page number or sheet name that the claim was found in the file.'
    )

    # NEW: Remove header on far right (append after current content)
    remove_col = _next_column_letter(ws, min_col_letter="X")
    _add_header_with_comment(
        ws,
        f'{remove_col}120',
        'Remove',
        '1 = row should be excluded based on occurrence/duplicate logic. Blank/0 = keep.'
    )

    for idx, claim in claims_sorted.iterrows():
        row = claims_start_row + idx

        # Column A: Policy Row ID (skip if None)
        policy_row_id = claim.get('policy_row_id')
        if policy_row_id is not None and pd.notna(policy_row_id):
            ws[f'A{row}'] = policy_row_id
        else:
            ws[f'A{row}'] = ''

        # Column B: Accident Date
        accident_date = claim.get('accident_date')
        if accident_date is not None and pd.notna(accident_date):
            ws[f'B{row}'] = accident_date.strftime('%m/%d/%Y')

        # Column D: Subline - handle None/NA values
        subline = claim.get('subline')
        ws[f'D{row}'] = '' if subline is None or pd.isna(subline) else str(subline)

        # Column E: Report Date
        report_date = claim.get('report_date')
        if report_date is not None and pd.notna(report_date):
            ws[f'E{row}'] = report_date.strftime('%m/%d/%Y')

        # Column F: Total Incurred
        ws[f'F{row}'] = round(claim.get('total_incurred', 0))

        # Column G: Total Paid
        ws[f'G{row}'] = round(claim.get('total_paid', 0))

        # Column H: Incurred ALAE
        ws[f'H{row}'] = round(claim.get('incurred_alae', 0))

        # Column I: Paid ALAE
        ws[f'I{row}'] = round(claim.get('paid_alae', 0))

        # Column J: Total Recoveries
        ws[f'J{row}'] = round(claim.get('total_recoveries', 0))

        # Column K: Status
        status = map_status(claim.get('status'))
        if status and status_mapping:
            status = status_mapping.get(status, None)
        if status:
            ws[f'K{row}'] = status

        # Column L: Claimant
        claimant = claim.get('claimant')
        ws[f'L{row}'] = '' if claimant is None or pd.isna(claimant) else str(claimant)

        # Column N: Description
        description = claim.get('claim_description')
        ws[f'N{row}'] = '' if description is None or pd.isna(description) else str(description)

        # Column O: Occurrence Number
        occurrence = claim.get('occurrence_number')
        ws[f'O{row}'] = '' if occurrence is None or pd.isna(occurrence) else str(occurrence)

        # Column P: Number of Claims
        ws[f'P{row}'] = 1

        # Column Q: Claim Number
        claim_id = claim.get('claim_id')
        ws[f'Q{row}'] = '' if claim_id is None or pd.isna(claim_id) else str(claim_id)

        # Column R: Accident State - handle None/NA values properly
        accident_state = claim.get('accident_state')
        if accident_state is not None and pd.notna(accident_state):
            accident_state_str = str(accident_state).strip()
            if state_mapping and accident_state_str:
                accident_state_str = state_mapping.get(accident_state_str, accident_state_str)
            ws[f'R{row}'] = accident_state_str
        else:
            ws[f'R{row}'] = ''

        # Column S: Garage State/Coverage State - handle None/NA values
        garage_state = claim.get('garage_state')
        coverage_state = claim.get('coverage_state')

        # Get the first non-null value
        garage_or_coverage_state = None
        if garage_state is not None and pd.notna(garage_state):
            garage_or_coverage_state = garage_state
        elif coverage_state is not None and pd.notna(coverage_state):
            garage_or_coverage_state = coverage_state

        if garage_or_coverage_state is not None:
            garage_or_coverage_state_str = str(garage_or_coverage_state).strip()
            if state_mapping and garage_or_coverage_state_str:
                garage_or_coverage_state_str = state_mapping.get(garage_or_coverage_state_str, garage_or_coverage_state_str)
            ws[f'S{row}'] = garage_or_coverage_state_str
        else:
            ws[f'S{row}'] = ''

        # Column V: File Name
        file_path = claim.get('file_path')
        ws[f'V{row}'] = '' if file_path is None or pd.isna(file_path) else str(file_path)

        # Column W: Source (page_num_or_sheet_name)
        page_num_or_sheet_name = claim.get('page_num_or_sheet_name')
        if page_num_or_sheet_name is None or pd.isna(page_num_or_sheet_name):
            ws[f'W{row}'] = ''
        else:
            # Try to convert to number if possible
            try:
                ws[f'W{row}'] = int(page_num_or_sheet_name)
            except (ValueError, TypeError):
                ws[f'W{row}'] = str(page_num_or_sheet_name)

        # Column X: Duplicate Report
        duplicate_report = claim.get('duplicate_number')
        ws[f'X{row}'] = '' if duplicate_report is None or pd.isna(duplicate_report) else str(duplicate_report)

        # NEW: Remove (from detect_occurrence_and_duplicate -> "remove")
        remove_val = claim.get('remove')

        # normalize: allow None/NA/''/' ' -> blank; allow 0/1/'0'/'1' -> int
        if remove_val is None or pd.isna(remove_val) or (isinstance(remove_val, str) and not remove_val.strip()):
            ws[f'{remove_col}{row}'] = ''
        else:
            try:
                ws[f'{remove_col}{row}'] = int(remove_val)
            except (ValueError, TypeError):
                # If upstream sends unexpected text, don't crash template generation
                ws[f'{remove_col}{row}'] = ''

    # Add conditional formatting for duplicate occurrence numbers
    occurrence_col = 'O'  # Column O is the Occurrence Number column
    last_claim_row = 60121

    # Define pink fill (classic Excel pink)
    pink_fill = PatternFill(start_color='FD63EB', end_color='FD63EB', fill_type='solid')

    # Create formula to check for duplicates
    # This formula checks if COUNTIF of the occurrence number range > 1
    duplicate_formula = f'COUNTIF(${occurrence_col}${claims_start_row}:${occurrence_col}${last_claim_row},{occurrence_col}{claims_start_row})>1'

    # Apply conditional formatting rule
    rule = FormulaRule(formula=[duplicate_formula], fill=pink_fill)
    ws.conditional_formatting.add(
        f'{occurrence_col}{claims_start_row}:{occurrence_col}{last_claim_row}',
        rule
    )

    # Add conditional formatting for WC monopolistic states
    if lob == 'WC':
        # Define the pink fill (same as other validation highlights)
        pink_fill = PatternFill(start_color='FD63EB', end_color='FD63EB', fill_type='solid')

        # Get the accident state column (column R)
        accident_state_col = 'R'

        # Create formula for conditional formatting
        # Check if the current cell value is ND, OH, WA, or WY
        monopolistic_formula = f'OR(R{claims_start_row}="ND",R{claims_start_row}="OH",R{claims_start_row}="WA",R{claims_start_row}="WY")'

        # Apply conditional formatting only to the accident state column cells
        ws.conditional_formatting.add(
            f'{accident_state_col}{claims_start_row}:{accident_state_col}{last_claim_row}',
            FormulaRule(formula=[monopolistic_formula], stopIfTrue=True, fill=pink_fill)
        )

    # Add conditional formatting for Duplicate Report column (X)
    duplicate_report_col = 'X'

    # Create formula to check for duplicates in Duplicate Report column
    duplicate_report_formula = f'COUNTIF(${duplicate_report_col}${claims_start_row}:${duplicate_report_col}${last_claim_row},' \
                               f'{duplicate_report_col}{claims_start_row})>1'

    # Apply conditional formatting to highlight duplicate report numbers
    ws.conditional_formatting.add(
        f'{duplicate_report_col}{claims_start_row}:{duplicate_report_col}{last_claim_row}',
        FormulaRule(formula=[duplicate_report_formula], stopIfTrue=True, fill=pink_fill)
    )

    # Add conditional formatting for open claims validation
    # Open claims should have total incurred > total paid
    # Flag when status = "OPEN" AND Total Incurred = Total Paid
    status_col = 'K'
    total_incurred_col = 'F'
    total_paid_col = 'G'
    incurred_alae_col = 'H'
    paid_alae_col = 'I'

    # Formula: Status = "OPEN" AND Total Incurred = Total Paid
    open_validation_formula = f'AND({status_col}{claims_start_row}="OPEN",{total_incurred_col}{claims_start_row}={total_paid_col}{claims_start_row})'

    # Apply to status column
    ws.conditional_formatting.add(
        f'{status_col}{claims_start_row}:{status_col}{last_claim_row}',
        FormulaRule(formula=[open_validation_formula], stopIfTrue=True, fill=pink_fill)
    )

    # Add conditional formatting for closed claims validation
    # Closed claims should have incurred = paid for both total and ALAE
    # Formula: Status = "CLOSED" AND (Total Incurred <> Total Paid OR Incurred ALAE <> Paid ALAE)
    closed_validation_formula = f'AND({status_col}{claims_start_row}="CLOSED",OR({total_incurred_col}{claims_start_row})<>' \
                                f'{total_paid_col}{claims_start_row},({incurred_alae_col}{claims_start_row})<>{paid_alae_col}{claims_start_row}))'

    # Apply to status column (this will be checked after the open validation)
    ws.conditional_formatting.add(
        f'{status_col}{claims_start_row}:{status_col}{last_claim_row}',
        FormulaRule(formula=[closed_validation_formula], stopIfTrue=True, fill=pink_fill)
    )

    # Populate Missing_LOB sheet if unknown claims exist
    if unknown_claims_df is not None and len(unknown_claims_df) > 0:
        if 'Missing_LOB' in wb.sheetnames:
            missing_lob_ws = wb['Missing_LOB']

            # Convert date columns for unknown claims
            unknown_claims_copy = unknown_claims_df.copy()
            for col in date_columns:
                if col in unknown_claims_copy.columns:
                    unknown_claims_copy[col] = pd.to_datetime(unknown_claims_copy[col], errors='coerce')

            populate_missing_lob_sheet(
                missing_lob_ws,
                unknown_claims_copy,
                wb,
                carrier_mapping,
                status_mapping,
                state_mapping
            )

    # Ensure RefData sheet remains hidden
    if 'RefData' in wb.sheetnames:
        wb['RefData'].sheet_state = 'hidden'

    # Save the workbook
    wb.save(output_path)

    return output_path

def generate_templates(claims_df, template_folder, prefix, output_folder=None):
    """
    Generate templates for each account and LOB combination

    Args:
        claims_df: DataFrame with all claims data
        template_folder: Path to folder containing COMPANY_NAME_LOB_Template.xlsm
        prefix: Prefix for output folder name
        output_folder: Optional base folder to write templates into. If None, defaults
                       to <template_folder>/<prefix>Templates

    Returns:
        Dictionary mapping (account, lob) to output path
    """
    template_folder = Path(template_folder)
    template_path = template_folder / 'COMPANY_NAME_LOB_Template.xlsm'

    if not template_path.exists():
        raise FileNotFoundError(f"Template not found: {template_path}")

    # Create output folder structure
    if output_folder is None:
        output_base = template_folder / f"{prefix}Templates"
    else:
        output_base = Path(output_folder) / f"Templates"
    output_base.mkdir(exist_ok=True)

    # Normalize LOB values
    claims_df['lob_normalized'] = claims_df['line_of_business'].apply(normalize_lob)

    # Separate known and unknown LOB claims
    claims_with_lob = claims_df[claims_df['lob_normalized'].notna()].copy()
    unknown_lob_claims = claims_df[claims_df['lob_normalized'].isna()].copy()

    if len(claims_with_lob) == 0:
        return

    # Process by account
    for account in claims_df['AccountName'].unique():
        account_start_time = time.time()
        account_claims = claims_with_lob[claims_with_lob['AccountName'] == account].copy()
        account_unknown = unknown_lob_claims[unknown_lob_claims['AccountName'] == account].copy()

        # Get unique LOBs for this account
        account_lobs = account_claims['lob_normalized'].unique()

        print(f"        Processing Account: {account}")

        # Pre-compute mappings once per account
        wb_temp = openpyxl.load_workbook(template_path, keep_vba=True)
        ws_temp = wb_temp['LOB']

        carrier_valid_values = get_refdata_values(wb_temp, 'A')
        status_valid_values = get_validated_values(ws_temp, 'K121:K9999') or get_validated_values(ws_temp, 'K:K')
        state_valid_values = get_refdata_values(wb_temp, 'G')

        # Create account-wide fuzzy match mappings
        all_carriers = pd.concat([account_claims['prior_carrier'], account_unknown.get('prior_carrier', pd.Series())])
        carrier_mapping = fuzzy_match_distinct(all_carriers, carrier_valid_values, default="Other Competitor") if carrier_valid_values else {}

        all_status = pd.concat([account_claims['status'], account_unknown.get('status', pd.Series())])
        mapped_status = all_status.apply(map_status)
        status_mapping = fuzzy_match_distinct(mapped_status, status_valid_values, default=None) if status_valid_values else {}

        all_states = pd.concat([
            account_claims['accident_state'],
            account_claims.get('garage_state', pd.Series()),
            account_claims.get('coverage_state', pd.Series()),
            account_unknown.get('accident_state', pd.Series()),
            account_unknown.get('garage_state', pd.Series()),
            account_unknown.get('coverage_state', pd.Series())
        ])
        state_mapping = fuzzy_match_distinct(all_states, state_valid_values, default=None) if state_valid_values else {}

        # Create account folder
        account_folder = output_base / account.replace(' ', '_')
        account_folder.mkdir(exist_ok=True)

        # Process each LOB for this account
        for lob in account_lobs:
            # Filter data for this LOB
            lob_claims = account_claims[account_claims['lob_normalized'] == lob].copy()

            # Generate output filename
            output_filename = f"{account.replace(' ', '_')}_{lob}_Template.xlsm"
            output_path = account_folder / output_filename

            try:
                result_path = populate_template_by_lob(
                    lob_claims,
                    lob,
                    template_path,
                    output_path,
                    unknown_claims_df=account_unknown if len(account_unknown) > 0 else None,
                    carrier_mapping=carrier_mapping,
                    status_mapping=status_mapping,
                    state_mapping=state_mapping
                )
            except Exception as e:
                print(f"        X Error processing {lob}: {str(e)}")
                import traceback
                traceback.print_exc()

        # Account summary
        account_elapsed = time.time() - account_start_time
        account_min = int(account_elapsed // 60)
        account_sec = int(account_elapsed % 60)

        # Record metrics for this account's template generation
        record_stage(
            account,
            "ALL_TEMPLATES",
            stage="template_generation",
            time_seconds=account_elapsed,
        )

        print(f"        ✅ Complete")
        print(f"        ⏰ Time: {account_min} min {account_sec} sec")

if __name__ == "__main__":
    df = pd.read_csv("extraction_output/TESTING_claims.csv")
    generate_templates(df, "templates", "TEST_TEMP")
