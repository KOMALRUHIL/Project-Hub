"""
OCR via Gemini Vision (Vertex) that mimics Textract's saved page_response.json format.

Key outputs per PDF (under output_data/<company>/<pdf_filename>/):
- page_response.json -> {"1": "<ocr text>", "2": "<ocr text>", ... }
- ocr_metrics.json   -> page + aggregate timing/token/cost/model info

Supports:
- use_cached=True  => use existing cached OCR when available and "replay" cached cost/time into metrics.py
- use_cached=False => re-run OCR for every page and overwrite cached outputs

Runs OCR in parallel across pages within a PDF.
"""

from __future__ import annotations

import asyncio
import json
import os
import time
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

from prompts import OCR_PROMPT
from utils_gpt_vision import gemini_vision_call, gpt_vision_call
import models
from metrics import record_stage

from tqdm.auto import tqdm
from collections import defaultdict


def _long_path(path: str) -> str:
    """Prefix path with \\\\?\\ on Windows to support paths longer than 260 characters."""
    path = os.path.abspath(path)
    if os.name == 'nt' and not path.startswith('\\\\?\\'):
        path = '\\\\?\\' + path
    return path


# Top-level constant model selection
OCR_MODEL_CFG = models.GPT_5_2
OCR_STAGE_NAME = "OCR"

# OCR about ~1s per page with Gemini 3 Flash Preview - should handle rate limits well
DEFAULT_MAX_WORKERS = 8


@dataclass(frozen=True)
class _PageOcrResult:
    page_num: int
    text: str
    input_tokens: int
    output_tokens: int
    cost: float
    time_seconds: float
    image_path: str


def _safe_read_json(path: str) -> Optional[dict]:
    try:
        path = os.path.abspath(path)
        if os.name == "nt" and not path.startswith("\\\\?\\"):
            path = "\\\\?\\" + path
        if not os.path.exists(path):
            return None
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _atomic_write_json(path: str, payload: dict) -> None:
    path = os.path.abspath(path)
    if os.name == "nt" and not path.startswith("\\\\?\\"):
        path = "\\\\?\\" + path
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp_path = f"{path}.tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    os.replace(tmp_path, path)


def _list_page_images(pdf_output_dir: str) -> List[Tuple[int, str]]:
    """
    Locate images for a PDF that were produced by pdf_to_images.py.
    We don't hardcode a single folder name; instead we search within the PDF output dir
    and try to infer page numbers from filenames like *-<page>.<ext>.

    Returns:
      list of (page_num, image_path) sorted by page_num
    """
    exts = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}
    candidates: List[Tuple[int, str]] = []

    for root, __, files in os.walk(_long_path(pdf_output_dir)):
        for fn in files:
            ext = os.path.splitext(fn)[1].lower()
            if ext not in exts:
                continue
            full = os.path.join(root, fn)

            # Heuristic: page number is the last dash-separated token before extension: something-3.png
            base = os.path.splitext(os.path.basename(fn))[0]
            page_num = None
            try:
                token = base.split("-")[-1]
                page_num = int(token)
            except Exception:
                # Fallback: try to find any trailing digits
                digits = ""
                for ch in reversed(base):
                    if ch.isdigit():
                        digits = ch + digits
                    else:
                        break

                if digits:
                    try:
                        page_num = int(digits)
                    except Exception:
                        page_num = None

            if page_num is None:
                continue

            candidates.append((page_num, full))

    candidates.sort(key=lambda x: x[0])
    return candidates


def _load_cached_outputs(pdf_output_dir: str) -> Tuple[Optional[Dict[str, str]], Optional[dict]]:
    page_response_path = os.path.join(pdf_output_dir, "page_response.json")
    ocr_metrics_path = os.path.join(pdf_output_dir, "ocr_metrics.json")
    cached_pages = _safe_read_json(page_response_path)
    cached_metrics = _safe_read_json(ocr_metrics_path)

    # ensure the page_response shape is dict[str, str]
    if isinstance(cached_pages, dict):
        # allow any values, but coerce to str in-memory when used
        pass
    else:
        cached_pages = None

    if not isinstance(cached_metrics, dict):
        cached_metrics = None

    return cached_pages, cached_metrics


def _write_outputs(
    pdf_output_dir: str,
    page_text_by_num: Dict[int, str],
    metrics_payload: dict,
) -> None:
    page_response_path = os.path.join(pdf_output_dir, "page_response.json")
    ocr_metrics_path = os.path.join(pdf_output_dir, "ocr_metrics.json")

    # mimic textract.py: keys as strings
    page_response_json = {str(k): v for k, v in sorted(page_text_by_num.items(), key=lambda x: x[0])}

    _atomic_write_json(page_response_path, page_response_json)
    _atomic_write_json(ocr_metrics_path, metrics_payload)


def _ocr_single_page(page_num: int, image_path: str) -> _PageOcrResult:
    start = time.perf_counter()
    model_name = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME") or OCR_MODEL_CFG.get("model_name", "gpt-4o")

    if "gemini" in model_name.lower():
        text, in_tok, out_tok = gemini_vision_call(
            OCR_PROMPT,
            [image_path],  # per-page call
            model=model_name,
            api_version=OCR_MODEL_CFG.get("api_version"),
            thinking_level="LOW"
        )
    else:
        text, in_tok, out_tok = gpt_vision_call(
            OCR_PROMPT,
            [image_path],
            model_name=model_name,
            api_version=OCR_MODEL_CFG.get("api_version") or "2024-10-21"
        )

    elapsed = time.perf_counter() - start
    cost = models.compute_cost(in_tok, out_tok, OCR_MODEL_CFG)

    return _PageOcrResult(
        page_num=page_num,
        text=text or "",
        input_tokens=int(in_tok or 0),
        output_tokens=int(out_tok or 0),
        cost=float(cost),
        time_seconds=float(elapsed),
        image_path=image_path,
    )


def _aggregate_metrics(page_results: List[_PageOcrResult], *, company: str, filename: str) -> dict:
    total_time = sum(r.time_seconds for r in page_results)
    total_in = sum(r.input_tokens for r in page_results)
    total_out = sum(r.output_tokens for r in page_results)
    total_cost = sum(r.cost for r in page_results)

    return {
        "stage": OCR_STAGE_NAME,
        "company": company,
        "filename": filename,
        "model": OCR_MODEL_CFG["model_name"],
        "api_version": OCR_MODEL_CFG.get("api_version"),
        "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "aggregate": {
            "time_seconds": total_time,
            "input_tokens": total_in,
            "output_tokens": total_out,
            "cost": total_cost,
            "pages": len(page_results),
        },
        "pages": [
            {
                "page_num": r.page_num,
                "image_path": r.image_path,
                "time_seconds": r.time_seconds,
                "input_tokens": r.input_tokens,
                "output_tokens": r.output_tokens,
                "cost": r.cost,
            }
            for r in sorted(page_results, key=lambda x: x.page_num)
        ],
    }


def _replay_cached_metrics_to_store(company: str, filename: str, cached_metrics: Optional[dict]) -> None:
    """
    When override=False and we skip OCR due to cache, we still want metrics.py to reflect
    the time/cost as if it ran (per requirements).
    """
    if not cached_metrics:
        return

    agg = cached_metrics.get("aggregate", {})
    if not isinstance(agg, dict):
        return

    record_stage(
        company,
        filename,
        OCR_STAGE_NAME,
        time_seconds=float(agg.get("time_seconds", 0.0) or 0.0),
        input_tokens=int(agg.get("input_tokens", 0) or 0),
        output_tokens=int(agg.get("output_tokens", 0) or 0),
        cost=float(agg.get("cost", 0.0) or 0.0),
    )


async def _ocr_company_async(
    company: str,
    jobs: List[Tuple[str, str, List[Tuple[int, str]]]],  # (filename, pdf_dir, page_images)
    *,
    max_concurrency: int,
) -> Dict[str, Tuple[List[_PageOcrResult], List[Tuple[int, str, str]], List[Tuple[int, str]]]]:
    """
    OCR all pages for a single company with one shared concurrency limit.

    Returns a dict keyed by pdf_dir:
      pdf_dir -> (page_results, failures, page_images)
    """
    sem = asyncio.Semaphore(max_concurrency)

    # flatten to per-page tasks, but keep routing info so we can re-group by pdf_dir
    flat: List[Tuple[str, str, int, str]] = []  # (pdf_dir, filename, page_num, img_path)
    by_pdf: Dict[str, Tuple[str, List[Tuple[int, str]]]] = {}  # pdf_dir -> (filename, page_images)

    total_pages = 0
    for filename, pdf_dir, page_images in jobs:
        by_pdf[pdf_dir] = (filename, page_images)
        total_pages += len(page_images)
        for page_num, img_path in page_images:
            flat.append((pdf_dir, filename, page_num, img_path))

    results_by_pdf: Dict[str, List[_PageOcrResult]] = defaultdict(list)
    failures_by_pdf: Dict[str, List[Tuple[int, str, str]]] = defaultdict(list)

    pbar = tqdm(total=total_pages, desc=f"OCR {company}", unit="page", leave=True)

    async def _run_one(pdf_dir: str, page_num: int, img_path: str) -> None:
        async with sem:
            try:
                res = await asyncio.to_thread(_ocr_single_page, page_num, img_path)
                results_by_pdf[pdf_dir].append(res)
            except Exception as e:
                failures_by_pdf[pdf_dir].append((page_num, img_path, str(e)))
            finally:
                pbar.update(1)

    try:
        await asyncio.gather(*(_run_one(pdf_dir, page_num, img_path) for pdf_dir, _, page_num, img_path in flat))
    finally:
        pbar.close()

    out: Dict[str, Tuple[List[_PageOcrResult], List[Tuple[int, str, str]], List[Tuple[int, str]]]] = {}
    for pdf_dir, (filename, page_images) in by_pdf.items():
        out[pdf_dir] = (results_by_pdf.get(pdf_dir, []), failures_by_pdf.get(pdf_dir, []), page_images)

    return out


def _log_ocr_summary(
    company: str,
    pdf_name: str,
    *,
    time_seconds: float,
    cost: float,
    input_tokens: int = 0,
    output_tokens: int = 0,
    pages_total: int | None = None,
    pages_succeeded: int | None = None,
    failures_count: int = 0,
    cached: bool = False,
) -> None:
    """
    Print per-PDF OCR summary in the same style/indentation as determine_pdf_cutoff._log_chunk_decision.
    """
    cached_tag = " (cached)" if cached else ""
    status_emoji = "✅" if not failures_count else "⚠️"

    print(f"        Company: {company}")
    print(f"        {status_emoji} OCR{cached_tag}: {pdf_name}")

    if pages_total is not None:
        if pages_succeeded is None:
            pages_succeeded = pages_total
        if failures_count:
            print(f"            Pages: {pages_succeeded}/{pages_total} succeeded ({failures_count} failed)")
        else:
            print(f"            Pages: {pages_succeeded}/{pages_total} succeeded")

    print(f"            ⏱️ OCR Time: {float(time_seconds or 0.0):.2f} seconds")
    print(f"            💲 OCR Cost: ${float(cost or 0.0):.6f}")


def _replay_cached_metrics_to_store(company: str, filename: str, cached_metrics: Optional[dict]) -> None:
    """
    When override=False and we skip OCR due to cache, we still want metrics.py to reflect
    the time/cost as if it ran (per requirements).
    """
    if not cached_metrics:
        return

    agg = cached_metrics.get("aggregate", {})
    if not isinstance(agg, dict):
        return

    time_seconds = float(agg.get("time_seconds", 0.0) or 0.0)
    input_tokens = int(agg.get("input_tokens", 0) or 0)
    output_tokens = int(agg.get("output_tokens", 0) or 0)
    cost = float(agg.get("cost", 0.0) or 0.0)

    record_stage(
        company,
        filename,
        OCR_STAGE_NAME,
        time_seconds=time_seconds,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        cost=cost,
    )

    # Print cached summary in the same CLI style
    _log_ocr_summary(
        company,
        filename,
        time_seconds=time_seconds,
        cost=cost,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        pages_total=int(agg.get("pages", 0) or 0) or None,
        cached=True,
    )


def run_ocr(
    company_names: List[str],
    input_path: str,
    output_path: str,
    *,
    use_cached: bool = True,
) -> None:
    """
    Run OCR for all PDFs

    Args:
        company_names: list of company folders to process (under input_path/output_path)
        input_path: base input_data directory (unused for OCR itself; kept for parity)
        output_path: base output_data directory (where per-file folders live)
        use_cached: if True, use cached outputs when present; if False, force re-ocr and overwrite.
        max_workers: thread count for per-PDF page parallelism.
    """
    for company in company_names:
        company_out_dir = _long_path(os.path.join(output_path, company))
        if not os.path.isdir(company_out_dir):
            continue

        company_jobs: List[Tuple[str, str, List[Tuple[int, str]]]] = []

        for file_or_dir in os.listdir(company_out_dir):
            pdf_dir = _long_path(os.path.join(company_out_dir, file_or_dir))
            if not os.path.isdir(pdf_dir):
                continue

            filename = file_or_dir
            page_images = _list_page_images(pdf_dir)
            if not page_images:
                continue

            cached_pages, cached_metrics = _load_cached_outputs(pdf_dir)

            # If we're allowed to use cache and we have it, replay metrics and skip OCR
            if use_cached and isinstance(cached_pages, dict) and cached_pages:
                _replay_cached_metrics_to_store(company, filename, cached_metrics)
                continue

            company_jobs.append((filename, pdf_dir, page_images))

        if not company_jobs:
            continue

        per_pdf = asyncio.run(
            _ocr_company_async(
                company,
                company_jobs,
                max_concurrency=DEFAULT_MAX_WORKERS,
            )
        )

        for filename, pdf_dir, page_images in company_jobs:
            page_results, failures, _page_images = per_pdf.get(pdf_dir, ([], [], page_images))

            page_text_by_num: Dict[int, str] = {p: "" for p, _ in page_images}
            for r in page_results:
                page_text_by_num[r.page_num] = r.text or ""

            metrics_payload = _aggregate_metrics(page_results, company=company, filename=filename)
            if failures:
                metrics_payload["failures"] = [
                    {"page_num": p, "image_path": img, "error": err}
                    for (p, img, err) in sorted(failures, key=lambda x: x[0])
                ]

            _write_outputs(pdf_dir, page_text_by_num, metrics_payload)

            agg = metrics_payload["aggregate"]
            record_stage(
                company,
                filename,
                OCR_STAGE_NAME,
                time_seconds=float(agg.get("time_seconds", 0.0)),
                input_tokens=int(agg.get("input_tokens", 0)),
                output_tokens=int(agg.get("output_tokens", 0)),
                cost=float(agg.get("cost", 0.0)),
            )

            _log_ocr_summary(
                company,
                filename,
                time_seconds=float(agg.get("time_seconds", 0.0) or 0.0),
                cost=float(agg.get("cost", 0.0) or 0.0),
                input_tokens=int(agg.get("input_tokens", 0) or 0),
                output_tokens=int(agg.get("output_tokens", 0) or 0),
                pages_total=len(page_images),
                pages_succeeded=len(page_results),
                failures_count=len(failures),
                cached=False,
            )
