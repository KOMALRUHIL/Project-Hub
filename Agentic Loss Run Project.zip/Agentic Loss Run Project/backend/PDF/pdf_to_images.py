import os
import time
import json
import base64
from mimetypes import guess_type
import fitz # PyMuPDF
from PIL import Image, ImageDraw, ImageFont
import models
from utils_gpt_vision import gpt_vision_call

# ROTATION_DETECTION_MODEL = models.GPT_5_MINI

# def detect_rotation(image_path):
#     """
#     Detects if a PDF page needs to be rotated to be read correctly.
#     Vision good at knowing when rotation is needed, but not good at knowing the degrees to fix.
#     """
#
#     detection_prompt = """
# You are tasked as a document orientation specialist. Your primary responsibility is to analyze and correct the orientation of various documents, including pages with text, tables, handwriting, and images, ensurin
#
# You will be provided with the exact same exact page four times, each with a different rotation. The task is to identify the only image that reflects the normal reading orientation out of the four images.
#
# The normal reading orientation would ensure text and tables are read from left to right and top to bottom.
# Conflicting Cues: In situations where different elements (like text and images) suggest conflicting orientations, give priority to the orientation suggested by text and tables.
#
# Your output should select which image is correctly oriented by responding with a JSON array in the following format:
# Ensure the JSON is valid. No Markdown, no explanation.
# [
#     {
#         "correct_image": <1, 2, 3, or 4>
#     }
# ]
# """
#
#     # Take in the image_path
#     # Generate the 4 orientations
#     # Pass main prompt & all of them into messages using the code from the blog
#     # Get the output from vision to select which of the 4 images to use
#
#     # Generate the 4 orientations and save them
#     img = Image.open(image_path)
#     rotations = [0, 90, 180, 270]
#     rotated_image_paths = []
#     base, ext = os.path.splitext(image_path)
#     for idx, angle in enumerate(rotations):
#         rotated_img = img.rotate(-angle, expand=True)
#         rotated_path = f"{base}_rot{angle}{ext}"
#         rotated_img.save(rotated_path)
#         rotated_image_paths.append(rotated_path)
#
#     # Encodes Image to format for Prompt
#     def encode_image(image_path):
#         # Guess the MIME type of the image based on the file extension
#         mime_type, _ = guess_type(image_path)
#         if mime_type is None:
#             mime_type = 'application/octet-stream' # Default MIME type if none is found
#
#         with open(image_path, "rb") as image_file:
#             encoded_string = base64.b64encode(image_file.read()).decode('utf-8')
#         return f"data:{mime_type};base64,{encoded_string}"
#
#     # Pass prompt to vision
#     messages = [
#         {
#             "role": "user",
#             "content": [
#                 {"type": "text", "text": detection_prompt},
#                 {
#                     "type": "image_url",
#                     "image_url": {"url": encode_image(rotated_image_paths[0])}
#                 },
#                 {
#                     "type": "image_url",
#                     "image_url": {"url": encode_image(rotated_image_paths[1])}
#                 },
#                 {
#                     "type": "image_url",
#                     "image_url": {"url": encode_image(rotated_image_paths[2])}
#                 },
#                 {
#                     "type": "image_url",
#                     "image_url": {"url": encode_image(rotated_image_paths[3])}
#                 }
#             ]
#         }
#     ]
#
#     for attempt in range(5):
#         try:
#             output, _, _ = gpt_vision_call(
#                 prompt=messages,
#                 model_name=ROTATION_DETECTION_MODEL["model_name"],
#                 api_version=ROTATION_DETECTION_MODEL["api_version"]
#             )
#             # Parse output as JSON list
#             output_json = json.loads(output)
#             correct_image = int(output_json[0]["correct_image"])
#             # Get the angle corresponding to correct image
#             # 1 -> 0, 2 -> 90, 3 -> 180, 4 -> 270
#             angles = [0, 90, 180, 270]
#             angle = angles[correct_image - 1]
#
#             # Rotate the original image to the correct orientation and save
#             if angle != 0:
#                 img = Image.open(image_path)
#                 img = img.rotate(-angle, expand=True)
#                 img.save(image_path)
#                 print(f"Corrected orientation for {image_path} (rotated by {angle} degrees)")
#
#             # Clean up temporary rotated images
#             for path in rotated_image_paths:
#                 if path != image_path:
#                     try:
#                         os.remove(path)
#                     except Exception as e:
#                         print(f"Warning: Could not delete {path}: {e}")
#             return angle
#         except Exception as e:
#             print(f"Failed attempt {attempt + 1} to detect rotation: {e}")
#             time.sleep(1)
#     print("Max retries reached. Keeping original image.")
#     for path in rotated_image_paths:
#         if path != image_path:
#             try:
#                 os.remove(path)
#             except Exception as e:
#                 print(f"Warning: Could not delete {path}: {e}")
#     return 0 # Default to 0 degrees if failed, since original is kept


def _long_path(path):
    """Prefix path with \\\\?\\\\ on Windows to support paths longer than 260 characters."""
    path = os.path.abspath(path)
    if os.name == 'nt' and not path.startswith('\\\\?\\\\'):
        path = '\\\\?\\\\' + path
    return path


def pdf_to_images(pdf_path, output_dir, bar_height=160, dpi=450):
    """
    Converts each page of a PDF to an image, adds a black bar with page number, and saves to output_dir.
    Returns a list of saved image paths.
    """
    output_dir = _long_path(output_dir)
    os.makedirs(output_dir, exist_ok=True)
    doc = fitz.open(pdf_path)
    image_paths = []

    for i, page in enumerate(doc):
        pix = page.get_pixmap(dpi=dpi)
        image_path = os.path.join(output_dir, f"image-page-{i+1}.jpg")
        pix.save(image_path)

        # Open image and correct orientation if needed
        img = Image.open(image_path)
        # rotation_value = detect_rotation(image_path)
        # if rotation_value and rotation_value in [90, 180, 270]:
        #     print(f"    GPT Vision Rotated: {pdf_path} page {i+1} by {rotation_value} degrees")

        # Re open with the updated image
        img = Image.open(image_path)

        # Add black bar with page number
        new_img = Image.new("RGB", (img.width, img.height + bar_height), "black")
        new_img.paste(img, (0, bar_height))

        draw = ImageDraw.Draw(new_img)
        try:
            font = ImageFont.truetype("arialbd.ttf", 96)
        except:
            font = ImageFont.load_default()
        text = f"Page {i+1}"
        bbox = draw.textbbox((0, 0), text, font=font)
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]
        text_x = (img.width - text_width) // 2
        text_y = (bar_height - text_height) // 2
        draw.text((text_x, text_y), text, fill="white", font=font)
        new_img.save(image_path)
        image_paths.append(image_path)

    return image_paths


def turn_pdf_to_images(companies, input_root, output_root):

    for company in companies:
        company_dir = os.path.join(input_root, company)
        if not os.path.isdir(company_dir):
            continue
        for filename in os.listdir(company_dir):
            if filename.lower().endswith(".pdf"):
                pdf_path = os.path.join(company_dir, filename)
                output_dir = _long_path(os.path.join(output_root, company, filename))
                os.makedirs(output_dir, exist_ok=True)

                # NEW: if images already exist for this file, skip
                already_has_images = any(
                    fname.lower().startswith("image-page-")
                    and fname.lower().endswith(".jpg")
                    for fname in os.listdir(output_dir)
                )
                if already_has_images:
                    continue

                pdf_to_images(pdf_path, output_dir)


if __name__ == "__main__":
    pdf_to_images(["Jason Douglas Holdings LLC"])
