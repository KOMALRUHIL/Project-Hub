"""Sheet Context Agent - classifies sheets for extraction and context propagation.

Instead of a binary "relevant / not relevant" decision, this agent produces
three outputs per sheet:

    1. `parse_full_sheet` - should the pipeline run full segmentation and
       extraction on this sheet?
    2. `is_still_relevant` - even if the sheet is not fully extracted, does
       it still contain metadata, labels, mappings, notes, or other context
       useful to downstream extraction?
    3. `sheet_summary` - a rich, up-to-10-sentence summary containing the
       most concrete values visible on the sheet.

The decision matrix is intentionally schema-driven rather than domain-locked:

    parse=False & relevant=False -> drop the sheet entirely
    parse=True  & relevant=True  -> fully extract the sheet
    parse=True  & relevant=False -> fully extract the sheet (normal flow)
    parse=False & relevant=True  -> treat as a context donor and propagate the
                                    summary to extractable sheets as fallback
                                    metadata/context

This module replaces `file_relevancy.classify_workbook_sheets` in the
preferred pipeline path so metadata-only sheets (cover pages, setup tabs,
reference tabs, summary tabs, notes, etc.) contribute their context instead
of being silently dropped.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Tuple

import models
from file_relevancy import (
    _build_sheet_snippets,
    get_relevancy_model,
)
from prompts import (
    SHEET_CONTEXT_AGENT_SYSTEM_TEMPLATE,
    SHEET_CONTEXT_AGENT_USER_TEMPLATE,
)
from utils import as_extended_path_str as _as_extended_path_str
from utils import log_cli
from utils_gpt import gpt_call


# - Data model -------------------------------------------------------------

@dataclass
class SheetContextClassification:
    """Per-sheet classification result from the Sheet Context Agent.

    Attributes
    ----------
    sheet_name : str
        The Excel sheet tab name.
    parse_full_sheet : bool
        True -> run segmentation + extraction on this sheet.
    is_still_relevant : bool
        True -> sheet carries metadata useful to other extractable sheets.
    sheet_summary : str
        Rich, up-to-10-sentence summary with **concrete values** (not
        generic descriptions). For context-donor sheets this is the sole
        vehicle through which metadata reaches the extraction code, so it
        must exhaustively list every date, name, number, and identifier
        found on the sheet.
    """

    sheet_name: str
    parse_full_sheet: bool      # Run segmentation + extraction on this sheet?
    is_still_relevant: bool     # Contains metadata useful to other sheets?
    sheet_summary: str          # Rich up-to-10-sentence summary (concrete metadata values)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# - Core function ----------------------------------------------------------

def classify_sheets_with_context(
    file_path: str,
    file_name: str | None = None,
    schema_text: str = "",
    instructions_text: str = "",
    precomputed_snippets: List[Dict[str, Any]] | None = None,
) -> Tuple[Dict[str, SheetContextClassification], int, int]:
    """Classify each sheet in a workbook with three-outcome context awareness.

    Parameters
    ----------
    file_path:
        Full path to the Excel file.
    file_name:
        Optional display name (used only for logging).
    schema_text:
        Serialized output schema (passed to LLM so it understands the goal).
    instructions_text:
        Domain extraction instructions (passed to LLM for context).
    precomputed_snippets:
        Optional pre-extracted sheet snippets from a prior
        `detect_relevant_file` call. When provided, the Excel file
        is NOT re-opened, saving I/O and pandas overhead.

    Returns
    -------
    classifications : dict[str, SheetContextClassification]
        Per-sheet classification keyed by sheet name.
    input_tokens : int
    output_tokens : int
    """
    display = file_name or os.path.basename(file_path)

    # -- CSV files: single-sheet, always parse -----------------------------
    if file_path.lower().endswith(".csv"):
        return {
            "Sheet1": SheetContextClassification(
                sheet_name="Sheet1",
                parse_full_sheet=True,
                is_still_relevant=True,
                sheet_summary="Single-sheet CSV file; parse fully for extraction.",
            )
        }, 0, 0

    # -- Use precomputed snippets if available -----------------------------
    if precomputed_snippets is not None and len(precomputed_snippets) > 0:
        sheet_names = [s["sheet"] for s in precomputed_snippets]
        if len(sheet_names) < 2:
            # Single-sheet workbook - always parse, no classification needed
            name = sheet_names[0]
            return {
                name: SheetContextClassification(
                    sheet_name=name,
                    parse_full_sheet=True,
                    is_still_relevant=True,
                    sheet_summary="Single-sheet workbook; parse fully for extraction.",
                )
            }, 0, 0
        sheet_snippets = precomputed_snippets
    else:
        # -- Use shared snippet builder (handles file-open + close) --------
        sheet_snippets = _build_sheet_snippets(
            file_path,
            log_context="sheet context agent",
        )

        if not sheet_snippets:
            return {}, 0, 0

    sheet_names = [s["sheet"] for s in sheet_snippets]

    if len(sheet_names) < 2:
        name = sheet_names[0] if sheet_names else "Sheet1"
        return {
            name: SheetContextClassification(
                sheet_name=name,
                parse_full_sheet=True,
                is_still_relevant=True,
                sheet_summary="Single-sheet workbook; parse fully for extraction.",
            )
        }, 0, 0

    if not sheet_snippets:
        # No readable content - default all sheets to parse
        all_names = [s["sheet"] for s in (precomputed_snippets or [])] or ["Sheet1"]
        return {
            name: SheetContextClassification(
                sheet_name=name,
                parse_full_sheet=True,
                is_still_relevant=True,
                sheet_summary="No readable content; defaulting to full parse.",
            )
            for name in all_names
        }, 0, 0

    # -- Build prompt and call LLM -----------------------------------------
    snippets_json = json.dumps(sheet_snippets, ensure_ascii=False, default=str)

    system_message = SHEET_CONTEXT_AGENT_SYSTEM_TEMPLATE.format(
        schema_text=schema_text,
        instructions_text=instructions_text,
    )
    user_message = SHEET_CONTEXT_AGENT_USER_TEMPLATE.format(input=snippets_json)

    _model = get_relevancy_model()
    raw_output, in_tokens, out_tokens = gpt_call(
        prompt=user_message,
        model_name=_model["model_name"],
        api_version=_model["api_version"],
        system_message=system_message,
    )

    # -- Parse response ----------------------------------------------------
    classifications: Dict[str, SheetContextClassification] = {}
    all_sheet_names = [s["sheet"] for s in sheet_snippets]

    if not raw_output:
        log_cli(
            f"[WARN] Sheet context agent LLM returned empty for {display}; "
            "defaulting all sheets to parse_full_sheet=True."
        )
        return {
            name: SheetContextClassification(
                sheet_name=name,
                parse_full_sheet=True,
                is_still_relevant=True,
                sheet_summary="LLM returned empty; defaulting to full parse.",
            )
            for name in all_sheet_names
        }, in_tokens, out_tokens

    try:
        result = json.loads(raw_output)
        sheets_dict = result.get("sheets", result)

        if isinstance(sheets_dict, dict):
            for sname, info in sheets_dict.items():
                if isinstance(info, dict):
                    classifications[sname] = SheetContextClassification(
                        sheet_name=sname,
                        parse_full_sheet=bool(info.get("parse_full_sheet", True)),
                        is_still_relevant=bool(info.get("is_still_relevant", True)),
                        sheet_summary=str(info.get("sheet_summary", "")),
                    )
                elif isinstance(info, bool):
                    # Backward-compatible: treat bool as parse_full_sheet
                    classifications[sname] = SheetContextClassification(
                        sheet_name=sname,
                        parse_full_sheet=info,
                        is_still_relevant=info,
                        sheet_summary="",
                    )
        elif isinstance(sheets_dict, list):
            for entry in sheets_dict:
                if isinstance(entry, dict) and "sheet" in entry:
                    sname = entry["sheet"]
                    classifications[sname] = SheetContextClassification(
                        sheet_name=sname,
                        parse_full_sheet=bool(entry.get("parse_full_sheet", True)),
                        is_still_relevant=bool(entry.get("is_still_relevant", True)),
                        sheet_summary=str(entry.get("sheet_summary", "")),
                    )
    except (json.JSONDecodeError, TypeError) as exc:
        log_cli(
            f"[WARN] Could not parse sheet context agent response for {display}: "
            f"{exc}; defaulting all sheets to parse_full_sheet=True."
        )
        return {
            name: SheetContextClassification(
                sheet_name=name,
                parse_full_sheet=True,
                is_still_relevant=True,
                sheet_summary="Unparseable LLM response; defaulting to full parse.",
            )
            for name in all_sheet_names
        }, in_tokens, out_tokens

    # -- Safety: ensure every sheet has a classification -------------------
    for name in all_sheet_names:
        if name not in classifications:
            classifications[name] = SheetContextClassification(
                sheet_name=name,
                parse_full_sheet=True,
                is_still_relevant=True,
                sheet_summary="No classification returned; defaulting to full parse.",
            )

    # -- Safety: don't skip ALL sheets -------------------------------------
    any_parse = any(c.parse_full_sheet for c in classifications.values())
    if not any_parse:
        log_cli(
            f"[WARN] Sheet context agent marked all sheets as parse_full_sheet=False "
            f"for {display}; overriding all to True."
        )
        for c in classifications.values():
            c.parse_full_sheet = True

    return classifications, in_tokens, out_tokens


# - Helper: derive legacy-compatible boolean sheet classifications ---------

def derive_sheet_classifications(
    context_classifications: Dict[str, SheetContextClassification],
) -> Dict[str, bool]:
    """Convert rich classifications to the legacy `{sheet_name: bool}` format.

    The boolean indicates `parse_full_sheet` - sheets that should be
    segmented and extracted. This is consumed by
    `segment_summarizer.summarize_segmented_payload()` which expects
    the old-style dict.
    """
    return {
        name: cls.parse_full_sheet
        for name, cls in context_classifications.items()
    }


def build_context_sheet_summaries(
    context_classifications: Dict[str, SheetContextClassification],
) -> List[Dict[str, str]]:
    """Build a list of cross-sheet context summaries for injection.

    Returns summaries ONLY from sheets where:
        parse_full_sheet=False AND is_still_relevant=True

    These are the **context-donor** (metadata-only) sheets whose rich
    summary should be injected into every extractable sheet's segment
    payload. The downstream extraction logic can use these summaries to
    populate schema fields that do not appear in the current table but do
    appear on another relevant sheet in the workbook.

    Each returned dict has:
        - `source_sheet`: the tab name the metadata came from
        - `summary`: the rich up-to-10-sentence summary with every
          concrete value found on the sheet
    """
    summaries: List[Dict[str, str]] = []
    for name, cls in context_classifications.items():
        if not cls.parse_full_sheet and cls.is_still_relevant and cls.sheet_summary:
            summaries.append({
                "source_sheet": name,
                "summary": cls.sheet_summary,
            })
    return summaries
