"""Pipeline metrics - record, aggregate, and save run data as JSON.

All agents record metrics through the public functions in this module.
At the end of a pipeline run, `save_metrics_json()` writes a single
hierarchical JSON file with:

    1. **Accounts** - per-account pipeline_wall_times, pipeline_steps
       (aggregated across files), per-file totals/steps/segments.
    2. **Account totals** - quick summary of each account's cost.
    3. **Grand total** - sum of all account-level totals (at the extreme end).
"""

from __future__ import annotations

import json
import logging
import os
import re
import threading
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List

# ---------------------------------------------------------------------------
# In-memory stores
# ---------------------------------------------------------------------------

_lock = threading.Lock()

logger = logging.getLogger(__name__)

# Per-(company, file, step) additive counters
_metrics = defaultdict(lambda: defaultdict(dict))

# Per-(company, file) list of rich per-segment detail dicts
_segments: Dict[str, Dict[str, List[Dict[str, Any]]]] = defaultdict(
    lambda: defaultdict(list)
)

# Pipeline-level steps (relevancy_detection, final_validation, etc.).
#
# Semantics:
# - `time_seconds` is the pipeline-node wall-clock time.
# - For steps that parallelize internal work (for example final validation),
#   extra fields such as `accumulated_work_time_seconds` may exceed wall-clock
#   because they represent summed worker time rather than elapsed time.
_pipeline_steps: Dict[str, Dict[str, Any]] = {}

# LangGraph node wall-clock timings
_pipeline_wall_times: Dict[str, float] = {}

# Per-(company, file) -> {sheet_name: {"source_file": ..., "routing_reason": ...}}
_sheet_sources: Dict[str, Dict[str, Dict[str, Dict[str, str]]]] = defaultdict(
    lambda: defaultdict(dict)
)


def reset_metrics_store():
    """Clear all in-memory metric stores before a new pipeline run."""
    with _lock:
        _metrics.clear()
        _segments.clear()
        _pipeline_steps.clear()
        _pipeline_wall_times.clear()
        _sheet_sources.clear()


def _is_synthetic_filename(filename: str) -> bool:
    """Return True for bookkeeping-only metric buckets, not real source files."""
    return filename.startswith("_") and filename.endswith("_")


def _normalize_scope_key(value: str | None) -> str:
    """Normalize a company/file lookup key for resilient scoped metrics lookup."""
    if value is None:
        return ""
    return "-".join(str(value).strip().split()).casefold()


_COMPANY_SUFFIX_TOKENS = {
    "co",
    "company",
    "corp",
    "corporation",
    "inc",
    "incorporated",
    "limited",
    "ltd",
    "llc",
    "lp",
    "llp",
    "plc",
}


def _simplify_company_key(value: str | None) -> str:
    """Return a loose company key that ignores punctuation and legal suffixes."""
    normalized = _normalize_scope_key(Path(str(value or "").strip()).stem)
    if not normalized:
        return ""

    tokens = [token for token in re.split(r"[^a-z0-9]+", normalized) if token]
    while tokens and tokens[-1] in _COMPANY_SUFFIX_TOKENS:
        tokens.pop()
    return "-".join(tokens)


def _resolve_company_keys(
    requested_company: str | None,
    available_companies: List[str],
) -> List[str]:
    """Resolve a requested company name against recorded metric keys.

    The pipeline normally uses the same company string end-to-end, but in
    practice account-scoped saves can miss when names differ only by casing,
    repeated whitespace, filesystem-derived stems, or common legal suffixes.
    Return all matching aliases so they can be merged into one scoped payload.
    """
    if requested_company is None:
        return []

    matches: List[str] = []

    def _extend(candidates: List[str]) -> None:
        for candidate in candidates:
            if candidate not in matches:
                matches.append(candidate)

    if requested_company in available_companies:
        _extend([requested_company])

    normalized_request = _normalize_scope_key(requested_company)
    if not normalized_request:
        return matches

    _extend([
        company for company in available_companies
        if _normalize_scope_key(company) == normalized_request
    ])

    stem_request = _normalize_scope_key(Path(str(requested_company).strip()).stem)
    if stem_request:
        _extend([
            company for company in available_companies
            if _normalize_scope_key(Path(str(company).strip()).stem) == stem_request
        ])

    simplified_request = _simplify_company_key(requested_company)
    if simplified_request:
        _extend([
            company for company in available_companies
            if _simplify_company_key(company) == simplified_request
        ])

    if matches:
        return matches

    if len(available_companies) == 1:
        return [available_companies[0]]

    return []


def _merge_metric_dicts(records: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Sum common numeric metric fields across multiple records."""
    merged = {
        "time_seconds": 0.0,
        "input_tokens": 0,
        "output_tokens": 0,
        "cost": 0.0,
    }
    extras: Dict[str, Any] = {}

    for record in records:
        merged["time_seconds"] += float(record.get("time_seconds", 0.0))
        merged["input_tokens"] += int(record.get("input_tokens", 0))
        merged["output_tokens"] += int(record.get("output_tokens", 0))
        merged["cost"] += float(record.get("cost", 0.0))
        for key, value in record.items():
            if key not in merged:
                extras[key] = value

    return {
        "time_seconds": round(merged["time_seconds"], 3),
        "input_tokens": merged["input_tokens"],
        "output_tokens": merged["output_tokens"],
        "cost": round(merged["cost"], 6),
        **extras,
    }


def _merge_account_payloads(account_payloads: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Combine multiple account buckets that actually represent one company."""
    merged_files: Dict[str, Any] = {}
    merged_steps: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    merged_wall_times: Dict[str, float] = defaultdict(float)

    for payload in account_payloads:
        for wall_name, wall_value in payload.get("pipeline_wall_times", {}).items():
            merged_wall_times[wall_name] += float(wall_value)

        for step_name, step_values in payload.get("pipeline_steps", {}).items():
            merged_steps[step_name].append(step_values)

        for file_name, file_payload in payload.get("files", {}).items():
            if file_name not in merged_files:
                merged_files[file_name] = file_payload
                continue

            existing = merged_files[file_name]
            existing_steps = existing.get("steps", {})
            for step_name, step_values in file_payload.get("steps", {}).items():
                if step_name in existing_steps:
                    existing_steps[step_name] = _merge_metric_dicts([
                        existing_steps[step_name],
                        step_values,
                    ])
                else:
                    existing_steps[step_name] = step_values

            existing_total = existing.get("total", {})
            existing["total"] = _merge_metric_dicts([
                existing_total,
                file_payload.get("total", {}),
            ])

            existing_segments = list(existing.get("segments", []))
            existing_segments.extend(file_payload.get("segments", []))
            if existing_segments:
                existing["segments"] = existing_segments

    merged_total = _merge_metric_dicts([
        payload.get("total", {})
        for payload in account_payloads
    ])
    merged_total["file_count"] = len(merged_files)

    return {
        "pipeline_wall_times": {
            name: round(value, 6)
            for name, value in merged_wall_times.items()
        },
        "pipeline_steps": {
            step_name: _merge_metric_dicts(step_values)
            for step_name, step_values in merged_steps.items()
        },
        "total": merged_total,
        "files": merged_files,
    }


def _resolve_filename_key(
    requested_filename: str | None,
    available_filenames: List[str],
) -> str | None:
    """Resolve a requested filename against recorded file keys."""
    if requested_filename is None:
        return None

    if requested_filename in available_filenames:
        return requested_filename

    normalized_request = _normalize_scope_key(requested_filename)
    if not normalized_request:
        return None

    normalized_matches = [
        filename for filename in available_filenames
        if _normalize_scope_key(filename) == normalized_request
    ]
    if len(normalized_matches) == 1:
        return normalized_matches[0]

    basename_request = _normalize_scope_key(os.path.basename(str(requested_filename).strip()))
    if basename_request:
        basename_matches = [
            file_key for file_key in available_filenames
            if _normalize_scope_key(os.path.basename(str(file_key).strip())) == basename_request
        ]
        if len(basename_matches) == 1:
            return basename_matches[0]

    if len(available_filenames) == 1:
        return available_filenames[0]

    return None


def record_stage(
    company: str,
    filename: str,
    stage: str,
    *,
    time_seconds: float | None = None,
    input_tokens: int | None = None,
    output_tokens: int | None = None,
    cost: float | None = None,
    **extra: Any,
) -> None:
    """Update metrics for a given (company, file, stage).

    Fields are additive where it makes sense (tokens, time, cost).
    """
    with _lock:
        rec = _metrics[company][filename].setdefault(
            stage,
            {"time_seconds": 0.0, "input_tokens": 0, "output_tokens": 0, "cost": 0.0},
        )

        if time_seconds is not None:
            rec["time_seconds"] += float(time_seconds)
        if input_tokens is not None:
            rec["input_tokens"] += int(input_tokens)
        if output_tokens is not None:
            rec["output_tokens"] += int(output_tokens)
        if cost is not None:
            rec["cost"] += float(cost)
        rec.update(extra)


def record_segment(
    company: str,
    filename: str,
    detail: Dict[str, Any],
) -> None:
    """Append a rich per-segment detail dict for one extraction segment.

    Typical keys (all optional - include what you have):
        index, sheet, row_range, attempts, final_valid, rows_extracted,
        time_seconds, input_tokens, output_tokens, cost,
        generated_code, validation_code,
        errors_found, fixes_applied, rows_dropped,
        attempt_log: [{attempt, code_generated, execution_success,
                       validation_valid, retry_reason}]
    """
    with _lock:
        _segments[company][filename].append(detail)


def record_pipeline_step(
    step_name: str,
    *,
    time_seconds: float | None = None,
    input_tokens: int | None = None,
    output_tokens: int | None = None,
    cost: float | None = None,
    **extra: Any,
) -> None:
    """Record a cross-account pipeline step (relevancy detection, validation, etc.).

    `time_seconds` should represent wall-clock time for the pipeline node.
    Extra keyword arguments are stored verbatim in the step dict; use them for
    observability fields such as `accumulated_work_time_seconds` when a step
    performs parallel work internally.
    """
    with _lock:
        rec = _pipeline_steps.setdefault(
            step_name,
            {"time_seconds": 0.0, "input_tokens": 0, "output_tokens": 0, "cost": 0.0},
        )
        if time_seconds is not None:
            rec["time_seconds"] += float(time_seconds)
        if input_tokens is not None:
            rec["input_tokens"] += int(input_tokens)
        if output_tokens is not None:
            rec["output_tokens"] += int(output_tokens)
        if cost is not None:
            rec["cost"] += float(cost)
        rec.update(extra)


def record_pipeline_wall_times(step_timings: Dict[str, float]):
    """Store LangGraph node wall-clock timings."""
    with _lock:
        _pipeline_wall_times.update(step_timings or {})


def record_sheet_source(
    company: str,
    filename: str,
    sheet_name: str,
    *,
    source_file: str,
    routing_reason: str,
    token_count: int | None = None,
):
    """Record which segmented JSON source was used for a particular sheet.

    Parameters
    ----------
    company : str
        Account / company name.
    filename : str
        The source Excel file being processed.
    sheet_name : str
        The worksheet name.
    source_file : str
        Either `*_segmented.json` (raw) or
        `*_segmented_totals_summary.json` (summarised).
    routing_reason : str
        Why this source was chosen, e.g.
        `"tokens<threshold"` or `"tokens>threshold"`.
    token_count : int | None
        Token count for the sheet (optional, for observability).
    """
    entry: Dict[str, Any] = {
        "source_file": source_file,
        "routing_reason": routing_reason,
    }
    if token_count is not None:
        entry["token_count"] = token_count
    with _lock:
        _sheet_sources[company][filename][sheet_name] = entry


def _empty_metrics_payload() -> Dict[str, Any]:
    """Return an empty metrics payload in the standard schema."""
    return {
        "pipeline_wall_times": {},
        "pipeline_steps": {},
        "accounts": {},
        "account_totals": {},
        "grand_total": {
            "time_seconds": 0.0,
            "accumulated_work_time_seconds": 0.0,
            "time_semantics": "wall_clock_time_seconds",
            "wall_clock_time_seconds": 0.0,
            "wall_clock_time_estimated": False,
            "input_tokens": 0,
            "output_tokens": 0,
            "cost": 0.0,
        },
    }


def _sum_wall_times(pipeline_wall_times: Dict[str, Any] | None) -> float:
    """Return the rounded sum of pipeline wall-clock timings."""
    return round(
        sum(float(value) for value in (pipeline_wall_times or {}).values()),
        3,
    )


def _build_total_payload(
    *,
    accumulated_work_time_seconds: float,
    input_tokens: int,
    output_tokens: int,
    cost: float,
    file_count: int | None = None,
    wall_clock_time_seconds: float | None = None,
    wall_clock_time_estimated: bool | None = None,
) -> Dict[str, Any]:
    """Build a total payload with explicit timing semantics.

    `time_seconds` remains backward compatible and continues to represent
    accumulated work time for account/file totals. Extra fields make that
    meaning explicit and expose wall-clock time when it is available or can be
    estimated.
    """
    payload: Dict[str, Any] = {
        "time_seconds": round(float(accumulated_work_time_seconds), 3),
        "accumulated_work_time_seconds": round(float(accumulated_work_time_seconds), 3),
        "time_semantics": "accumulated_work_time_seconds",
        "input_tokens": int(input_tokens),
        "output_tokens": int(output_tokens),
        "cost": round(float(cost), 6),
    }
    if file_count is not None:
        payload["file_count"] = int(file_count)
    if wall_clock_time_seconds is not None:
        payload["wall_clock_time_seconds"] = round(float(wall_clock_time_seconds), 3)
    if wall_clock_time_estimated is not None:
        payload["wall_clock_time_estimated"] = bool(wall_clock_time_estimated)
    return payload


def _build_full_metrics_payload() -> Dict[str, Any]:
    """Compute the full hierarchical metrics payload using legacy aggregation semantics.

    Output structure::

        accounts          - per-account -> pipeline_wall_times, pipeline_steps,
                             total, files (per-file steps + segments)
        account_totals    - quick per-account cost summary
        grand_total       - sum of all account-level totals (at the end)
    """
    # - Build per-account / per-file / per-step hierarchy -------------------
    accounts_json: Dict[str, Any] = {}

    # - Merge any legacy record_stage("ALL", ...) calls into pipeline_steps
    # Build this locally so repeated save calls do not inflate totals.
    merged_pipeline_steps: Dict[str, Dict[str, Any]] = {
        step_name: dict(vals)
        for step_name, vals in _pipeline_steps.items()
    }
    for _filename, stages in _metrics.get("ALL", {}).items():
        for stage_name, vals in stages.items():
            rec = merged_pipeline_steps.setdefault(
                stage_name,
                {"time_seconds": 0.0, "input_tokens": 0, "output_tokens": 0, "cost": 0.0},
            )
            rec["time_seconds"] += float(vals.get("time_seconds", 0))
            rec["input_tokens"] += int(vals.get("input_tokens", 0))
            rec["output_tokens"] += int(vals.get("output_tokens", 0))
            rec["cost"] += float(vals.get("cost", 0))

    # Collect all non-"ALL" companies and their total times for proportional
    # distribution of global pipeline_wall_times.
    company_names = [c for c in _metrics if c != "ALL"]
    company_times: Dict[str, float] = {}

    for company in company_names:
        files = _metrics[company]
        t = 0.0
        for filename, stages in files.items():
            for vals in stages.values():
                t += float(vals.get("time_seconds", 0))
        company_times[company] = t

    total_company_time = sum(company_times.values()) or 1.0  # avoid div-by-zero

    for company in company_names:
        files = _metrics[company]
        acct_time = 0.0
        acct_in = 0
        acct_out = 0
        acct_cost = 0.0
        files_json: Dict[str, Any] = {}

        # Accumulate per-step totals across all files for this account
        acct_steps_agg: Dict[str, Dict[str, float]] = {}

        for filename, stages in files.items():
            is_synthetic_file = _is_synthetic_filename(filename)
            f_time = 0.0
            f_in = 0
            f_out = 0
            f_cost = 0.0
            steps_json: Dict[str, Any] = {}

            for stage_name, vals in stages.items():
                s_time = float(vals.get("time_seconds", 0))
                s_in = int(vals.get("input_tokens", 0))
                s_out = int(vals.get("output_tokens", 0))
                s_cost = float(vals.get("cost", 0))

                steps_json[stage_name] = {
                    "time_seconds": round(s_time, 3),
                    "input_tokens": s_in,
                    "output_tokens": s_out,
                    "cost": round(s_cost, 6),
                    **{
                        k: v for k, v in vals.items()
                        if k not in {"time_seconds", "input_tokens", "output_tokens", "cost"}
                    },
                }
                f_time += s_time
                f_in += s_in
                f_out += s_out
                f_cost += s_cost

                # Aggregate into account-level step summary
                agg = acct_steps_agg.setdefault(
                    stage_name,
                    {"time_seconds": 0.0, "input_tokens": 0, "output_tokens": 0, "cost": 0.0},
                )
                agg["time_seconds"] += s_time
                agg["input_tokens"] += s_in
                agg["output_tokens"] += s_out
                agg["cost"] += s_cost

            acct_time += f_time
            acct_in += f_in
            acct_out += f_out
            acct_cost += f_cost

            if is_synthetic_file:
                continue

            file_entry: Dict[str, Any] = {
                "total": _build_total_payload(
                    accumulated_work_time_seconds=f_time,
                    input_tokens=f_in,
                    output_tokens=f_out,
                    cost=f_cost,
                ),
                "steps": steps_json,
            }

            # Attach segment details if any
            segs = _segments.get(company, {}).get(filename)
            if segs:
                file_entry["segments"] = segs

            # Attach sheet source routing metadata
            sheet_src = _sheet_sources.get(company, {}).get(filename)
            if sheet_src:
                file_entry["sheet_source_routing"] = dict(sheet_src)

            files_json[filename] = file_entry

        # - Account-level pipeline_steps (aggregated across files) -----------------
        acct_pipeline_steps: Dict[str, Any] = {}
        for step_name, agg in acct_steps_agg.items():
            acct_pipeline_steps[step_name] = {
                "time_seconds": round(float(agg["time_seconds"]), 3),
                "input_tokens": int(agg["input_tokens"]),
                "output_tokens": int(agg["output_tokens"]),
                "cost": round(float(agg["cost"]), 6),
                **{
                    k: v for k, v in agg.items()
                    if k not in {"time_seconds", "input_tokens", "output_tokens", "cost"}
                },
            }

        # - Account-level pipeline_wall_times (distributed proportionally) ---------
        acct_fraction = company_times.get(company, 0.0) / total_company_time
        acct_wall_times: Dict[str, float] = {}
        for wt_name, wt_val in _pipeline_wall_times.items():
            acct_wall_times[wt_name] = round(float(wt_val) * acct_fraction, 6)
        acct_wall_total = _sum_wall_times(acct_wall_times)

        for file_entry in files_json.values():
            file_total = dict(file_entry.get("total", {}))
            file_accumulated_time = float(file_total.get("accumulated_work_time_seconds", file_total.get("time_seconds", 0.0)))
            estimated_file_wall_time = (
                acct_wall_total * (file_accumulated_time / acct_time)
                if acct_time > 0
                else 0.0
            )
            file_entry["total"] = _build_total_payload(
                accumulated_work_time_seconds=file_accumulated_time,
                input_tokens=int(file_total.get("input_tokens", 0)),
                output_tokens=int(file_total.get("output_tokens", 0)),
                cost=float(file_total.get("cost", 0.0)),
                wall_clock_time_seconds=estimated_file_wall_time,
                wall_clock_time_estimated=True,
            )

        accounts_json[company] = {
            "pipeline_wall_times": acct_wall_times,
            "pipeline_steps": acct_pipeline_steps,
            "total": _build_total_payload(
                accumulated_work_time_seconds=acct_time,
                input_tokens=acct_in,
                output_tokens=acct_out,
                cost=acct_cost,
                file_count=len(files_json),
                wall_clock_time_seconds=acct_wall_total,
                wall_clock_time_estimated=(len(company_names) > 1),
            ),
            "files": files_json,
        }

    # - Compute accumulated work totals as the sum of all account totals -------
    grand_time = 0.0
    grand_in = 0
    grand_out = 0
    grand_cost = 0.0

    for acct_data in accounts_json.values():
        acct_total = acct_data["total"]
        grand_time += float(acct_total["time_seconds"])
        grand_in += int(acct_total["input_tokens"])
        grand_out += int(acct_total["output_tokens"])
        grand_cost += float(acct_total["cost"])

    # - Build account-level cost summary ---------------------------------------
    account_totals_json: Dict[str, Any] = {}
    for acct_name, acct_data in accounts_json.items():
        account_totals_json[acct_name] = acct_data["total"]

    pipeline_steps_json: Dict[str, Any] = {}
    for step_name, vals in merged_pipeline_steps.items():
        pipeline_steps_json[step_name] = {
            "time_seconds": round(float(vals.get("time_seconds", 0.0)), 3),
            "input_tokens": int(vals.get("input_tokens", 0)),
            "output_tokens": int(vals.get("output_tokens", 0)),
            "cost": round(float(vals.get("cost", 0.0)), 6),
            **{
                k: v for k, v in vals.items()
                if k not in {"time_seconds", "input_tokens", "output_tokens", "cost"}
            },
        }

    pipeline_wall_times_json = {
        name: round(float(value), 6)
        for name, value in _pipeline_wall_times.items()
    }
    grand_wall_time = _sum_wall_times(pipeline_wall_times_json)

    # - Build file-level relevancy summary -------------------------------------
    file_relevancy_json: Dict[str, Dict[str, bool]] = {}
    for company in company_names:
        company_relevancy: Dict[str, bool] = {}
        for fname, stages in _metrics[company].items():
            if _is_synthetic_filename(fname):
                continue
            rel_stage = stages.get("relevancy_detection")
            if rel_stage is None:
                continue
            status = rel_stage.get("classification_status", "relevant")
            company_relevancy[fname] = status != "not_relevant"
        if company_relevancy:
            file_relevancy_json[company] = company_relevancy

    # - Assemble final JSON ----------------------------------------------------
    data = {
        "pipeline_wall_times": pipeline_wall_times_json,
        "pipeline_steps": pipeline_steps_json,
        "file_relevancy": file_relevancy_json,
        "accounts": accounts_json,
        "account_totals": account_totals_json,
        "grand_total": {
            "time_seconds": grand_wall_time,
            "accumulated_work_time_seconds": round(grand_time, 3),
            "time_semantics": "wall_clock_time_seconds",
            "wall_clock_time_seconds": grand_wall_time,
            "wall_clock_time_estimated": False,
            "input_tokens": grand_in,
            "output_tokens": grand_out,
            "cost": round(grand_cost, 6),
        },
    }

    return data


def _build_grand_total_from_total(
    total: Dict[str, Any],
    pipeline_wall_times: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    """Return a grand-total style dict with wall-clock and accumulated time.

    `total['time_seconds']` is accumulated work time from summed stage/file
    metrics, which can exceed elapsed runtime when work happens in parallel.
    `pipeline_wall_times` represents elapsed wall-clock time for the scoped
    pipeline/account/file view and is what should drive `grand_total`.
    """
    return {
        "time_seconds": _sum_wall_times(pipeline_wall_times)
        if pipeline_wall_times is not None
        else round(float(total.get("time_seconds", 0.0)), 3),
        "accumulated_work_time_seconds": round(
            float(total.get("accumulated_work_time_seconds", total.get("time_seconds", 0.0))),
            3,
        ),
        "time_semantics": "wall_clock_time_seconds"
        if pipeline_wall_times is not None
        else str(total.get("time_semantics", "accumulated_work_time_seconds")),
        **({
            "wall_clock_time_seconds": _sum_wall_times(pipeline_wall_times),
            "wall_clock_time_estimated": bool(total.get("wall_clock_time_estimated", False)),
        } if pipeline_wall_times is not None else {}),
        "input_tokens": int(total.get("input_tokens", 0)),
        "output_tokens": int(total.get("output_tokens", 0)),
        "cost": round(float(total.get("cost", 0.0)), 6),
    }


def _scope_metrics_payload(
    data: Dict[str, Any],
    company_name: str | None = None,
    filename: str | None = None,
) -> Dict[str, Any]:
    """Filter a full metrics payload to one account/file while preserving legacy totals.

    The legacy metrics builder always produced a complete run-level payload.
    For per-account saves, we now scope *that* payload rather than rebuilding a
    narrower payload from scratch. This keeps the JSON generation logic aligned
    with `old_metrics.py` and avoids empty outputs when name resolution is a
    little messy.
    """
    if company_name is None:
        return data

    full_relevancy = data.get("file_relevancy", {})

    accounts = data.get("accounts", {})
    if not accounts:
        return data if any(data.values()) else _empty_metrics_payload()

    resolved_company_names = _resolve_company_keys(company_name, list(accounts.keys()))
    if not resolved_company_names:
        return data

    scoped_accounts = [
        accounts.get(resolved_company_name)
        for resolved_company_name in resolved_company_names
        if accounts.get(resolved_company_name) is not None
    ]
    if not scoped_accounts:
        return data

    scoped_company_name = company_name
    scoped_account = _merge_account_payloads(scoped_accounts)
    scoped_total = scoped_account.get("total", {})

    # Scope file_relevancy to the resolved company names
    scoped_relevancy: Dict[str, Dict[str, bool]] = {}
    for rc in resolved_company_names:
        if rc in full_relevancy:
            for fname, val in full_relevancy[rc].items():
                scoped_relevancy.setdefault(scoped_company_name, {})[fname] = val

    if filename is None:
        return {
            "pipeline_wall_times": data.get("pipeline_wall_times", {}),
            "pipeline_steps": data.get("pipeline_steps", {}),
            "file_relevancy": scoped_relevancy,
            "accounts": {scoped_company_name: scoped_account},
            "account_totals": {scoped_company_name: scoped_total},
            "grand_total": _build_grand_total_from_total(
                scoped_total,
                scoped_account.get("pipeline_wall_times", {}),
            ),
        }

    resolved_filename = _resolve_filename_key(filename, list(scoped_account.get("files", {}).keys()))
    if resolved_filename is None:
        return {
            "pipeline_wall_times": data.get("pipeline_wall_times", {}),
            "pipeline_steps": data.get("pipeline_steps", {}),
            "file_relevancy": scoped_relevancy,
            "accounts": {scoped_company_name: scoped_account},
            "account_totals": {scoped_company_name: scoped_total},
            "grand_total": _build_grand_total_from_total(
                scoped_total,
                scoped_account.get("pipeline_wall_times", {}),
            ),
        }

    scoped_file = scoped_account.get("files", {}).get(resolved_filename)
    if scoped_file is None:
        return {
            "pipeline_wall_times": data.get("pipeline_wall_times", {}),
            "pipeline_steps": data.get("pipeline_steps", {}),
            "file_relevancy": scoped_relevancy,
            "accounts": {scoped_company_name: scoped_account},
            "account_totals": {scoped_company_name: scoped_total},
            "grand_total": _build_grand_total_from_total(
                scoped_total,
                scoped_account.get("pipeline_wall_times", {}),
            ),
        }

    file_total = dict(scoped_file.get("total", {}))
    file_total["file_count"] = 1

    account_total_time = float(scoped_account.get("total", {}).get("time_seconds", 0.0))
    file_total_time = float(file_total.get("time_seconds", 0.0))
    if account_total_time > 0:
        file_fraction = file_total_time / account_total_time
    else:
        file_fraction = 1.0 if scoped_account.get("files", {}) else 0.0

    scoped_account_wall_times = {
        name: round(float(value) * file_fraction, 6)
        for name, value in scoped_account.get("pipeline_wall_times", {}).items()
    }
    scoped_account_payload = {
        "pipeline_wall_times": scoped_account_wall_times,
        "pipeline_steps": scoped_file.get("steps", {}),
        "total": file_total,
        "files": {resolved_filename: scoped_file},
    }

    # Narrow file_relevancy to just the scoped file
    file_scoped_relevancy: Dict[str, Dict[str, bool]] = {}
    company_rel = scoped_relevancy.get(scoped_company_name, {})
    if resolved_filename in company_rel:
        file_scoped_relevancy[scoped_company_name] = {resolved_filename: company_rel[resolved_filename]}

    return {
        "pipeline_wall_times": data.get("pipeline_wall_times", {}),
        "pipeline_steps": data.get("pipeline_steps", {}),
        "file_relevancy": file_scoped_relevancy,
        "accounts": {scoped_company_name: scoped_account_payload},
        "account_totals": {scoped_company_name: file_total},
        "grand_total": _build_grand_total_from_total(
            file_total,
            scoped_account_wall_times,
        ),
    }


def _build_metrics_payload(
    company_name: str | None = None,
    filename: str | None = None,
) -> Dict[str, Any]:
    """Compute the final hierarchical metrics payload.

    The full payload is always assembled using the legacy aggregation rules.
    Optional account/file scoping is then applied as a filtering step so the
    generated JSON stays consistent with `old_metrics.py`.
    """
    full_payload = _build_full_metrics_payload()
    return _scope_metrics_payload(
        full_payload,
        company_name=company_name,
        filename=filename,
    )


def save_metrics_json(
    output_path: str,
    company_name: str | None = None,
    filename: str | None = None,
):
    """Write the final hierarchical metrics JSON to disk.

    When `company_name` is provided, the written file is scoped to that
    account only. When `filename` is also provided, the payload is further
    scoped to that single source file.
    """
    data = _build_metrics_payload(company_name=company_name, filename=filename)

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=str)
