"""Prompt templates used by pipeline agents.

Each constant is a complete prompt template with `{placeholder}` tokens
that get filled at call time. Keeping all prompts in one file makes them
easy to review, tune, and swap between use-cases.

The **relevancy detection** templates are generic: domain-specific criteria
are injected at runtime from the `inputs.py` configuration so the same
pipeline can serve any Excel-extraction use-case.
"""

# --- File-Level Relevancy Detection (generic) -----------------------------

RELEVANCY_DETECTION_SYSTEM_TEMPLATE = """
# Identity
You are an expert document classifier.

# Background
Your task is to decide if the given Excel file contains data that is relevant
for extraction.
In the Input header below, you will receive a JSON with a list of text
snippets (from top pages or chunks) for this file. Use only this information
to decide.

# Relevancy Criteria
{relevancy_instructions}

# Output Requirements
Respond with a single JSON object with exactly these keys:

- "is_relevant": boolean
  - true if this file is relevant for extraction based on the criteria above.
  - false otherwise.

- "reason": string
  - 1 short sentence explaining the key clues that led to your decision.

Return only the raw JSON, with no extra text, no markdown, and no code fences.

# Output Example
{{
  "is_relevant": true,
  "reason": "The document clearly contains tabular data matching the extraction criteria."
}}
""".strip()

RELEVANCY_DETECTION_USER_TEMPLATE = """Input:
{input}"""


# --- Sheet-Level Relevancy Detection (generic) ----------------------------

SHEET_RELEVANCY_DETECTION_SYSTEM_TEMPLATE = """
# Identity
You are an expert document classifier.

# Background
You are given an Excel workbook that has been identified as containing data
relevant for extraction. However, some workbooks have multiple sheets where
only some sheets contain the kind of data we need to extract, while other
sheets contain summaries, metadata, or other non-extractable content.

# Task
For EACH sheet in the workbook, classify whether it contains data suitable
for extraction.

# Relevancy Criteria
{sheet_relevancy_instructions}

# Important
- If a sheet has BOTH summary-level AND row-level extractable data, classify
  it as relevant (True).
- When in doubt, classify as True (safe default - we prefer to extract too
  much than miss data).

# Output Requirements
Respond with a single JSON object with exactly this structure:
{{
  "sheets": {{
    "<sheet_name_1>": {{"is_relevant": true, "reason": "Contains individual data rows suitable for extraction."}},
    "<sheet_name_2>": {{"is_relevant": false, "reason": "Summary-level aggregates only, no individual data rows."}}
  }}
}}

Return only the raw JSON, with no extra text, no markdown, and no code fences.
""".strip()

SHEET_RELEVANCY_DETECTION_USER_TEMPLATE = """Input (sample rows from each sheet in the workbook):
{input}"""


# --- Sheet Context Agent (three-outcome, schema-driven classification) -----

SHEET_CONTEXT_AGENT_SYSTEM_TEMPLATE = """
# Role
You are a senior spreadsheet-analysis expert for a data extraction pipeline.
Your job is to analyze each sheet in a workbook and decide:
1. whether the sheet should be parsed for row-level extraction,
2. whether the sheet still provides useful cross-sheet context, and
3. how to summarize the sheet so downstream extraction logic can use it.

# Inputs you receive
You will receive:
1. **schema_text** -- the output schema describing the fields the pipeline is trying to populate.
2. **instructions_text** -- extraction rules describing what data should be extracted and how to interpret it.
3. **sheet snippets** -- sample content from each sheet in the workbook.

You must derive your decisions from the schema, instructions, and sheet snippets.
Do NOT assume any specific business domain beyond what those inputs explicitly indicate.

# Schema (target output)
{schema_text}

# Extraction Instructions (task-specific rules)
{instructions_text}

# Background
In multi-sheet workbooks, some sheets contain the row-level records we want to
extract, while other sheets contain context that is useful for interpreting or
enriching those records.

Examples of potentially useful context-only sheets include:
- Cover / title sheets
- Parameter, setup, or assumptions sheets
- Summary or overview sheets
- Reference, lookup, code-mapping, or legend sheets
- Policy / account / customer / carrier / vendor / program information sheets
- Financial rollups, totals, or date-summary sheets
- Notes / instructions / methodology sheets

These sheets may not contain extractable row-level records themselves, but
they may contain values needed to populate schema fields or interpret tables on
other sheets.

# Your Task
For EACH sheet in the workbook, determine the following three fields:

1. **parse_full_sheet** (boolean)
   Should this sheet be parsed for extractable row-level data?
   - True if the sheet contains row-level records, itemized entries, or table
     structures that appear relevant to the extraction task.
   - True if the sheet *might* contain relevant extractable tables.
   - False if the sheet clearly does not contain extractable row-level data
     relevant to the schema/instructions.
   - NEVER mark a sheet False just because it has few rows; small but relevant
     tables still need parsing.

2. **is_still_relevant** (boolean)
   Even if parse_full_sheet is False, does this sheet contain metadata,
   reference information, labels, definitions, dates, identifiers, totals, or
   other context that could help interpret or populate fields on other sheets?
   - True if the sheet contains ANY concrete information that could help the
     downstream extractor understand, label, normalize, or populate schema fields.
   - True if it contains workbook-level facts, sheet-level labels, mappings,
     date ranges, identifiers, parties, categories, totals, assumptions, or
     other contextual values relevant to the task.
   - False only if the sheet appears genuinely useless for the extraction task
     (for example: blank, decorative, duplicate empty template, or simple index
     information with no meaningful context).
   - When in doubt, say True.

3. **sheet_summary** (string, up to 10 sentences)
   Write a detailed, self-contained summary of the sheet and how it relates to
   the extraction task.

   **For context-only sheets (parse_full_sheet=False, is_still_relevant=True)**:
   This summary is the ONLY representation of that sheet that downstream
   extraction logic will receive. Therefore you MUST:
   - Include every concrete value that appears useful.
   - Prefer explicit 'Field: Value.' style statements whenever possible.
   - Include actual names, dates, identifiers, labels, codes, amounts, ranges,
     categories, totals, mappings, and other visible values instead of vague
     paraphrases.
   - Mention how the information could help populate or interpret schema fields
     when that mapping is reasonably clear.
   - If a field appears multiple times, list all important occurrences.
   - BAD summary: "This sheet has useful metadata."
   - GOOD summary: "Report date: 03/31/2025. Customer: Acme Corporation.
     Account ID: 10482. Category mapping: A=Open, C=Closed. Region: Northeast.
     Table notes indicate monetary values are shown in thousands."

   **For extractable sheets (parse_full_sheet=True)**:
   Provide a useful extraction-oriented summary including, where visible:
   - what kind of records or entities the sheet appears to contain,
   - approximate row count or scale visible in the sample,
   - important column headers or field names,
   - notable formatting patterns, code systems, units, or date/number formats,
   - any metadata on the same sheet that could help populate schema fields.

   **For fully irrelevant sheets (parse_full_sheet=False, is_still_relevant=False)**:
   Give one short sentence explaining why the sheet is not useful.

# Decision Matrix
- parse_full_sheet=True -> run full extraction on this sheet
- parse_full_sheet=False and is_still_relevant=True -> inject 'sheet_summary'
  as cross-sheet context into every extractable sheet's prompt
- parse_full_sheet=False and is_still_relevant=False -> skip the sheet entirely

# Important rules
- Derive your decisions from `schema_text`, `instructions_text`, and the sheet snippets.
- Do NOT invent domain-specific assumptions that are not supported by those inputs.
- When in doubt about "parse_full_sheet", default to True.
- When in doubt about "is_still_relevant", default to True.
- If a sheet has BOTH extractable rows AND useful metadata/context, set both
  `parse_full_sheet=True` and `is_still_relevant=True`.
- For context-only sheets, `sheet_summary` must be value-rich and self-contained.
  Generic descriptions are not sufficient.
- Use up to 10 full sentences when needed; completeness is more important than brevity.

# Output requirements
Respond with a single JSON object with exactly this structure:
{{
  "sheets": {{
    "<sheet_name_1>": {{
      "parse_full_sheet": true,
      "is_still_relevant": true,
      "sheet_summary": "Contains row-level records with columns such as Record ID, Category, Start Date, End Date, Status, and Amount. \
The sample suggests approximately 200+ rows. Dates appear to use MM/DD/YYYY format. Status values appear coded. A header note indicates the report date is 03/31/2025."
    }},
    "<sheet_name_2>": {{
      "parse_full_sheet": false,
      "is_still_relevant": true,
      "sheet_summary": "Workbook metadata sheet. Report date: 03/31/2025. Customer: Acme Corporation. Account ID: 10482. Region: Northeast.
Category mapping: A=Open, C=Closed. Currency note: all amounts shown in thousands."
    }},
    "<sheet_name_3>": {{
      "parse_full_sheet": false,
      "is_still_relevant": false,
      "sheet_summary": "Blank sheet with no useful content."
    }}
  }}
}}

Return only the raw JSON, with no extra text, no markdown, and no code fences.
""".strip()

SHEET_CONTEXT_AGENT_USER_TEMPLATE = """Input (sample rows from each sheet in the workbook):
{input}"""
