"""LangGraph sub-graphs for the code-generation / validation loop.

This module implements the full extraction pipeline using LangGraph
``StateGraph`` nodes and edges at three layers:

    1. **Segment sub-graph** - ``codegen -> execute -> validate`` with
       conditional retry edges back to ``codegen``. The loop is an
       explicit graph with nodes, edges, and routing functions. State
       flows through a proper ``TypedDict`` so LangGraph manages
       merging, checkpointing, and replay.
    2. **File sub-graph** - Uses LangGraph's ``Send`` API for fan-out /
       fan-in parallel processing of segments (map-reduce pattern).
       The ``segment_results`` key uses an ``Annotated[list, operator.add]``
       reducer so worker outputs are automatically accumulated.
    3. **Pipeline integration** - ``run_file_graph()`` is the entry
       point called by the pipeline's extraction node, which itself
       uses Send-based fan-out across files.

Each sub-graph has its own ``TypedDict`` state with ``Annotated``
reducers where aggregation is needed. The ``Send`` API lets LangGraph
dispatch multiple *independent* copies of a node with different state
slices, enabling true graph-managed parallelism instead of manual
``ThreadPoolExecutor`` pools.
"""

from __future__ import annotations

import ast
import operator
import os
import re
import time
import threading
import warnings
from enum import Enum
from typing import Annotated, Any, Dict, List, Optional, Tuple, TypedDict

import pandas as pd
from tqdm import tqdm

from langgraph.graph import END, START, StateGraph # type: ignore[import-not-found]
from langgraph.types import Send # type: ignore[import-not-found]

import models
import constants
from config_runtime import call_active_inputs_helper, get_active_inputs_module_name
from constants import MAX_VALIDATION_RETRIES
from code_generation import generate_segment_code
from metrics import record_segment, record_stage
from sandbox_executor import execute_generated_code
from segment_summarizer import build_all_segment_payloads
from utils import as_extended_path_str as _as_extended_path_str
from validation import summarize_validation_outcome, validate_segment_output

# Metadata column name aliases - lazily populated on first use to avoid
# executing inputs.py helpers at import time.
_ACCOUNT_COL: str = ""
_FILE_SRC_COL: str = ""
_COLUMN_CONFIG_MODULE: str = ""


def _lazy_init_columns() -> None:
    """Populate module-level column aliases and schema columns on first use."""
    global _ACCOUNT_COL, _FILE_SRC_COL, _SCHEMA_COLUMNS, _COLUMN_CONFIG_MODULE
    active_module = get_active_inputs_module_name()
    if _ACCOUNT_COL and _COLUMN_CONFIG_MODULE == active_module:
        return # already initialised
    _ACCOUNT_COL = call_active_inputs_helper("get_account_name_column", default="AccountName")
    _FILE_SRC_COL = call_active_inputs_helper("get_file_source_column", default="file_path")
    _SCHEMA_COLUMNS = call_active_inputs_helper("get_column_names", default=[]) or []
    _COLUMN_CONFIG_MODULE = active_module


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# MAX_VALIDATION_RETRIES is imported from constants.py


# ---------------------------------------------------------------------------
# Generated-code persistence helper
# ---------------------------------------------------------------------------

def _sanitize_windows_path_component(value: str, fallback: str) -> str:
    """Make a safe single path component for Windows (no trailing space/dot)."""
    v = str(value or "").strip()
    if not v:
        return fallback
    # Windows forbids these in names: < > : " / \ | ? *
    v = re.sub(r'[<>:"/\\|?*]', "_", v)
    # Windows also effectively forbids trailing spaces/dots
    v = v.rstrip(" .")
    return v or fallback


def _save_generated_code(
    code: str,
    output_data_dir: str,
    company_name: str,
    file_label: str,
    sheet_name: str,
    row_range: str,
    segment_index: int,
    kind: str
) -> None:
    """Write a generated extraction module to the account's output folder.

    Gated behind ``constants.SAVE_GENERATED_CODE`` or ``constants.CLI_VERBOSE``
    to avoid unnecessary disk I/O during normal production runs.
    """
    if not (constants.SAVE_GENERATED_CODE or constants.CLI_VERBOSE):
        return
    if not code or not output_data_dir or not company_name:
        return

    output_data_dir = str(output_data_dir or "").strip().rstrip(" .")
    company_name = _sanitize_windows_path_component(company_name, "unknown_company")
    file_label = str(file_label or "").strip()

    file_stem = os.path.splitext(file_label)[0] if file_label else "unknown_file"
    file_stem = _sanitize_windows_path_component(file_stem, "unknown_file")

    safe_sheet = re.sub(r'[^\w\-.]', '_', sheet_name).strip('_') if sheet_name else "segment"
    safe_sheet = safe_sheet.rstrip(" .") or "segment"

    # Normalize row_range: if it's a stringified dict like "{"start": 2, "end": 86}",
    # extract start/end values to produce a clean short string like "2-86" instead of
    # the bloated "__start__2__end___86_" that would be produced by naive regex sanitisation.
    # This avoids Windows MAX_PATH (260-char) violations on deeply-nested output paths.
    _rr = row_range
    try:
        _parsed = ast.literal_eval(_rr)
        if isinstance(_parsed, dict):
            _start = _parsed.get("start", "")
            _end = _parsed.get("end", "")
            _rr = f"{_start}-{_end}" if (_start != "" or _end != "") else ""
    except (ValueError, SyntaxError):
        pass

    safe_range = re.sub(r'[^\w\-]', '_', str(_rr)).strip('_') if _rr else ""

    safe_kind = re.sub(r'[^\w\-]', "_", str(kind or "extraction")).strip("_") or "extraction"

    filename_parts = [safe_sheet]
    if safe_range:
        filename_parts.append(f"rows{safe_range}")
    filename_parts.append(f"seg{segment_index}")
    filename_parts.append(safe_kind)  # NEW
    code_filename = "_".join(filename_parts) + ".py"

    code_dir = os.path.join(output_data_dir, company_name, "generated_code", file_stem)
    os.makedirs(_as_extended_path_str(code_dir), exist_ok=True)

    code_path = os.path.join(code_dir, code_filename)
    try:
        with open(_as_extended_path_str(code_path), "w", encoding="utf-8") as fh:
            fh.write(code)
    except OSError as exc:
        tqdm.write(f" [WARN] Could not save generated code to {code_path}: {exc}")


_EXECUTION_RETRY_MARKER = "# Execution Error From Your Previous Output"
_VALIDATION_RETRY_MARKER = "# Validation Agent Feedback"

# Column helpers - lazily populated via _lazy_init_columns()
_SCHEMA_COLUMNS: List[str] = []


# ---------------------------------------------------------------------------
# RetryOrigin enum - replaces raw string comparisons
# ---------------------------------------------------------------------------

class RetryOrigin(str, Enum):
    """Classify why code generation is being retried.

    Inherits from ``str`` so ``RetryOrigin.INITIAL == "initial"`` is True,
    keeping backward compatibility with any logging / serialization that
    expects plain strings.
    """
    INITIAL = "initial"
    EXECUTION_ERROR = "execution_error"
    VALIDATION_FEEDBACK = "validation_feedback"


# ---------------------------------------------------------------------------
# Data-driven execution error -> guidance mapping
# ---------------------------------------------------------------------------

_EXECUTION_ERROR_GUIDANCE: List[Tuple[str, str]] = [
    (
        "truth value of a Series is ambiguous",
        "\n\nThis usually means your code used a pandas Series in a boolean context, "
        "such as `if series`, `if df['col']`, or `cond_a and series_cond`. "
        "Never use Series/DataFrame objects directly in `if`/`and`/`or`. "
        "Reduce them explicitly with `.any()`, `.all()`, `.empty`, or select a scalar "
        "value with `.iloc[...]` before testing.",
    ),
    (
        "'Series' object has no attribute 'strftime'",
        "\n\nThis usually means your code called `.strftime(...)` on an entire pandas "
        "Series instead of on a scalar datetime value. For a Series, use vectorized "
        "formatting like `pd.to_datetime(series, errors='coerce').dt.strftime('%m/%d/%Y')`. "
        "Only call `.strftime(...)` directly on a scalar `Timestamp`/`datetime`.",
    ),
    (
        "Unalignable boolean Series provided as indexer",
        "\n\nThis usually means a boolean mask built from one DataFrame/Series was used "
        "to filter a different DataFrame whose index no longer matches. Recompute the mask "
        "from the exact DataFrame being filtered (for example, if you created `d = df[...]`, "
        "then later masks must be built from `d`, not `df`) or reindex the mask before applying it.",
    ),
    (
        "not 'NAType'",
        "\n\nThis usually means your code passed a pandas `pd.NA` (NAType) value to "
        "`float()`, `int()`, or `str()` without checking for it first. "
        "Cells read by openpyxl from nullable-typed columns can be `pd.NA` instead of "
        "`None`. Always guard numeric conversions with a check like:\n"
        "    `if value is None or (hasattr(value, '__class__') and type(value).__name__ == 'NAType')` "
        "or (hasattr(pd, 'isna') and pd.isna(value)): return None\n"
        "Or more simply, add `import pandas as pd` and use "
        "`if value is None or pd.isna(value): return None` at the top of any "
        "numeric/date/string conversion helper. This catches `None`, `pd.NA`, `pd.NaT`, "
        "and `float('nan')` uniformly.",
    ),
    (
        "bad operand type for unary ~",
        "\n\nThis means you applied the bitwise NOT operator `~` to a column or "
        "Series that contains float values (including NaN) instead of booleans. "
        "Before negating a mask, ensure it is truly boolean:\n"
        "    `mask = mask.astype(bool)` or `mask = mask.fillna(False).astype(bool)`\n"
        "Then use `~mask`. A common cause is building a mask from `.str.contains()` "
        "or `.isin()` on a column that has NaN - the result is float-typed, not bool. "
        "Always chain `.fillna(False)` immediately after `.str.contains(..., na=False)` "
        "or use the `na=False` parameter.",
    ),
    (
        "single positional indexer is out-of-bounds",
        "\n\nThis means your code used `.iloc[i]` with an integer index that "
        "exceeds the DataFrame's row count. After filtering or slicing, the "
        "DataFrame may have fewer rows than expected. Always check "
        "`len(df) > i` before accessing `df.iloc[i]`, or use `.iterrows()` "
        "to loop safely over whatever rows remain.",
    ),
    (
        "Cannot index with multidimensional key",
        "\n\nThis means you passed a multi-column DataFrame (e.g. `df[['a','b']]`) "
        "where a 1-D boolean mask or single column was expected. "
        "When building a filter mask, ensure the result is a 1-D Series, "
        "e.g. `mask = df[cols].notna().any(axis=1)` (note the `.any(axis=1)`).",
    ),
    (
        "unsupported operand type",
        "\n\nThis usually means you mixed incompatible types in an arithmetic or "
        "comparison operation. Common causes: comparing a string column to a number "
        "without `pd.to_numeric(..., errors='coerce')`, or using `+`/`-` between "
        "a numeric column and a column that still contains strings. "
        "Cast columns to the correct dtype before operating on them.",
    ),
    (
        "KeyError",
        "\n\nThis usually means the column name you referenced does not exist "
        "in the DataFrame. Column names from Excel can have leading/trailing "
        "spaces or different casing. After reading, always normalize with "
        "`df.columns = df.columns.astype(str).str.strip()` and use the exact "
        "header names from the segment_json `columns[].header_name` values.",
    ),
]


# ---------------------------------------------------------------------------
# Utility helpers
# ---------------------------------------------------------------------------

def _add_metadata_columns(
    df: pd.DataFrame,
    company_name: str = "",
    file_path: str = "",
    sheet_name: str = "",
    output_data_dir: str = "",
) -> pd.DataFrame:
    """Stamp each row with source metadata."""
    if not df.empty:
        if _ACCOUNT_COL not in df.columns:
            df[_ACCOUNT_COL] = company_name
        else:
            mask = df[_ACCOUNT_COL].isna() | (df[_ACCOUNT_COL].astype(str).str.strip() == "")
            df.loc[mask, _ACCOUNT_COL] = company_name

        file_basename = os.path.basename(file_path) if file_path else ""

        if _FILE_SRC_COL not in df.columns:
            df[_FILE_SRC_COL] = file_basename
        else:
            mask = df[_FILE_SRC_COL].isna() | (df[_FILE_SRC_COL].astype(str).str.strip() == "")
            df.loc[mask, _FILE_SRC_COL] = file_basename

    return df


def _classify_retry_origin(retry_context: str) -> RetryOrigin:
    """Classify why code generation is being retried."""
    text = (retry_context or "").strip()
    if text.startswith(_EXECUTION_RETRY_MARKER):
        return RetryOrigin.EXECUTION_ERROR
    if text.startswith(_VALIDATION_RETRY_MARKER):
        return RetryOrigin.VALIDATION_FEEDBACK
    return RetryOrigin.INITIAL


def _clip_cli_text(text: Any, max_chars: Optional[int] = None) -> str:
    """Trim verbose text so retry/status lines stay readable in the CLI."""
    if max_chars is None:
        max_chars = constants.CLI_DETAIL_MAX_CHARS
    value = " ".join(str(text or "").split())
    if len(value) <= max_chars:
        return value
    return value[: max(0, max_chars - 3)].rstrip() + "..."


def _row_range_label(row_range: Any) -> str:
    """Format a row-range dict into a compact CLI label."""
    if isinstance(row_range, dict):
        start = row_range.get("start", "?")
        end = row_range.get("end", "?")
        return f"{start}-{end}"
    return str(row_range or "?")


def _segment_cli_label(sheet_name: str, row_range: Any) -> str:
    """Return a compact segment identifier such as Claims[2-77]."""
    return f"{sheet_name or '?'}[{_row_range_label(row_range)}]"


def _preview_items(items: List[Any], max_items: Optional[int] = None) -> str:
    """Return a concise preview of a list for CLI logging."""
    if max_items is None:
        max_items = constants.CLI_PREVIEW_ITEM_LIMIT
    preview_items = [str(item).strip() for item in items[:max_items] if str(item).strip()]
    preview = "; ".join(_clip_cli_text(item) for item in preview_items)
    remaining = max(0, len(items) - len(preview_items))
    if remaining:
        suffix = f"; ... (+{remaining} more)" if preview else f"(+{remaining} more)"
        preview = f"{preview}{suffix}" if preview else suffix
    return preview


# ===========================================================================
# LAYER 1 - Segment sub-graph (codegen -> execute -> validate -> retry?)
# ===========================================================================

class SegmentState(TypedDict, total=False):
    """State flowing through the segment-level code/validate graph.

    This is a proper TypedDict so LangGraph can manage state merging,
    checkpointing, and type-checking natively.  Each node returns only
    the keys it updates; LangGraph merges them into the running state.
    """
    segment_payload: dict
    file_path: str
    company_name: str
    output_data_dir: str
    schema_text: str
    instructions_text: str
    model_cfg: dict
    max_retries: int
    attempt: int
    retry_context: str
    retry_history: list # Accumulated list of all prior retry feedback strings (one per failed attempt)
    generated_code: str
    extracted_df: Any # pd.DataFrame (TypedDict doesn't support DataFrame type)
    validation_result: Optional[dict]
    best_df: Any # pd.DataFrame
    final_valid: bool
    last_errors: list
    total_input_tokens: int
    total_output_tokens: int
    validation_input_tokens: int
    validation_output_tokens: int
    start_time: float
    metrics: dict


# -- Segment nodes ----------------------------------------------------------

def segment_init(state: SegmentState) -> dict:
    """Initialise bookkeeping for a new segment attempt loop."""
    return {
        "attempt": 0,
        "retry_context": "",
        "retry_history": [],
        "generated_code": "",
        "extracted_df": pd.DataFrame(columns=_SCHEMA_COLUMNS),
        "validation_result": None,
        "best_df": pd.DataFrame(columns=_SCHEMA_COLUMNS),
        "final_valid": False,
        "last_errors": [],
        "total_input_tokens": 0,
        "total_output_tokens": 0,
        "validation_input_tokens": 0,
        "validation_output_tokens": 0,
        "start_time": time.perf_counter(),
    }


def segment_codegen(state: SegmentState) -> dict:
    """LLM code generation node.  Increments the attempt counter."""
    attempt = state.get("attempt", 0) + 1
    max_retries = state.get("max_retries", MAX_VALIDATION_RETRIES)
    segment_payload = state["segment_payload"]
    model_cfg = state.get("model_cfg") or models.get_active_model()
    retry_context = state.get("retry_context", "")
    retry_history: list = state.get("retry_history", [])
    sheet_name = segment_payload.get("sheet_name", "")
    row_range = (segment_payload.get("segment_summary") or {}).get("row_range", "")
    segment_label = _segment_cli_label(sheet_name, row_range)
    retry_origin = _classify_retry_origin(retry_context)

    # Build accumulated retry context from ALL prior rounds so the coder
    # never re-introduces a mistake it was already told about.
    if len(retry_history) > 1:
        history_parts: list = []
        for idx, entry in enumerate(retry_history, start=1):
            history_parts.append(f"## Retry feedback from attempt {idx}\n\n{entry}")
        accumulated_retry_context = (
            "# All Prior Validation / Execution Feedback\n"
            "(Review ALL sections - do not re-introduce previously fixed mistakes.)\n\n"
            + "\n\n---\n\n".join(history_parts)
            + "\n\nPlease fix the extraction code to address ALL of the above issues."
        )
    elif retry_context:
        accumulated_retry_context = retry_context
    else:
        accumulated_retry_context = ""

    if attempt > 1 and retry_context:
        if retry_origin == RetryOrigin.EXECUTION_ERROR:
            tqdm.write(
                f" [{attempt}/{max_retries}] ♻ Regenerating code for {segment_label} "
                "after execution failure"
            )
        elif retry_origin == RetryOrigin.VALIDATION_FEEDBACK:
            tqdm.write(
                f" [{attempt}/{max_retries}] ♻ Regenerating code for {segment_label} "
                "after validation feedback"
            )

    try:
        code, _, in_tok, out_tok = generate_segment_code(
            segment_payload=segment_payload,
            model_cfg=model_cfg,
            retry_context=accumulated_retry_context,
        )
        return {
            "attempt": attempt,
            "generated_code": code,
            "total_input_tokens": state.get("total_input_tokens", 0) + in_tok,
            "total_output_tokens": state.get("total_output_tokens", 0) + out_tok,
        }
    except Exception as gen_exc:
        max_retries = state.get("max_retries", MAX_VALIDATION_RETRIES)
        tqdm.write(
            f" [{attempt}/{max_retries}] ❌ Code generation failed for "
            f"{segment_label}: {_clip_cli_text(gen_exc)}"
        )
        return {
            "attempt": attempt,
            "generated_code": "",
            "last_errors": [str(gen_exc)],
        }


def segment_execute(state: SegmentState) -> dict:
    """Execute the LLM-generated code against the source file."""
    code = state.get("generated_code", "")
    file_path = state["file_path"]
    company_name = state.get("company_name", "")
    output_data_dir = state.get("output_data_dir", "")
    sheet_name = state.get("segment_payload", {}).get("sheet_name", "")
    row_range = (state.get("segment_payload", {}).get("segment_summary") or {}).get("row_range", "")
    segment_label = _segment_cli_label(sheet_name, row_range)
    attempt = state.get("attempt", 0)
    max_retries = state.get("max_retries", MAX_VALIDATION_RETRIES)
    retry_origin = _classify_retry_origin(state.get("retry_context", ""))

    if not code:
        return {"extracted_df": pd.DataFrame(columns=_SCHEMA_COLUMNS)}

    try:
        df = execute_generated_code(code, file_path)
        df = _add_metadata_columns(
            df,
            company_name=company_name,
            file_path=file_path,
            sheet_name=sheet_name,
            output_data_dir=output_data_dir,
        )
        if attempt > 1 and retry_origin == RetryOrigin.EXECUTION_ERROR:
            tqdm.write(
                f" [{attempt}/{max_retries}] ✅ Code executes for {segment_label}; "
                "validating output"
            )
        # Clear any stale retry_context so route_after_execute cannot mistake
        # a legitimately empty result (e.g. over-correction after validation
        # feedback) for an execution failure.
        return {"extracted_df": df, "retry_context": ""}
    except Exception as exec_exc:
        tqdm.write(
            f" [{attempt}/{max_retries}] ❌ Execution failed for "
            f"{segment_label}: {type(exec_exc).__name__}: {_clip_cli_text(exec_exc)}"
        )
        extra_guidance = ""
        exc_str = str(exec_exc)
        for pattern, guidance in _EXECUTION_ERROR_GUIDANCE:
            if pattern in exc_str:
                extra_guidance = guidance
                break
        # Include the failing code (truncated) so the LLM can see what
        # it wrote and avoid the same mistake.  Cap at ~4,000 chars to
        # keep the prompt within budget.
        code_snippet = code[:4000] if code else ""
        failed_code_section = (
            "\n\n## Your Previous Code (which raised the error above)\n"
            "Do NOT repeat the same pattern that caused the crash.\n"
            "```python\n"
            f"{code_snippet}\n"
            "```"
        ) if code_snippet else ""

        retry_context = (
            f"# Execution Error From Your Previous Output\n\n"
            f"Your code raised the following exception when executed:\n"
            f"{type(exec_exc).__name__}: {exec_exc}{extra_guidance}\n"
            f"{failed_code_section}\n"
            f"Please fix the code so it runs without errors.\n"
            f"Return the corrected complete Python module."
        )
        # Append to retry_history so the coder sees ALL prior feedback
        prior_history: list = list(state.get("retry_history", []))
        prior_history.append(
            f"Your code raised the following exception when executed:\n"
            f"  {type(exec_exc).__name__}: {exec_exc}{extra_guidance}"
        )
        return {
            "extracted_df": pd.DataFrame(columns=_SCHEMA_COLUMNS),
            "retry_context": retry_context,
            "retry_history": prior_history,
            "last_errors": [str(exec_exc)],
        }


def segment_validate(state: SegmentState) -> dict:
    """Run the LLM-based validation agent on the extracted DataFrame."""
    df = state.get("extracted_df", pd.DataFrame())
    schema_text = state.get("schema_text", "")
    instructions_text = state.get("instructions_text", "")
    model_cfg = state.get("model_cfg") or models.get_active_model()
    company_name = state.get("company_name", "")
    file_path = state.get("file_path", "")
    sheet_name = state.get("segment_payload", {}).get("sheet_name", "")
    row_range = (state.get("segment_payload", {}).get("segment_summary") or {}).get("row_range", "")
    segment_label = _segment_cli_label(sheet_name, row_range)
    attempt = state.get("attempt", 0)
    max_retries = state.get("max_retries", MAX_VALIDATION_RETRIES)
    attempt_label = f"[{attempt}/{max_retries}]"
    retry_origin = _classify_retry_origin(state.get("retry_context", ""))

    if df.empty:
        tqdm.write(
            f" {attempt_label} ⏩ Skipping validation for {segment_label} (0 rows extracted)"
        )
        return {
            "validation_result": {
                "is_valid": True,
                "needs_retry": False,
                "retry_feedback": "",
                "errors_found": [],
                "validation_code": "",
                "system_failure": False,
            },
            "best_df": df,
            "final_valid": True,
            "last_errors": [],
        }

    # Strip metadata columns before validation
    META_COLS = [_ACCOUNT_COL, _FILE_SRC_COL]
    saved_meta = {c: df[c].copy() for c in META_COLS if c in df.columns}
    df_for_validation = df.drop(columns=[c for c in META_COLS if c in df.columns])

    if retry_origin == RetryOrigin.EXECUTION_ERROR:
        tqdm.write(
            f" {attempt_label} 🔍 Validating recovered output for {segment_label}"
        )
    elif retry_origin == RetryOrigin.VALIDATION_FEEDBACK:
        tqdm.write(
            f" {attempt_label} 🔄 Re-validating {segment_label} after feedback"
        )
    else:
        tqdm.write(
            f" {attempt_label} 🔍 Validating {segment_label}"
        )

    vr = validate_segment_output(
        df=df_for_validation,
        schema_text=schema_text,
        instructions_text=instructions_text,
        model_cfg=model_cfg,
    )

    # Re-attach metadata columns
    validated_df = df_for_validation.copy()
    for col, series in saved_meta.items():
        validated_df[col] = series.reindex(validated_df.index)

    outcome = summarize_validation_outcome(vr)
    if retry_origin == RetryOrigin.EXECUTION_ERROR:
        tqdm.write(
            f" {attempt_label} ↪ After execution recovery: {outcome['message']}"
        )
    elif retry_origin == RetryOrigin.VALIDATION_FEEDBACK:
        tqdm.write(
            f" {attempt_label} ↪ After validation-driven regeneration: {outcome['message']}"
        )
    else:
        tqdm.write(f" {attempt_label} {outcome['message']}")

    if vr.system_failure and vr.errors_found:
        tqdm.write(
            f" {attempt_label} 📋 Validator diagnostics: "
            f"{_clip_cli_text(vr.errors_found[0])}"
        )
    elif vr.needs_retry and vr.errors_found:
        preview = _preview_items(vr.errors_found)
        if preview:
            tqdm.write(f" {attempt_label} █ Validation findings: {preview}")

    if constants.CLI_VERBOSE and vr.needs_retry and vr.retry_feedback:
        tqdm.write(
            f" {attempt_label} ♻ Sending validation feedback for {segment_label}"
        )

    result = {
        "validation_result": {
            "is_valid": vr.is_valid,
            "needs_retry": vr.needs_retry,
            "retry_feedback": vr.retry_feedback,
            "errors_found": vr.errors_found,
            "validation_code": vr.validation_code,
            "system_failure": vr.system_failure,
        },
        "best_df": validated_df,
        "last_errors": vr.errors_found,
        # Codegen tokens stay in total_input/output_tokens (priced at agentic rate).
        # Validation tokens tracked separately (priced at utility rate) - Bug #6 fix.
        "total_input_tokens": state.get("total_input_tokens", 0),
        "total_output_tokens": state.get("total_output_tokens", 0),
        "validation_input_tokens": state.get("validation_input_tokens", 0) + vr.input_tokens,
        "validation_output_tokens": state.get("validation_output_tokens", 0) + vr.output_tokens,
    }

    if vr.is_valid:
        result["final_valid"] = True

    return result


def segment_finalize(state: SegmentState) -> dict:
    """Build the final metrics dict for the segment."""
    elapsed = time.perf_counter() - state.get("start_time", time.perf_counter())
    segment_payload = state.get("segment_payload", {})
    sheet_name = segment_payload.get("sheet_name", "")
    row_range = (segment_payload.get("segment_summary") or {}).get("row_range", "")
    best_df = state.get("best_df", pd.DataFrame())

    metrics = {
        "time_seconds": elapsed,
        "input_tokens": state.get("total_input_tokens", 0),
        "output_tokens": state.get("total_output_tokens", 0),
        "validation_input_tokens": state.get("validation_input_tokens", 0),
        "validation_output_tokens": state.get("validation_output_tokens", 0),
        "attempts": state.get("attempt", 0),
        "final_valid": state.get("final_valid", False),
        "rows_extracted": len(best_df),
        "sheet": sheet_name,
        "row_range": str(row_range),
        "generated_code": state.get("generated_code", ""),
        "validation_code": (state.get("validation_result") or {}).get("validation_code", ""),
        "validation_system_failure": bool((state.get("validation_result") or {}).get("system_failure", False)),
        "errors": state.get("last_errors", []),
    }

    return {
        "best_df": best_df,
        "metrics": metrics,
    }


# -- Segment routing --------------------------------------------------------

def route_after_execute(state: SegmentState) -> str:
    """After code execution, decide: validate or retry (on exec error)."""
    df = state.get("extracted_df", pd.DataFrame())
    code = state.get("generated_code", "")
    attempt = state.get("attempt", 0)
    max_retries = state.get("max_retries", MAX_VALIDATION_RETRIES)

    # Only retry codegen when the execution itself raised an exception.
    # Use _classify_retry_origin() to avoid confusing a stale validation-
    # feedback context with a real execution failure.
    retry_origin = _classify_retry_origin(state.get("retry_context", ""))
    if df.empty and retry_origin == RetryOrigin.EXECUTION_ERROR:
        if attempt < max_retries:
            return "retry_codegen"
        return "finalize"

    # No code was generated (codegen failed) - retry or finalize
    if not code:
        if attempt < max_retries:
            return "retry_codegen"
        return "finalize"

    return "validate"


def route_after_validate(state: SegmentState) -> str:
    """After validation, decide: done or retry codegen."""
    vr = state.get("validation_result") or {}
    attempt = state.get("attempt", 0)
    max_retries = state.get("max_retries", MAX_VALIDATION_RETRIES)

    if state.get("final_valid", False):
        return "done"

    if vr.get("needs_retry") and vr.get("retry_feedback") and attempt < max_retries:
        return "retry_codegen"

    # Agent fixed what it could - accept
    return "done"


def route_prepare_retry(state: SegmentState) -> dict:
    """Prepare retry_context from validation feedback before looping back.

    Appends the current round's feedback to ``retry_history`` so that
    ``segment_codegen`` can build an accumulated prompt containing ALL
    prior feedback - preventing the coder from re-introducing mistakes
    it was already told about in earlier rounds.
    """
    vr = state.get("validation_result") or {}
    retry_feedback = vr.get("retry_feedback", "")
    attempt = state.get("attempt", 0)
    max_retries = state.get("max_retries", MAX_VALIDATION_RETRIES)

    # Accumulate history - copy to avoid mutating the shared list in state
    prior_history: list = list(state.get("retry_history", []))

    if retry_feedback:
        if constants.CLI_VERBOSE:
            tqdm.write(
                f" [{attempt}/{max_retries}] ♻ Routing validation feedback back "
                f"into code generation"
            )
        retry_context = (
            f"# Validation Agent Feedback\n\n"
            f"{retry_feedback}\n\n"
            f"Please fix the extraction code to address these issues."
        )
        prior_history.append(retry_feedback)
    else:
        retry_context = state.get("retry_context", "")
    return {"retry_context": retry_context, "retry_history": prior_history}


# -- Build segment graph ----------------------------------------------------

def build_segment_graph() -> Any:
    """Compile the segment-level codegen/validate/retry sub-graph.

    Graph topology::

        START -> init -> codegen -> execute
                                      |
                                      v
                                   validate -> [done] -> finalize -> END
                                      |        [retry] -> prepare_retry -> codegen
                                      |        [finalize] -> finalize -> END
    """
    g = StateGraph(SegmentState)

    g.add_node("init", segment_init)
    g.add_node("codegen", segment_codegen)
    g.add_node("execute", segment_execute)
    g.add_node("validate", segment_validate)
    g.add_node("prepare_retry", route_prepare_retry)
    g.add_node("finalize", segment_finalize)

    # Edges
    g.add_edge(START, "init")
    g.add_edge("init", "codegen")
    g.add_edge("codegen", "execute")

    g.add_conditional_edges(
        "execute",
        route_after_execute,
        {
            "validate": "validate",
            "retry_codegen": "prepare_retry",
            "finalize": "finalize",
        },
    )

    g.add_conditional_edges(
        "validate",
        route_after_validate,
        {
            "done": "finalize",
            "retry_codegen": "prepare_retry",
        },
    )

    g.add_edge("prepare_retry", "codegen")
    g.add_edge("finalize", END)

    return g.compile()


# Pre-compiled graph (singleton)
_segment_graph = None
_segment_graph_lock = threading.Lock()


def _get_segment_graph():
    """Lazy-load the compiled segment graph."""
    global _segment_graph
    with _segment_graph_lock:
        if _segment_graph is None:
            _segment_graph = build_segment_graph()
        return _segment_graph


def run_segment_graph(
    segment_payload: Dict[str, Any],
    file_path: str,
    company_name: str = "",
    output_data_dir: str = "",
    schema_text: str = "",
    instructions_text: str = "",
    model_cfg: Optional[Dict[str, Any]] = None,
    max_retries: int = MAX_VALIDATION_RETRIES,
) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """Run the segment sub-graph and return (df, metrics).

    Drop-in replacement for the old ``process_segment()`` function,
    but now the codegen -> execute -> validate -> retry loop is a
    proper LangGraph state machine.
    """
    graph = _get_segment_graph()

    initial_state: SegmentState = {
        "segment_payload": segment_payload,
        "file_path": file_path,
        "company_name": company_name,
        "output_data_dir": output_data_dir,
        "schema_text": schema_text,
        "instructions_text": instructions_text,
        "model_cfg": model_cfg or models.get_active_model(),
        "max_retries": max_retries,
    }

    final_state = graph.invoke(initial_state)

    best_df = final_state.get("best_df", pd.DataFrame(columns=_SCHEMA_COLUMNS))
    metrics = final_state.get("metrics", {})

    return best_df, metrics


# ===========================================================================
# LAYER 2 - File sub-graph (fan-out segments via Send, fan-in results)
# ===========================================================================

class FileGraphState(TypedDict, total=False):
    """State for the file-level sub-graph.

    Uses ``Annotated`` with ``operator.add`` as the reducer on
    ``segment_results`` so that LangGraph automatically merges outputs
    from all parallel Send workers.
    """
    file_path: str
    company_name: str
    output_data_dir: str
    schema_text: str
    instructions_text: str
    model_cfg: dict
    table_summaries: list
    file_label: str
    max_retries: int
    payloads: list
    segment_results: Annotated[list, operator.add]
    combined_df: Any # pd.DataFrame
    total_input_tokens: int
    total_output_tokens: int
    extraction_wall_time: float
    extraction_start_time: float


def file_build_payloads(state: FileGraphState) -> dict:
    """Build segment payloads from table summaries."""
    payloads = build_all_segment_payloads(
        table_summaries=state["table_summaries"],
        schema_text=state.get("schema_text", ""),
        instructions_text=state.get("instructions_text", ""),
        file_path=state["file_path"],
    )

    # Inject filename/sheet-name type hints when the inputs module provides them.
    from config_runtime import get_active_inputs_module
    _inputs_mod = get_active_inputs_module()
    _get_type_hint = getattr(_inputs_mod, "get_type_hint", None)
    if payloads and _get_type_hint is not None:
        file_name = payloads[0].get("file_path", "")
        for p in payloads:
            hint = _get_type_hint(file_name, p.get("sheet_name", ""))
            if hint:
                p["type_hint"] = hint

    # Log a compact segment plan
    if payloads:
        payload_labels = [
            f"{p.get('sheet_name', '?')}[{((p.get('segment_summary') or {}).get('row_range', {}).get('start', '?'))}-"
            f"{((p.get('segment_summary') or {}).get('row_range', {}).get('end', '?'))}]"
            for p in payloads
        ]
        sheets_summary = _preview_items(payload_labels)
        total_rows = sum(
            max(0, (p.get('segment_summary') or {}).get('row_range', {}).get('end', 0)
                   - (p.get('segment_summary') or {}).get('row_range', {}).get('start', 0) + 1)
            for p in payloads
        )
        tqdm.write(
            f" 📋 {len(payloads)} segment(s), ~{total_rows} rows: {sheets_summary}"
        )

    return {
        "payloads": payloads,
        "segment_results": [],
        "extraction_start_time": time.perf_counter(),
    }


class _SegmentWorkerState(TypedDict, total=False):
    """Per-segment state used by Send dispatch.

    Each field from FileGraphState is available (via Send spreading),
    plus the per-dispatch keys ``_segment_index`` and ``_segment_payload``.
    """
    file_path: str
    company_name: str
    output_data_dir: str
    schema_text: str
    instructions_text: str
    model_cfg: dict
    file_label: str
    max_retries: int
    _segment_index: int
    _segment_payload: dict
    segment_results: Annotated[list, operator.add]


def _dispatch_segments(state: FileGraphState) -> list:
    """Fan-out: return a Send for each segment payload."""

    # LangGraph will run these in parallel (up to its concurrency limit).

    payloads = state.get("payloads", [])
    if not payloads:
        return [Send("file_reduce", state)]

    sends = []
    for i, payload in enumerate(payloads):
        sends.append(
            Send(
                "segment_worker",
                {
                    **state,
                    "_segment_index": i + 1,
                    "_segment_payload": payload,
                },
            )
        )
    return sends


def segment_worker_node(state: dict) -> dict:
    """
    This node is invoked once per Send from ``_dispatch_segments``.
    Empty / invalid segments are short-circuited to avoid wasting an LLM
    round-trip on ranges that cannot contain meaningful data.
    """
    payload = state["_segment_payload"]
    idx = state.get("_segment_index", 0)

    # -- Short-circuit only empty / invalid segments ------------------------
    # Row ranges are inclusive. A range like 25-25 is a valid one-row table
    # and may still contain a real record, so it must NOT be skipped.
    # Only skip when the detected range is actually empty / malformed.
    seg_summary = payload.get("segment_summary") or {}
    row_range = seg_summary.get("row_range") or {}
    if isinstance(row_range, dict):
        rr_start = row_range.get("start", 0)
        rr_end = row_range.get("end", 0)
        row_count = max(0, rr_end - rr_start + 1)
        if row_count <= 0:
            tqdm.write(
                f"   -> Segment {idx}: ⏭ skipped (empty/invalid range {rr_start}-{rr_end})"
            )
            empty_df = pd.DataFrame(columns=_SCHEMA_COLUMNS)
            skip_metrics = {
                "time_seconds": 0.0,
                "input_tokens": 0,
                "output_tokens": 0,
                "attempts": 0,
                "final_valid": True,
                "rows_extracted": 0,
                "sheet": payload.get("sheet_name", ""),
                "row_range": str(row_range),
                "generated_code": "",
                "validation_code": "",
                "validation_system_failure": False,
                "errors": [],
            }
            record_segment(
                company=state.get("company_name", ""),
                filename=state.get("file_label", os.path.basename(state.get("file_path", ""))),
                detail={"index": idx, **skip_metrics},
            )
            return {"segment_results": [(empty_df, skip_metrics)]}

    df, metrics = run_segment_graph(
        segment_payload=payload,
        file_path=state["file_path"],
        company_name=state.get("company_name", ""),
        output_data_dir=state.get("output_data_dir", ""),
        schema_text=state.get("schema_text", ""),
        instructions_text=state.get("instructions_text", ""),
        model_cfg=state.get("model_cfg") or models.get_active_model(),
        max_retries=state.get("max_retries", MAX_VALIDATION_RETRIES),
    )

    valid_str = "✔" if metrics.get("final_valid") else "X"
    attempts = metrics.get("attempts", 0)
    rows = len(df)
    tqdm.write(
        f"   -> Segment {idx}: {valid_str} {rows} row(s), {attempts} attempt(s), "
        f"{metrics.get('time_seconds', 0):.1f}s"
    )

    # Save generated extraction code
    _save_generated_code(
        code=metrics.get("generated_code", ""),
        output_data_dir=state.get("output_data_dir", ""),
        company_name=state.get("company_name", ""),
        file_label=state.get("file_label", os.path.basename(state.get("file_path", ""))),
        sheet_name=metrics.get("sheet", ""),
        row_range=str(metrics.get("row_range", "")),
        segment_index=idx,
        kind="extraction",
    )

    # Record per-segment metrics
    record_segment(
        company=state.get("company_name", ""),
        filename=state.get("file_label", os.path.basename(state.get("file_path", ""))),
        detail={"index": idx, **metrics},
    )

    return {
        "segment_results": [(df, metrics)],
    }


def file_reduce(state: FileGraphState) -> dict:
    """Fan-in: combine all segment results into one DataFrame."""
    results = state.get("segment_results", [])
    extraction_start = state.get("extraction_start_time", time.perf_counter())
    extraction_wall_time = time.perf_counter() - extraction_start

    segment_dfs: List[pd.DataFrame] = []
    total_in = 0
    total_out = 0
    total_val_in = 0
    total_val_out = 0

    for df, metrics in results:
        total_in += metrics.get("input_tokens", 0)
        total_out += metrics.get("output_tokens", 0)
        total_val_in += metrics.get("validation_input_tokens", 0)
        total_val_out += metrics.get("validation_output_tokens", 0)
        if not df.empty:
            segment_dfs.append(df)

    # Record aggregate file metrics with blended cost (Bug #6 fix).
    # Codegen tokens are priced at the agentic model rate;
    # Validation tokens are priced at the utility model rate.
    model_cfg = state.get("model_cfg") or models.get_active_model()
    codegen_cost = models.compute_cost(total_in, total_out, model_cfg)
    validation_cost = models.compute_cost(total_val_in, total_val_out, models.get_utility_model())
    cost = codegen_cost + validation_cost
    record_stage(
        company=state.get("company_name", ""),
        filename=state.get("file_label", os.path.basename(state.get("file_path", ""))),
        stage="extraction",
        time_seconds=extraction_wall_time,
        input_tokens=total_in + total_val_in,
        output_tokens=total_out + total_val_out,
        cost=cost,
    )

    # Save the validation code exactly once per file.
    # Validation code is generated solely from schema_text + instructions_text -
    # it is identical across all segments and has nothing to do with the
    # per-segment row ranges or sheet names.  We save it here in file_reduce
    # (rather than inside segment_worker_node) because this is the only point
    # where ALL segment results have arrived, so we can reliably pick the first
    # non-empty copy.  This also avoids the race where segment 1 may have
    # extracted 0 rows (causing segment_validate to short-circuit and return
    # "validation_code": ""), which would have silently skipped the save entirely
    # if we had guarded on idx == 1 in segment_worker_node.
    first_validation_code = next(
        (m.get("validation_code", "") for _, m in results if m.get("validation_code", "")),
        "",
    )
    _save_generated_code(
        code=first_validation_code,
        output_data_dir=state.get("output_data_dir", ""),
        company_name=state.get("company_name", ""),
        file_label=state.get("file_label", os.path.basename(state.get("file_path", ""))),
        sheet_name="shared",
        row_range="",
        segment_index=0,
        kind="validation",
    )

    if not segment_dfs:
        combined = pd.DataFrame(columns=_SCHEMA_COLUMNS)
    else:
        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore",
                message=r".*empty or all-NA.*",
                category=FutureWarning,
            )
            combined = pd.concat(segment_dfs, ignore_index=True).reset_index(drop=True)

    return {
        "combined_df": combined,
        "total_input_tokens": total_in,
        "total_output_tokens": total_out,
        "extraction_wall_time": extraction_wall_time,
    }


def build_file_graph() -> Any:
    """Compile the file-level sub-graph.

    Topology::

        START -> build_payloads -> [Send per segment] -> segment_worker -> file_reduce -> END

    The ``segment_results`` key in ``FileGraphState`` uses an
    ``Annotated[list, operator.add]`` reducer, so LangGraph automatically
    merges all worker outputs into a single list during fan-in.
    """
    g = StateGraph(FileGraphState)

    g.add_node("build_payloads", file_build_payloads)
    g.add_node("segment_worker", segment_worker_node)
    g.add_node("file_reduce", file_reduce)

    g.add_edge(START, "build_payloads")
    g.add_conditional_edges("build_payloads", _dispatch_segments)
    g.add_edge("segment_worker", "file_reduce")
    g.add_edge("file_reduce", END)

    return g.compile()


# Pre-compiled file graph (singleton)
_file_graph = None
_file_graph_lock = threading.Lock()


def _get_file_graph():
    global _file_graph
    with _file_graph_lock:
        if _file_graph is None:
            _file_graph = build_file_graph()
        return _file_graph


def run_file_graph(
    file_path: str,
    table_summaries: List[Dict[str, Any]],
    schema_text: str,
    instructions_text: str,
    company_name: str = "",
    output_data_dir: str = "",
    model_cfg: Optional[Dict[str, Any]] = None,
    file_label: str = "",
) -> pd.DataFrame:
    """Run the file-level sub-graph: fan-out segments, fan-in results.

    This is the main entry point called by ``pipeline.py``.
    """
    _lazy_init_columns()  # populate column aliases on first use
    graph = _get_file_graph()

    initial_state: FileGraphState = {
        "file_path": file_path,
        "company_name": company_name,
        "output_data_dir": output_data_dir,
        "schema_text": schema_text,
        "instructions_text": instructions_text,
        "model_cfg": model_cfg or models.get_active_model(),
        "table_summaries": table_summaries,
        "file_label": file_label,
        "max_retries": MAX_VALIDATION_RETRIES,
        "segment_results": [],
    }

    final_state = graph.invoke(initial_state)
    return final_state.get("combined_df", pd.DataFrame(columns=_SCHEMA_COLUMNS))
