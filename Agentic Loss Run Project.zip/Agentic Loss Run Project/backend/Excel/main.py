import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from run_pipeline import COMPANY_NAMES

from constants import get_cli_log_mode
from pipeline import run_dual_agentic_langgraph_pipeline
from sandbox_executor import get_sandbox_status_message
from utils_gpt import print_llm_startup_notice


def main():
    company_names = list(COMPANY_NAMES)


    # Print sandbox execution mode
    print(f"\n{get_sandbox_status_message()}")
    print(f"CLI log mode: {get_cli_log_mode()}")
    print_llm_startup_notice()
    print()

    run_dual_agentic_langgraph_pipeline(
        company_names=company_names,
    )

if __name__ == "__main__":
    main()
