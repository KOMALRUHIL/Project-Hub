"""LLM-based validation agent for extracted DataFrames.

This module implements a check-only validation design:

1. The validation-code generator sees only `schema_text` and
   `instructions_text`.
2. It generates a Python function that checks an extracted DataFrame.
3. The generated function may inspect the DataFrame at runtime and report
   mistakes, but it must never mutate values, drop rows, or return a repaired
   DataFrame.
4. Any detected issues are returned as feedback to the extraction code
   generator so the coding agent can regenerate extraction logic.

Caching / "Generate Once" Semantics

Validation code depends *only* on the schema and extraction instructions -
it is completely independent of any specific file, sheet, segment, or account.
Therefore the module maintains a **thread-safe, Event-gated cache** keyed by
`(model_name, schema_text, instructions_text)`.

- On the *first* call within a pipeline run the LLM generates the validation
  function. Concurrent callers (from parallel segment fan-outs) block on a
  `threading.Event` until that generation completes - avoiding duplicate
  LLM calls.
- Every subsequent call - across all files, segments, and accounts in the same
  pipeline run - is a zero-cost cache hit.
- `reset_validation_cache()` **must** be called at the start of each pipeline
  run (handled by `pipeline.py`) so that stale code from a prior run is
  never served.
"""

from __future__ import annotations

import re
import time
import threading
import warnings
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
from tqdm import tqdm

import models
from constants import (
    VALIDATION_NA_FIX_RETRIES,
    VALIDATION_RUNTIME_FIX_RETRIES,
    VALIDATION_SYNTAX_FIX_RETRIES,
)
from llm_code_utils import (
    extract_code_from_llm_output as _extract_code_from_llm_output,
    sanitize_generated_code as _sanitize_generated_code,
)
from metrics import record_pipeline_step
from utils import fmt_duration as _fmt_duration, log_cli
from utils_gpt import gpt_call


@dataclass
class ValidationAgentResult:
    """Outcome of a single validation-agent pass."""

    is_valid: bool = False
    needs_retry: bool = False
    retry_feedback: str = ""
    errors_found: List[str] = field(default_factory=list)
    validation_code: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    system_failure: bool = False


_SYSTEM_PROMPT = r"""\
# Role
You are a senior Python engineer generating a **validation function** for a
data extraction pipeline. The function checks an extracted pandas DataFrame
against a schema and extraction instructions, reports issues, but NEVER
mutates the DataFrame.

# Inputs you receive (in the user message)
1. **schema_text** -- column names, types, formats, allowed values, constraints.
2. **instructions_text** -- domain-specific extraction rules.

You do NOT receive any sample rows or observed data. Generate **generic**
validation code that works on any DataFrame that might be produced.

# Required output
Generate a **single self-contained Python function**:

    def validate_output(df: pd.DataFrame) -> dict:
        ...

Return dict with exactly these keys:

    {"errors": list[str], "needs_retry": bool, "retry_feedback": str}

##############################################################################
# MANDATORY CODING RULES (violating ANY of these will crash at runtime)
##############################################################################

## Regex escaping in JSON output (CRITICAL - causes "nothing to repeat" crashes)
- Your output is a JSON string value. Raw strings (r"...") preserve backslashes
  literally - they do NOT need an extra escape layer.
- Regex metacharacters (\\d, \\s, \\w, \\b, \\., etc.) need ONLY the single JSON
  escape: write \\\\d, \\\\s, \\\\w, \\\\b in your JSON output.
- NEVER double-escape: \\\\\\\\d, \\\\\\\\s, \\\\\\\\w are WRONG and will cause regex
  compilation errors at runtime (e.g. "nothing to repeat").
- Correct: {"code": "date_re = re.compile(r'^\\\\d{4}$')"}
- WRONG:   {"code": "date_re = re.compile(r'^\\\\\\\\d{4}$')"}

## Inline regex flags (CRITICAL - causes "global flags not at the start" crashes)
- In Python 3.11+, inline global flags like (?i), (?s), (?m) MUST appear at
  the very START of the pattern, BEFORE any other characters.
- Correct: re.compile(r'(?i)^open|closed$')
- WRONG:   re.compile(r'^(?i)open|closed$')
- Preferred: use the flags= parameter instead of inline flags:
  re.compile(r'^open|closed$', re.IGNORECASE)

## Pandas 2.x compatibility
- **NEVER** use `.iteritems()` -- it was REMOVED in pandas 2.0.
  Use `.items()` instead.
- **NEVER** use `infer_datetime_format` -- it was removed.

## Index safety (CRITICAL -- most common crash cause)
- The DataFrame index may NOT be 0..n-1 (it can be non-contiguous after
  filtering, e.g. [0, 2, 5, 10, ...]).
- **NEVER** use `for i in range(len(df)): df.at[i, col]` -- this WILL
  raise KeyError on non-contiguous indexes.
- **ALWAYS** use one of these safe patterns:
  - Vectorized masks: `mask = df['col'].notna(); bad = df.loc[mask, 'col']`
  - `for idx, row in df.iterrows(): row['col']` (row-loop, idx is the label)
  - `df.iloc[i]` (positional) if you truly need integer position

## Boolean operators (CRITICAL -- second most common crash)
- **NEVER** use Python `and`, `or`, `not` with pandas Series.
  They raise "Truth value of a Series is ambiguous".
- **ALWAYS** use bitwise operators with parentheses: `(mask1) & (mask2)`,
  `(mask1) | (mask2)`, `~mask1`.
- **NEVER** call `.invert()` on a pandas `Series` or `Index`.
  That method does not exist in pandas; use `~mask` instead.

## Null safety
- **ALWAYS** filter out nulls BEFORE checking formats or values.
  `str(np.nan)` produces `"nan"` which fails date/state format checks.
- Correct pattern:
    mask_notnull = df[col].notna()
    vals = df.loc[mask_notnull, col].astype(str).str.strip()
    bad = vals[~vals.str.match(pattern)]
- Use `pd.isna(x)` for scalar null checks -- it handles None, np.nan,
  pd.NA, and pd.NaT uniformly.

## String parsing safety
- **NEVER** unpack date splits directly: `mm, dd, yyyy = s.split('/')`
  If the string has unexpected parts this raises ValueError.
  Use `re.match()` / `re.compile()` for format validation instead.

## Imports
- All imports (`numpy`, `re`, `math`, `datetime`, etc.) MUST be placed
  **inside** the function body, not at module level.
  `pd` is already available in the namespace -- you may use it directly
  OR import pandas inside the function.

## Other restrictions
- NEVER mutate the DataFrame (no drop, no assignment, no inplace).
- NEVER return a modified DataFrame.
- Use ONLY: pandas, numpy, re, math, datetime, and the Python stdlib.

##############################################################################
# WHAT TO VALIDATE (derive ALL checks from schema_text + instructions_text)
##############################################################################

Read the schema and instructions carefully. Every validation check you
generate must be **derived from what the schema and instructions say**.
Do NOT invent domain-specific rules that are not stated there.

Typical categories of checks (implement only those relevant to the schema):

1. **Column presence** -- verify all schema-defined columns exist in the
   DataFrame.
2. **Allowed / enum values** -- if the schema defines an explicit set of
   allowed values for a column, validate with vectorized `.isin()`.
3. **Format checks** -- if the schema specifies a format (date pattern,
   regex, code length, etc.), validate non-null values against that format.
   Use `re.compile()` for pattern matching. Do NOT parse with `split()`.
4. **Numeric constraints** -- if the schema declares a column as numeric or
   specifies bounds (e.g. >= 0), validate via `pd.to_numeric(..., errors='coerce')`.
5. **Cross-field / conditional rules** -- if the instructions describe
   relationships between columns (e.g. "column A is required only when
   column B equals X"), implement those conditional checks.
6. **Identifier validity** -- if the schema defines an ID column, check that
   non-null values look like plausible identifiers (not accidental flags,
   booleans, or formatting artifacts). Derive what is "plausible" from the
   schema description.
7. **Row-level plausibility** -- if the instructions mention filtering out
   summary, total, or aggregate rows, flag rows that match those criteria.

**Important guidelines**:
- Derive column names, types, allowed values, formats, and business rules
  **exclusively** from the schema and instructions provided.
- Not every field is required and can be optional. This means some rows may
  have nulls and others may have values. Unless it is explicitly stated that
  a column is required or must take a certain value, do not treat nulls as
  validation errors.
- Ignore metadata columns that the schema marks as auto-populated or
  system-generated.

##############################################################################
# RETRY FEEDBACK FORMAT (this is what the extraction coder will see)
##############################################################################

The coding agent only sees column names, column-level stats, and a few sample
values from the original spreadsheet. Therefore `retry_feedback` must include
enough concrete context so it can understand what went wrong.

For each issue, include:
- Column name(s) involved
- What was **expected** (format, allowed values)
- What was **observed** (a few example bad values)
- Failing row indices (up to 10) and count (e.g. "3/120 rows")
- If cross-field: name BOTH columns and show the conflicting combination

Style: short header + bullet list. Example:
  "Issue: Column 'status' invalid values. Expected ['O','C','R','S'].
  Observed: ['Open', 'Closed']. Failing rows: [0,1,5] (3/120)."

If no issues: return errors=[], needs_retry=False, retry_feedback="".

##############################################################################
# RECOMMENDED CODE SKELETON (adapt to the specific schema)
##############################################################################

def validate_output(df: pd.DataFrame) -> dict:
    import re
    import numpy as np

    errors = []
    needs_retry = False
    feedback = []
    total_rows = len(df)

    def add_issue(msg):
        nonlocal needs_retry
        errors.append(msg)
        needs_retry = True
        feedback.append("- " + msg)

    def sample(series, n=5):
        return list(series.dropna().astype(str).unique()[:n])

    # 1. Column presence
    expected = [...] # fill from schema
    missing = [c for c in expected if c not in df.columns]
    if missing:
        add_issue(f"Missing columns: {missing}")

    # 2. Enum checks (vectorized, null-safe)
    if 'col' in df.columns:
        mask = df['col'].notna()
        vals = df.loc[mask, 'col'].astype(str).str.strip().str.lower()
        invalid = vals[~vals.isin(allowed_set)]
        if len(invalid) > 0:
            add_issue(f"Column 'col' ... Examples: {sample(invalid)}")

    # 3. Date format (regex, null-safe -- NO split-based parsing)
    date_re = re.compile(r'^(0[1-9]|1[0-2])/(0[1-9]|[12]\d|3[01])/\d{4}$')
    for col in date_cols:
        if col in df.columns:
            mask = df[col].notna()
            vals = df.loc[mask, col].astype(str).str.strip()
            bad = vals[~vals.str.match(date_re)]
            if len(bad) > 0:
                add_issue(...)

    # 4. Financial checks (vectorized)
    for col in money_cols:
        if col in df.columns:
            mask = df[col].notna()
            converted = pd.to_numeric(df.loc[mask, col], errors='coerce')
            ...

    # ... more checks (all vectorized, all null-safe) ...

    if not needs_retry:
        return {"errors": [], "needs_retry": False, "retry_feedback": ""}
    header = "Validation issues found:\\n"
    return {"errors": errors, "needs_retry": True,
            "retry_feedback": header + "\\n".join(feedback)}

Adapt this skeleton to the SPECIFIC schema and instructions you receive.
Do NOT copy it verbatim -- fill in the actual column names, allowed values,
and business rules from the schema and instructions.

# Output format
Return ONLY the complete function as a single JSON object:
  {"code": "<full function text>"}

Do NOT include markdown fences, explanations, or anything outside the JSON.
"""


# Minimal system prompt for validation-code fix retries.
# Syntax/runtime/missing-function repairs need only basic Python knowledge,
# not the full validation schema/instructions, saving ~2,400 input tokens per retry.
_VALIDATION_FIX_SYSTEM_PROMPT: str = """\
You are a senior Python engineer. Your only task is to fix code errors.
Return ONLY a JSON object: {"code": "<full corrected function text>"}
Do NOT include markdown fences, explanations, or anything outside the JSON.
""".strip()


def _build_validation_syntax_fix_prompt(broken_code: str, syn_err: SyntaxError) -> Tuple[str, str]:
    """Ask the model to make the smallest possible syntax-only repair."""
    lineno = syn_err.lineno or "?"
    msg = syn_err.msg or str(syn_err)
    lines = broken_code.splitlines()
    ctx_start = max(0, (syn_err.lineno or 1) - 6)
    ctx_end = min(len(lines), (syn_err.lineno or 1) + 5)
    snippet = "\\n".join(
        f"{i + 1:>4}: {line}"
        for i, line in enumerate(lines[ctx_start:ctx_end], start=ctx_start)
    )
    user_message = f"""You previously generated Python validation code. It has a SYNTAX ERROR.

Do NOT change the validation logic unless a tiny change is strictly required to
fix the syntax. Keep the same function and behavior.

Syntax error:
- Message: {msg}
- Line: {lineno}

Code around the error (lines {ctx_start + 1}-{ctx_end}):
{snippet}

Output format (VERY IMPORTANT):
- Return EXACTLY ONE JSON object of the form:
  {{"code": "<full corrected function text>"}}
- The value of "code" must be the ENTIRE validation code as plain text.
- Do NOT include markdown fences, explanations, or extra keys.

Full validation code to fix:
{broken_code}""".strip()
    return _VALIDATION_FIX_SYSTEM_PROMPT, user_message


def _build_validation_runtime_fix_prompt(broken_code: str, runtime_err: Exception) -> Tuple[str, str]:
    """Ask the model to repair module-level/runtime errors in validation code."""
    err_type = type(runtime_err).__name__
    err_msg = str(runtime_err)
    user_message = f"""The Python validation code you previously generated raises a runtime
error before or while defining the validation function.

Do NOT change the overall validation intent. ONLY make the smallest changes
needed so the code can be executed and defines a callable validate_output(df).

Runtime error details:
- Type: {err_type}
- Message: {err_msg}

Output format (VERY IMPORTANT):
- Return EXACTLY ONE JSON object of the form:
  {{"code": "<full corrected function text>"}}
- The value of "code" must be the ENTIRE validation code as plain text.
- Do NOT include markdown fences, explanations, or extra keys.

Full validation code to fix:
{broken_code}""".strip()
    return _VALIDATION_FIX_SYSTEM_PROMPT, user_message


def _build_missing_validation_function_prompt(partial_code: str) -> Tuple[str, str]:
    """Ask the model to add the required validate_output function."""
    user_message = f"""The Python validation code you generated is missing the required
callable `validate_output(df: pd.DataFrame) -> dict`.

Do NOT change the overall validation behavior except to add or complete that
function. Keep the code compact and deterministic.

Required return value:
{{
    "errors": list[str],
    "needs_retry": bool,
    "retry_feedback": str,
}}

Output format (VERY IMPORTANT):
- Return EXACTLY ONE JSON object of the form:
  {{"code": "<full corrected function text>"}}
- The value of "code" must be the ENTIRE validation code as plain text.
- Do NOT include markdown fences, explanations, or extra keys.

Current validation code:
{partial_code}""".strip()
    return _VALIDATION_FIX_SYSTEM_PROMPT, user_message


def _build_validation_namespace_template() -> Dict[str, Any]:
    """Build the canonical execution namespace template for validation code.

    This is called ONCE at module load time. Each actual execution gets a
    shallow copy via `_get_validation_namespace()` (Bug #3 fix).
    """

    # Whitelist of modules that validation code is allowed to import.
    ALLOWED_MODULES = frozenset({
        "math", "re", "datetime", "collections", "itertools", "functools",
        "string", "decimal", "fractions", "statistics", "copy", "json",
        "typing", "dataclasses", "enum", "operator", "textwrap",
        "numpy", "np", "pandas", "pd",
    })

    import builtins as _builtins_mod
    _real_import = _builtins_mod.__import__

    def _safe_import(name, globals=None, locals=None, fromlist=(), level=0):
        """Allow imports only for whitelisted modules."""
        top_level = name.split(".")[0]
        if top_level not in ALLOWED_MODULES:
            raise ImportError(
                f"Import of '{name}' is not allowed in validation code. "
                f"Allowed modules: {', '.join(sorted(ALLOWED_MODULES))}"
            )
        return _real_import(name, globals, locals, fromlist, level)

    namespace: Dict[str, Any] = {
        "pd": pd,
        "re": re,
        "__builtins__": {
            "__import__": _safe_import,
            "True": True,
            "False": False,
            "None": None,
            "len": len,
            "range": range,
            "enumerate": enumerate,
            "zip": zip,
            "map": map,
            "filter": filter,
            "list": list,
            "dict": dict,
            "set": set,
            "tuple": tuple,
            "str": str,
            "object": object,
            "int": int,
            "float": float,
            "bool": bool,
            "min": min,
            "max": max,
            "sum": sum,
            "abs": abs,
            "round": round,
            "any": any,
            "all": all,
            "sorted": sorted,
            "reversed": reversed,
            "isinstance": isinstance,
            "type": type,
            "hasattr": hasattr,
            "getattr": getattr,
            "print": print,
            "repr": repr,
            "format": format,
            "iter": iter,
            "next": next,
            "frozenset": frozenset,
            "ValueError": ValueError,
            "TypeError": TypeError,
            "KeyError": KeyError,
            "IndexError": IndexError,
            "NameError": NameError,
            "ImportError": ImportError,
            "AssertionError": AssertionError,
            "ArithmeticError": ArithmeticError,
            "LookupError": LookupError,
            "OSError": OSError,
            "IOError": IOError,
            "FileNotFoundError": FileNotFoundError,
            "UnicodeError": UnicodeError,
            "Exception": Exception,
            "BaseException": BaseException,
            "RuntimeError": RuntimeError,
            "AttributeError": AttributeError,
            "StopIteration": StopIteration,
            "NotImplementedError": NotImplementedError,
            "ZeroDivisionError": ZeroDivisionError,
            "OverflowError": OverflowError,
        },
    }

    import math
    import numpy as np

    namespace["math"] = math
    namespace["np"] = np
    namespace["numpy"] = np
    return namespace


# Lazy init: built on first call to _build_validation_namespace(), not at import
# time, so that `import numpy`, `import math`, and the full namespace dict
# construction only happen when validation is actually used (Issue #9 fix).
_VALIDATION_NAMESPACE_TEMPLATE = None  # type: Dict[str, Any] | None


def _build_validation_namespace() -> Dict[str, Any]:
    """Return a fresh copy of the validation namespace for code execution.

    The template is built lazily on first call so that heavy imports
    (numpy, math) and the full namespace dict are only constructed when
    validation is actually needed - not at module import time.
    """
    global _VALIDATION_NAMESPACE_TEMPLATE
    if _VALIDATION_NAMESPACE_TEMPLATE is None:
        _VALIDATION_NAMESPACE_TEMPLATE = _build_validation_namespace_template()
    import copy
    return copy.copy(_VALIDATION_NAMESPACE_TEMPLATE)


@contextmanager
def _pandas_validation_compat() -> Any:
    """Temporarily add tiny pandas compatibility shims for generated validators.

    Some generated validation code has been observed to call `.invert()` on a
    boolean `Series`, even though pandas exposes inversion via the `~` operator
    rather than a `Series.invert()` method. Install a narrow, thread-safe shim
    during validator execution so these runs degrade gracefully instead of being
    treated as validator system failures.
    """
    global _PANDAS_VALIDATION_COMPAT_REFCOUNT

    with _PANDAS_VALIDATION_COMPAT_LOCK:
        if _PANDAS_VALIDATION_COMPAT_REFCOUNT == 0:
            added_patches: List[Tuple[Any, str]] = []

            def _invert(self):
                return ~self

            for cls in (pd.Series, pd.Index):
                if not hasattr(cls, "invert"):
                    setattr(cls, "invert", _invert)
                    added_patches.append((cls, "invert"))

            _PANDAS_VALIDATION_COMPAT_PATCHES[:] = added_patches

        _PANDAS_VALIDATION_COMPAT_REFCOUNT += 1

    try:
        yield
    finally:
        with _PANDAS_VALIDATION_COMPAT_LOCK:
            _PANDAS_VALIDATION_COMPAT_REFCOUNT -= 1
            if _PANDAS_VALIDATION_COMPAT_REFCOUNT == 0:
                for cls, attr_name in _PANDAS_VALIDATION_COMPAT_PATCHES:
                    try:
                        delattr(cls, attr_name)
                    except AttributeError:
                        pass
                _PANDAS_VALIDATION_COMPAT_PATCHES.clear()


def _preflight_validation_code(code: str) -> None:
    """Ensure generated validation code compiles and defines the required callable."""
    namespace = _build_validation_namespace()
    compiled = compile(code, "<validation_agent>", "exec")
    exec(compiled, namespace)  # noqa: S102
    fn = namespace.get("validate_output")
    if fn is None or not callable(fn):
        raise RuntimeError("Validation code does not define a callable 'validate_output'.")


def _build_validation_prompt(schema_text: str, instructions_text: str) -> Tuple[str, str]:
    """Assemble the system + user messages for validation-code generation."""
    user_message = "\n".join(
        [
            "--- schema_text ---",
            "",
            schema_text,
            "",
            "--- instructions_text ---",
            "",
            instructions_text,
        ]
    )
    return _SYSTEM_PROMPT, user_message


def _get_validation_code(
    schema_text: str,
    instructions_text: str,
    model_cfg: Dict[str, Any],
) -> Tuple[str, int, int]:
    """Generate or reuse cached validation code based only on schema/instructions.

    Uses a threading.Event-based pending sentinel so that when multiple segments
    run concurrently (via LangGraph Send fan-out) only the *first* thread fires
    the LLM call. All other threads block on the Event and reuse the result.
    """
    cache_key = (
        model_cfg.get("model_name", ""),
        schema_text,
        instructions_text,
    )

    # -- Fast path: already completed ---------------------------------------
    with _VALIDATION_CODE_CACHE_LOCK:
        entry = _VALIDATION_CODE_CACHE.get(cache_key)
        if isinstance(entry, tuple):
            # Completed result from a previous call - reused across all
            # files, segments, and accounts within this pipeline run.
            code, _, _ = entry
            log_cli(
                f" ♻️ [ValidationCodeGen] ♻️ cache hit - reusing shared validator "
                f"(model={model_cfg.get('model_name')})"
            )
            return code, 0, 0
        if isinstance(entry, threading.Event):
            # Another thread is already generating; we'll wait below.
            pending_event: Optional[threading.Event] = entry
        else:
            # We are the first thread for this key - claim it.
            pending_event = None
            new_event: threading.Event = threading.Event()
            _VALIDATION_CODE_CACHE[cache_key] = new_event

    # -- Slow path A: wait for another thread that is already generating ----------
    if pending_event is not None:
        global _VALIDATION_CACHE_WAITERS
        with _VALIDATION_CODE_CACHE_LOCK:
            _VALIDATION_CACHE_WAITERS += 1
            waiter_num = _VALIDATION_CACHE_WAITERS
        log_cli(
            f" ⏳ [ValidationCodeGen] ⏳ thread #{waiter_num} waiting for in-flight "
            f"validator generation (model={model_cfg.get('model_name')})"
        )
        pending_event.wait()  # blocks until the generating thread signals
        with _VALIDATION_CODE_CACHE_LOCK:
            entry = _VALIDATION_CODE_CACHE.get(cache_key)
        if isinstance(entry, tuple):
            code, _, _ = entry
            log_cli(
                f" ♻️ [ValidationCodeGen] ♻️ cache hit after wait - reusing shared "
                f"validator (model={model_cfg.get('model_name')})"
            )
            return code, 0, 0
        # Generating thread failed - propagate the failure immediately
        # instead of triggering a thundering herd of redundant LLM calls.
        if isinstance(entry, _ValidationFailure):
            raise RuntimeError(
                f"Validation code generation failed (from generating thread): "
                f"{entry.exception}"
            ) from entry.exception
        # Unknown cache state - raise explicitly instead of recursing,
        # which could cause an infinite loop on cache corruption (Bug #7 fix).
        with _VALIDATION_CODE_CACHE_LOCK:
            _VALIDATION_CODE_CACHE.pop(cache_key, None)
        raise RuntimeError(
            "Validation code cache in unexpected state after wait. "
            "The generating thread may have failed silently. "
            "Resetting cache entry; the next pipeline run will regenerate."
        )

    # -- Slow path B: we own the generation ----------------------------------
    system_message, user_message = _build_validation_prompt(schema_text, instructions_text)

    log_cli(
        f" 🔥 [ValidationCodeGen] 🔥 cache miss - generating shared validator "
        f"(model={model_cfg.get('model_name')}). "
        f"This code will be reused for ALL segments/files/accounts in this run."
    )
    llm_start = time.perf_counter()
    log_cli(" 💬 [ValidationCodeGen] LLM request started... (waiting on model)")

    raw_output, in_tokens, out_tokens = gpt_call(
        user_message,
        model_cfg["model_name"],
        model_cfg["api_version"],
        skip_json_coercion=True,
        system_message=system_message,
    )

    llm_elapsed = time.perf_counter() - llm_start
    log_cli(
        f" ⚡ [ValidationCodeGen] LLM response received in {_fmt_duration(llm_elapsed)} "
        f"(tokens: {in_tokens:,} in / {out_tokens:,} out)"
    )

    code = _sanitize_generated_code(_extract_code_from_llm_output(raw_output or "", error_context="validation agent"))

    # -- Unified fix loop: syntax -> runtime -> function presence -----------
    # Re-checks all three from the top after each fix, matching the pattern
    # in code_generation.py. This prevents the old sequential approach from
    # sending a wrong fix prompt (e.g. a runtime-fix prompt for what is
    # actually a new syntax error introduced by a prior fix).
    _max_fix_attempts = VALIDATION_SYNTAX_FIX_RETRIES + VALIDATION_RUNTIME_FIX_RETRIES
    for _fix_attempt in range(_max_fix_attempts):
        # 1. Syntax check
        try:
            compile(code, "<validation_agent>", "exec")
        except SyntaxError as syn_err:
            fix_sys, fix_user = _build_validation_syntax_fix_prompt(code, syn_err)
            raw_fix, add_in, add_out = gpt_call(
                fix_user,
                model_cfg["model_name"],
                model_cfg["api_version"],
                skip_json_coercion=True,
                system_message=fix_sys,
            )
            in_tokens += add_in
            out_tokens += add_out
            code = _sanitize_generated_code(_extract_code_from_llm_output(raw_fix or "", error_context="validation agent"))
            continue  # Re-check all validations from the top

        # 2. Runtime + function presence check
        try:
            _preflight_validation_code(code)
        except RuntimeError as runtime_err:
            if "callable 'validate_output'" in str(runtime_err):
                fix_sys, fix_user = _build_missing_validation_function_prompt(code)
            else:
                fix_sys, fix_user = _build_validation_runtime_fix_prompt(code, runtime_err)
            raw_fix, add_in, add_out = gpt_call(
                fix_user,
                model_cfg["model_name"],
                model_cfg["api_version"],
                skip_json_coercion=True,
                system_message=fix_sys,
            )
            in_tokens += add_in
            out_tokens += add_out
            code = _sanitize_generated_code(_extract_code_from_llm_output(raw_fix or "", error_context="validation agent"))
            continue  # Re-check all validations from the top

        break  # All checks passed

    try:
        _preflight_validation_code(code)
    except Exception as exc:
        # Store a failure sentinel so waiting threads propagate the error
        # immediately instead of all racing to regenerate (thundering herd).
        with _VALIDATION_CODE_CACHE_LOCK:
            entry = _VALIDATION_CODE_CACHE.get(cache_key)
            event_to_set = entry if isinstance(entry, threading.Event) else None
            _VALIDATION_CODE_CACHE[cache_key] = _ValidationFailure(exc)
        if event_to_set is not None:
            event_to_set.set()
        raise RuntimeError(f"Validation code failed preflight: {exc}") from exc

    with _VALIDATION_CODE_CACHE_LOCK:
        event_to_signal: Optional[threading.Event] = None
        entry = _VALIDATION_CODE_CACHE.get(cache_key)
        if isinstance(entry, threading.Event):
            event_to_signal = entry
        _VALIDATION_CODE_CACHE[cache_key] = (code, in_tokens, out_tokens)

    if event_to_signal is not None:
        event_to_signal.set()  # Wake up any waiting threads

    # Record the one-time validation-codegen cost at pipeline level so it
    # appears in the metrics JSON under pipeline_steps.
    codegen_elapsed = time.perf_counter() - llm_start
    try:
        codegen_cost = models.compute_cost(in_tokens, out_tokens, model_cfg)
    except Exception as exc:
        log_cli(f" ⚠️ [ValidationCodeGen] [WARN] Cost computation failed: {exc}")
        codegen_cost = 0.0
    record_pipeline_step(
        "validation_codegen",
        time_seconds=codegen_elapsed,
        input_tokens=in_tokens,
        output_tokens=out_tokens,
        cost=codegen_cost,
    )
    log_cli(
        f"  [ValidationCodeGen] ✅ Shared validator ready "
        f"(cost: ${codegen_cost:.4f}, tokens: {in_tokens:,} in / {out_tokens:,} out)"
    )

    return code, in_tokens, out_tokens


def _execute_validation_code(code: str, df: pd.DataFrame) -> dict:
    """Execute the generated validation function against a DataFrame."""
    import numpy as np

    namespace = _build_validation_namespace()

    def _deep_sanitize_df(frame: pd.DataFrame) -> pd.DataFrame:
        out = frame.copy()
        for col in out.columns:
            try:
                if pd.api.types.is_extension_array_dtype(out[col].dtype):
                    out[col] = out[col].astype(object)
                mask = out[col].isna()
                if mask.any():
                    out[col] = out[col].astype(object)
                    out.loc[mask, col] = np.nan
            except (TypeError, ValueError):
                pass
        return out

    def _coerce_errors(val: Any) -> List[str]:
        if val is None:
            return []
        if isinstance(val, list):
            return [str(v).strip() for v in val if str(v).strip()]
        if isinstance(val, tuple):
            return [str(v).strip() for v in val if str(v).strip()]
        if isinstance(val, set):
            return [str(v).strip() for v in val if str(v).strip()]
        if isinstance(val, pd.Series):
            return [str(v).strip() for v in val.dropna().tolist() if str(v).strip()]
        if isinstance(val, pd.Index):
            return [str(v).strip() for v in val.tolist() if str(v).strip()]
        text = str(val).strip()
        return [text] if text else []

    def _safe_result_value(val: Any) -> Any:
        try:
            if pd.isna(val):
                return None
        except (TypeError, ValueError):
            pass
        return val

    def _coerce_bool_result(val: Any, default: bool = False) -> bool:
        if val is None:
            return default
        if isinstance(val, bool):
            return val
        if isinstance(val, pd.Series):
            non_null = val.dropna()
            if non_null.empty:
                return default
            if non_null.dtype == bool:
                return bool(non_null.any())
            lowered = non_null.astype(str).str.strip().str.lower()
            truthy = {"true", "1", "yes", "y", "t"}
            falsy = {"false", "0", "no", "n", "f", ""}
            if lowered.isin(truthy | falsy).all():
                return bool(lowered.isin(truthy).any())
            return default
        try:
            if pd.isna(val):
                return default
        except (TypeError, ValueError):
            pass
        if isinstance(val, str):
            lowered = val.strip().lower()
            if lowered in {"true", "1", "yes", "y", "t"}:
                return True
            if lowered in {"false", "0", "no", "n", "f", ""}:
                return False
        try:
            return bool(val)
        except (TypeError, ValueError):
            return default

    def _coerce_text_result(val: Any, default: str = "") -> str:
        if val is None:
            return default
        if isinstance(val, str):
            return val
        if isinstance(val, pd.Series):
            parts = [str(v).strip() for v in val.dropna().tolist() if str(v).strip()]
            return "\n".join(parts) if parts else default
        try:
            if pd.isna(val):
                return default
        except (TypeError, ValueError):
            pass
        return str(val)

    with _pandas_validation_compat():
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", category=FutureWarning)
            warnings.filterwarnings("ignore", category=UserWarning)
            try:
                exec(compile(code, "<validation_agent>", "exec"), namespace)  # noqa: S102
            except Exception as exc:
                raise RuntimeError(f"Validation code failed to compile/exec: {exc}") from exc

            fn = namespace.get("validate_output")
            if fn is None or not callable(fn):
                raise RuntimeError("Validation code does not define a callable 'validate_output'.")

            safe_df = _deep_sanitize_df(df)
            max_na_retries = VALIDATION_NA_FIX_RETRIES
            last_exc: Optional[Exception] = None
            result: Optional[dict] = None
            for _na_attempt in range(max_na_retries):
                try:
                    result = fn(safe_df)
                    last_exc = None
                    break
                except TypeError as exc:
                    if "boolean value of NA is ambiguous" in str(exc):
                        safe_df = _deep_sanitize_df(safe_df)
                        last_exc = exc
                        continue
                    raise RuntimeError(f"Validation code raised {type(exc).__name__}: {exc}") from exc
                except Exception as exc:
                    raise RuntimeError(f"Validation code raised {type(exc).__name__}: {exc}") from exc

            if result is None:
                raise RuntimeError(f"Validation code raised {type(last_exc).__name__}: {last_exc}")

            if not isinstance(result, dict):
                raise RuntimeError(f"validate_output returned {type(result).__name__}, expected dict.")

            for key in ("needs_retry", "retry_feedback"):
                if key in result:
                    result[key] = _safe_result_value(result[key])

            # Defensive: some generated validators return a non-standard
            # `error_count` key - sanitize it so downstream coercion
            # does not choke on NA / NaT sentinel values.
            if "error_count" in result:
                result["error_count"] = _safe_result_value(result["error_count"])

        errors_found = _coerce_errors(result.get("errors", []))
        needs_retry = _coerce_bool_result(result.get("needs_retry", False), default=False)
        retry_feedback = _coerce_text_result(result.get("retry_feedback", ""), default="").strip()
        # Honour the validator's own severity judgment: only force needs_retry=True
        # when the generated code explicitly set it, OR when there are errors AND
        # a non-empty retry_feedback (i.e. actionable issues, not just advisories).
        # This prevents advisory / optional-field warnings from burning extra
        # codegen retries unnecessarily.
        if errors_found and retry_feedback and not needs_retry:
            needs_retry = True
        if errors_found and not retry_feedback:
            retry_feedback = "\n".join(errors_found)

        result = {
            "errors": errors_found,
            "needs_retry": needs_retry,
            "retry_feedback": retry_feedback,
        }
        return result


def summarize_validation_outcome(
    vr: ValidationAgentResult,
) -> Dict[str, Any]:
    """Classify a validation pass for concise CLI/status reporting."""
    error_count = len(vr.errors_found)
    if vr.system_failure:
        detail = vr.errors_found[0] if vr.errors_found else "validator preflight/execution failed"
        return {
            "status": "system_failure",
            "message": f"🔴 Validation system failure; skipping retry ({detail})",
        }

    if vr.needs_retry:
        return {
            "status": "retry_required",
            "message": f"⚠️ 🔺 Validation found {error_count} issue(s)",
        }

    if error_count > 0:
        return {
            "status": "advisory",
            "message": (
                f"🟡 Validation reported {error_count} issue(s) but did not request retry"
            ),
        }

    return {
        "status": "clean",
        "message": "✅ Validation check passed - no issues found",
    }


def validate_segment_output(
    df: pd.DataFrame,
    schema_text: str,
    instructions_text: str,
    model_cfg: Optional[Dict[str, Any]] = None,
) -> ValidationAgentResult:
    """Run the schema/instructions-only validation-code generator and checker."""
    # Validation code generation is a lightweight one-time task (schema ->
    # Python function) that doesn't need the expensive extraction model.
    # Use the shared utility model from inputs.UTILITY_MODEL instead.
    validation_model = models.get_utility_model()

    if df.empty:
        return ValidationAgentResult(is_valid=True)

    try:
        code, in_tokens, out_tokens = _get_validation_code(schema_text, instructions_text, validation_model)
    except Exception as exc:
        tqdm.write(f" ⚠️ [ValidationCodeGen] Code generation failed: {exc}")
        return ValidationAgentResult(
            is_valid=True,
            needs_retry=False,
            retry_feedback="",
            errors_found=[f"Validation system failure: {exc}"],
            system_failure=True,
        )

    try:
        result = _execute_validation_code(code, df)
    except Exception as exc:
        tqdm.write(f" ⚠️ [ValidationAgent] Execution failed: {exc}")
        return ValidationAgentResult(
            is_valid=True,
            needs_retry=False,
            retry_feedback="",
            errors_found=[f"Validation system failure: {exc}"],
            validation_code=code,
            input_tokens=in_tokens,
            output_tokens=out_tokens,
            system_failure=True,
        )

    errors_found = result.get("errors", [])
    needs_retry = bool(result.get("needs_retry", False))
    retry_feedback = str(result.get("retry_feedback", "") or "").strip()
    if errors_found and not retry_feedback:
        retry_feedback = "\n".join(errors_found)

    return ValidationAgentResult(
        is_valid=(not needs_retry) and len(errors_found) == 0,
        needs_retry=needs_retry,
        retry_feedback=retry_feedback,
        errors_found=errors_found,
        validation_code=code,
        input_tokens=in_tokens,
        output_tokens=out_tokens,
        system_failure=False,
    )
