"""Shared utilities for processing LLM-generated code output.

Used by both `code_generation.py` and `validation.py` to avoid
duplicating JSON extraction, sanitization, and regex-flag fixing logic.
"""

from __future__ import annotations

import json
import re

# -----------------------------------------------------------------------------
# Inline regex flag pattern (shared across code-gen and validation)
# -----------------------------------------------------------------------------
_INLINE_FLAG_RE = re.compile(r"\(\?[imsxaLu]+\)")


# -----------------------------------------------------------------------------
# String-aware replacement
# -----------------------------------------------------------------------------

def replace_outside_strings(code: str, pattern: str, replacement: str) -> str:
    """Replace "pattern" only when it appears outside of string literals.
    
    Walks the code character-by-character to track whether we are inside a
    single-quoted, double-quoted, or triple-quoted string. Replacements are
    only applied to regions outside strings, preventing accidental mutation
    of string contents like `"true"` -> `"True"`.
    """
    result: list[str] = []
    i = 0
    n = len(code)
    while i < n:
        # Detect triple-quoted strings
        if code[i:i+3] in ('"""', "'''"):
            quote = code[i:i+3]
            end = code.find(quote, i + 3)
            if end == -1:
                result.append(code[i:])
                break
            result.append(code[i:end+3])
            i = end + 3
            continue
            
        # Detect single/double quoted strings
        if code[i] in ('"', "'"):
            quote = code[i]
            j = i + 1
            while j < n:
                if code[j] == '\\':
                    j += 2
                    continue
                if code[j] == quote:
                    j += 1
                    break
                j += 1
            result.append(code[i:j])
            i = j
            continue
            
        # Detect comments
        if code[i] == '#':
            end = code.find('\n', i)
            if end == -1:
                result.append(code[i:])
                break
            result.append(code[i:end])
            i = end
            continue
            
        # Outside strings - accumulate and apply regex replacement
        j = i
        while j < n and code[j] not in ('"', "'", '#'):
            if code[j:j+3] in ('"""', "'''"):
                break
            j += 1
        chunk = code[i:j]
        chunk = re.sub(pattern, replacement, chunk)
        result.append(chunk)
        i = j
        
    return "".join(result)


# -----------------------------------------------------------------------------
# Regex flag fixer
# -----------------------------------------------------------------------------

def fix_misplaced_regex_flags(code: str) -> str:
    """Move inline regex flags to position 0 of the pattern string."""
    
    def _move_flags_to_front(pattern_body: str) -> str:
        flags = _INLINE_FLAG_RE.findall(pattern_body)
        if not flags:
            return pattern_body
        body = _INLINE_FLAG_RE.sub("", pattern_body)
        return "".join(flags) + body
        
    def _rewrite(m: re.Match) -> str:
        func_open = m.group(1)
        content = m.group(2)
        close_q = m.group(3)
        new_content = _move_flags_to_front(content)
        if new_content == content:
            return m.group(0)
        return f"{func_open}{new_content}{close_q}"
        
    _RE_FUNC = r"re\.(?:compile|search|match|fullmatch|findall|finditer|sub|subn)\s*\(\s*"
    code = re.sub(rf"({_RE_FUNC}r\')([^'\\]*(?:\\.[^'\\]*)*)({r'(?:\s*,|\))'})", _rewrite, code)
    code = re.sub(rf'({_RE_FUNC}r")([^"\\]*(?:\\.[^"]*)*)({r"(?:\s*,|\))"})', _rewrite, code)
    code = re.sub(rf"({_RE_FUNC}\')([^\'\\]*(?:\\.[^\'\\]*)*)({r'(?:\s*,|\))'})", _rewrite, code)
    code = re.sub(rf'({_RE_FUNC}")([^"]*(?:\\.[^"]*)*)({r"(?:\s*,|\))"})', _rewrite, code)
    return code


# -----------------------------------------------------------------------------
# Capturing-group -> non-capturing-group fixer for str.contains()
# -----------------------------------------------------------------------------

# Matches `.str.contains(r'...'` or `.str.contains(r"..."` or without `r` prefix
_STR_CONTAINS_RE = re.compile(
    r"(\.str\.contains\s*\(\s*)"
    r"(r?)(['\"])"
    r"(.*?)"
    r"(\3)"
    r"(\s*,|\))",
    re.DOTALL,
)


def _convert_capturing_to_noncapturing(pattern: str) -> str:
    """Convert plain capturing groups `(...)` to `(?:...)`.
    
    Leaves special groups like `(?...)`, `(?=...)`, `(?!...)`,
    `(?<=...)`, `(?<!...)`, and `(?P<...>)` untouched.
    """
    # Match a `(` that is NOT followed by `?` - i.e. a plain capturing group
    return re.sub(r"\((?!\?)", "(?:", pattern)


def fix_capturing_groups_in_str_contains(code: str) -> str:
    """Replace capturing groups with non-capturing groups inside
    `str.contains()` regex arguments to suppress pandas UserWarning."""
    
    def _repl(m: re.Match) -> str:
        prefix = m.group(1)       # `.str.contains(`
        raw_flag = m.group(2)     # `r` or ``
        quote = m.group(3)        # `'` or `"`
        body = m.group(4)         # regex pattern body
        end_quote = m.group(5)    # closing quote
        new_body = _convert_capturing_to_noncapturing(body)
        return f"{prefix}{raw_flag}{quote}{new_body}{end_quote}"
        
    return _STR_CONTAINS_RE.sub(_repl, code)


# -----------------------------------------------------------------------------
# Code sanitization (merged from code_generation + validation)
# -----------------------------------------------------------------------------

def sanitize_generated_code(code: str) -> str:
    """Remove common LLM code-generation artifacts from generated Python.
    
    Combines the best of both the extraction and validation sanitizers:
    - Stray `\n` artifact removal
    - Smart/curly quote normalisation
    - Zero-width character removal
    - Misplaced inline regex flag correction
    - JSON literal -> Python keyword replacement (string-literal safe)
    """
    code = code or ""
    # Stray n artifact sometimes emitted by the LLM
    code = re.sub(r"(?m)^n(?=[ \t]+[a-zA-Z_])", "", code)
    # Smart / curly quotes -> ASCII
    code = code.replace("\u2018", "'").replace("\u2019", "'")
    code = code.replace("\u201c", '"').replace("\u201d", '"')
    # Zero-width / invisible characters
    code = re.sub(r"[\u200b\u200c\u200d\ufeff]", "", code)
    # Misplaced inline regex flags
    code = fix_misplaced_regex_flags(code)
    # Capturing groups -> non-capturing in str.contains() (suppress UserWarning)
    code = fix_capturing_groups_in_str_contains(code)
    # JSON literals -> Python (only outside string literals to avoid mangling
    # comparisons like `if val.lower() in ["true", "false"]`)
    code = replace_outside_strings(code, r"\bnull\b", "None")
    code = replace_outside_strings(code, r"\btrue\b", "True")
    code = replace_outside_strings(code, r"\bfalse\b", "False")
    return code


# -----------------------------------------------------------------------------
# LLM output -> code extraction
# -----------------------------------------------------------------------------

def extract_code_from_llm_output(raw: str, *, error_context: str = "code generation") -> str:
    """Parse model output that may be JSON, fenced code, or raw Python.
    
    Tries multiple strategies in order:
    1. Strict JSON parse
    2. Lenient JSON parse (allows literal control chars)
    3. Repair invalid backslash escapes + strict JSON
    4. Repair + lenient JSON
    5. Fenced code block (```python ... ```)
    6. Fallback: treat entire output as code
    
    Parameters
    ----------
    raw : str
        Raw LLM output text.
    error_context : str
        Label for error messages (e.g. `"code generation"` or
        `"validation agent"`).
    """
    text = (raw or "").strip()
    if not text:
        raise RuntimeError(f"LLM returned empty output for {error_context}.")
        
    # Attempt 1: strict JSON
    try:
        parsed = json.loads(text)
        code = parsed.get("code") if isinstance(parsed, dict) else None
        if isinstance(code, str) and code.strip():
            return code
    except json.JSONDecodeError:
        pass
        
    # Attempt 2: lenient JSON (allows literal control chars)
    try:
        parsed = json.JSONDecoder(strict=False).decode(text)
        code = parsed.get("code") if isinstance(parsed, dict) else None
        if isinstance(code, str) and code.strip():
            return code
    except (json.JSONDecodeError, Exception):
        pass
        
    # Attempt 3: repair invalid backslash escapes + strict
    try:
        repaired = re.sub(r'\\(?![\\"/bfnrtu])', '', text)
        if repaired != text:
            parsed = json.loads(repaired)
            code = parsed.get("code") if isinstance(parsed, dict) else None
            if isinstance(code, str) and code.strip():
                return code
    except (json.JSONDecodeError, Exception):
        pass
        
    # Attempt 4: repair + lenient
    try:
        repaired_lenient = re.sub(r'\\(?![\\"/bfnrtu])', '', text)
        if repaired_lenient != text:
            parsed = json.JSONDecoder(strict=False).decode(repaired_lenient)
            code = parsed.get("code") if isinstance(parsed, dict) else None
            if isinstance(code, str) and code.strip():
                return code
    except (json.JSONDecodeError, Exception):
        pass
        
    # Attempt 5: fenced code block
    fence_match = re.search(r"```(?:python)?\s*(.*?)```", text, re.DOTALL | re.IGNORECASE)
    if fence_match:
        candidate = fence_match.group(1).strip()
        if candidate:
            return candidate
            
    # Fallback: treat entire output as code
    return text
