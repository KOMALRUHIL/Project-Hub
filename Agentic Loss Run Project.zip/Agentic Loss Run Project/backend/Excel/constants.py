"""Shared runtime constants for the agentic extraction pipeline.

Credentials remain in ``.env``. Runtime behavior and pipeline defaults live
here so the application configuration is code-driven rather than controlled by
environment variables.
"""

from __future__ import annotations

from pathlib import Path

from dotenv import load_dotenv

from config_runtime import call_active_inputs_helper, get_active_inputs_module_name

# Resolve all runtime paths relative to the project root so the pipeline
# works no matter which folder it is launched from.
PROJECT_ROOT: Path = Path(__file__).resolve().parent


# Load credentials from the project-local .env once, early, for the whole pipeline.
if not globals().get("_dotenv_loaded"):
    load_dotenv(dotenv_path=PROJECT_ROOT / ".env", override=True)
    _dotenv_loaded = True


# ------------------------------------------------------------------------------
# Pipeline entry defaults
# ------------------------------------------------------------------------------
DEFAULT_INPUT_DATA_DIR: str = str(PROJECT_ROOT / "input_data")
DEFAULT_OUTPUT_DATA_DIR: str = str(PROJECT_ROOT / "output_data")
DEFAULT_EXTRACTION_DATA_DIR: str = str(PROJECT_ROOT / "extraction_output")


# ------------------------------------------------------------------------------
# API runtime behavior
# ------------------------------------------------------------------------------
API_CALL_TIMEOUT_SECONDS: float = 240.0
MAX_CONCURRENT_API_CALLS: int = 15
API_MAX_RETRY_ATTEMPTS: int = 10
API_RETRY_BASE_DELAY: float = 2.0
API_RETRY_MAX_DELAY: float = 60.0
LLM_ERROR_LOG_PATH: str = str(PROJECT_ROOT / "llm_error_log.txt")


# ------------------------------------------------------------------------------
# CLI logging behavior
# ------------------------------------------------------------------------------
# CLI_LOG_MODE and CLI_VERBOSE are lazily resolved on first access via
# _ensure_cli_settings() / module __getattr__, avoiding an import-time
# dependency on inputs.py (Issue #15 fix).
CLI_PREVIEW_ITEM_LIMIT: int = 2
CLI_DETAIL_MAX_CHARS: int = 160


def _ensure_cli_settings() -> None:
    """Lazily resolve CLI_LOG_MODE and CLI_VERBOSE from inputs.py."""
    if (
        "CLI_LOG_MODE" in globals()
        and globals().get("_CLI_SETTINGS_SOURCE") == get_active_inputs_module_name()
    ):
        return
    mode = call_active_inputs_helper("get_cli_log_mode_setting", default="concise")
    globals()["CLI_LOG_MODE"] = mode
    globals()["CLI_VERBOSE"] = mode == "verbose"
    globals()["_CLI_SETTINGS_SOURCE"] = get_active_inputs_module_name()


def get_cli_log_mode() -> str:
    """Return the active CLI log mode label."""
    _ensure_cli_settings()
    return globals()["CLI_LOG_MODE"]


def __getattr__(name: str):
    """Lazy module-level attributes for CLI_LOG_MODE and CLI_VERBOSE."""
    if name in ("CLI_LOG_MODE", "CLI_VERBOSE"):
        _ensure_cli_settings()
        return globals()[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


# ------------------------------------------------------------------------------
# API use-case label
# ------------------------------------------------------------------------------
API_USE_CASE: str = "testing"


# ------------------------------------------------------------------------------
# Sandbox runtime behavior
# ------------------------------------------------------------------------------
SANDBOX_ENABLED: bool = False
SANDBOX_FALLBACK_TO_LEGACY: bool = True
SANDBOX_TIMEOUT_SECONDS: int = 120
SANDBOX_MEMORY_LIMIT: str = "1g"
SANDBOX_CPU_COUNT: int = 2
SANDBOX_POOL_MAX_SIZE: int = 8
SANDBOX_POOL_MIN_SIZE: int = 2
SANDBOX_VERBOSE: bool = False


# ------------------------------------------------------------------------------
# Generated-code persistence
# ------------------------------------------------------------------------------
SAVE_GENERATED_CODE: bool = False


# ------------------------------------------------------------------------------
# Token-based sheet routing
# ------------------------------------------------------------------------------
# Sheets with token count <= this threshold use raw _segmented.json data;
# sheets above this threshold use summarised _segmented_totals_summary.json.
SHEET_TOKEN_THRESHOLD: int = 10_000

# Retry / loop limits
# ------------------------------------------------------------------------------
MAX_VALIDATION_RETRIES: int = 3
MAX_CODE_FIX_RETRIES: int = 1
VALIDATION_SYNTAX_FIX_RETRIES: int = 1
VALIDATION_RUNTIME_FIX_RETRIES: int = 1
VALIDATION_NA_FIX_RETRIES: int = 2
