from __future__ import annotations

import datetime
import json
import re
import string
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple
from zipfile import BadZipFile

import pandas as pd
from openpyxl import load_workbook
from openpyxl.utils import column_index_from_string, get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

from block_detection import (
    _block_looks_like_header,
    get_or_create_chunkable_copy,
    _merge_tables_with_neighbors,
    _rect_col_count,
    _rect_gap_rows,
    _rect_overlap_cols,
    _rect_union,
    classify_block,
    connected_blocks,
    extract_tables_from_block,
    merge_adjacent_blocks,
    non_empty_coords,
)
from utils import (
    as_extended_path as _as_extended_path,
    is_blank_value as _is_blank_value,
    parse_numeric_value as _parse_numeric_value,
    write_json as _write_json,
)

Row = List[Dict[str, Any]]


@dataclass
class TotalDetectionResult:
    row_type: Optional[str]
    reasons: List[str]


DEFAULT_TOKENS = {
    "total",
    "totals",
    "subtotal",
    "subtotals",
    "grand",
    "overall",
    "grandtotal",
    "overalltotal",
    "count",
    "counts",
    "totalcount",
}


def _row_non_empty_values(row: Row) -> List[Any]:
    return [cell.get("value") for cell in row if not _is_blank_value(cell.get("value"))]


def _row_has_meaningful_text(row: Row) -> bool:
    for cell in row:
        value = cell.get("value")
        if _is_blank_value(value):
            continue
        if isinstance(value, str):
            if any(ch.isalnum() for ch in value):
                return True
    return False


def _normalize_token(token: str) -> str:
    return "".join(ch for ch in token.lower() if ch.isalnum())


def _normalize_alpha_token(text: str) -> str:
    return "".join(ch for ch in text.lower() if ch.isalpha())


def _normalize_whitespace(text: str) -> str:
    return " ".join(text.strip().lower().split())


def _normalize_token_set(tokens: Iterable[str]) -> Set[str]:
    return {_normalize_token(token) for token in tokens if token}


def _match_total_tokens(
    tokens: Iterable[str],
    total_tokens: Optional[Sequence[str]] = None,
    allow_count: bool = True,
) -> Set[str]:
    normalized_tokens = _normalize_token_set(tokens)
    target_tokens = _normalize_token_set(total_tokens) if total_tokens else set(DEFAULT_TOKENS)
    if not allow_count:
        target_tokens = target_tokens.difference({"count", "counts", "totalcount"})
    matched = normalized_tokens.intersection(target_tokens)
    if allow_count and "total" in normalized_tokens and "count" in normalized_tokens:
        matched.add("totalcount")
    return matched


def _text_is_total_marker_token(token: str) -> bool:
    normalized = _normalize_token(token)
    return normalized in {"total", "totals", "grandtotal", "overalltotal"}


def _text_is_count_marker_token(token: str) -> bool:
    normalized = _normalize_token(token)
    return normalized in {"count", "counts", "totalcount"}


def _is_header_repeat(row: Row, headers: Sequence[dict]) -> bool:
    header_texts = {_normalize_text(h.get("text")) for h in headers if h.get("text")}
    if not header_texts:
        return False
    row_texts = [_normalize_text(cell.get("value")) for cell in row if isinstance(cell.get("value"), str)]
    row_texts = [t for t in row_texts if t]
    if not row_texts:
        return False
    match_count = sum(1 for v in row_texts if v in header_texts)
    return (match_count / max(1, len(row_texts))) >= 0.6


def _normalize_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip().lower()


def _tokenize(value: Any) -> List[str]:
    text = _normalize_text(value)
    if not text:
        return []
    translator = str.maketrans({ch: " " for ch in string.punctuation})
    cleaned = text.translate(translator)
    parts = [p for p in cleaned.split() if p]
    return parts


def _row_text_tokens(row: Row) -> List[str]:
    tokens: List[str] = []
    for cell in row:
        value = cell.get("value")
        if _is_blank_value(value):
            continue
        if not isinstance(value, str):
            continue
        tokens.extend(_tokenize(value))
    return tokens


def _row_label_markers(row: Row) -> Set[str]:
    markers: Set[str] = set()
    for cell in row:
        value = cell.get("value")
        if not isinstance(value, str):
            continue
        stripped = value.strip()
        if not stripped:
            continue
        alpha = _normalize_alpha_token(stripped)
        if alpha in {
            "total",
            "totals",
            "grandtotal",
            "overalltotal",
            "subtotal",
            "subtotals",
            "count",
            "counts",
            "totalcount",
        }:
            markers.add(alpha)
        normalized_ws = _normalize_whitespace(stripped)
        if normalized_ws in {"total count", "total counts"}:
            markers.add("totalcount")
    return markers


def _row_numeric_values(row: Row) -> List[float]:
    numeric_values: List[float] = []
    for cell in row:
        value = cell.get("value")
        if _is_blank_value(value):
            continue
        numeric = _parse_numeric_value(value)
        if numeric is not None:
            numeric_values.append(numeric)
    return numeric_values


def _row_numeric_cell_positions(row: Row) -> List[int]:
    positions: List[int] = []
    for idx, cell in enumerate(row):
        value = cell.get("value")
        if _parse_numeric_value(value) is not None:
            positions.append(idx)
    return positions


def _row_layout_score(row: Row, max_label_cells: int) -> Tuple[float, List[str]]:
    reasons: List[str] = []
    text_positions = _row_text_cell_positions(row)
    numeric_positions = _row_numeric_cell_positions(row)

    if not numeric_positions:
        return -1.0, ["no_numeric_positions"]

    if not text_positions:
        return -1.0, ["no_text_positions"]

    score = 0.0
    if max(text_positions) < min(numeric_positions):
        score += 1.0
        reasons.append("text_left_of_numeric")
    else:
        score -= 1.0
        reasons.append("text_not_left_of_numeric")

    if (max(text_positions) + 1) <= max_label_cells:
        score += 0.75
        reasons.append("label_in_leading_cells")
    else:
        score -= 0.5
        reasons.append("label_not_leading")

    if min(numeric_positions) >= max_label_cells:
        score += 0.75
        reasons.append("numeric_after_label_region")
    else:
        score -= 0.5
        reasons.append("numeric_in_label_region")

    if len(row) > 0 and min(numeric_positions) >= max(1, len(row) // 2):
        score += 0.5
        reasons.append("numeric_right_half")
    else:
        score -= 0.25
        reasons.append("numeric_not_right_half")

    if any(pos > min(numeric_positions) for pos in text_positions):
        score -= 0.5
        reasons.append("text_after_numeric")

    return score, reasons


def _row_text_cell_positions(row: Row) -> List[int]:
    positions: List[int] = []
    for idx, cell in enumerate(row):
        value = cell.get("value")
        if _is_blank_value(value):
            continue
        if isinstance(value, str):
            if _normalize_text(value):
                positions.append(idx)
    return positions


def _row_has_rollup_context(
    row_idx: int,
    data_run_start: int,
    min_data_rows: int = 2,
) -> bool:
    if row_idx <= data_run_start:
        return False
    return (row_idx - data_run_start) >= min_data_rows


def _detect_total_row(
    row: Row,
    row_idx: int,
    data_run_start: int,
    headers: Optional[Sequence[dict]] = None,
    total_tokens: Optional[Sequence[str]] = None,
    allow_count: bool = True,
    max_label_cells: int = 3,
    min_numeric_cells: int = 1,
    layout_score_threshold: float = 1.75,
    allow_without_rollup: bool = False,
) -> TotalDetectionResult:
    values = _row_non_empty_values(row)
    if not values:
        return TotalDetectionResult(None, ["empty_row"])

    if headers and _is_header_repeat(row, headers):
        return TotalDetectionResult(None, ["header_repeat"])

    tokens = _row_text_tokens(row)
    label_markers = _row_label_markers(row)
    if not tokens:
        if label_markers:
            tokens = list(label_markers)
        else:
            return TotalDetectionResult(None, ["no_text_tokens"])

    matched_tokens = _match_total_tokens(tokens, total_tokens=total_tokens, allow_count=allow_count)
    matched_tokens = matched_tokens.union(label_markers)
    if not matched_tokens:
        return TotalDetectionResult(None, ["no_total_tokens"])

    numeric_values = _row_numeric_values(row)
    if len(numeric_values) < min_numeric_cells:
        return TotalDetectionResult(None, ["no_numeric_context"])

    text_positions = _row_text_cell_positions(row)
    if text_positions and (max(text_positions) + 1) > max_label_cells:
        return TotalDetectionResult(None, ["label_not_leading"])

    numeric_positions = _row_numeric_cell_positions(row)
    if not text_positions:
        return TotalDetectionResult(None, ["no_label_text"])
    if numeric_positions and max(text_positions) >= min(numeric_positions):
        return TotalDetectionResult(None, ["text_not_left_of_numeric"])

    rollup_ok = _row_has_rollup_context(row_idx, data_run_start)
    if not rollup_ok:
        return TotalDetectionResult(None, ["no_rollup_context"])

    layout_score, layout_reasons = _row_layout_score(row, max_label_cells=max_label_cells)
    if layout_score < layout_score_threshold:
        return TotalDetectionResult(None, ["layout_mismatch", *layout_reasons])

    row_type = None
    if {
        "grand",
        "overall",
        "grandtotal",
        "overalltotal",
    }.intersection(matched_tokens):
        row_type = "grand_total"
    elif {"subtotal", "subtotals"}.intersection(matched_tokens):
        row_type = "sub_total"
    elif {"total", "totals"}.intersection(matched_tokens):
        row_type = "total"
    elif {"count", "counts", "totalcount"}.intersection(matched_tokens):
        row_type = "count"

    return TotalDetectionResult(row_type, ["matched"] if row_type else ["unknown_match"])


def _classify_row_type_non_regex(
    row: Row,
    headers: Sequence[dict],
    row_idx: int,
    data_run_start: int,
    total_tokens: Optional[Sequence[str]] = None,
    allow_count: bool = True,
    max_label_cells: int = 2,
    min_numeric_cells: int = 1,
    min_data_rows_for_rollup: int = 3,
    layout_score_threshold: float = 1.75,
    allow_without_rollup: bool = False,
) -> str:
    values = _row_non_empty_values(row)
    if not values:
        return "non_informative"

    numeric_values = _row_numeric_values(row)
    has_text = bool(_row_text_tokens(row))
    has_numeric = bool(numeric_values)

    if not has_numeric and not _row_has_meaningful_text(row):
        return "non_informative"

    rollup_ok = _row_has_rollup_context(row_idx, data_run_start, min_data_rows=min_data_rows_for_rollup)
    tokens = _row_text_tokens(row)
    label_markers = _row_label_markers(row)
    matched_tokens = _match_total_tokens(tokens, total_tokens=total_tokens, allow_count=allow_count)
    matched_tokens = matched_tokens.union(label_markers)
    text_positions = _row_text_cell_positions(row)
    numeric_positions = _row_numeric_cell_positions(row)
    layout_score, _ = _row_layout_score(row, max_label_cells=max_label_cells)
    if (
        matched_tokens
        and has_numeric
        and rollup_ok
        and text_positions
        and (not numeric_positions or max(text_positions) < min(numeric_positions))
        and layout_score >= layout_score_threshold
    ):
        if not text_positions or (max(text_positions) + 1) <= max_label_cells:
            if {"grand", "overall", "grandtotal", "overalltotal"}.intersection(matched_tokens):
                return "grand_total"
            if {"subtotal", "subtotals"}.intersection(matched_tokens):
                return "sub_total"
            if {"total", "totals"}.intersection(matched_tokens):
                return "total"
            if {"count", "counts", "totalcount"}.intersection(matched_tokens):
                return "count"

    if _is_header_repeat(row, headers):
        return "non_informative"

    if len(values) == 1 and isinstance(values[0], str) and any(ch.isalpha() for ch in values[0]):
        return "non_informative"

    if not has_text and len(values) <= 1:
        return "non_informative"

    return "data"


def classify_row_type(
    row: Row,
    headers: Sequence[dict],
    row_idx: int,
    data_run_start: int,
    total_tokens: Optional[Sequence[str]] = None,
    allow_count: bool = True,
    max_label_cells: int = 2,
    min_numeric_cells: int = 1,
    min_data_rows_for_rollup: int = 3,
    layout_score_threshold: float = 1.75,
    allow_without_rollup: bool = False,
) -> str:
    """Unified row classifier - replaces the two-pass
    `detect_total_row` -> `classify_row_type_non_regex` pattern.

    Returns one of: `"grand_total"`, `"sub_total"`, `"total"`,
    `"count"`, `"data"`, `"non_informative"`.
    """
    detection = _detect_total_row(
        row,
        row_idx,
        data_run_start,
        headers=headers,
        total_tokens=total_tokens,
        allow_count=allow_count,
        max_label_cells=max_label_cells,
        min_numeric_cells=min_numeric_cells,
        layout_score_threshold=layout_score_threshold,
        allow_without_rollup=allow_without_rollup,
    )
    if detection.row_type:
        return detection.row_type

    return _classify_row_type_non_regex(
        row,
        headers,
        row_idx,
        data_run_start,
        total_tokens=total_tokens,
        allow_count=allow_count,
        max_label_cells=max_label_cells,
        min_numeric_cells=min_numeric_cells,
        min_data_rows_for_rollup=min_data_rows_for_rollup,
        layout_score_threshold=layout_score_threshold,
        allow_without_rollup=allow_without_rollup,
    )


def _parse_cell_row(cell_ref: Optional[str]) -> Optional[int]:
    if not cell_ref:
        return None
    stripped = str(cell_ref).strip()
    if not stripped:
        return None
    num = ""
    for ch in stripped:
        if ch.isdigit():
            num += ch
        elif num:
            break
    return int(num) if num else None


def _row_index(row: Row) -> Optional[int]:
    for cell in row:
        row_num = _parse_cell_row(cell.get("cell"))
        if row_num is not None:
            return row_num
    return None


def _header_row(headers: Sequence[Dict[str, Any]]) -> Optional[int]:
    row_nums = [_parse_cell_row(h.get("cell")) for h in headers if h.get("cell")]
    row_nums = [r for r in row_nums if r is not None]
    return min(row_nums) if row_nums else None


def _iter_rows(segments: Sequence[Dict[str, Any]]) -> Iterable[Row]:
    for segment in segments:
        for row in segment.get("rows", []):
            yield row


def _row_values(row: Row, max_cols: int) -> List[Any]:
    values: List[Any] = []
    for idx in range(max_cols):
        if idx >= len(row):
            values.append(None)
            continue
        values.append(row[idx].get("value"))
    return values


def _contains_alpha(value: str) -> bool:
    return any(ch.isalpha() for ch in value)


def _is_two_row_header_table(ws: Worksheet, t1: Tuple[int, int], br: Tuple[int, int]) -> bool:
    r1, c1 = t1
    r2, c2 = br
    rows = r2 - r1 + 1
    cols = c2 - c1 + 1
    if rows != 2 or cols < 3:
        return False

    def _row_counts(row_idx: int) -> Tuple[int, int, int, int]:
        non_empty = 0
        text_count = 0
        numeric_count = 0
        max_text_len = 0
        for c in range(c1, c2 + 1):
            v = ws.cell(row_idx, c).value
            if v in (None, ""):
                continue
            non_empty += 1
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                numeric_count += 1
                continue
            s = str(v).strip()
            if s:
                max_text_len = max(max_text_len, len(s))
                if _contains_alpha(s):
                    text_count += 1
        return non_empty, text_count, numeric_count, max_text_len

    header_non_empty, header_text, header_numeric, header_max_len = _row_counts(r1)
    data_non_empty, data_text, data_numeric, _ = _row_counts(r2)

    if header_non_empty < 3:
        return False
    if header_text < 2 or header_numeric > 1:
        return False
    if header_max_len > 80:
        return False
    if data_non_empty < 2:
        return False
    if (data_text + data_numeric) < 2:
        return False
    return True


def _find_two_row_header_tables(
    ws: Worksheet,
    t1: Tuple[int, int],
    br: Tuple[int, int],
    min_cols: int = 3,
) -> List[Tuple[Tuple[int, int], Tuple[int, int]]]:
    r1, c1 = t1
    r2, c2 = br
    ranges: List[Tuple[Tuple[int, int], Tuple[int, int]]] = []
    for r in range(r1, r2):
        cols = [
            c
            for c in range(c1, c2 + 1)
            if ws.cell(r, c).value not in (None, "")
            or ws.cell(r + 1, c).value not in (None, "")
        ]
        if not cols:
            continue
        sub_c1, sub_c2 = min(cols), max(cols)
        if (sub_c2 - sub_c1 + 1) < min_cols:
            continue
        if _is_two_row_header_table(ws, (r, sub_c1), (r + 1, sub_c2)):
            ranges.append(((r, sub_c1), (r + 1, sub_c2)))

    unique: List[Tuple[Tuple[int, int], Tuple[int, int]]] = []
    for candidate in sorted(ranges, key=lambda item: (item[0][0], item[0][1])):
        if not unique:
            unique.append(candidate)
            continue
        last_t1, last_br = unique[-1]
        if candidate[0][0] <= last_br[0] and candidate[1][0] <= last_br[0]:
            if (candidate[1][1] - candidate[0][1]) > (last_br[1] - last_t1[1]):
                unique[-1] = candidate
        else:
            unique.append(candidate)
    return unique


def _build_non_table_block(
    ws: Worksheet,
    t1: Tuple[int, int],
    br: Tuple[int, int],
    label: str,
) -> Optional[Dict[str, Any]]:
    r1, c1 = t1
    r2, c2 = br

    rows: List[List[Dict[str, Any]]] = []
    for row_idx in range(r1, r2 + 1):
        row_cells: List[Dict[str, Any]] = []
        for col_idx in range(c1, c2 + 1):
            value = ws.cell(row_idx, col_idx).value
            if value in (None, ""):
                continue
            if isinstance(value, str) and _normalize_text(value).startswith("unnamed:"):
                continue
            row_cells.append(
                {
                    "value": value,
                    "cell": f"{get_column_letter(col_idx)}{row_idx}",
                }
            )
        if row_cells:
            rows.append(row_cells)

    if not rows:
        return None

    return {
        "type": label,
        "range": f"{get_column_letter(c1)}{r1}:{get_column_letter(c2)}{r2}",
        "segments": [
            {
                "row_type": label,
                "headers": [],
                "rows": rows,
            }
        ],
    }


def _detect_sheet_blocks(ws: Worksheet) -> List[Dict[str, Any]]:
    coords = non_empty_coords(ws)
    if not coords:
        return []

    raw_blocks = connected_blocks(coords)
    labels = [classify_block(ws, t1, br, members) for (t1, br, members) in raw_blocks]
    merged_blocks, merged_labels = merge_adjacent_blocks(raw_blocks, labels)
    merged_blocks, merged_labels = _merge_tables_with_neighbors(
        merged_blocks,
        merged_labels,
        max_vertical_gap=8,
        max_horizontal_gap=2,
    )

    block_info = []
    for (t1, br, members), label in zip(merged_blocks, merged_labels):
        if label in ("key_values", "text_lines") and _is_two_row_header_table(ws, t1, br):
            label = "table"
        block_info.append({"t1": t1, "br": br, "label": label, "members": members})

    to_remove = set()
    for i, block in enumerate(block_info):
        if block["label"] != "table":
            continue
        t1_i, br_i = block["t1"], block["br"]
        for j, other in enumerate(block_info):
            if i == j or j in to_remove:
                continue
            if other["label"] not in ("text_lines", "key_values"):
                continue
            top_row_limit = t1_i[0] + 2
            if other["br"][0] > top_row_limit:
                continue
            vgap = _rect_gap_rows(t1_i, br_i, other["t1"], other["br"])
            if vgap > 2:
                continue
            col_overlap = _rect_overlap_cols(t1_i, br_i, other["t1"], other["br"])
            min_cols = min(_rect_col_count(t1_i, br_i), _rect_col_count(other["t1"], other["br"]))
            overlap_ratio = (col_overlap / min_cols) if min_cols else 0.0
            if overlap_ratio < 0.2:
                continue
            if not _block_looks_like_header(ws, other["t1"], other["br"]):
                continue
            new_t1, new_br = _rect_union(t1_i, br_i, other["t1"], other["br"])
            block["t1"], block["br"] = new_t1, new_br
            block["members"].update(other["members"])
            t1_i, br_i = new_t1, new_br
            to_remove.add(j)

    if to_remove:
        block_info = [b for idx, b in enumerate(block_info) if idx not in to_remove]

    ordered_table_t1s = sorted(
        [block["t1"] for block in block_info if block["label"] == "table"],
        key=lambda t1: (t1[0], t1[1]),
    )

    sheet_blocks: List[Dict[str, Any]] = []
    for block in block_info:
        t1, br, label = block["t1"], block["br"], block["label"]
        if label == "table":
            next_table_start_row: Optional[int] = None
            for nt1 in ordered_table_t1s:
                if nt1[0] > t1[0]:
                    next_table_start_row = nt1[0]
                    break
            for table in extract_tables_from_block(
                ws, t1, br, context_below_row_limit=next_table_start_row
            ):
                if table.get("type") == "table":
                    sheet_blocks.append(table)
            continue

        if label not in ("key_values", "text_lines"):
            continue

        embedded_tables = _find_two_row_header_tables(ws, t1, br)
        if embedded_tables:
            next_table_start_row_emb: Optional[int] = None
            for nt1 in ordered_table_t1s:
                if nt1[0] > br[0]:
                    next_table_start_row_emb = nt1[0]
                    break
            for table_t1, table_br in embedded_tables:
                for table in extract_tables_from_block(
                    ws,
                    table_t1,
                    table_br,
                    context_below_row_limit=next_table_start_row_emb,
                ):
                    if table.get("type") == "table":
                        sheet_blocks.append(table)
            continue

        non_table_block = _build_non_table_block(ws, t1, br, label)
        if non_table_block:
            sheet_blocks.append(non_table_block)

    def _sort_key(block: Dict[str, Any]) -> Tuple[int, int]:
        range_ref = block.get("range")
        if not isinstance(range_ref, str) or ":" not in range_ref:
            return (10**9, 10**9)
        start_ref = range_ref.split(":", 1)[0]
        match = re.match(r"^([A-Z]+)(\d+)$", start_ref)
        if not match:
            return (10**9, 10**9)
        return (int(match.group(2)), column_index_from_string(match.group(1)))

    sheet_blocks.sort(key=_sort_key)
    return sheet_blocks


def build_total_detection_output_from_excel(
    file_path: str,
    sheet_filter: Optional[Sequence[str]] = None,
) -> Dict[str, Any]:
    path = Path(file_path)
    prepared_path, cleanup_paths = get_or_create_chunkable_copy(path)
    sheets: Dict[str, List[Dict[str, Any]]] = {}

    try:
        try:
            wb = load_workbook(prepared_path, data_only=True, read_only=False)
        except BadZipFile:
            raise ValueError(
                f"Cannot open '{path.name}' the file is not a valid .xlsx "
                f"archive (BadZipFile). This may be a stale conversion "
                f"artefact (_temp.xlsx) from a previous run. Delete it and "
                f"retry."
            )
        try:
            for ws in wb.worksheets:
                if sheet_filter and ws.title not in sheet_filter:
                    continue
                sheet_blocks_payload = _detect_sheet_blocks(ws)
                sheet_blocks = sheets.setdefault(ws.title, [])
                for block in sheet_blocks_payload:
                    if block.get("type") == "table":
                        block_entry = {
                            "type": "table",
                            "range": block.get("range"),
                            "context": block.get("context"),
                            "segments": [
                                {
                                    "row_type": "data_group",
                                    "headers": block.get("headers", []),
                                    "rows": block.get("rows", []),
                                }
                            ],
                        }
                        if block.get("context_above"):
                            block_entry["context_above"] = block["context_above"]
                        if block.get("context_below"):
                            block_entry["context_below"] = block["context_below"]
                        sheet_blocks.append(block_entry)
                        continue

                    sheet_blocks.append(block)
        finally:
            wb.close()
    finally:
        for temp_path in cleanup_paths:
            try:
                if temp_path.exists():
                    temp_path.unlink()
            except Exception:
                pass

    return {
        "source_file": path.name,
        "generated_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "sheets": [
            {
                "sheet_name": sheet_name,
                "blocks": blocks,
            }
            for sheet_name, blocks in sheets.items()
        ],
    }


def save_total_detection_output_from_excel_to_company_folder(
    file_path: str,
    company_name: str,
    base_output_dir: str,
    sheet_filter: Optional[Sequence[str]] = None,
    filename: Optional[str] = None,
) -> Path:
    payload = build_total_detection_output_from_excel(file_path, sheet_filter=sheet_filter)
    company_dir = Path(base_output_dir) / company_name
    output_name = filename or f"{Path(file_path).stem}_segmented.json"
    output_path = company_dir / output_name
    _write_json(output_path, payload)
    return output_path
