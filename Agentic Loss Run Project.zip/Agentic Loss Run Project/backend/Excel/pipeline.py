from __future__ import annotations

import json
import operator
import os
import sys
import time
from pathlib import Path
from typing import Annotated, Any, Callable, TypedDict

import pandas as pd
from tqdm import tqdm

from config_runtime import (
    call_active_inputs_helper,
    get_active_inputs_module_name,
    set_active_inputs_module,
)
from langgraph.graph import END, START, StateGraph  # type: ignore[import-not-found]
from langgraph.types import Send  # type: ignore[import-not-found]

from constants import (
    DEFAULT_EXTRACTION_DATA_DIR,
    DEFAULT_INPUT_DATA_DIR,
    DEFAULT_OUTPUT_DATA_DIR,
    SHEET_TOKEN_THRESHOLD,
)
from file_relevancy import filter_relevant_files, classify_workbook_sheets, get_relevancy_model
from metrics import record_pipeline_step, record_pipeline_wall_times, record_sheet_source, record_stage, reset_metrics_store, save_metrics_json
import models
from row_segmentation import save_total_detection_output_from_excel_to_company_folder
from sandbox_executor import get_sandbox_pool, close_sandbox_pool, clear_converted_file_cache, evict_converted_file_cache
from extraction import run_file_graph as run_segment_extraction_graph
from sheet_context_agent import (
    classify_sheets_with_context,
    derive_sheet_classifications,
    build_context_sheet_summaries,
)
from segment_summarizer import (
    count_payload_candidate_rows,
    save_total_detection_summary_to_company_folder,
    count_tokens_per_sheet,
    build_raw_table_summaries_from_segmented,
)
from utils import as_extended_path_str as _as_extended_path_str
from utils import log_cli
from validation import reset_validation_cache

# File-level parallelism is now handled by LangGraph's Send API.
# The Send fan-out each in processing sub-graph dispatches one worker per
# file; LangGraph manages concurrency internally.

# Module-level column name aliases - lazily populated on first pipeline use
# to avoid executing inputs.py helpers at import time.
_OUTPUT_COLUMN_ORDER: list[str] = []
_LEADING_COL: str = ""
_ACCOUNT_COL: str = ""
_FILE_SRC_COL: str = ""
_COLUMN_CONFIG_MODULE: str = ""


def _lazy_init_columns() -> None:
    """Populate module-level column aliases on first use."""
    global _OUTPUT_COLUMN_ORDER, _LEADING_COL, _ACCOUNT_COL, _FILE_SRC_COL, _COLUMN_CONFIG_MODULE
    active_module = get_active_inputs_module_name()
    if _ACCOUNT_COL and _COLUMN_CONFIG_MODULE == active_module:
        return  # already initialised
    _OUTPUT_COLUMN_ORDER = call_active_inputs_helper("get_output_column_order", default=[]) or []
    _LEADING_COL = call_active_inputs_helper("get_leading_schema_column", default="") or ""
    _ACCOUNT_COL = call_active_inputs_helper("get_account_name_column", default="AccountName")
    _FILE_SRC_COL = call_active_inputs_helper("get_file_source_column", default="file_path")
    _COLUMN_CONFIG_MODULE = active_module


def _get_runtime_relevancy_keywords() -> list[str]:
    """Return the active fast-pass keyword set, including optional no-claims keywords."""
    primary = call_active_inputs_helper("get_relevancy_keywords", default=[]) or []
    deduped: list[str] = []
    seen: set[str] = set()
    for keyword in list(primary):
        norm = str(keyword or "").strip().lower()
        if not norm or norm in seen:
            continue
        seen.add(norm)
        deduped.append(keyword)
    return deduped


def _get_output_csv_filename() -> str:
    """Return the configured output CSV file name for the active config."""
    file_name = call_active_inputs_helper("get_output_csv_filename", default="claims.csv")
    normalized = Path(str(file_name or "claims.csv")).name.strip()
    return normalized or "claims.csv"


def _get_metrics_filename_suffix() -> str:
    """Return an optional suffix for metrics files based on the output CSV name."""
    stem = Path(_get_output_csv_filename()).stem.strip()
    if not stem or stem == "claims":
        return "_excel"
    return f"_{stem}_excel"


class PipelineState(TypedDict, total=False):
    input_data_dir: str
    output_data_dir: str
    extraction_data_dir: str
    company_names: list[str]
    file_jobs: list[dict[str, str]]
    skipped_files: list[dict[str, str]]
    agentic_outputs: list[pd.DataFrame]
    processed_files: int
    overall_start_time: float | None
    step_timings: dict[str, float]
    schema_text: str
    instructions_text: str
    relevancy_keywords: list[str]
    relevancy_instructions: str
    file_work_items: list[dict[str, Any]]


# -- Step-level timing colours ------------------------------------------------
# Only emit ANSI escape codes when stdout is a real terminal (not a log file
# or CI runner that would display raw escape sequences).
_USE_COLOR = hasattr(sys.stdout, "isatty") and sys.stdout.isatty()
_CYAN = "\033[96m" if _USE_COLOR else ""
_GREEN = "\033[92m" if _USE_COLOR else ""
_YELLOW = "\033[93m" if _USE_COLOR else ""
_BOLD = "\033[1m" if _USE_COLOR else ""
_RESET = "\033[0m" if _USE_COLOR else ""


def _timed_node(step_label: str, fn):
    """Wrap a LangGraph node function so it records & prints its wall-clock time."""

    def wrapper(state: PipelineState) -> PipelineState:
        log_cli(f"\n{_CYAN}{'-'*60}")
        log_cli(f" Starting step: {_BOLD}{step_label}{_RESET}{_CYAN}")
        log_cli(f"{'-'*60}{_RESET}")

        t0 = time.perf_counter()
        result = fn(state)
        elapsed = time.perf_counter() - t0

        mins = int(elapsed // 60)
        secs = elapsed % 60
        log_cli(
            f"{_GREEN} Completed step: {_BOLD}{step_label}{_RESET}{_GREEN}"
            f" -> {mins}m {secs:.2f}s{_RESET}"
        )

        # Persist timing into state so the summary can access it later.
        timings = dict(state.get("step_timings") or {})
        timings[step_label] = elapsed
        # Guard: discard any step_timings the inner fn() may have returned
        # to prevent overwriting the accumulated timing dict.
        result.pop("step_timings", None)
        result["step_timings"] = timings
        return result

    wrapper.__name__ = fn.__name__
    return wrapper


def _print_timing_summary(step_timings: dict[str, float]) -> None:
    """Print a formatted summary table of all pipeline step timings."""
    if not step_timings:
        return

    total = sum(step_timings.values())
    total_mins = int(total // 60)
    total_secs = total % 60

    hdr = f"{_BOLD}{_YELLOW}"
    row_c = _CYAN
    rst = _RESET

    log_cli(f"\n{hdr}{'='*72}")
    log_cli(f" PIPELINE TIMING SUMMARY")
    log_cli(f"{'='*72}{rst}")
    log_cli(f"{hdr}{'#':<4} {'Step':<40} {'Time':>10} {'%':>8}{rst}")
    log_cli(f"{'-'*4} {'-'*40} {'-'*10} {'-'*8}")

    for idx, (step, elapsed) in enumerate(step_timings.items(), 1):
        m = int(elapsed // 60)
        s = elapsed % 60
        pct = (elapsed / total * 100) if total > 0 else 0.0
        time_str = f"{m}m {s:05.2f}s"
        log_cli(f"{row_c}{idx:<4} {step:<40} {time_str:>10} {pct:>7.1f}%{rst}")

    log_cli(f"{'-'*4} {'-'*40} {'-'*10} {'-'*8}")
    log_cli(
        f"{hdr}{'':<4} {'TOTAL':<40} "
        f"{f'{total_mins}m {total_secs:05.2f}s':>10} {'100.0%':>8}{rst}"
    )
    log_cli(f"{hdr}{'='*72}{rst}\n")


def _discover_excel_jobs(state: PipelineState) -> PipelineState:
    input_data_dir = state["input_data_dir"]
    company_names = state["company_names"]
    supported_extensions = (".xls", ".xlsx", ".xlsm", ".xlsb", ".csv")

    jobs: list[dict[str, str]] = []
    for company in company_names:
        company_input_path = os.path.join(input_data_dir, company)
        if not os.path.isdir(company_input_path):
            continue
        for root, _, files in os.walk(company_input_path):
            for file in files:
                if file.lower().endswith(supported_extensions) and "_temp." not in file.lower():
                    # Skip _temp.xlsx artifacts left by _ensure_chunkable_copy
                    # from a previous run (conversion of .xls / .xlsb sources).
                    if file.lower().endswith("_temp.xlsx"):
                        base_stem = file[:-len("_temp.xlsx")]
                        if any(
                            os.path.isfile(os.path.join(root, base_stem + ext))
                            for ext in (".xls", ".xlsb")
                        ):
                            continue
                    jobs.append(
                        {
                            "company": company,
                            "file_name": file,
                            "file_path": _as_extended_path_str(os.path.join(root, file)),
                        }
                    )

    # Sort by file size descending - largest files start first so they
    # process in parallel with smaller files instead of queueing behind them.
    jobs.sort(key=lambda x: os.path.getsize(x["file_path"]), reverse=True)

    return {
        "file_jobs": jobs,
        "agentic_outputs": [],
        "processed_files": 0,
        "overall_start_time": time.perf_counter() if jobs else None,
    }


def _filter_relevant_files(state: PipelineState) -> PipelineState:
    """Use the Relevancy Detection Agent to classify each discovered file.

    Two-tier approach:
      1. Filename keyword match - instant accept (zero LLM cost).
      2. LLM-based content classification - only when keywords don't match.

    Files that are NOT relevant are moved to `skipped_files` and will not
    proceed to the extraction stages, saving time and LLM tokens.
    """
    file_jobs = state.get("file_jobs", [])

    if not file_jobs:
        return {"file_jobs": [], "skipped_files": []}

    keywords = state.get("relevancy_keywords") or _get_runtime_relevancy_keywords()
    exclusion_keywords = state.get("relevancy_exclusion_keywords") or (call_active_inputs_helper("get_relevancy_exclusion_keywords", default=[]) or [])
    relevancy_instructions = state.get("relevancy_instructions") or call_active_inputs_helper("get_relevancy_instructions", default="")

    filter_start = time.perf_counter()
    log_cli(f"\n{'-'*60}")
    log_cli(f"Relevancy Detection: Classifying {len(file_jobs)} file(s)...")
    log_cli(f"{'-'*60}")

    relevant_jobs, skipped_jobs, in_tokens, out_tokens = filter_relevant_files(
        file_jobs=file_jobs, keywords=keywords, exclusion_keywords=exclusion_keywords,
        relevancy_instructions=relevancy_instructions,
    )

    fallback_jobs = [
        job for job in relevant_jobs
        if job.get("relevancy_status") == "fallback_infra_failure"
    ]
    confident_relevant_jobs = [
        job for job in relevant_jobs
        if job.get("relevancy_status") != "fallback_infra_failure"
    ]

    filter_elapsed = time.perf_counter() - filter_start
    filter_cost = models.compute_cost(in_tokens, out_tokens, get_relevancy_model())

    log_cli(
        f"\nRelevancy detection complete:\n"
        f"  {len(confident_relevant_jobs)} relevant file(s), "
        f"  {len(fallback_jobs)} fallback-kept, "
        f"  {len(skipped_jobs)} skipped\n"
        f"  in {int(filter_elapsed // 60)}m {filter_elapsed % 60:.2f}s\n"
        f"  (tokens: {in_tokens:,} in / {out_tokens:,} out, cost: ${filter_cost:.4f})"
    )
    if fallback_jobs:
        log_cli("  Fallback-kept files (classification infrastructure failure):")
        for job in fallback_jobs:
            log_cli(
                f"    {job['company']} | {job['file_name']} - "
                f"{job.get('relevancy_reason', job.get('skip_reason', 'fallback-kept'))}"
            )

    # Record per-account / per-file detection costs
    # Each job dict now carries detection_input_tokens / detection_output_tokens
    # so we can attribute detection cost directly to the account that owns the file.
    all_classified_jobs = list(relevant_jobs) + list(skipped_jobs)
    _per_acct: dict[str, dict] = {}  # {company: {in, out, cost, files}}
    for job in all_classified_jobs:
        company = job["company"]
        file_name = job["file_name"]
        det_in = job.get("detection_input_tokens", 0)
        det_out = job.get("detection_output_tokens", 0)
        det_cost = models.compute_cost(det_in, det_out, get_relevancy_model())

        # Record at file level so it shows up under account -> file -> steps
        record_stage(
            company=company,
            filename=file_name,
            stage="relevancy_detection",
            input_tokens=det_in,
            output_tokens=det_out,
            cost=det_cost,
            classification_status=job.get("relevancy_status", "relevant"),
            classification_reason=job.get("relevancy_reason") or job.get("skip_reason", ""),
        )

        # Accumulate per-account totals for the summary printout
        acct = _per_acct.setdefault(company, {"input_tokens": 0, "output_tokens": 0, "cost": 0.0, "files": 0})
        acct["input_tokens"] += det_in
        acct["output_tokens"] += det_out
        acct["cost"] += det_cost
        acct["files"] += 1
        acct[job.get("relevancy_status", "relevant")] = acct.get(job.get("relevancy_status", "relevant"), 0) + 1

    # Print per-account detection cost breakdown
    if _per_acct:
        log_cli(f"\n  Per-account detection costs:")
        for acct_name, acct_data in sorted(_per_acct.items()):
            log_cli(
                f"    {acct_name}: {acct_data['files']} file(s), "
                f"{acct_data['input_tokens']:,} in / {acct_data['output_tokens']:,} out, "
                f"${acct_data['cost']:.4f}"
                f" [relevant={acct_data.get('relevant', 0)}, "
                f"fallback={acct_data.get('fallback_infra_failure', 0)}, "
                f"not_relevant={acct_data.get('not_relevant', 0)}]"
            )

    # Also keep the aggregate pipeline-level step for the grand total
    record_pipeline_step(
        "relevancy_detection",
        time_seconds=filter_elapsed,
        input_tokens=in_tokens,
        output_tokens=out_tokens,
        cost=filter_cost,
        relevant_files=len(confident_relevant_jobs),
        fallback_kept_files=len(fallback_jobs),
        skipped_files=len(skipped_jobs),
    )

    return {
        "file_jobs": relevant_jobs,
        "skipped_files": skipped_jobs,
        # Preserve the original overall_start_time from _discover_excel_jobs
        # so that the end-to-end timing in _combine_and_save_csv includes
        # the relevancy detection phase.
    }


# =============================================================================
# FILE-LEVEL PARALLEL STAGES - LangGraph Send sub-graphs
# =============================================================================

# Each heavy-processing stage (Segmentation, Sheet Classification,
# Summarization, Extraction) uses a LangGraph Send-based
# sub-graph to fan-out across files in parallel, then fan-in the results.
# This replaces the old ThreadPoolExecutor-based _run_file_items_stage()
# with graph-native parallelism that LangGraph can checkpoint and manage.
# =============================================================================

# NOTE: These TypedDict classes MUST be at module level so that
# `get_type_hints()` (used internally by LangGraph) can resolve
# the forward-reference strings created by `from __future__ import annotations`.


class _ExtStageState(TypedDict, total=False):
    file_work_items: list[dict[str, Any]]
    output_data_dir: str
    schema_text: str
    instructions_text: str
    completed_items: Annotated[list, operator.add]
    extracted_dfs: Annotated[list, operator.add]


_DispatchStateBuilder = Callable[[dict, dict[str, Any], int], dict]

# Cache compiled Send-stage sub-graphs keyed by (state_type, worker_name)
# so they are not recompiled on every pipeline run.
_send_stage_graph_cache: dict[tuple, Any] = {}


def _run_send_stage_graph(
    *,
    state_type: Any,
    file_work_items: list[dict[str, Any]],
    worker_name: str,
    worker_fn: Callable[[dict], dict],
    invoke_state: dict[str, Any] | None = None,
    accumulator_state: dict[str, Any] | None = None,
    dispatch_state_builder: _DispatchStateBuilder | None = None,
) -> dict:
    """Run a one-worker-per-file Send stage and return the final sub-graph state."""
    if dispatch_state_builder is None:
        dispatch_state_builder = lambda st, item, _: {**st, "_item": item}

    cache_key = (state_type, worker_name)
    if cache_key not in _send_stage_graph_cache:
        def _dispatch(st) -> list:
            return [
                Send(worker_name, dispatch_state_builder(st, item, i))
                for i, item in enumerate(st["file_work_items"])
            ]

        def _reduce(_st) -> dict:
            return {}

        g = StateGraph(state_type)
        g.add_node("_dispatch_node", lambda st: {})
        g.add_node(worker_name, worker_fn)
        g.add_node("_reduce", _reduce)
        g.add_edge(START, "_dispatch_node")
        g.add_conditional_edges("_dispatch_node", _dispatch)
        g.add_edge(worker_name, "_reduce")
        g.add_edge("_reduce", END)

        _send_stage_graph_cache[cache_key] = g.compile()

    sub_graph = _send_stage_graph_cache[cache_key]

    tqdm.write(f" Processing {len(file_work_items)} file(s)...")
    initial_state = {
        "file_work_items": file_work_items,
        **(invoke_state or {}),
        **(accumulator_state or {}),
    }
    return sub_graph.invoke(initial_state)


# =============================================================================
# COMBINED PREPARE + EXTRACT - eliminates serialisation barrier
# =============================================================================
# Previously, preparation (segment + classify + summarise) and extraction
# were two separate Send fan-out stages with a full state-serialisation
# barrier between them. That meant File A could NOT start extraction
# until File Z finished preparation. This combined stage lets each file
# begin extraction as soon as its own preparation completes - a
# significant end-to-end speedup for multi-file runs.
# =============================================================================


def _prepare_and_extract_files(state: PipelineState) -> PipelineState:
    """Combined prepare + extract: segment, classify, summarise, then extract each file
    in a single Send fan-out.

    This merges the old `_prepare_file_work_items`, `_prepare_files`,
    and `_extract_jobs` into one stage. Each per-file worker completes
    its own preparation and immediately proceeds to extraction without
    waiting for other files, eliminating the serialisation barrier.
    """
    output_data_dir = state["output_data_dir"]
    file_jobs = state.get("file_jobs", [])

    if not file_jobs:
        return {
            "file_work_items": [],
            "agentic_outputs": [],
            "processed_files": 0,
            "schema_text": "",
            "instructions_text": "",
        }

    # -- Inline what _prepare_file_work_items did ------------------------------
    schema_text = call_active_inputs_helper("get_schema_text", default="")
    instructions_text = call_active_inputs_helper("get_instructions_text", default="")

    file_work_items: list[dict[str, Any]] = []
    for job in file_jobs:
        file_work_items.append(
            {
                "company": job["company"],
                "file_name": job["file_name"],
                "file_path": job["file_path"],
                "_cached_snippets": job.get("_cached_snippets"),
                "output_path": "",
                "totals_summary_path": "",
                "sheet_classifications": None,
                "expected_payload_candidate_rows": 0,
                "extracted_df": pd.DataFrame(),
                "segmentation_elapsed": 0.0,
                "summarization_elapsed": 0.0,
                "extraction_elapsed": 0.0,
            }
        )

    total_jobs = len(file_work_items)

    # -- Validation pre-warm (same as old _prepare_files) ----------------------
    import threading
    from validation import _get_validation_code

    _val_prewarm_thread = None
    _val_prewarm_lock = threading.Lock()
    validation_model = models.get_utility_model()

    def _ensure_validation_prewarm_started() -> None:
        nonlocal _val_prewarm_thread
        with _val_prewarm_lock:
            if _val_prewarm_thread is not None:
                return

            def _prewarm_validation():
                try:
                    _get_validation_code(schema_text, instructions_text, validation_model)
                except Exception as exc:
                    tqdm.write(f"  [WARN] Validation code pre-warm failed (will retry at extraction time): {exc}")

            try:
                _val_prewarm_thread = threading.Thread(target=_prewarm_validation, daemon=True, name="val-prewarm")
                _val_prewarm_thread.start()
                tqdm.write("  Pre-warming validation code generation (background)...")
            except Exception as exc:
                tqdm.write(f"  [WARN] Validation pre-warm thread creation failed: {exc}")

    sheet_rel_instr = call_active_inputs_helper("get_sheet_relevancy_instructions", default="")

    # -- Combined worker: prepare -> extract for ONE file ----------------------
    def _combined_worker(st: dict) -> dict:
        item = dict(st["_item"])  # shallow copy to avoid cross-worker mutation
        idx = st.get("_item_idx", 0)
        out_dir = st["output_data_dir"]
        sch_text = st.get("schema_text", "")
        instr_text = st.get("instructions_text", "")

        company = item["company"]
        file = item["file_name"]
        file_path = item["file_path"]

        # =====================================================================
        # PHASE 1 - PREPARE (segment + classify + summarise)
        # =====================================================================

        # -- 1a. Segmentation
        seg_start = time.perf_counter()
        output_path = save_total_detection_output_from_excel_to_company_folder(
            file_path, company, out_dir,
        )
        segmentation_elapsed = time.perf_counter() - seg_start
        item["output_path"] = output_path
        item["segmentation_elapsed"] = segmentation_elapsed

        record_stage(
            company=company, filename=file, stage="segmentation",
            time_seconds=segmentation_elapsed, input_tokens=0,
            output_tokens=0, cost=0.0,
        )
        tqdm.write(f"  Segmented: {file} ({segmentation_elapsed:.1f}s)")

        # -- 1b. Sheet Context Agent (or legacy classification) ----------------
        sheet_classifications = None
        context_sheet_summaries = None
        sheet_cls_elapsed = 0.0
        sheet_cls_in_tokens = 0
        sheet_cls_out_tokens = 0
        sheet_cls_cost = 0.0
        try:
            sc_start = time.perf_counter()

            if call_active_inputs_helper("get_sheet_context_agent_enabled", default=False):
                # -- New: three-outcome Sheet Context Agent
                context_classifications, sc_in, sc_out = classify_sheets_with_context(
                    file_path, file,
                    schema_text=sch_text,
                    instructions_text=instr_text,
                    precomputed_snippets=item.get("_cached_snippets"),
                )
                sheet_cls_elapsed = time.perf_counter() - sc_start
                sheet_cls_in_tokens = sc_in
                sheet_cls_out_tokens = sc_out
                sheet_cls_cost = models.compute_cost(sc_in, sc_out, get_relevancy_model())

                # Derive legacy-compatible boolean classifications for
                # summarize_segmented_payload()
                sheet_classifications = derive_sheet_classifications(context_classifications)

                # Build cross-sheet context summaries from metadata-only sheets
                context_sheet_summaries = build_context_sheet_summaries(context_classifications)

                if context_classifications:
                    parse_sheets = [
                        s for s, c in context_classifications.items()
                        if c.parse_full_sheet
                    ]
                    context_only_sheets = [
                        s for s, c in context_classifications.items()
                        if not c.parse_full_sheet and c.is_still_relevant
                    ]
                    skipped_sheets = [
                        s for s, c in context_classifications.items()
                        if not c.parse_full_sheet and not c.is_still_relevant
                    ]
                    if context_only_sheets or skipped_sheets:
                        tqdm.write(
                            f"  Sheet context agent for {file}: "
                            f"extract={parse_sheets}, "
                            f"context-only={context_only_sheets}, "
                            f"skipped={skipped_sheets}"
                        )
                    if context_sheet_summaries:
                        for cs in context_sheet_summaries:
                            tqdm.write(
                                f"    Context from '{cs['source_sheet']}': "
                                f"'{cs['summary'][:120]}{'...' if len(cs['summary']) > 120 else ''}'"
                            )
            else:
                # -- Legacy: binary sheet classification ------------------------
                sheet_classifications, sc_in, sc_out = classify_workbook_sheets(
                    file_path, file,
                    sheet_relevancy_instructions=sheet_rel_instr,
                    precomputed_snippets=item.get("_cached_snippets"),
                )
                sheet_cls_elapsed = time.perf_counter() - sc_start
                sheet_cls_in_tokens = sc_in
                sheet_cls_out_tokens = sc_out
                sheet_cls_cost = models.compute_cost(sc_in, sc_out, get_relevancy_model())

                if sheet_classifications:
                    relevant_sheets = [s for s, v in sheet_classifications.items() if v]
                    non_relevant_sheets = [s for s, v in sheet_classifications.items() if not v]
                    if non_relevant_sheets:
                        tqdm.write(
                            f"  Sheet classification for {file}: "
                            f"relevant={relevant_sheets}, skipping={non_relevant_sheets}"
                        )
        except Exception as exc:
            tqdm.write(
                f"  [WARN] Sheet context agent failed for {file}, "
                f"processing all sheets: {exc}"
            )

        # -- Hard-exclude sheets whose name matches known exclusion patterns ---
        _excl_kws = call_active_inputs_helper("get_sheet_name_exclusions", default=[]) or []
        if _excl_kws:
            if sheet_classifications is None:
                sheet_classifications = {}
            # Ensure segmented sheets are present in the dict so the
            # summariser doesn't fall back to True for unlisted names.
            if output_path:
                try:
                    with open(_as_extended_path_str(output_path), "r", encoding="utf-8") as _sf:
                        _seg_payload = json.load(_sf)
                    for _sh_entry in _seg_payload.get("sheets", []):
                        _sh_name = _sh_entry.get("sheet_name", "") if isinstance(_sh_entry, dict) else str(_sh_entry)
                        if _sh_name:
                            sheet_classifications.setdefault(_sh_name, True)
                except Exception:
                    pass
            for sname in list(sheet_classifications):
                sname_lower = sname.lower()
                if any(kw in sname_lower for kw in _excl_kws):
                    if sheet_classifications.get(sname, False):
                        tqdm.write(f"  🛑 Sheet excluded by name rule: '{sname}' in {file}")
                    sheet_classifications[sname] = False

        item["sheet_classifications"] = sheet_classifications
        item["context_sheet_summaries"] = context_sheet_summaries

        # -- 1b-post. Inject context_from_other_sheets into _segmented.json ----
        if context_sheet_summaries and output_path:
            try:
                _seg_path = _as_extended_path_str(str(output_path))
                with open(_seg_path, "r", encoding="utf-8") as _sf:
                    _seg_payload = json.load(_sf)
                # Attach context_from_other_sheets at the top level of the
                # segmented payload so downstream consumers (and humans
                # inspecting the file) can see cross-sheet metadata.
                _seg_payload["context_from_other_sheets"] = context_sheet_summaries
                with open(_seg_path, "w", encoding="utf-8") as _sf:
                    json.dump(_seg_payload, _sf, ensure_ascii=False, indent=2)
                tqdm.write(f"    Injected context_from_other_sheets into _segmented.json for {file}")
            except Exception as _inject_exc:
                tqdm.write(
                    f"    [WARN] Could not inject context_from_other_sheets "
                    f"into segmented JSON for {file}: {_inject_exc}"
                )

        record_stage(
            company=company, filename=file, stage="sheet_context_agent",
            time_seconds=sheet_cls_elapsed, input_tokens=sheet_cls_in_tokens,
            output_tokens=sheet_cls_out_tokens, cost=sheet_cls_cost,
        )

        # -- 1c. Summarisation -------------------------------------------------
        totals_summary_path = None
        table_summaries = None  # parsed once in summarisation, reused in extraction
        expected_rows = 0
        summarization_elapsed = 0.0
        if not output_path:
            tqdm.write(f"  [WARN] Skipping summarization (no segmentation output): {file}")
            item["expected_payload_candidate_rows"] = 0
        else:
            sum_start = time.perf_counter()
            totals_summary_path = save_total_detection_summary_to_company_folder(
                output_path, company, out_dir,
                sheet_classifications=item.get("sheet_classifications"),
                context_sheet_summaries=item.get("context_sheet_summaries"),
            )
            summarization_elapsed = time.perf_counter() - sum_start

            item["totals_summary_path"] = totals_summary_path
            item["summarization_elapsed"] = summarization_elapsed

            try:
                with open(_as_extended_path_str(str(totals_summary_path)), "r", encoding="utf-8") as f:
                    table_summaries = json.load(f)
                expected_rows = count_payload_candidate_rows(table_summaries)
            except Exception as exc:
                tqdm.write(f"  [WARN] Could not inspect summarized payload count for {file}: {exc}")

            item["expected_payload_candidate_rows"] = expected_rows
            if expected_rows > 0:
                _ensure_validation_prewarm_started()

            record_stage(
                company=company, filename=file, stage="summarization",
                time_seconds=summarization_elapsed, input_tokens=0,
                output_tokens=0, cost=0.0,
            )
            tqdm.write(
                f"  ✔ Prepared: {file} "
                f"({segmentation_elapsed + sheet_cls_elapsed + summarization_elapsed:.1f}s, "
                f"candidate rows={expected_rows:,})"
            )

        # =====================================================================
        # PHASE 2 - EXTRACT (immediately, no barrier)
        # =====================================================================

        extracted_df = pd.DataFrame()
        extraction_elapsed = 0.0
        extract_start = time.perf_counter()
        try:
            if not totals_summary_path:
                raise ValueError("totals summary path missing")

            if expected_rows <= 0:
                tqdm.write(f"  ➖ Skipping extraction for {company} | {file} (0 payload-candidate rows)")
                record_stage(
                    company=company, filename=file, stage="extraction_skipped_zero_payload",
                    time_seconds=0.0, input_tokens=0, output_tokens=0, cost=0.0,
                )
            else:
                # Reuse table_summaries parsed during summarisation phase
                # instead of re-reading the JSON file (Issue #17 fix).
                if table_summaries is None:
                    summary_path_ext = _as_extended_path_str(str(totals_summary_path))
                    with open(summary_path_ext, "r", encoding="utf-8") as f:
                        table_summaries = json.load(f)

                # -- Token-based sheet routing ---------------------------------
                # Sheets <= SHEET_TOKEN_THRESHOLD tokens use raw
                # _segmented.json data; larger sheets use the summarised
                # _segmented_totals_summary.json data.
                merged_table_summaries = table_summaries  # default: all summarised
                _skip_extraction_all_vetoed = False
                try:
                    seg_path_ext = _as_extended_path_str(str(output_path))
                    with open(seg_path_ext, "r", encoding="utf-8") as _sf:
                        seg_payload = json.load(_sf)
                    sheet_token_counts = count_tokens_per_sheet(seg_payload)

                    # -- Classifier filter (single routing choke point) --------
                    # Token routing must never override the Sheet Context
                    # Agent. Drop every sheet the classifier marked
                    # parse_full_sheet=False (context-only donor sheets,
                    # skipped tabs, name-excluded sheets) BEFORE partitioning
                    # into small/large. Because all three routing branches
                    # derive from this filtered token map, none of them can
                    # leak a vetoed sheet's rows into the raw extraction path.
                    _classifications = item.get("sheet_classifications") or {}
                    if _classifications:
                        _vetoed = [
                            name for name in sheet_token_counts
                            if not _classifications.get(name, True)
                        ]
                        for name in _vetoed:
                            tqdm.write(
                                f"    🚫 Skipped by classifier: {name} "
                                f"({sheet_token_counts[name]:,} tokens)"
                            )
                            record_sheet_source(
                                company, file, name,
                                source_file="(none)",
                                routing_reason="skipped_by_classifier",
                                token_count=sheet_token_counts[name],
                            )
                    sheet_token_counts = {
                        name: tok
                        for name, tok in sheet_token_counts.items()
                        if _classifications.get(name, True)
                    }

                    small_sheets = [
                        name for name, tok in sheet_token_counts.items()
                        if tok <= SHEET_TOKEN_THRESHOLD
                    ]
                    large_sheets = [
                        name for name, tok in sheet_token_counts.items()
                        if tok > SHEET_TOKEN_THRESHOLD
                    ]

                    if not sheet_token_counts:
                        # Classifier vetoed every sheet. Do not fall through
                        # into a routing branch that would emit a misleading
                        # "using summarised data" message and invoke the
                        # extraction graph with an empty payload.
                        _skip_extraction_all_vetoed = True
                        tqdm.write(
                            f"  ➖ Skipping extraction for {company} | {file} - "
                            f"(all sheets vetoed by Sheet Context Agent classifier)"
                        )
                        record_stage(
                            company=company, filename=file,
                            stage="extraction_skipped_all_sheets_vetoed",
                            time_seconds=0.0, input_tokens=0,
                            output_tokens=0, cost=0.0,
                        )
                    elif small_sheets and large_sheets:
                        # Mixed: build raw summaries for small sheets,
                        # keep summarised entries for large sheets.
                        raw_summaries = build_raw_table_summaries_from_segmented(
                            seg_payload,
                            sheet_names=small_sheets,
                            context_sheet_summaries=context_sheet_summaries,
                        )
                        # Keep only large-sheet entries from table_summaries
                        large_set = set(large_sheets)
                        summarised_entries = [
                            ts for ts in table_summaries
                            if ts.get("sheet", "") in large_set
                        ]
                        merged_table_summaries = raw_summaries + summarised_entries
                        tqdm.write(
                            f"  🔀 Token routing for {file}: "
                            f"raw({len(small_sheets)} sheet(s) <= {SHEET_TOKEN_THRESHOLD:,} tok) + "
                            f"summarised({len(large_sheets)} sheet(s) > {SHEET_TOKEN_THRESHOLD:,} tok)"
                        )
                        for name in small_sheets:
                            tqdm.write(f"      🎛 Raw: {name} ({sheet_token_counts[name]:,} tokens)")
                            record_sheet_source(
                                company, file, name,
                                source_file="_segmented.json",
                                routing_reason=f"tokens({sheet_token_counts[name]:,})<=threshold({SHEET_TOKEN_THRESHOLD:,})",
                                token_count=sheet_token_counts[name],
                            )
                        for name in large_sheets:
                            tqdm.write(f"      📄 Summarised: {name} ({sheet_token_counts[name]:,} tokens)")
                            record_sheet_source(
                                company, file, name,
                                source_file="_segmented_totals_summary.json",
                                routing_reason=f"tokens({sheet_token_counts[name]:,})>threshold({SHEET_TOKEN_THRESHOLD:,})",
                                token_count=sheet_token_counts[name],
                            )
                    elif small_sheets:
                        # All surviving sheets are small - use raw data.
                        # Pass the explicit filtered list (never None) so the
                        # raw builder can never fall back to processing every
                        # sheet in the workbook and re-introduce vetoed sheets.
                        raw_summaries = build_raw_table_summaries_from_segmented(
                            seg_payload,
                            sheet_names=small_sheets,
                            context_sheet_summaries=context_sheet_summaries,
                        )
                        merged_table_summaries = raw_summaries
                        tqdm.write(
                            f"  🎛 All sheets <= {SHEET_TOKEN_THRESHOLD:,} tokens for {file} - using raw segmented data"
                        )
                        for name in small_sheets:
                            record_sheet_source(
                                company, file, name,
                                source_file="_segmented.json",
                                routing_reason=f"all_sheets_small;tokens({sheet_token_counts[name]:,})<=threshold({SHEET_TOKEN_THRESHOLD:,})",
                                token_count=sheet_token_counts[name],
                            )
                    else:
                        # All surviving sheets are large - use summarised.
                        # Restrict the summarised payload to surviving sheets
                        # so vetoed sheets present in table_summaries cannot
                        # slip through on this path either.
                        large_set = set(large_sheets)
                        merged_table_summaries = [
                            ts for ts in table_summaries
                            if ts.get("sheet", "") in large_set
                        ]
                        tqdm.write(
                            f"  📄 All sheets > {SHEET_TOKEN_THRESHOLD:,} tokens for {file} - using summarised data"
                        )
                        for name in large_sheets:
                            record_sheet_source(
                                company, file, name,
                                source_file="_segmented_totals_summary.json",
                                routing_reason=f"all_sheets_large;tokens({sheet_token_counts[name]:,})>threshold({SHEET_TOKEN_THRESHOLD:,})",
                                token_count=sheet_token_counts[name],
                            )
                except Exception as _route_exc:
                    tqdm.write(
                        f"  [WARN] Token-based routing failed for {file}, "
                        f"falling back to summarised data: {_route_exc}"
                    )

                if not _skip_extraction_all_vetoed:
                    extracted_df = run_segment_extraction_graph(
                        file_path=file_path,
                        table_summaries=merged_table_summaries,
                        schema_text=sch_text,
                        instructions_text=instr_text,
                        company_name=company,
                        output_data_dir=out_dir,
                        file_label=file,
                    )

                if not extracted_df.empty:
                    if _ACCOUNT_COL not in extracted_df.columns:
                        extracted_df[_ACCOUNT_COL] = company
                    else:
                        s = extracted_df[_ACCOUNT_COL]
                        extracted_df[_ACCOUNT_COL] = (
                            s.where(s.notna() & (s.astype(str).str.strip() != ""), company)
                        )

                    if _FILE_SRC_COL not in extracted_df.columns:
                        extracted_df[_FILE_SRC_COL] = ""
                    fp_series = extracted_df[_FILE_SRC_COL]
                    empty_fp = fp_series.isna() | (fp_series.astype(str).str.strip() == "")
                    if empty_fp.any():
                        extracted_df.loc[empty_fp, _FILE_SRC_COL] = file

                extracted_rows = len(extracted_df)
                if expected_rows and extracted_rows < expected_rows:
                    log_cli(
                        f"  [WARN] Row-count shortfall for {company} | {file}: "
                        f"extracted {extracted_rows:,} rows vs {expected_rows:,} "
                        f"payload-candidate rows (missing {expected_rows - extracted_rows:,})"
                    )
                elif expected_rows and extracted_rows > expected_rows:
                    log_cli(
                        f"  [WARN] Row-count expansion for {company} | {file}: "
                        f"extracted {extracted_rows:,} rows vs {expected_rows:,} "
                        f"payload-candidate rows (extra {extracted_rows - expected_rows:,})"
                    )
                else:
                    log_cli(
                        f"  💚 Row-count check for {company} | {file}: "
                        f"extracted={extracted_rows:,}/{expected_rows:,} payload-candidate rows preserved."
                    )

        except Exception as exc:
            tqdm.write(f"  [ERROR] Agentic extraction failed for {file}: {exc}")
            record_stage(
                company=company, filename=file, stage="extraction_failure",
                time_seconds=0.0, input_tokens=0, output_tokens=0, cost=0.0,
            )
        finally:
            extraction_elapsed = time.perf_counter() - extract_start

        # Release cached temp file for this specific file to avoid temp
        # directory bloat during multi-file runs (Issue #4 fix).
        try:
            evict_converted_file_cache(file_path)
        except Exception:
            pass

        item["extracted_df"] = extracted_df
        item["extraction_elapsed"] = extraction_elapsed

        file_rows = len(extracted_df) if not extracted_df.empty else 0
        file_claims = (
            extracted_df[_LEADING_COL].dropna().nunique()
            if not extracted_df.empty and _LEADING_COL and _LEADING_COL in extracted_df.columns
            else 0
        )

        tqdm.write(
            f"  ✔ [({idx + 1}/{total_jobs})] {company} | {file} - "
            f"{file_rows} rows, {file_claims} unique {_LEADING_COL or 'record'} IDs "
            f"(seg={item.get('segmentation_elapsed', 0.0):.2f}s, "
            f"sum={item.get('summarization_elapsed', 0.0):.2f}s, "
            f"ext={item.get('extraction_elapsed', 0.0):.2f}s)"
        )

        result_dfs = [extracted_df] if not extracted_df.empty else []
        return {"completed_items": [item], "extracted_dfs": result_dfs}

    # -- Fan-out via Send --------------------------------------------------
    result = _run_send_stage_graph(
        state_type=_ExtStageState,
        file_work_items=file_work_items,
        worker_name="_combined_worker",
        worker_fn=_combined_worker,
        invoke_state={
            "output_data_dir": output_data_dir,
            "schema_text": schema_text,
            "instructions_text": instructions_text,
        },
        accumulator_state={"completed_items": [], "extracted_dfs": []},
        dispatch_state_builder=lambda st, item, i: {**st, "_item": item, "_item_idx": i},
    )

    return {
        "file_work_items": result.get("completed_items", file_work_items),
        "agentic_outputs": result.get("extracted_dfs", []),
        "processed_files": len(result.get("completed_items", [])),
        "schema_text": schema_text,
        "instructions_text": instructions_text,
    }


def _route_after_discovery(state: PipelineState) -> str:
    return "continue" if state.get("file_jobs") else "no_files"


def _route_after_relevancy_filter(state: PipelineState) -> str:
    return "continue" if state.get("file_jobs") else "no_relevant_files"


def _mark_no_work(state: PipelineState) -> PipelineState:
    discovered = len(state.get("file_jobs", []))
    skipped = len(state.get("skipped_files", []))
    log_cli(
        "\nNo eligible files to process\n"
        f"(remaining files={discovered}, skipped={skipped}). "
        f"Proceeding to output and metrics."
    )
    return {"agentic_outputs": [], "processed_files": 0, "file_work_items": []}


def _prepare_final_output_df(df: pd.DataFrame) -> pd.DataFrame:
    """Normalize final output columns and apply the canonical schema order."""
    prepared_df = df.copy()

    for col in _OUTPUT_COLUMN_ORDER:
        if col not in prepared_df.columns:
            prepared_df[col] = None

    return prepared_df[_OUTPUT_COLUMN_ORDER]


def _account_stem(account_name: str) -> str:
    """Return a filesystem-friendly account stem while preserving the account name."""
    account_stem = Path(account_name).stem.strip()
    return account_stem or account_name.strip() or "account"


def _build_account_csv_outputs(
    file_work_items: list[dict[str, Any]],
    extraction_data_dir: str,
) -> list[str]:
    """Write one final aggregated output per account under extraction_output."""
    output_paths: list[str] = []
    grouped_frames: dict[str, list[pd.DataFrame]] = {}

    for item in file_work_items:
        company_name = str(item.get("company", "")).strip()
        extracted_df = item.get("extracted_df")

        if not company_name or not isinstance(extracted_df, pd.DataFrame):
            continue
        if extracted_df.empty or extracted_df.dropna(how="all").empty:
            continue

        grouped_frames.setdefault(company_name, []).append(extracted_df)

    # Use pluggable writer + suffix from the active inputs module.
    # Falls back to CSV if the inputs module doesn't provide them.
    file_suffix = call_active_inputs_helper("get_output_file_suffix", default=None)
    writer = call_active_inputs_helper("get_output_writer", default=None)

    # Legacy fallback: use get_output_format / get_output_csv_filename if
    # the inputs module doesn't provide the new pluggable hooks.
    if file_suffix is None:
        file_suffix = f"_{_get_output_csv_filename()}"
    if writer is None:
        output_format = str(
            call_active_inputs_helper("get_output_format", default="csv") or "csv"
        ).strip().lower()
        if output_format == "json":
            def writer(df, path):
                df.to_json(path, orient="records", indent=2, force_ascii=False)
        else:
            def writer(df, path):
                df.to_csv(path, index=False)

    for company_name, frames in grouped_frames.items():
        combined_df = pd.concat(frames, ignore_index=True)
        prepared_df = _prepare_final_output_df(combined_df)
        company_dir = Path(extraction_data_dir) / company_name
        output_path = company_dir / f"{_account_stem(company_name)}{file_suffix}"
        company_dir.mkdir(parents=True, exist_ok=True)

        writer(prepared_df, str(output_path))

        output_paths.append(str(output_path))

    return output_paths


def _build_account_metrics_output_targets(
    extraction_data_dir: str,
    file_work_items: list[dict[str, Any]],
) -> list[tuple[str, str]]:
    """Return one metrics target per account under extraction_output."""
    targets: list[tuple[str, str]] = []
    account_names: list[str] = []

    for item in file_work_items:
        company_name = str(item.get("company", "")).strip()
        if not company_name:
            continue
        if company_name in account_names:
            continue
        account_names.append(company_name)

        account_output_dir = Path(extraction_data_dir) / company_name
        output_path = account_output_dir / f"{_account_stem(company_name)}{_get_metrics_filename_suffix()}_metrics.json"
        targets.append((company_name, str(output_path)))

    return targets


def _combine_and_save_csv(state: PipelineState) -> PipelineState:
    extraction_data_dir = state["extraction_data_dir"]
    file_work_items = state.get("file_work_items", [])
    outputs = [
        item.get("extracted_df")
        for item in file_work_items
        if isinstance(item.get("extracted_df"), pd.DataFrame)
    ]
    valid_outputs = [df for df in outputs if (not df.empty) and (not df.dropna(how="all").empty)]

    if valid_outputs:
        # Concatenate all frames (keep all columns so no canonical field is lost).
        combined_df = pd.concat(valid_outputs, ignore_index=True)
        # -- Final row/claim count summary -----------------------------------
        final_total_rows = len(combined_df)
        final_unique_claims = 0
        if _LEADING_COL and _LEADING_COL in combined_df.columns:
            final_unique_claims = combined_df[_LEADING_COL].dropna().nunique()
        # Per-file breakdown
        _id_label = _LEADING_COL or "record"
        if _FILE_SRC_COL and _FILE_SRC_COL in combined_df.columns:
            log_cli(f"\n🎉 Final output: {final_total_rows} rows, {final_unique_claims} unique {_id_label} IDs")
            log_cli(" Per-source breakdown:")
            for fp, group in combined_df.groupby(_FILE_SRC_COL, dropna=False):
                fp_claims = group[_LEADING_COL].dropna().nunique() if _LEADING_COL and _LEADING_COL in group.columns else 0
                log_cli(f"    {fp}: {len(group)} rows, {fp_claims} unique {_id_label} IDs")
        else:
            log_cli(f"\n🎉 Final output: {final_total_rows} rows, {final_unique_claims} unique {_id_label} IDs")

        # No duplicate filtering here - the agentic path only structures data.

        combined_df = _prepare_final_output_df(combined_df)

        csv_start_time = time.perf_counter()
        csv_output_paths = _build_account_csv_outputs(
            file_work_items=file_work_items,
            extraction_data_dir=extraction_data_dir,
        )
        csv_elapsed_seconds = time.perf_counter() - csv_start_time
        csv_minutes = int(csv_elapsed_seconds // 60)
        csv_seconds = csv_elapsed_seconds % 60

        _fmt_label = (call_active_inputs_helper("get_output_file_suffix", default="_claims.csv") or "_claims.csv").rsplit(".", 1)[-1].upper()
        log_cli(f"\nOutput path(s):")
        for csv_output_path in csv_output_paths:
            log_cli(f"  {csv_output_path}")

        overall_start_time = state.get("overall_start_time")
        if overall_start_time is not None:
            total_elapsed_seconds = time.perf_counter() - overall_start_time
            total_minutes = int(total_elapsed_seconds // 60)
            total_seconds = total_elapsed_seconds % 60
            log_cli(
                f"  {_fmt_label} output generated in: {csv_minutes}m {csv_seconds:.2f}s | "
                f"end-to-end time (file ingestion to output): {total_minutes}m {total_seconds:.2f}s "
                f"across {state.get('processed_files', 0)} file(s) and {len(csv_output_paths)} output file(s)"
            )
    else:
        _fmt_label = (call_active_inputs_helper("get_output_file_suffix", default="_claims.csv") or "_claims.csv").rsplit(".", 1)[-1].upper()
        csv_minutes = 0
        csv_seconds = 0.0
        log_cli(
            f"  {_fmt_label} output generated in: {csv_minutes}m {csv_seconds:.2f}s | "
            f"end-to-end time unavailable (no eligible files found)"
        )

    return {}


def _save_metrics(state: PipelineState) -> PipelineState:
    # Persist pipeline-level step timings into the metrics store
    # so they appear in the output JSON alongside per-stage data.
    step_timings = state.get("step_timings") or {}
    record_pipeline_wall_times(step_timings)

    metrics_output_targets = _build_account_metrics_output_targets(
        extraction_data_dir=state["extraction_data_dir"],
        file_work_items=state.get("file_work_items", []),
    )

    log_cli("Metrics output path(s):")
    for company_name, output_path in metrics_output_targets:
        save_metrics_json(output_path, company_name=company_name)
        log_cli(f"  {output_path}")

    return {}


def build_pipeline_graph():
    """Build the top-level LangGraph pipeline.

    All file-level parallelism is handled by LangGraph Send sub-graphs
    within each processing node. The pipeline graph itself is a
    sequential StateGraph with conditional early-exit edges.

    Topology::

        discover_jobs -> filter_relevant_files
                               ↓
        prepare_and_extract (Send fan-out: segment + classify + summarise + extract per file)
                               ↓
        save_csv -> save_metrics -> END

    The prepare and extract stages are merged into a single fan-out so
    that each file can begin extraction as soon as its own preparation
    finishes, eliminating the serialisation barrier that previously forced
    ALL files to complete preparation before ANY file could start
    extraction.
    """

    graph = StateGraph(PipelineState)
    graph.add_node("discover_jobs",           _timed_node("Discover Jobs",           _discover_excel_jobs))
    graph.add_node("filter_relevant_files",   _timed_node("Relevancy Detection",   _filter_relevant_files))
    graph.add_node("mark_no_work",            _timed_node("No-Work Guard",            _mark_no_work))
    graph.add_node("prepare_and_extract",    _timed_node("Prepare & Extract",    _prepare_and_extract_files))
    graph.add_node("save_csv",                _timed_node("Save CSV",                _combine_and_save_csv))
    graph.add_node("save_metrics",            _timed_node("Save Metrics",            _save_metrics))

    graph.set_entry_point("discover_jobs")
    graph.add_conditional_edges(
        "discover_jobs",
        _route_after_discovery,
        {"continue": "filter_relevant_files", "no_files": "mark_no_work"},
    )
    graph.add_conditional_edges(
        "filter_relevant_files",
        _route_after_relevancy_filter,
        {"continue": "prepare_and_extract", "no_relevant_files": "mark_no_work"},
    )
    graph.add_edge("prepare_and_extract", "save_csv")
    graph.add_edge("mark_no_work", "save_csv")
    graph.add_edge("save_csv", "save_metrics")
    graph.add_edge("save_metrics", END)

    return graph.compile()


def run_agentic_langgraph_pipeline(
    *,
    input_data_dir: str = DEFAULT_INPUT_DATA_DIR,
    output_data_dir: str = DEFAULT_OUTPUT_DATA_DIR,
    extraction_data_dir: str = DEFAULT_EXTRACTION_DATA_DIR,
    company_names: list[str],
    config_module_name: str = "inputs_claims",
) -> dict[str, Any]:
    previous_config_module = get_active_inputs_module_name()
    set_active_inputs_module(config_module_name)

    reset_metrics_store()
    reset_validation_cache()  # ensure no stale validation code from a prior run
    _lazy_init_columns()  # populate column aliases on first use
    initial_state = PipelineState(
        input_data_dir=input_data_dir,
        output_data_dir=output_data_dir,
        extraction_data_dir=extraction_data_dir,
        company_names=company_names,
        relevancy_keywords=_get_runtime_relevancy_keywords(),
        relevancy_instructions=call_active_inputs_helper("get_relevancy_instructions", default=""),
    )

    app = build_pipeline_graph()
    pipeline_start = time.perf_counter()

    # Initialise the sandbox container pool (pre-warms Docker containers)
    # This is a no-op if Docker / llm-sandbox is not available.
    get_sandbox_pool()

    try:
        try:
            final_state = app.invoke(initial_state)
        finally:
            # Always close the sandbox pool to release Docker resources
            close_sandbox_pool()
            # Clean up cached file conversions from this run
            clear_converted_file_cache()
            # Release compiled Send-stage sub-graphs so their closure
            # references don't pin large state dicts in memory (Issue #3 fix).
            _send_stage_graph_cache.clear()

        pipeline_total = time.perf_counter() - pipeline_start

        # Print per-step timing summary
        step_timings = final_state.get("step_timings") or {}
        _print_timing_summary(step_timings)

        # Print overall wall-clock time
        total_m = int(pipeline_total // 60)
        total_s = pipeline_total % 60
        log_cli(
            f"{_BOLD}{_GREEN}🏁 Pipeline finished in "
            f"{total_m}m {total_s:.2f}s (wall-clock){_RESET}\n"
        )

        return final_state
    finally:
        set_active_inputs_module(previous_config_module)


def run_dual_agentic_langgraph_pipeline(
    *,
    input_data_dir: str = DEFAULT_INPUT_DATA_DIR,
    output_data_dir: str = DEFAULT_OUTPUT_DATA_DIR,
    extraction_data_dir: str = DEFAULT_EXTRACTION_DATA_DIR,
    company_names: list[str],
) -> dict[str, dict[str, Any]]:
    """Run claims, no-claims, and exposures extraction passes for the same accounts."""
    run_results: dict[str, dict[str, Any]] = {}
    pipeline_runs = [
        ("claims", "inputs_claims"),
        ("no_claims", "inputs_no_claims"),
        ("exposures", "inputs_exposures"),
    ]

    for run_label, config_module_name in pipeline_runs:
        log_cli(f"\n{'=' * 72}")
        log_cli(f"Starting {run_label.replace('_', ' ')} pipeline using {config_module_name}")
        log_cli(f"{'=' * 72}")
        run_results[run_label] = run_agentic_langgraph_pipeline(
            input_data_dir=input_data_dir,
            output_data_dir=output_data_dir,
            extraction_data_dir=extraction_data_dir,
            company_names=company_names,
            config_module_name=config_module_name,
        )

    return run_results
