import threading

from config_runtime import call_active_inputs_helper


def compute_cost(input_tokens, output_tokens, model_cfg):
    """
    Compute detection cost in dollars using model's per 1M token prices.
    """
    input_millions = input_tokens / 1_000_000.0
    output_millions = output_tokens / 1_000_000.0
    return (
        input_millions * model_cfg["input_costs"]
        + output_millions * model_cfg["output_costs"]
    )


# LibertyAIR Models
GPT_4_1 = {
    "model_name": "gpt-4.1-2025-04-14-us-data-zone",
    "api_version": "2024-10-21",
    "input_costs": 2.20,  # cost per 1M input tokens
    "output_costs": 8.80, # cost per 1M output tokens
}

GPT_4_1_MINI = {
    "model_name": "gpt-4.1-mini-2025-04-14-us-data-zone",
    "api_version": "2024-10-21",
    "input_costs": 0.44,  # cost per 1M input tokens
    "output_costs": 1.76, # cost per 1M output tokens
}

GPT_5 = {
    "model_name": "gpt-5-2025-08-07-us-data-zone",
    "api_version": "2024-12-01-preview",
    "input_costs": 1.38,  # cost per 1M input tokens
    "output_costs": 11.00, # cost per 1M output tokens
}

GPT_5_MINI = {
    "model_name": "gpt-5-mini-2025-08-07-us-data-zone",
    "api_version": "2024-12-01-preview",
    "input_costs": 0.28,  # cost per 1M input tokens
    "output_costs": 2.20,  # cost per 1M output tokens
}

GPT_5_1 = {
    "model_name": "gpt-5.1-2025-11-13-us-data-zone",
    "api_version": "2024-10-21",
    "input_costs": 1.38,  # cost per 1M input tokens
    "output_costs": 11.00, # cost per 1M output tokens
}

GPT_5_2 = {
    "model_name": "gpt-5.2-2025-12-11-us-data-zone",
    "api_version": "2024-10-21",
    "input_costs": 1.925,  # cost per 1M input tokens
    "output_costs": 15.40,  # cost per 1M output tokens
}

GPT_5_4 = {
    "model_name": "gpt-5.4-2026-03-05-us-data-zone",
    "api_version": "2024-10-21",
    "input_costs": 2.5,  # cost per 1M input tokens
    "output_costs": 15,  # cost per 1M output tokens
}

# — Model registry - maps configured model keys to config dicts ———
_MODEL_REGISTRY = {
    "GPT_4_1":      GPT_4_1,
    "GPT_4_1_MINI": GPT_4_1_MINI,
    "GPT_5":        GPT_5,
    "GPT_5_MINI":   GPT_5_MINI,
    "GPT_5_1":      GPT_5_1,
    "GPT_5_2":      GPT_5_2,
    "GPT_5_4":      GPT_5_4,
}

# Default model when the configured key is blank or invalid
_DEFAULT_MODEL_KEY = "GPT_5_2"


def get_model_by_key(key: str) -> dict:
    """Return a model config dict by registry key.

    Falls back to `get_active_model()` when *key* is not recognised.
    """
    normalised = (key or "").strip().upper()
    if normalised in _MODEL_REGISTRY:
        return _MODEL_REGISTRY[normalised]
    return get_active_model()


def get_utility_model() -> dict:
    """Return the model config for lightweight utility tasks.

    Used for relevancy detection, sheet classification, and validation
    code generation - tasks that don't require the full extraction model.
    Controlled by `UTILITY_MODEL` in `inputs.py`.
    """
    utility_key = call_active_inputs_helper("get_utility_model_key", default=_DEFAULT_MODEL_KEY)
    return get_model_by_key(utility_key)


_active_model_printed: bool = False
_cached_active_model = None  # type: dict | None
_cached_model_key = None    # type: str | None
_model_lock = threading.Lock()


def get_active_model() -> dict:
    """Return the model config dict selected by the AGENTIC_MODEL setting.

    Set `AGENTIC_MODEL` in `inputs.py` to one of:
        GPT_4_1, GPT_4_1_MINI, GPT_5, GPT_5_MINI, GPT_5_1, GPT_5_2, GPT_5_4

    Falls back to GPT_5 when the configured value is blank or unrecognised.

    The result is cached keyed by the resolved model key. If `AGENTIC_MODEL`
    is changed at runtime (e.g. between pipeline runs in an interactive
    session), the cache is automatically invalidated.
    """
    global _active_model_printed, _cached_active_model, _cached_model_key
    key = call_active_inputs_helper("get_agentic_model_key", default=_DEFAULT_MODEL_KEY) or _DEFAULT_MODEL_KEY
    with _model_lock:
        if _cached_active_model is not None and _cached_model_key == key:
            return _cached_active_model
        if key not in _MODEL_REGISTRY:
            print(
                f"[WARN] AGENTIC_MODEL='{key}' is not recognised. "
                f"Valid options: {', '.join(_MODEL_REGISTRY.keys())}. "
                f"Falling back to {_DEFAULT_MODEL_KEY}."
            )
            key = _DEFAULT_MODEL_KEY
        selected = _MODEL_REGISTRY[key]
        _cached_active_model = selected
        _cached_model_key = key
        if not _active_model_printed:
            print(f"🤖 Active LLM model: {key} ({selected['model_name']})")
            _active_model_printed = True
        return selected
