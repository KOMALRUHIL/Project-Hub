"""Post-processing for exposure extraction - JSON bucketing, normalization & dedup.

This module contains all exposure-specific post-processing logic that runs
AFTER the shared core extraction pipeline produces a flat DataFrame. It is
only imported when the pipeline operates in exposure mode (output_format="json").

Responsibilities:
- Convert flat DataFrame -> nested JSON by exposure type bucket
- Reclassify records missing key fields (auto without VIN -> other, etc.)
- Normalize policy_year, VIN, model_name
- Aggregate WC entity-level rows within the same document
- Cross-file deduplication (basic, classified, safety-net)
- Remove empty exposures

This code previously lived inline in pipeline.py. Moving it here ensures
the core pipeline has zero exposure-specific imports or logic.
"""

from __future__ import annotations

import json
import re
from collections import defaultdict
from typing import Any, Dict, List, Tuple

import pandas as pd

from inputs_exposures import get_account_name_column, get_file_source_column


# ==============================================================================
# Cross-file deduplication & merge for exposure records
# ==============================================================================
#
# Implements the full deduplication strategy from DEDUP_MERGE_STRATEGY.md:
#
# Step 1 - dedup_buckets            : Basic per-bucket key-based dedup
# Step 4 - dedup_classified         : Main dedup with SELECT BEST / MERGE
# Step 5b - final_safety_dedup      : Safety-net dedup on final output
# Step 6 - filter_empty_exposures   : Remove exposures with all key fields empty
#
# Strategies per exposure category
# --------------------------------
# Auto      : Key=VIN; collision=SELECT BEST (most complete data)
# GL        : Key=(class_code, location_key, exposure_value); collision=SELECT BEST
# WC        : Key=(class_code, location_key, payroll, policy_year); collision=SELECT BEST
# Property  : Key=address; collision=MERGE (SUM BI+contents, MAX building)
# Other     : Key=(type, description[:60]); collision=SELECT BEST
#

# --- dedup helpers ---

def _norm_str(record: Dict[str, Any], key: str) -> str | None:
    """Return lowercased / stripped string, or `None` if absent / blank."""
    v = record.get(key)
    if v is None:
        return None
    v = str(v).strip().lower()
    return v if v else None


def _norm_num(record: Dict[str, Any], key: str):
    """Return numeric value rounded to 2 dp, or `None` if absent."""
    v = record.get(key)
    if v is None:
        return None
    try:
        return round(float(v), 2)
    except (ValueError, TypeError):
        return None


def _to_numeric(val: Any) -> int | float:
    """Convert val to a number, returning 0 for None / unconvertible."""
    if val is None:
        return 0
    if isinstance(val, (int, float)):
        return val
    if isinstance(val, str):
        cleaned = val.replace(",", "").replace("$", "").replace("%", "").strip()
        if not cleaned:
            return 0
        try:
            return int(cleaned) if "." not in cleaned else float(cleaned)
        except ValueError:
            return 0
    try:
        return float(val)
    except (ValueError, TypeError):
        return 0


def _safe_numeric_add(val1: Any, val2: Any) -> int | float:
    """Safely add two values that may be int, float, str, or None."""
    return _to_numeric(val1) + _to_numeric(val2)


# Extract 4-digit calendar years (19xx/20xx) to normalise policy_year
_YEAR_4D_RE = re.compile(r"\b(?:19|20)\d{2}\b")
# Fallback: 2-digit shorthand like "25-26" or "18-19"
_YEAR_2D_RE = re.compile(r"\b(\d{2})\s*[-\u2013]\s*(\d{2})\b")


def normalize_policy_year(raw: str | None) -> str | None:
    """Normalise policy_year to `YYYY-YYYY` format.

    Handles full-date ranges, typos, 2-digit shorthand, and already-normalised values.

    Examples
    --------
    >>> normalize_policy_year("10/1/2024-10/1/2025")
    '2024-2025'
    >>> normalize_policy_year("10/1/2019-101/2020")
    '2019-2020'
    >>> normalize_policy_year("2024-2025")
    '2024-2025'
    >>> normalize_policy_year("25-26")
    '2025-2026'
    >>> normalize_policy_year(None)
    """
    if raw is None:
        return None
    raw = str(raw).strip()
    if not raw:
        return None
    # Try 4-digit years first
    years = _YEAR_4D_RE.findall(raw)
    if len(years) >= 2:
        return f"{years[0]}-{years[1]}"
    # Fallback: 2-digit shorthand (e.g. "25-26")
    m = _YEAR_2D_RE.search(raw)
    if m:
        y1, y2 = int(m.group(1)), int(m.group(2))
        c1 = 2000 if y1 < 80 else 1900
        c2 = 2000 if y2 < 80 else 1900
        return f"{c1 + y1}-{c2 + y2}"
    return raw


# --- VIN / model normalization ------------------------------------------------


# Standard VIN character replacement: letter O -> digit 0, letter I -> digit 1,
# letter Q -> digit 0. These are commonly confused in OCR / manual entry and
# are not valid characters in ISO 3779 VINs.
_VIN_CHAR_MAP = str.maketrans("OIQ", "010")


def normalize_vin(raw: str | None) -> str | None:
    """Normalise a VIN: uppercase, strip whitespace/dashes, fix O->0 / I->1 / Q->0."""
    if raw is None:
        return None
    v = str(raw).strip().upper().replace("-", "").replace(" ", "")
    if not v:
        return None
    return v.translate(_VIN_CHAR_MAP)


def normalize_model_name(raw: str | None) -> str | None:
    """Normalise a vehicle model name for consistent comparison.

    * Uppercase
    * Strip leading/trailing whitespace
    * Collapse internal whitespace runs
    * Remove dashes between alphanumeric tokens (F-150 -> F150)
    """
    if raw is None:
        return None
    v = str(raw).strip().upper()
    if not v:
        return None
    # Remove dashes that sit between alphanumeric chars (F-150 -> F150)
    v = re.sub(r"(?<=[A-Z0-9])-(?=[A-Z0-9])", "", v)
    # Collapse whitespace
    v = re.sub(r"\s+", " ", v)
    return v


# --- location key builder -----------------------------------------------------

def _build_location_key(record: Dict[str, Any]) -> str:
    """Build a composite location key with priority: address > state > loc_num > ""."""
    # Used for WC and GL dedup to group exposures at the same location.
    address = (record.get("address") or "").strip()
    if address:
        return f"addr:{address[:60].lower()}"
    state = (record.get("state") or "").strip().upper()
    if state:
        return f"state:{state}"
    loc_num = str(record.get("location_number") or "").strip()
    if loc_num:
        return f"loc:{loc_num}"
    return ""


# --- SELECT BEST logic --------------------------------------------------------

# Priority and secondary fields for each exposure type, used by "select best".
_SELECT_BEST_FIELDS: Dict[str, Tuple[List[str], List[str]]] = {
    "auto": (
        ["year", "make", "model_name"],
        ["gvwr", "use", "garaging_location", "class_code", "category"],
    ),
    "wc": (
        ["description", "employees"],
        ["address", "location_number", "context", "reasoning"],
    ),
    "gl": (
        ["description", "exposure_basis"],
        ["address", "location_number", "context", "reasoning"],
    ),
    "other": (
        ["exposure_value", "exposure_basis"],
        ["address", "location_number", "context", "reasoning"],
    ),
}


def _count_non_null(record: Dict[str, Any], fields: List[str]) -> int:
    """Count how many *fields* have a non-empty value in *record*."""
    count = 0
    for f in fields:
        v = record.get(f)
        if v is not None and str(v).strip():
            count += 1
    return count


def _select_best(existing: Dict[str, Any], candidate: Dict[str, Any], bucket: str) -> Dict[str, Any]:
    """Return whichever exposure has the most complete data.

    Compares priority fields first; on tie, compares secondary fields.
    On full tie, keeps existing.
    """
    priority_fields, secondary_fields = _SELECT_BEST_FIELDS.get(
        bucket, ([], [])
    )
    ex_pri = _count_non_null(existing, priority_fields)
    ca_pri = _count_non_null(candidate, priority_fields)
    if ca_pri > ex_pri:
        return candidate
    if ca_pri < ex_pri:
        return existing

    # Tie on priority - check secondary
    ex_sec = _count_non_null(existing, secondary_fields)
    ca_sec = _count_non_null(candidate, secondary_fields)
    return candidate if ca_sec > ex_sec else existing


# -- Step 1: per-type key builders (basic first-pass dedup) --------------------

def _key_auto(r: Dict[str, Any]) -> tuple | None:
    vin = _norm_str(r, "vin")
    if vin is None or len(vin) < 10:
        return None
    return ("auto", vin)


def _key_gl(r: Dict[str, Any]) -> tuple | None:
    cc = _norm_str(r, "class_code")
    state = _norm_str(r, "state")
    val = _norm_num(r, "exposure_value")
    if cc is None or state is None or val is None:
        return None
    return ("gl", cc, state, val)


def _key_wc(r: Dict[str, Any]) -> tuple | None:
    cc = _norm_str(r, "class_code")
    state = _norm_str(r, "state")
    val = _norm_num(r, "exposure_value")
    if cc is None or state is None or val is None:
        return None
    return ("wc", cc, state, val)


def _key_property(r: Dict[str, Any]) -> tuple | None:
    loc = _norm_str(r, "location_number")
    addr = _norm_str(r, "address")
    bv = _norm_num(r, "building_value")
    if loc is None and addr is None:
        return None

    # Include building_value so only exact duplicates drop at Step 1;
    # different values at the same address survive for Step 4 MERGE.
    return ("property", loc, addr, bv)


def _key_other(r: Dict[str, Any]) -> tuple | None:
    desc = _norm_str(r, "description")
    val = _norm_num(r, "exposure_value")
    if desc is None or val is None:
        return None
    return ("other", desc, val)


_KEY_BUILDERS = {
    "auto": _key_auto,
    "gl": _key_gl,
    "wc": _key_wc,
    "property": _key_property,
    "other": _key_other,
}


# ==============================================================================
# Step 1: dedup_buckets - basic first-pass dedup (first occurrence wins)
# ==============================================================================

def dedup_buckets(
    buckets: Dict[str, List[Dict[str, Any]]],
) -> Tuple[Dict[str, List[Dict[str, Any]]], Dict[str, int]]:
    """Deduplicate each bucket and return (deduped_buckets, stats).

    Basic first-pass: if any key component is missing the record is kept
    without dedup. First occurrence wins when a duplicate key is seen.
    """
    deduped: Dict[str, List[Dict[str, Any]]] = {}
    stats: Dict[str, int] = {}

    for bucket_name, records in buckets.items():
        key_fn = _KEY_BUILDERS.get(bucket_name)
        if key_fn is None:
            deduped[bucket_name] = records
            continue

        seen: set = set()
        kept: List[Dict[str, Any]] = []
        dropped = 0

        for rec in records:
            key = key_fn(rec)
            if key is not None and key in seen:
                dropped += 1
                continue
            if key is not None:
                seen.add(key)
            kept.append(rec)

        deduped[bucket_name] = kept
        if dropped:
            stats[bucket_name] = dropped

    return deduped, stats


# ==============================================================================
# Step 4: dedup_classified - main dedup with SELECT BEST / MERGE
# ==============================================================================

def _dedup_auto(items: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], int]:
    """Deduplicate auto/vehicle records. Key=VIN, collision=SELECT BEST."""
    seen: Dict[tuple, int] = {}
    unique: List[Dict[str, Any]] = []
    dropped = 0

    for item in items:
        if not isinstance(item, dict):
            continue
        vin = (item.get("vin") or "").strip().upper()
        if not vin or len(vin) < 10:
            # No usable VIN - fallback key on (year, make, model)
            year = str(item.get("year") or "").strip()
            make = (item.get("make") or "").strip().upper()
            model = (item.get("model_name") or item.get("model") or "").strip().upper()
            if year or make or model:
                key = ("auto_no_vin", year, make, model)
                if key in seen:
                    idx = seen[key]
                    unique[idx] = _select_best(unique[idx], item, "auto")
                    dropped += 1
                    continue
                seen[key] = len(unique)
                unique.append(item)
            continue

        key = ("auto", vin)
        if key in seen:
            idx = seen[key]
            unique[idx] = _select_best(unique[idx], item, "auto")
            dropped += 1
            continue
        seen[key] = len(unique)
        unique.append(item)

    return unique, dropped


def _dedup_wc(items: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], int]:
    """Deduplicate WC records.

    Key = (class_code, location_key, payroll, policy_year).
    Payroll in key means different payrolls -> different entries.
    Collision -> SELECT BEST (no merge).
    """
    seen: Dict[tuple, int] = {}
    unique: List[Dict[str, Any]] = []
    dropped = 0

    for item in items:
        if not isinstance(item, dict):
            continue
        cc = str(item.get("class_code") or "").strip()
        if not cc:
            unique.append(item)
            continue

        location_key = _build_location_key(item)
        payroll_val = item.get("payroll")
        payroll_key = round(float(payroll_val), 2) if payroll_val is not None else None
        policy_year = str(item.get("policy_year") or "").strip()

        key = ("wc", cc, location_key, payroll_key, policy_year)

        if key in seen:
            idx = seen[key]
            unique[idx] = _select_best(unique[idx], item, "wc")
            dropped += 1
            continue
        seen[key] = len(unique)
        unique.append(item)

    return unique, dropped


def _dedup_gl(items: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], int]:
    """Deduplicate GL records.

    Key = (class_code, location_key, exposure_value).
    Exposure_value in key means different amounts -> different entries.
    Collision -> SELECT BEST (no merge).
    Only keeps numeric 3-5 digit class codes.
    """
    seen: Dict[tuple, int] = {}
    unique: List[Dict[str, Any]] = []
    dropped = 0
    filtered_non_numeric = 0

    for item in items:
        if not isinstance(item, dict):
            continue
        cc = str(item.get("class_code") or "").strip()
        # Filter non-numeric class codes (loss-run artefacts)
        if cc and not re.match(r"^\d{3,5}$", cc):
            filtered_non_numeric += 1
            continue
        if not cc:
            unique.append(item)
            continue

        location_key = _build_location_key(item)
        exp_val = _norm_num(item, "exposure_value")
        key = ("gl", cc, location_key, exp_val)

        if key in seen:
            idx = seen[key]
            unique[idx] = _select_best(unique[idx], item, "gl")
            dropped += 1
            continue
        seen[key] = len(unique)
        unique.append(item)

    if filtered_non_numeric:
        print(f"[dedup-gl] Filtered {filtered_non_numeric} non-numeric class codes")
    return unique, dropped


def _dedup_property(items: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], int]:
    """Deduplicate property records.

    Key = normalised address.
    Collision -> MERGE: SUM(business_income_value, contents_value), MAX(building_value).
    Properties without address are kept without dedup.
    """
    seen: Dict[tuple, int] = {}
    unique: List[Dict[str, Any]] = []
    merged = 0

    for item in items:
        if not isinstance(item, dict):
            continue
        addr = (item.get("address") or "").strip().lower()
        if not addr:
            unique.append(item)
            continue

        key = ("property", addr)

        if key in seen:
            idx = seen[key]
            existing = unique[idx]
            # SUM for business_income_value and contents_value
            for sum_field in ("business_income_value", "contents_value"):
                new_val = item.get(sum_field)
                if new_val is not None:
                    ex_val = existing.get(sum_field)
                    existing[sum_field] = (
                        new_val if ex_val is None
                        else _safe_numeric_add(ex_val, new_val)
                    )
            # MAX for building_value
            new_bv = item.get("building_value")
            if new_bv is not None:
                ex_bv = existing.get("building_value")
                if ex_bv is None:
                    existing["building_value"] = new_bv
                else:
                    try:
                        existing["building_value"] = max(
                            float(ex_bv), float(new_bv)
                        )
                    except (TypeError, ValueError):
                        existing["building_value"] = _safe_numeric_add(ex_bv, new_bv)
            # Carry over non-null fields the existing entry may lack
            for carry_field in ("location_number", "doc", "sheet"):
                if not existing.get(carry_field) and item.get(carry_field):
                    existing[carry_field] = item[carry_field]

            merged += 1
            continue

        seen[key] = len(unique)
        unique.append(item)

    return unique, merged


def _dedup_other(items: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], int]:
    """Deduplicate 'other' records.

    Key = (type, description[:60]).
    Collision -> SELECT BEST.
    """
    seen: Dict[tuple, int] = {}
    unique: List[Dict[str, Any]] = []
    dropped = 0

    for item in items:
        if not isinstance(item, dict):
            continue
        item_type = (item.get("type") or "other").strip().lower()
        desc = (item.get("description") or "")[:60].strip().lower()
        if not desc:
            unique.append(item)
            continue

        key = ("other", item_type, desc)

        if key in seen:
            idx = seen[key]
            unique[idx] = _select_best(unique[idx], item, "other")
            dropped += 1
            continue

        seen[key] = len(unique)
        unique.append(item)

    return unique, dropped


_CLASSIFIED_DEDUP_FNS = {
    "auto": _dedup_auto,
    "wc": _dedup_wc,
    "gl": _dedup_gl,
    "property": _dedup_property,
    "other": _dedup_other,
}


def dedup_classified(
    buckets: Dict[str, List[Dict[str, Any]]],
) -> Tuple[Dict[str, List[Dict[str, Any]]], Dict[str, int]]:
    """Main dedup pass (Step 4) with SELECT BEST / MERGE logic per type.

    Returns
    -------
    deduped_buckets : same structure after advanced dedup
    stats : mapping of bucket -> number of duplicates resolved
    """
    deduped: Dict[str, List[Dict[str, Any]]] = {}
    stats: Dict[str, int] = {}

    for bucket_name, records in buckets.items():
        dedup_fn = _CLASSIFIED_DEDUP_FNS.get(bucket_name)
        if dedup_fn is None:
            deduped[bucket_name] = records
            continue
        result, count = dedup_fn(records)
        deduped[bucket_name] = result
        if count:
            stats[bucket_name] = count

    return deduped, stats


# ==============================================================================
# Step 5b: final_safety_dedup - safety-net dedup on final output
# ==============================================================================

def _safety_dedup_auto(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Safety dedup for vehicles - same SELECT BEST on VIN."""
    result, _ = _dedup_auto(items)
    return result


def _safety_dedup_wc(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Safety dedup for WC - same SELECT BEST key."""
    result, _ = _dedup_wc(items)
    return result


def _safety_dedup_gl(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Safety dedup for GL - same SELECT BEST key."""
    result, _ = _dedup_gl(items)
    return result


def _safety_dedup_property(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Safety dedup for property - DROP + keep highest building_value.

    Unlike the main dedup (which MERGEs), the safety net just keeps the
    property with the highest building_value (no SUM).
    """
    seen: Dict[str, int] = {}
    unique: List[Dict[str, Any]] = []

    for item in items:
        if not isinstance(item, dict):
            continue
        addr = (item.get("address") or "").strip().lower()
        if not addr:
            unique.append(item)
            continue

        if addr in seen:
            idx = seen[addr]
            existing_bv = _to_numeric(unique[idx].get("building_value"))
            new_bv = _to_numeric(item.get("building_value"))
            if new_bv > existing_bv:
                unique[idx] = item
            continue
        seen[addr] = len(unique)
        unique.append(item)

    return unique


def _safety_dedup_other(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Safety dedup for other - same SELECT BEST key."""
    result, _ = _dedup_other(items)
    return result


_SAFETY_DEDUP_FNS = {
    "auto": _safety_dedup_auto,
    "wc": _safety_dedup_wc,
    "gl": _safety_dedup_gl,
    "property": _safety_dedup_property,
    "other": _safety_dedup_other,
}


def final_safety_dedup(
    buckets: Dict[str, List[Dict[str, Any]]],
) -> Tuple[Dict[str, List[Dict[str, Any]]], Dict[str, int]]:
    """Safety-net dedup (Step 5b) that catches any duplicates that slipped through Step 4.

    Returns
    -------
    deduped_buckets, stats
    """
    deduped: Dict[str, List[Dict[str, Any]]] = {}
    stats: Dict[str, int] = {}

    for bucket_name, records in buckets.items():
        fn = _SAFETY_DEDUP_FNS.get(bucket_name)
        if fn is None:
            deduped[bucket_name] = records
            continue
        before = len(records)
        result = fn(records)
        after = len(result)
        deduped[bucket_name] = result
        diff = before - after
        if diff:
            stats[bucket_name] = diff

    return deduped, stats


# ==============================================================================
# Step 6: filter_empty_exposures - remove records with all key fields empty
# ==============================================================================

_EMPTY_CHECK_FIELDS: Dict[str, List[str]] = {
    "auto": ["vin", "year", "make", "model_name"],
    "wc": ["class_code", "description", "payroll", "employees", "state"],
    "gl": ["class_code", "description", "exposure_basis", "exposure_value", "sic"],
    "property": ["building_value", "contents_value", "business_income_value", "address", "location_number"],
    "other": ["description", "exposure_basis", "exposure_value", "class_code"],
}


def _is_empty_record(record: Dict[str, Any], fields: List[str]) -> bool:
    """True when ALL *fields* are absent / blank / None in *record*."""
    for f in fields:
        v = record.get(f)
        if v is not None and str(v).strip():
            return False
    return True


def filter_empty_exposures(
    buckets: Dict[str, List[Dict[str, Any]]],
) -> Tuple[Dict[str, List[Dict[str, Any]]], Dict[str, int]]:
    """Remove exposures where all key fields are null/empty (Step 6).

    Returns
    -------
    filtered_buckets, stats (bucket -> count removed)
    """
    filtered: Dict[str, List[Dict[str, Any]]] = {}
    stats: Dict[str, int] = {}

    for bucket_name, records in buckets.items():
        check_fields = _EMPTY_CHECK_FIELDS.get(bucket_name)
        if check_fields is None:
            filtered[bucket_name] = records
            continue

        kept: List[Dict[str, Any]] = []
        removed = 0
        for rec in records:
            if _is_empty_record(rec, check_fields):
                removed += 1
            else:
                kept.append(rec)

        filtered[bucket_name] = kept
        if removed:
            stats[bucket_name] = removed

    return filtered, stats


def _aggregate_wc_records(buckets: Dict[str, list]) -> None:
    """Aggregate WC entity-level rows into one per (doc, state, class_code, policy_year).

    Multi-entity companies often have separate payroll rows for each subsidiary
    within the same state + class code in a single document. This sums their
    exposure_value **within each source document** so the output produces one
    row per (doc, state, class_code) combination. Cross-document dedup is then
    handled by `dedup_buckets` (which keys on state + class_code only).
    Modifies *buckets* in place.
    """
    wc_records = buckets.get("wc", [])
    if not wc_records:
        return

    # Group by (source_doc, state, class_code, policy_year)
    groups: Dict[tuple, List[dict]] = defaultdict(list)
    ungrouped: List[dict] = []

    for rec in wc_records:
        state = rec.get("state")
        cc = rec.get("class_code")
        if state and cc:
            doc = rec.get("doc", "") or ""
            py = rec.get("policy_year", "") or ""
            groups[(doc.strip(), str(state).strip(), str(cc).strip(), str(py).strip())].append(rec)
        else:
            ungrouped.append(rec)

    aggregated: List[dict] = []
    merged_count = 0
    for _key, recs in groups.items():
        if len(recs) == 1:
            aggregated.append(recs[0])
            continue

        # Take the first record as the base and sum exposure_value
        base = dict(recs[0])
        total = 0.0
        has_value = False
        for r in recs:
            v = r.get("exposure_value")
            if v is not None:
                try:
                    total += float(v)
                    has_value = True
                except (ValueError, TypeError):
                    pass
        if has_value:
            base["exposure_value"] = total
        aggregated.append(base)
        merged_count += len(recs) - 1

    if merged_count:
        print(f"[wc-agg] Merged {merged_count} entity-level WC rows "
              f"({len(wc_records)} -> {len(aggregated) + len(ungrouped)})")

    buckets["wc"] = aggregated + ungrouped


def write_exposure_json(df: pd.DataFrame, output_path: str) -> None:
    """Convert a flat DataFrame of exposure rows into nested JSON by type bucket.

    Produces the same structure as the triage pipeline's exposures_raw.json::

        {"exposures": {"gl": [...], "wc": [...], "auto": [...], "property": [...], "other": [...]}}

    Each item is a dict with only the non-null fields for that row, excluding
    the pipeline metadata columns (AccountName, file_path).
    """
    account_col = get_account_name_column()
    file_src_col = get_file_source_column()

    buckets: Dict[str, list] = {"gl": [], "wc": [], "auto": [], "property": [], "other": []}
    meta_cols = {account_col, file_src_col}

    for _, row in df.iterrows():
        bucket = str(row.get("type") or "other").strip().lower()
        if bucket not in buckets:
            bucket = "other"

        # Post-extraction guard: reclassify "auto" records that lack a VIN -
        # these are likely driver schedules or aggregate summaries, not
        # individual vehicles. Year/make/model may legitimately be null.
        if bucket == "auto":
            vin_val = row.get("vin")
            if not (pd.notna(vin_val) and str(vin_val).strip()):
                bucket = "other"

        # Post-extraction guard: reclassify "gl" records that lack a class
        # code - these are typically revenue/sales summaries by subsidiary
        # or entity, not rated GL classification schedules.
        if bucket == "gl":
            cc_val = row.get("class_code")
            if not (pd.notna(cc_val) and str(cc_val).strip()):
                bucket = "other"

        record: Dict[str, Any] = {}
        for col, val in row.items():
            if col in meta_cols:
                continue
            if pd.isna(val):
                continue
            # Coerce numpy/pandas numeric types to native Python for clean JSON
            if hasattr(val, "item"):
                val = val.item()
            # Ensure float-encoded integers (e.g. page=1.0) become int
            if isinstance(val, float) and val == int(val):
                val = int(val)
            record[col] = val
        # Ensure the type field matches the (possibly reclassified) bucket
        record["type"] = bucket
        buckets[bucket].append(record)

    # Normalise policy_year to YYYY-YYYY across all buckets
    for bucket_records in buckets.values():
        for rec in bucket_records:
            if "policy_year" in rec:
                rec["policy_year"] = normalize_policy_year(rec["policy_year"]) or rec["policy_year"]

    # Normalise VIN and model_name for auto records
    for rec in buckets.get("auto", []):
        if "vin" in rec:
            rec["vin"] = normalize_vin(rec["vin"]) or rec["vin"]
        if "model_name" in rec:
            rec["model_name"] = normalize_model_name(rec["model_name"]) or rec["model_name"]

    # Aggregate WC entity-level rows: sum exposure_value for the same
    # (state, class_code, policy_year) so multi-entity payroll breakdowns
    # collapse into one row per rated combination.
    _aggregate_wc_records(buckets)

    # Step 1: Cross-file basic deduplication per exposure type
    buckets, dedup_stats = dedup_buckets(buckets)
    if dedup_stats:
        parts = ", ".join(f"{k}: {v}" for k, v in sorted(dedup_stats.items()))
        print(f"[dedup] Step 1 - basic dedup: {parts}")

    # Step 4: Main dedup - SELECT BEST for auto/WC/GL, MERGE for property
    buckets, classified_stats = dedup_classified(buckets)
    if classified_stats:
        parts = ", ".join(f"{k}: {v}" for k, v in sorted(classified_stats.items()))
        print(f"[dedup] Step 4 - classified dedup: {parts}")

    # Step 5b: Safety-net dedup (catches any stragglers)
    buckets, safety_stats = final_safety_dedup(buckets)
    if safety_stats:
        parts = ", ".join(f"{k}: {v}" for k, v in sorted(safety_stats.items()))
        print(f"[dedup] Step 5b - safety dedup: {parts}")

    # Step 6: Remove exposures with all key fields empty
    buckets, empty_stats = filter_empty_exposures(buckets)
    if empty_stats:
        parts = ", ".join(f"{k}: {v}" for k, v in sorted(empty_stats.items()))
        print(f"[dedup] Step 6 - empty removal: {parts}")

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump({"exposures": buckets}, f, ensure_ascii=False, indent=2, default=str)
