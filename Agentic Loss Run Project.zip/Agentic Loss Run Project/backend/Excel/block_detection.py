from __future__ import annotations
import logging
import os
import re
import shutil
import tempfile
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple
from uuid import uuid4

import pandas as pd
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter, column_index_from_string
from openpyxl.worksheet.worksheet import Worksheet

from utils import as_extended_path as _as_extended_path
from utils import read_csv_with_detected_delimiter

logger = logging.getLogger(__name__)


_LONG_PATH_THRESHOLD = 240
_SHORT_TEMP_STEM_MAX_LEN = 48
_HEADER_MIN_CELLS_FLOOR = 3
_HEADER_MIN_CELLS_CAP = 8
_HEADER_FILL_RATIO_WIDE = 0.15
_HEADER_FILL_RATIO_NARROW = 0.4
_MIN_DATA_ROWS_AFTER_HEADER = 1
_MIN_DATA_CELLS_PER_ROW = 2
_HEADER_SHORT_LABEL_MAX_LEN = 30
_HEADER_LONG_LABEL_MAX_LEN = 120
_HEADER_TOP_SCAN_ROWS = 5
_HEADER_LOOKBACK_ROWS = 200
_HEADER_PROMOTION_SCORE_DELTA = 2.0
_ROW_REPEAT_RATIO_REJECT = 0.85
_ROW_REPEAT_RATIO_DATA_REJECT = 0.9
_HEADER_UNIQUE_RATIO_MIN = 0.5
_HEADER_TEXT_MAX_LEN_FOR_DETECTION = 60
_CATEGORY_SUPER_HEADER_FILL_RATE = 0.4
_DATA_FILL_RATIO_RELAXED = 0.5
_HEADER_SCORE_FILL_CAP = 10.0  # Cap for normalised non empty contribution

_chunkable_copy_cache: Dict[str, Tuple[Path, List[Path]]] = {}
_chunkable_copy_cache_lock = threading.Lock()


# --- XLS shim -------------------------------------------------------------
# Converts legacy / non-openpyxl formats to .xlsx for chunking compatibility.
def _copy_file_resilient(source: Path, dest: Path) -> None:
    """
    Copy a file to "dest" while handling Windows MAX_PATH limitations.
    On Windows this adds the extended-length path prefix (\\\\?\\) when needed so
    long paths can still be opened even if the system-wide long path policy is
    disabled. Falls back to the original shutil.copy2 behaviour for other
    platforms.
    """
    src_for_copy = _as_extended_path(source)

    try:
        shutil.copy2(src_for_copy, dest)
        return
    except Exception as e:
        # Re-raise with context so the caller sees the original path for debugging.
        raise FileNotFoundError(
            f"Failed to copy file (len={len(str(source))}): {source} -> {dest}."
        ) from e


def _ensure_dir(path: Path) -> None:
    """Create a directory, using extended-length paths on Windows when necessary."""
    try:
        if os.name == "nt":
            resolved = path.resolve()
            if len(str(resolved)) >= 240:
                os.makedirs(str(_as_extended_path(resolved)), exist_ok=True)
                return
        path.mkdir(parents=True, exist_ok=True)
    except FileExistsError:
        # Race condition where the dir already exists
        pass


def _ensure_chunkable_copy(source: Path, long_path_threshold: int = _LONG_PATH_THRESHOLD) -> Tuple[Path, List[Path]]:
    """
    Ensure the given file path is usable by pandas/openpyxl by handling two cases:
    1) Legacy .xls files are converted to .xlsx.
    2) Binary .xlsb files are converted to .xlsx.
    3) CSV files are converted to a temporary single-sheet .xlsx workbook.
    4) Windows long-path issues are avoided by copying to a short temp location.

    Returns
    -------
    prepared_path : Path
        Path that downstream chunkers should read.
    cleanup_paths : list[Path]
        Any temporary paths that should be deleted by the caller when finished.
    """

    cleanup_paths: List[Path] = []

    def _short_temp_path(suffix: str) -> Path:
        safe_stem = re.sub(r"[^A-Za-z0-9_.-]+", "_", source.stem)[:_SHORT_TEMP_STEM_MAX_LEN] or "temp"
        return Path(tempfile.gettempdir()) / f"losslens_{safe_stem}_{uuid4().hex[:8]}{suffix}"

    suffix = source.suffix.lower()
    abs_source = source if source.is_absolute() else source.resolve()
    use_short_path = len(str(abs_source)) >= long_path_threshold

    working_source = source
    if use_short_path:
        # Copy the original file to a shorter temp path to avoid MAX_PATH issues on Windows.
        short_copy = _short_temp_path(suffix or ".tmp")
        if short_copy.exists():
            short_copy.unlink()
        try:
            _copy_file_resilient(abs_source, short_copy)
            working_source = short_copy
            cleanup_paths.append(short_copy)
        except PermissionError:
            # Fall back to using the original path if copying is blocked (e.g., OneDrive ACLs).
            working_source = abs_source
            use_short_path = False

    if suffix in {".xls", ".xlsb"}:
        # Always place the converted file in the system temp directory to
        # avoid polluting the input folder with _temp.xlsx artefacts and to
        # avoid long-path failures on Windows.
        temp_path = _short_temp_path(".xlsx")
        if temp_path.exists():
            temp_path.unlink()
        engine = "xlrd" if suffix == ".xls" else "pyxlsb"
        with pd.ExcelFile(working_source, engine=engine) as xls:
            with pd.ExcelWriter(temp_path, engine="openpyxl") as writer:
                for sheet in xls.sheet_names:
                    xls.parse(sheet).to_excel(writer, sheet_name=str(sheet), index=False)
        cleanup_paths.append(temp_path)
        return temp_path, cleanup_paths

    if suffix == ".csv":
        temp_path = _short_temp_path(".xlsx")
        if temp_path.exists():
            temp_path.unlink()
        df = read_csv_with_detected_delimiter(working_source)
        with pd.ExcelWriter(temp_path, engine="openpyxl") as writer:
            df.to_excel(writer, sheet_name="Sheet1", index=False)
        cleanup_paths.append(temp_path)
        return temp_path, cleanup_paths

    # Non-xls files: if we copied to a short temp path, mark it for cleanup; otherwise use the original path.
    return working_source, cleanup_paths


def get_or_create_chunkable_copy(
    source: Path,
    long_path_threshold: int = _LONG_PATH_THRESHOLD,
) -> Tuple[Path, List[Path]]:
    """Return a cached prepared workbook path, creating it on first use."""
    abs_source = source if source.is_absolute() else source.resolve()
    cache_key = os.path.abspath(str(abs_source))

    with _chunkable_copy_cache_lock:
        cached = _chunkable_copy_cache.get(cache_key)
        if cached is not None:
            prepared_path, _cleanup_paths = cached
            if prepared_path.exists():
                return prepared_path, []

    prepared_path, cleanup_paths = _ensure_chunkable_copy(
        abs_source,
        long_path_threshold=long_path_threshold,
    )

    with _chunkable_copy_cache_lock:
        _chunkable_copy_cache[cache_key] = (prepared_path, cleanup_paths)

    return prepared_path, []


def clear_chunkable_copy() -> None:
    """Delete cached conversion artifacts created for workbook chunking."""
    with _chunkable_copy_cache_lock:
        cached_items = list(_chunkable_copy_cache.values())
        _chunkable_copy_cache.clear()

    for _prepared_path, cleanup_paths in cached_items:
        for temp_path in cleanup_paths:
            try:
                if temp_path.exists():
                    temp_path.unlink()
            except Exception:
                pass


def evict_chunkable_copy(source: Path) -> None:
    """Remove a single file's cached conversion artifacts.

    Thread-safe per-file eviction - called after extraction completes for
    a file so temp files don't accumulate during multi-file pipeline runs.
    """
    abs_source = source if source.is_absolute() else source.resolve()
    cache_key = os.path.abspath(str(abs_source))

    with _chunkable_copy_cache_lock:
        entry = _chunkable_copy_cache.pop(cache_key, None)

    if entry is not None:
        _prepared_path, cleanup_paths = entry
        for temp_path in cleanup_paths:
            try:
                if temp_path.exists():
                    temp_path.unlink()
            except Exception:
                pass


# --- Block utilities (adapted from Excel_chunk.py, trimmed) -----------------
Coord = Tuple[int, int]
Block = Tuple[Tuple[int, int], Tuple[int, int], set]


# Utility functions for block detection and classification in Excel worksheets.
# Converts row and column indices to Excel A1 cell notation.
def a1(r: int, c: int) -> str:
    return f"{get_column_letter(c)}{r}"

# Finds all non-empty cell coordinates in a worksheet.
# Returns a set of coordinates for all non-empty cells in a worksheet.
#
# Placeholder-header pattern: covers two sources of generic column labels:
#
# 1. pandas auto-generated labels ("Unnamed: N") - produced when a legacy .xls
#    file is converted to .xlsx via pd.ExcelFile.parse -> ExcelWriter.to_excel.
#    Every column with no value in the original header row gets an "Unnamed: N"
#    synthetic label, creating a solid horizontal strip that would otherwise
#    connect separate data regions into a single giant block.
#
# 2. Spreadsheet-native placeholder rows ("Column 1", "Column 2", ...) - some
#    Excel templates insert a literal row of "Column 1" / "Column 2" etc. as a
#    visual caption row above the real header row (e.g. row 4 has "Column 1...14"
#    and row 5 has the actual column names like "DOL", "Claimant", etc.).
#    Without filtering these, _row_stats_from_ws counts them as genuine text
#    values, _row_looks_like_header returns True for the placeholder row, and
#    the Jaccard-similarity validation in extract tables from block eliminates
#
# Both classes of placeholder values are treated as effectively empty for the
# purpose of block connectivity and header-row detection.
_UNNAMED_COL_RE = re.compile(
    r"^(?:"
    r"Unnamed[:\s]*\d+"            # pandas auto-generated "Unnamed: N"
    r"|Column[_\s]*\d+"            # "Column 1", "Column_1"
    r"|Col[_\s]*\d+"               # "Col 1", "Col_1"
    r"|Field[_\s]*\d+"             # "Field 1", "Field_1"
    r"|Attr(?:ibute)?[_\s]*\d+"    # "Attr 1", "Attribute_2"
    r"|Item[_\s]*\d+"              # "Item 1", "Item_3"
    r"|Header[_\s]*\d+"            # "Header 1"
    r"|Label[_\s]*\d+"             # "Label 1"
    r"|Variable[_\s]*\d+"          # "Variable 1"
    r"|Var[_\s]*\d+"               # "Var 1", "Var_2"
    r"|Data[_\s]*\d+"              # "Data 1"
    r"|Value[_\s]*\d+"             # "Value 1", "Value_2"
    r"|Val[_\s]*\d+"               # "Val 1"
    r"|Key[_\s]*\d+"               # "Key 1"
    r"|Param(?:eter)?[_\s]*\d+"    # "Param 1", "Parameter_2"
    r"|Metric[_\s]*\d+"            # "Metric 1"
    r"|Index[_\s]*\d+"             # "Index 1"
    r"|Entry[_\s]*\d+"             # "Entry 1"
    r")$",
    re.IGNORECASE,
)

# Merged-cell expansion threshold: merged ranges that span more than this many
# columns are treated as decorative/title headers (e.g. "Business Loss Run"
# spanning A1:IO1). For such wide merges we only add the anchor cell to
# `coords` rather than every cell in the merge. This prevents a single wide
# title row from creating a continuous horizontal strip that erroneously
# connects all column regions into one giant connected block.
_WIDE_MERGE_COL_SPAN_LIMIT = 10


def _is_placeholder_coord_value(v: Any) -> bool:
    """Return True if *v* is a pandas-generated placeholder column name."""
    if not isinstance(v, str):
        return False
    return bool(_UNNAMED_COL_RE.match(v.strip()))


def non_empty_coords(ws: Worksheet) -> set:
    coords = set()
    for r_idx, row in enumerate(ws.iter_rows(values_only=True), start=1):
        for c_idx, v in enumerate(row, start=1):
            if v not in (None, "") and not _is_placeholder_coord_value(v):
                coords.add((r_idx, c_idx))
    # Also include cells inside merged ranges whose anchor has a value.
    # iter_rows(values_only=True) returns None for non-anchor merged cells,
    # which can break connected-block boundaries at merge seams.
    #
    # Guard: skip expansion for very wide horizontal merges (e.g. title rows
    # spanning the full sheet width). These decorative merges should not
    # bridge separate column regions into a single connected block.
    if hasattr(ws, "merged_cells"):
        for merged_range in ws.merged_cells.ranges:
            anchor_val = ws.cell(merged_range.min_row, merged_range.min_col).value
            if anchor_val in (None, "") or _is_placeholder_coord_value(anchor_val):
                continue
            col_span = merged_range.max_col - merged_range.min_col + 1
            row_span = merged_range.max_row - merged_range.min_row + 1
            # Wide purely-horizontal merges (title/label rows): only add the
            # anchor cell so the merge does not create a horizontal bridge
            # between otherwise-separate data columns.
            if col_span > _WIDE_MERGE_COL_SPAN_LIMIT and row_span == 1:
                coords.add((merged_range.min_row, merged_range.min_col))
                continue
            # Multi-row merges containing long free text (e.g. a company address
            # such as "85 Broad Street, 7th Floor New York, NY 10004" that spans
            # rows 2-3): expanding all merged rows adds phantom coords to the
            # intermediate rows, creating a 4-adjacency bridge from the free-text
            # row down into key-value or data sections separated by an empty row.
            # Fix: only add the anchor cell so the merge occupies exactly one
            # coordinate, leaving the empty gap rows truly empty and preserving
            # correct block boundaries.
            if row_span > 1 and isinstance(anchor_val, str) and len(anchor_val.strip()) > 20:
                coords.add((merged_range.min_row, merged_range.min_col))
                continue
            for rr in range(merged_range.min_row, merged_range.max_row + 1):
                for cc in range(merged_range.min_col, merged_range.max_col + 1):
                    coords.add((rr, cc))
    return coords


# Groups non-empty cell coordinates into connected blocks based on adjacency.
# Returns a list of blocks, each defined by its top-left and bottom-right coordinates and member cells.
def connected_blocks(coords: set) -> List[Block]:
    from collections import deque

    coords = set(coords)
    seen = set()
    blocks: List[Block] = []
    for start in sorted(coords):
        if start in seen:
            continue
        q = deque([start])
        members = {start}
        seen.add(start)
        while q:
            r, c = q.popleft()
            for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                nb = (r + dr, c + dc)
                if nb in coords and nb not in seen:
                    seen.add(nb)
                    members.add(nb)
                    q.append(nb)
        rs = [r for r, _ in members]
        cs = [c for _, c in members]
        tl = (min(rs), min(cs))
        br = (max(rs), max(cs))
        blocks.append((tl, br, members))
    blocks.sort(key=lambda b: (b[0][0], b[0][1]))
    return blocks


# Classifies a block of cells into 'table', 'key_values', or 'text_lines' based on structure and content density.
def classify_block(ws: Worksheet, tl: Tuple[int, int], br: Tuple[int, int], members: set) -> str:
    r1, c1 = tl; r2, c2 = br
    rows = r2 - r1 + 1
    cols = c2 - c1 + 1
    total = rows * cols if rows and cols else 0
    density = (len(members) / total) if total else 0.0

    # Single-column blocks are always text lines (no key-value or table structure)
    if cols == 1:
        return "text_lines"

    if cols == 2 and rows >= 2:
        text_like = 0
        non_empty_rows = 0
        for r in range(r1, r2 + 1):
            v1 = ws.cell(r, c1).value
            v2 = ws.cell(r, c2).value
            if v1 not in (None, "") or v2 not in (None, ""):
                non_empty_rows += 1
                if isinstance(v1, str) and v1.strip():
                    text_like += 1
        if non_empty_rows and (text_like / non_empty_rows) > 0.6:
            return "key_values"
    # For wider blocks that *look* like key-value despite having >2 columns
    # (e.g. merged-cell regions), count logical non-empty cells per row.
    if cols > 2 and rows >= 2 and density < 0.5:
        kv_rows = 0
        checked = 0
        for r in range(r1, r2 + 1):
            vals = [ws.cell(r, c).value for c in range(c1, c2 + 1) if ws.cell(r, c).value not in (None, "")]
            if not vals:
                continue
            checked += 1
            if len(vals) <= 2:
                kv_rows += 1
        if checked >= 2 and (kv_rows / checked) >= 0.7:
            return "key_values"
    if rows >= 3 and cols >= 2 and density >= 0.5:
        return "table"
    # Detect 2-row mini-tables: a wide block (>=5 columns) with exactly 2 rows
    # (typically a header row + a single data row) and high cell density.
    # These appear as standalone summary tables in loss run spreadsheets
    # (e.g. policy-level metadata tables sitting above a detailed claim table).
    # Classifying them as "table" instead of "key_values" prevents
    # _merge_tables_with_neighbors from absorbing them into an adjacent larger
    # table, because the existing width-ratio check in _should_merge will
    # correctly refuse to merge two "table" blocks that have significantly
    # different column spans.
    if rows == 2 and cols >= 5 and density >= 0.5:
        return "table"
    if rows <= 2 and len(members) <= 6:
        return "text_lines"
    return "key_values"


# Calculates the number of overlapping columns between two rectangular blocks.
def _rect_overlap_cols(a_tl, a_br, b_tl, b_br) -> int:
    ac1, ac2 = a_tl[1], a_br[1]; bc1, bc2 = b_tl[1], b_br[1]
    left = max(ac1, bc1); right = min(ac2, bc2)
    return max(0, right - left + 1)


# Calculates the number of overlapping rows between two rectangular blocks.
def _rect_overlap_rows(a_tl, a_br, b_tl, b_br) -> int:
    ar1, ar2 = a_tl[0], a_br[0]; br1, br2 = b_tl[0], b_br[0]
    top = max(ar1, br1); bot = min(ar2, br2)
    return max(0, bot - top + 1)


# Calculates the vertical gap (in rows) between two rectangles. Returns 0 if they overlap.
def _rect_gap_rows(a_tl, a_br, b_tl, b_br) -> int:
    if _rect_overlap_rows(a_tl, a_br, b_tl, b_br) > 0:
        return 0
    ar2 = a_br[0]; br1 = b_tl[0]
    if ar2 < br1:
        return max(0, br1 - ar2 - 1)
    br2 = b_br[0]; ar1 = a_tl[0]
    return max(0, ar1 - br2 - 1)


# Calculates the horizontal gap (in columns) between two rectangles. Returns 0 if they overlap.
def _rect_gap_cols(a_tl, a_br, b_tl, b_br) -> int:
    if _rect_overlap_cols(a_tl, a_br, b_tl, b_br) > 0:
        return 0
    ac2 = a_br[1]; bc1 = b_tl[1]
    if ac2 < bc1:
        return max(0, bc1 - ac2 - 1)
    bc2 = b_br[1]; ac1 = a_tl[1]
    return max(0, ac1 - bc2 - 1)


# Returns the number of columns in a rectangle defined by top-left and bottom-right coordinates.
def _rect_col_count(tl, br) -> int:
    return br[1] - tl[1] + 1


# Returns the number of rows in a rectangle defined by top-left and bottom-right coordinates.
def _rect_row_count(tl, br) -> int:
    return br[0] - tl[0] + 1


# Returns the union of two rectangles defined by their top-left and bottom-right coordinates.
def _rect_union(a_tl, a_br, b_tl, b_br):
    (ar1, ac1), (ar2, ac2) = a_tl, a_br
    (br1, bc1), (br2, bc2) = b_tl, b_br
    return (min(ar1, br1), min(ac1, bc1)), (max(ar2, br2), max(ac2, bc2))


# Heuristic: determine whether a non-table block looks like a header row group.
def _block_looks_like_header(ws: Worksheet, tl: Tuple[int, int], br: Tuple[int, int]) -> bool:
    text_count = 0
    numeric_count = 0
    total = 0
    max_text_len = 0
    for r in range(tl[0], br[0] + 1):
        for c in range(tl[1], br[1] + 1):
            v = ws.cell(r, c).value
            if v in (None, ""):
                continue
            total += 1
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                numeric_count += 1
                continue
            s = str(v).strip()
            if s:
                max_text_len = max(max_text_len, len(s))
                if re.search(r"[A-Za-z]", s):
                    text_count += 1
    if total == 0:
        return False
    # Header-like: multiple short text labels, few numbers.
    if text_count >= 2 and numeric_count <= 1 and max_text_len <= 60:
        return True
    return False


# Determines whether two blocks should be merged based on their labels and spatial relationship.
def _should_merge(a_label: str, a_tl, a_br, b_label: str, b_tl, b_br) -> bool:
    a_is_table = a_label == "table"
    b_is_table = b_label == "table"
    if a_is_table and b_is_table:
        col_overlap = _rect_overlap_cols(a_tl, a_br, b_tl, b_br)
        min_cols = min(_rect_col_count(a_tl, a_br), _rect_col_count(b_tl, b_br))
        max_cols = max(_rect_col_count(a_tl, a_br), _rect_col_count(b_tl, b_br))
        same_cols = min_cols > 0 and col_overlap / min_cols >= 0.5
        width_ratio = (min_cols / max_cols) if max_cols else 0.0
        vgap = max(0, b_tl[0] - a_br[0] - 1) if a_br[0] < b_tl[0] else max(0, a_tl[0] - b_br[0] - 1)
        hgap = _rect_gap_cols(a_tl, a_br, b_tl, b_br)
        # Vertical stacking: same column structure, small vertical gap, similar widths.
        if width_ratio >= 0.8 and same_cols and vgap <= 2:
            return True
        # Horizontal adjacency: significant row overlap, small horizontal gap.
        # Width ratio is intentionally not checked here - side-by-side sub-tables
        # (e.g. a 3-column block next to a 43-column block) are common in loss runs.
        row_overlap = _rect_overlap_rows(a_tl, a_br, b_tl, b_br)
        min_rows = min(_rect_row_count(a_tl, a_br), _rect_row_count(b_tl, b_br))
        row_overlap_ratio = (row_overlap / min_rows) if min_rows else 0.0
        if row_overlap_ratio >= 0.6 and hgap <= 2:
            return True
    return False


# Merges adjacent blocks based on their labels and spatial relationship.
def merge_adjacent_blocks(blocks, labels):
    merged = []
    merged_labels = []
    used = [False] * len(blocks)
    for i, blk in enumerate(blocks):
        if used[i]:
            continue
        acc_tl, acc_br = blk[0], blk[1]
        acc_label = labels[i]
        acc_members = set(blk[2])
        for j in range(i + 1, len(blocks)):
            if used[j]:
                continue
            if _should_merge(acc_label, acc_tl, acc_br, labels[j], blocks[j][0], blocks[j][1]):
                acc_tl, acc_br = _rect_union(acc_tl, acc_br, blocks[j][0], blocks[j][1])
                acc_members.update(blocks[j][2])
                used[j] = True
        merged.append((acc_tl, acc_br, acc_members))
        merged_labels.append(acc_label)
        used[i] = True
    return merged, merged_labels


# Expands table blocks by merging nearby sparse blocks (key_values/text_lines) that share layout.
# The vertical gap is intentionally lenient to allow tables split by subtotal rows or repeated headers.
def _merge_tables_with_neighbors(
    blocks,
    labels,
    max_vertical_gap: int = 6,
    max_horizontal_gap: int = 2,
    max_vertical_gap_non_table: int = 2,
    min_col_overlap_ratio_non_table: float = 0.7,
):
    blocks = list(blocks)
    labels = list(labels)
    logger.debug("_merge_tables_with_neighbors: %d blocks, %d labels", len(blocks), len(labels))

    def _row_overlap_ratio(a_tl, a_br, b_tl, b_br) -> float:
        overlap = _rect_overlap_rows(a_tl, a_br, b_tl, b_br)
        denom = min(_rect_row_count(a_tl, a_br), _rect_row_count(b_tl, b_br))
        return (overlap / denom) if denom else 0.0

    def _col_overlap_ratio(a_tl, a_br, b_tl, b_br) -> float:
        overlap = _rect_overlap_cols(a_tl, a_br, b_tl, b_br)
        denom = min(_rect_col_count(a_tl, a_br), _rect_col_count(b_tl, b_br))
        return (overlap / denom) if denom else 0.0

    changed = True
    while changed:
        changed = False
        to_drop = set()
        for i, blk in enumerate(blocks):
            if blk is None or labels[i] != "table":
                continue
            tl_i, br_i, members_i = blk
            for j, other in enumerate(blocks):
                if i == j or other is None or j in to_drop:
                    continue
                lbl_j = labels[j]
                if lbl_j not in ("table", "key_values", "text_lines"):
                    continue

                tl_j, br_j, members_j = other
                col_ratio = _col_overlap_ratio(tl_i, br_i, tl_j, br_j)
                row_ratio = _row_overlap_ratio(tl_i, br_i, tl_j, br_j)
                vgap = _rect_gap_rows(tl_i, br_i, tl_j, br_j)
                hgap = _rect_gap_cols(tl_i, br_i, tl_j, br_j)

                is_above = tl_j[0] < tl_i[0]
                if is_above and tl_j[0] < (tl_i[0] - max_vertical_gap):
                    continue

                if lbl_j == "table":
                    min_cols = min(_rect_col_count(tl_i, br_i), _rect_col_count(tl_j, br_j))
                    max_cols = max(_rect_col_count(tl_i, br_i), _rect_col_count(tl_j, br_j))
                    width_ratio = (min_cols / max_cols) if max_cols else 0.0
                    near_vertical = col_ratio >= 0.5 and vgap <= max_vertical_gap
                    near_horizontal = row_ratio >= 0.6 and hgap <= max_horizontal_gap
                    # Width ratio check only applies to vertically stacked tables;
                    # horizontally adjacent tables (e.g. 3-col block next to 43-col
                    # main table) can have very different widths and should still merge.
                    if near_vertical and width_ratio < 0.8:
                        near_vertical = False
                    if not (near_vertical or near_horizontal):
                        continue
                else:
                    # Be conservative when merging non-table blocks (likely context/metadata)
                    # into a table: only allow very close vertical adjacency with strong
                    # column overlap. This avoids pulling header/footer text into the table range.

                    # Guard: don't merge narrow non-table blocks sitting BELOW a
                    # wide table - these are typically footnotes or disclaimers
                    # (e.g. single-column text lines below a 10-column table).
                    is_below_table = tl_j[0] > br_i[0]
                    if is_below_table:
                        table_cols = _rect_col_count(tl_i, br_i)
                        other_cols = _rect_col_count(tl_j, br_j)
                        if table_cols >= 4 and other_cols < max(2, int(table_cols * 0.3)):
                            continue

                    near_vertical = (
                        col_ratio >= min_col_overlap_ratio_non_table
                        and vgap <= max_vertical_gap_non_table
                    )
                    # Also allow horizontal adjacency for non-table blocks that share
                    # significant row overlap (e.g., sparse columns next to main table).
                    near_horizontal = (
                        row_ratio >= 0.6
                        and hgap <= max_horizontal_gap
                    )
                    if not (near_vertical or near_horizontal):
                        continue

                new_tl, new_br = _rect_union(tl_i, br_i, tl_j, br_j)
                new_members = set(members_i)
                new_members.update(members_j)
                blocks[i] = (new_tl, new_br, new_members)
                labels[i] = "table"
                blocks[j] = None
                labels[j] = None
                to_drop.add(j)
                tl_i, br_i, members_i = blocks[i]
                changed = True

        if changed:
            compact_blocks = []
            compact_labels = []
            for blk, lbl in zip(blocks, labels):
                if blk is not None and lbl is not None:
                    compact_blocks.append(blk)
                    compact_labels.append(lbl)
            blocks, labels = compact_blocks, compact_labels

    return blocks, labels


# --- Table result builder - extracted from extract_table() for readability. ----------------
#
# ---------------------------------------------------------------------------

def _build_table_result(
    ws: Worksheet,
    r1: int, c1: int, r2: int, c2: int,
    header_row: Optional[int],
    merged_map: Dict[Tuple[int, int], Any],
    context_below_row_limit: Optional[int] = None,
) -> Dict[str, Any]:
    """Build the final table dict once a header row has been determined.

    Extracts above/below context, header cells, data rows, and detects
    sparse trailing rows that are really footnotes. Separated from
    `extract_table` to keep that function focused on header detection.
    """
    def _cv(row: int, col: int):
        if (row, col) in merged_map:
            return merged_map[(row, col)]
        return ws.cell(row, col).value

    # --- Above-table free text
    context_lines_above: List[Dict[str, Any]] = []
    if header_row is not None:
        for row in range(r1, header_row):
            for col in range(c1, c2 + 1):
                val = ws.cell(row, col).value
                if val and str(val).strip() and not _is_placeholder_coord_value(val):
                    context_lines_above.append({"cell": a1(row, col), "value": str(val).strip()})

    # --- Below-table free text
    context_lines_below: List[Dict[str, Any]] = []
    last_data_row = None
    if header_row is not None:
        for r in range(header_row + 1, r2 + 1):
            row_values = [ws.cell(r, c).value for c in range(c1, c2 + 1)]
            if any(v not in (None, "") for v in row_values):
                last_data_row = r
    if last_data_row:
        sheet_max_row = ws.max_row or r2
        scan_end = min(sheet_max_row, last_data_row + 10)
        if context_below_row_limit is not None:
            scan_end = min(scan_end, context_below_row_limit - 1)
        for row in range(last_data_row + 1, scan_end + 1):
            row_has_value = False
            for col in range(c1, c2 + 1):
                val = ws.cell(row, col).value
                if val and str(val).strip():
                    context_lines_below.append({"cell": a1(row, col), "value": str(val).strip()})
                    row_has_value = True
            if not row_has_value and row > last_data_row + 1:
                prev_had = any(
                    ws.cell(row - 1, c).value not in (None, "")
                    for c in range(c1, c2 + 1)
                )
                if not prev_had:
                    break

    # --- First-row legacy context
    context_lines_first_row: List[Dict[str, Any]] = []
    if header_row is None or header_row != r1:
        for c in range(c1, c2 + 1):
            val = ws.cell(r1, c).value
            if val and str(val).strip():
                context_lines_first_row.append({"cell": a1(r1, c), "value": str(val).strip()})

    # --- Deduplicate context, filter header values
    header_values: Set = set()
    if header_row is not None:
        for c in range(c1, c2 + 1):
            val = _cv(header_row, c)
            if val is None:
                continue
            text = str(val).strip()
            if text:
                header_values.add(text)

    all_context_entries = context_lines_above + context_lines_first_row + context_lines_below
    seen: Set = set()
    context_entries_unique: List[Dict[str, Any]] = []
    for entry in all_context_entries:
        val_text = entry.get("value", "")
        if val_text in header_values:
            continue
        if val_text not in seen:
            context_entries_unique.append(entry)
            seen.add(val_text)

    context = "\n".join([e["value"] for e in context_entries_unique]) if context_entries_unique else None
    above_values = {e["value"] for e in context_lines_above + context_lines_first_row}
    context_above = [e for e in context_entries_unique if e["value"] in above_values]
    context_below = [e for e in context_entries_unique if e["value"] not in above_values]

    if header_row is None:
        return {"headers": [], "rows": [], "range": f"{a1(r1, c1)}:{a1(r2, c2)}"}

    # --- Find first non-empty row
    first_non_empty_row = None
    for rr in range(r1, r2 + 1):
        if any(_cv(rr, c) not in (None, "") for c in range(c1, c2 + 1)):
            first_non_empty_row = rr
            break

    # --- Extract header cells
    headers = []
    for c in range(c1, c2 + 1):
        raw = ws.cell(header_row, c).value
        if (header_row, c) in merged_map:
            raw = merged_map[(header_row, c)]
        if _is_placeholder_coord_value(raw):
            raw = None
        text = str(raw).strip() if raw is not None else None
        headers.append({"text": text, "cell": a1(header_row, c)})

    header_indices = [(idx, h) for idx, h in enumerate(headers) if h["text"]]
    num_headers = len(header_indices)

    # --- Extract data rows
    rows: List[List[Dict[str, Any]]] = []
    last_row_with_values = None
    for r in range(header_row + 1, r2 + 1):
        row_obj = []
        for idx, h in header_indices:
            c = c1 + idx
            val = ws.cell(r, c).value
            if (r, c) in merged_map:
                val = merged_map[(r, c)]
            row_obj.append({"header": h["text"], "value": val, "cell": a1(r, c)})
        if any(v["value"] not in (None, "") for v in row_obj):
            rows.append(row_obj)
            last_row_with_values = r

    # --- Detect sparse trailing rows -> context
    if num_headers >= 4 and rows:
        trailing_context_rows: List[List[Dict[str, Any]]] = []
        while rows:
            last = rows[-1]
            filled = sum(1 for cell in last if cell.get("value") not in (None, ""))
            if filled <= 2:
                trailing_context_rows.insert(0, rows.pop())
            else:
                break
        for trow in trailing_context_rows:
            for cell in trow:
                val = cell.get("value")
                if val not in (None, ""):
                    entry = {"cell": cell.get("cell"), "value": str(val).strip()}
                    if entry["value"] not in {e.get("value") for e in context_below}:
                        context_below.append(entry)
        if rows:
            last_cell = rows[-1][0].get("cell", "")
            _m = re.match(r"[A-Z]+(\d+)", last_cell)
            last_row_with_values = int(_m.group(1)) if _m else last_row_with_values
        else:
            last_row_with_values = header_row

    # --- Compute header confidence score
    # 0.0 = no confidence (no header found), 1.0 = high confidence.
    # Signals: fill ratio, unique ratio, text-vs-numeric ratio, row count.
    header_confidence = 0.0
    if header_row is not None:
        _hc_ne, _hc_txt, _hc_num, _hc_uq, _hc_mc, _hc_ml = _row_stats_from_ws(ws, header_row, c1, c2)
        _total_cols = c2 - c1 + 1
        _hc_fill = (_hc_ne / _total_cols) if _total_cols else 0.0
        _hc_text_ratio = (_hc_txt / _hc_ne) if _hc_ne else 0.0
        _hc_data_rows = len(rows)
        header_confidence = round(min(1.0, (
            min(_hc_fill, 1.0) * 0.30          # fill coverage
            + min(_hc_uq, 1.0) * 0.25          # label uniqueness
            + _hc_text_ratio * 0.20            # text-dominant
            + (1.0 - _hc_mc) * 0.10            # low repetition
            + min(_hc_data_rows / 5, 1.0) * 0.15 # data rows present
        )), 3)

    # --- Assemble result
    range_start_row = header_row if header_row is not None else first_non_empty_row
    range_end_row = last_row_with_values or header_row
    result: Dict[str, Any] = {
        "type": "table",
        "range": f"{a1(range_start_row, c1)}:{a1(range_end_row, c2)}",
        "headers": headers,
        "rows": rows,
        "header_confidence": header_confidence,
    }
    if context:
        result["context"] = context
    if context_above:
        result["context_above"] = context_above
    if context_below:
        result["context_below"] = context_below
    return result


# Extracts a table block from a worksheet into a structured dictionary.
def extract_table(ws: Worksheet, tl, br, context_below_row_limit: Optional[int] = None) -> Dict[str, Any]:
    r1, c1 = tl; r2, c2 = br
    logger.debug("extract_table: sheet=%s range=(%d,%d)-(%d,%d)", ws.title, r1, c1, r2, c2)

    # Build merged cell map scoped to the block range for efficiency.
    merged_map: Dict[Tuple[int, int], Any] = {}
    if hasattr(ws, "merged_cells"):
        for merged_range in ws.merged_cells.ranges:
            min_row, min_col, max_row, max_col = (
                merged_range.min_row, merged_range.min_col,
                merged_range.max_row, merged_range.max_col,
            )
            if max_row < r1 or min_row > r2 or max_col < c1 or min_col > c2:
                continue
            value = ws.cell(min_row, min_col).value
            for rr in range(min_row, max_row + 1):
                for cc in range(min_col, max_col + 1):
                    merged_map[(rr, cc)] = value

    # Detect the primary header row via the unified algorithm.
    header_rows = _detect_header_rows(ws, r1, r2, c1, c2, merged_map)
    header_row = header_rows[0] if header_rows else None

    return _build_table_result(ws, r1, c1, r2, c2, header_row, merged_map, context_below_row_limit)


def parse_cell_ref(cell_ref: str) -> Optional[Tuple[int, int]]:
    if not cell_ref:
        return None
    match = re.match(r"^([A-Za-z]+)(\d+)$", str(cell_ref))
    if not match:
        return None
    col_letters, row_str = match.groups()
    try:
        return int(row_str), column_index_from_string(col_letters)
    except Exception:
        return None


def _row_stats_from_ws(ws: Worksheet, row_idx: int, c1: int, c2: int) -> Tuple[int, int, int, float, float, int]:
    values = []
    for c in range(c1, c2 + 1):
        v = ws.cell(row_idx, c).value
        # Treat pandas-generated "Unnamed: N" placeholder headers as empty
        if v not in (None, "") and not _is_placeholder_coord_value(v):
            values.append(v)
    if not values:
        return 0, 0, 0, 0.0, 0.0, 0
    text_vals = [v for v in values if isinstance(v, str) and str(v).strip()]
    numeric_vals = [v for v in values if isinstance(v, (int, float)) and not isinstance(v, bool)]
    normalized = [str(v).strip().lower() for v in values]
    unique_count = len(set(normalized))
    most_common = max((normalized.count(x) for x in set(normalized)), default=0)
    unique_ratio = unique_count / len(normalized)
    most_common_ratio = most_common / len(normalized)
    max_text_len = max((len(str(v)) for v in text_vals), default=0)
    return len(values), len(text_vals), len(numeric_vals), unique_ratio, most_common_ratio, max_text_len


# Pre-compiled pattern that matches labels of the form "Word N", "Word_N",
# "Word-N" (digit suffix) or "Word A", "Word_A" (single-letter suffix).
# These are universally synthetic placeholder labels regardless of casing.
_WORD_N_RE = re.compile(
    r"^[A-Za-z][A-Za-z_\-]*[\s_\-]+\d+$"     # "Item 1", "Col_3", "Field-14"
    r"|^[A-Za-z][A-Za-z_\-]*[\s_\-]+[A-Za-z]$", # "Col A", "Field_B"
    re.IGNORECASE,
)

# Expanded set of generic placeholder root words used by _score_header_quality.
# Any label whose root (after stripping trailing digits/letters/separators)
# collapses to one of these is treated as a synthetic placeholder.
_GENERIC_ROOTS: Set[str] = {
    "column", "col", "field", "unnamed", "header", "attribute", "attr",
    "item", "data", "variable", "var", "label", "value", "val", "key",
    "entry", "row", "record", "text", "name", "type", "code", "num",
    "number", "desc", "description", "element", "param", "parameter",
    "property", "prop", "index", "idx", "input", "output", "result",
    "metric", "measure", "category", "cat", "group", "grp", "tag",
}


def _score_header_quality(texts: List[str]) -> float:
    """Score how much a list of cell text values looks like genuine column headers.

    Returns a float in [0.0, 1.0]. A score below `_HEADER_QUALITY_MIN_SCORE`
    indicates a false / placeholder header row.

    The score is built from five independent signals so that no single signal
    can dominate. This avoids hard regex blacklists while remaining robust to
    novel placeholder patterns:

    1. **Semantic richness** - labels that contain letters from more than one
       word, mixed capitalisation, or common domain tokens score higher.
       Pure `"Column N"` / `"Field N"` style labels score near zero because
       all meaningful content is just a generic word + a digit.

    2. **Label diversity** - all values being the same pattern (e.g. every
       label is `"Column N"` where *N* varies) is penalised. Genuine headers
       mix different concepts (dates, names, amounts, states ...).

    3. **Structural variety** - real column headers mix word counts, lengths,
       and capitalisation styles. Placeholder rows produced by templates have
       uniform structure (same prefix, ascending number suffix).

    4. **Non-sequential uniqueness** - when labels stripped of trailing digits
       all collapse to the same root word (e.g. `"column"`) the row looks
       synthetic. Genuine headers have conceptually distinct roots.

    5. **Length distribution** - very short single-word numeric-suffix labels
       (`"Col 1"`) differ from real headers which tend to be 3-25 chars and
       varied in length.
    """
    if not texts:
        return 0.0

    n = len(texts)
    lowered = [t.strip().lower() for t in texts]

    # -- Signal 1: semantic richness per label
    # ... generic_roots moved to module-level _GENERIC_ROOTS (expanded set).
    richness_scores = []
    for t in texts:
        t = t.strip()
        words = t.split()
        word_count = len(words)

        # Hard-penalise "Word N" / "Word_N" / "Word A" patterns - these are
        # synthetic placeholders regardless of capitalisation style.
        if _WORD_N_RE.match(t):
            richness_scores.append(0.02)
            continue

        has_digit_only_suffix = bool(re.search(r'[\s_\-]\d+$', t))
        # Only credit mixed case when it is NOT a digit-suffix label ("Item 1"
        # is title-case yet still a placeholder).
        has_mixed_case = (
            not has_digit_only_suffix
            and t != t.upper()
            and t != t.lower()
        )
        # Only count a word as "meaningful" if its root is not a generic placeholder.
        has_meaningful_words = any(
            len(w) > 3
            and not w.isdigit()
            and re.sub(r'[\s_\-]*\d+$', '', w.lower()).strip() not in _GENERIC_ROOTS
            for w in words
        )
        r = 0.0
        if word_count >= 2 and not has_digit_only_suffix:
            r += 0.4
        elif word_count >= 2 and has_digit_only_suffix:
            # "Column 1", "Field 3" etc - penalise
            r += 0.05
        else:
            # Single word
            r += 0.2 if len(t) > 3 else 0.05
        if has_mixed_case:
            r += 0.2
        if has_meaningful_words:
            r += 0.2
        # Bonus: root word is NOT a generic placeholder word.
        root = re.sub(r'[\s_\-]*\d+$', '', t.lower()).strip()
        if root and root not in _GENERIC_ROOTS:
            r += 0.2
        richness_scores.append(min(r, 1.0))
    signal_richness = sum(richness_scores) / n

    # -- Signal 2: label diversity (concept-level) ------------------------------
    # Strip trailing digits/letters and separators to get conceptual roots.
    # Fix vs. V0: use (unique_roots-1)/(n-1) instead of unique_roots/n so that
    # a 2-label all-same-root set (["Item 1", "Item 2"]) gives diversity=0.0
    # rather than 0.5, which was enough to push past the 0.35 threshold.
    roots = [
        re.sub(r'[\s_\-]*\d+$|[\s_\-]+[A-Za-z]$', '', lbl).strip()
        for lbl in lowered
    ]
    unique_roots = len(set(roots))
    signal_diversity = (unique_roots - 1) / max(n - 1, 1)

    # -- Signal 3: structural variety -------------------------------------------
    # Real headers vary in word count, length, and capitalisation.
    lengths = [len(t.strip()) for t in texts]
    length_variance = max(lengths) - min(lengths) if n > 1 else 0
    # Normalise: a spread of >=10 chars across labels is good variety
    signal_structure = min(length_variance / 10.0, 1.0)

    # -- Signal 4: non-sequential uniqueness -------------------------------------
    # If every unique root appears only once (no repetition beyond the generic
    # prefix) that is a positive signal. Placeholder rows repeat the same
    # root over and over with ascending numbers.
    root_counts: Dict[str, int] = {}
    for r in roots:
        root_counts[r] = root_counts.get(r, 0) + 1
    max_root_count = max(root_counts.values())
    # Penalise when one root dominates (e.g. "column" appears 14 times)
    signal_nonrepeat = 1.0 - min((max_root_count - 1) / max(n - 1, 1), 1.0)

    # -- Signal 5: sort-arrow bonus ----------------------------------------------
    # Sort arrows (↑↓) are an unambiguous signal of a real interactive header.
    has_sort_arrows = any(re.search(r'[↑↓]', t) for t in texts)
    signal_arrows = 1.0 if has_sort_arrows else 0.0

    # -- Signal 6: sequential suffix detection -----------------------------------
    # When every label shares the same root AND the numeric suffixes form a
    # strictly consecutive integer sequence (1,2,3... or 0,1,2...), the row is a
    # synthetic template. Hard-cap the final score below the acceptance
    # threshold so this can never be promoted to a real header regardless of
    # the scores of the other signals.
    if n >= 2 and unique_roots == 1:
        suffixes = []
        for lbl in lowered:
            m = re.search(r'[\s_\-]*(\d+)$', lbl)
            if m:
                suffixes.append(int(m.group(1)))
        if len(suffixes) == n:
            sorted_s = sorted(suffixes)
            if sorted_s == list(range(sorted_s[0], sorted_s[0] + n)):
                # Perfectly sequential numbering - hard-cap at 0.10.
                raw = (
                    signal_richness * 0.35
                    + signal_diversity * 0.25
                    + signal_structure * 0.15
                    + signal_nonrepeat * 0.20
                    + signal_arrows * 0.05
                )
                return round(min(raw, 0.10), 4)

    # --- Weighted combination
    score = (
        signal_richness * 0.35
        + signal_diversity * 0.25
        + signal_structure * 0.15
        + signal_nonrepeat * 0.20
        + signal_arrows * 0.05
    )
    return round(min(score, 1.0), 4)


# Minimum quality score for a row to be accepted as a genuine column header.
# Rows scoring below this threshold are treated as false / placeholder headers
# regardless of their structural appearance.
_HEADER_QUALITY_MIN_SCORE = 0.35


def _row_looks_like_header(ws: Worksheet, row_idx: int, c1: int, c2: int) -> bool:
    non_empty, text_count, numeric_count, unique_ratio, most_common_ratio, max_text_len = _row_stats_from_ws(
        ws, row_idx, c1, c2
    )
    if non_empty < _HEADER_MIN_CELLS_FLOOR:
        return False
    if text_count < 2:
        return False
    if numeric_count > 1:
        return False
    # -- Reject rows with very low fill rate (merged category / super-headers) ---
    # Merged-cell "group header" rows (e.g. "POLICY FACTS | CLAIM FACTS: | ...")
    # show very few non-empty cells when read without merge expansion because
    # only the top-left cell of each merge carries a value. A genuine column
    # header row has one label per column and therefore a much higher fill rate.
    total_cols = c2 - c1 + 1
    if total_cols >= 6:
        fill_rate = non_empty / total_cols
        if fill_rate < 0.25:
            return False
    if most_common_ratio >= _ROW_REPEAT_RATIO_REJECT:
        return False
    if unique_ratio < _HEADER_UNIQUE_RATIO_MIN:
        return False
    # Lowered from 120 -> 60: genuine column headers are short labels (<= 60 chars).
    # Values > 60 chars are almost certainly data cells (descriptions, narratives, etc.),
    # not header labels. This prevents data rows whose longest cell contains a long
    # description sentence from being misclassified as header rows.
    if max_text_len > _HEADER_TEXT_MAX_LEN_FOR_DETECTION:
        return False

    # -- Domain-agnostic structural header detection ----------------------------
    # Instead of requiring insurance-specific keywords, we verify the row
    # looks like column labels structurally: short text cells, mostly
    # non-numeric, with title-like casing.
    texts = []
    for c in range(c1, c2 + 1):
        v = ws.cell(row_idx, c).value
        if isinstance(v, str) and v.strip():
            texts.append(v.strip())
    if not texts:
        return False
    # Reject rows that look like total/subtotal rows
    total_texts = [t for t in texts if re.search(r"\b(sub\s*total|subtotal|total|sum|grand\s*total)\b", t, re.IGNORECASE)]
    if total_texts and (len(total_texts) / len(texts)) >= 0.5:
        return False
    # All label cells must be short (<= 60 chars) - already enforced by
    # max_text_len check above, so here we do a finer per-cell check on
    # the keyword-length threshold.
    short_labels = [t for t in texts if len(t) <= _HEADER_TEXT_MAX_LEN_FOR_DETECTION]
    if len(short_labels) < 2:
        return False
    # Majority of short labels should look like column titles:
    # title-case, UPPER-CASE, or short phrases (<= 4 words).
    title_like = sum(
        1 for t in short_labels
        if t == t.upper() or t == t.title() or len(t.split()) <= 4
    )
    if title_like < len(short_labels) * 0.5:
        return False

    # -- Quality score gate ----------------------------------------------------
    # Score the label set for semantic richness, diversity, and structural
    # variety. Rows that pass all structural checks above but consist
    # entirely of generic template labels ("Column 1", "Field 2", etc.)
    # score below the threshold and are rejected as false headers without
    # relying on any regex blacklist.
    quality = _score_header_quality(short_labels)
    if quality < _HEADER_QUALITY_MIN_SCORE:
        return False
    return True


def _row_looks_like_data(ws: Worksheet, row_idx: int, c1: int, c2: int) -> bool:
    non_empty, text_count, numeric_count, unique_ratio, most_common_ratio, max_text_len = _row_stats_from_ws(
        ws, row_idx, c1, c2
    )
    if non_empty < _MIN_DATA_CELLS_PER_ROW:
        return False
    if most_common_ratio >= _ROW_REPEAT_RATIO_DATA_REJECT:
        return False
    if numeric_count > 0:
        return True
    if text_count >= 2 and unique_ratio >= 0.6:
        return True
    # -- Relaxed data detection for rows with repetitive string values ---
    # Loss run rows often contain many repeated zero-dollar amounts ("$0",
    # "$0.00") or identical status codes, causing unique_ratio to drop below
    # 0.6 even though the row is genuine data (not a header or empty row).
    # Accept such rows as data if they are well-filled AND at least one cell
    # looks like a currency/number pattern or a date-like string.
    if text_count >= 3:
        total_cols = c2 - c1 + 1
        fill_ratio = non_empty / total_cols if total_cols else 0.0
        if fill_ratio >= _DATA_FILL_RATIO_RELAXED:
            # Check for at least one currency, numeric string, or date-like value
            for c in range(c1, c2 + 1):
                v = ws.cell(row_idx, c).value
                if not isinstance(v, str):
                    continue
                vs = v.strip()
                if re.match(r"^\$[\d,.\-]+$", vs):
                    return True
                if re.match(r"^\d{1,2}/\d{1,2}/\d{2,4}$", vs):
                    return True
                if re.match(r"^\d[\d,.\-]*$", vs):
                    return True
    return False


def _row_is_category_super_header(ws: Worksheet, row_idx: int, c1: int, c2: int) -> bool:
    """Detect whether a row is a merged-cell category / group super-header.

    Category super-headers use wide merged cells to label groups of columns
    (e.g. "POLICY FACTS" spanning A1:H1, "CLAIM FACTS" spanning O1:Z1).
    When read cell-by-cell the merged regions appear as `None` except for
    the top-left cell, producing a very low fill rate.

    The function also examines the worksheet's `merged_cells` attribute to
    catch cases where moderate numbers of wide merges still cover a majority
    of the column span.

    Returns `True` when the row looks like a super-header rather than a
    genuine column header.
    """
    total_cols = c2 - c1 + 1
    if total_cols < 4:
        return False

    # --- raw fill-rate (no merged-cell expansion) ---
    non_empty = 0
    for c in range(c1, c2 + 1):
        v = ws.cell(row_idx, c).value
        if v not in (None, ""):
            non_empty += 1
    if non_empty == 0:
        return False

    fill_rate = non_empty / total_cols
    # Very low fill rate is a strong signal of merged category cells.
    if fill_rate < _CATEGORY_SUPER_HEADER_FILL_RATE:
        return True

    # --- merged-cell coverage check ---
    # Even with moderate fill rates, wide merges that cover >= 50 % of the
    # column span indicate a group-header row.
    if hasattr(ws, "merged_cells"):
        merged_col_count = 0
        for merged_range in ws.merged_cells.ranges:
            if merged_range.min_row <= row_idx <= merged_range.max_row:
                span_c1 = max(merged_range.min_col, c1)
                span_c2 = min(merged_range.max_col, c2)
                if span_c1 <= span_c2:
                    span_width = span_c2 - span_c1 + 1
                    if span_width >= 2:  # Only count actual multi-cell merges
                        merged_col_count += span_width
        if total_cols > 0 and merged_col_count / total_cols >= 0.5:
            return True

    return False


def _score_row_as_header(
    ws: Worksheet,
    row_idx: int,
    c1: int,
    c2: int,
    r2: int,
    require_data_below: bool = True,
) -> Optional[float]:
    """Unified header-row scoring - single source of truth for both detection paths.

    Returns a confidence score >= 0.0 when `row_idx` is a plausible column
    header, or `None` to hard-reject it. No local closures or regex
    blacklists; all judgements flow through module-level helpers so both
    `extract_table` and `extract_tables_from_block` share identical logic.

    Gates applied in order (cheapest first):
    1. Structural: fill ratio, text count, numeric count, repetition, label length.
    2. Total/subtotal keyword rejection.
    3. Data-below confirmation (row immediately below must look like data).
    4. Semantic quality gate via `_score_header_quality`.

    Composite score components (when all gates pass):
    - Fill density        0-10 (label coverage across columns)
    - Label uniqueness    0-10 (distinct values)
    - Semantic quality    0-15 (richness, diversity, structural variety)
    - Sort-arrow bonus    0-4  (unambiguous interactive-header signal)
    - Text-dominance      0-3  (proportion of text vs numeric cells)
    - Repetition penalty  0-5  (subtracted when values repeat)
    """
    total_cols = c2 - c1 + 1
    min_header_cells = max(_HEADER_MIN_CELLS_FLOOR, min(_HEADER_MIN_CELLS_CAP, int(total_cols * 0.25)))
    min_fill_ratio = _HEADER_FILL_RATIO_WIDE if total_cols >= 10 else _HEADER_FILL_RATIO_NARROW

    non_empty, text_count, numeric_count, unique_ratio, most_common_ratio, max_text_len = \
        _row_stats_from_ws(ws, row_idx, c1, c2)

    # -- Gate 1: structural ----------------------------------------------------
    if non_empty < min_header_cells:
        return None
    fill_ratio = non_empty / total_cols if total_cols else 0.0
    if fill_ratio < min_fill_ratio:
        return None
    if text_count < 2:
        return None
    # Allow up to 1/3 of cells to be numeric but reject data-dominated rows.
    if numeric_count > max(1, non_empty // 3):
        return None
    if most_common_ratio >= _ROW_REPEAT_RATIO_REJECT:
        return None
    if unique_ratio < 0.3:
        return None
    if max_text_len > _HEADER_LONG_LABEL_MAX_LEN:
        return None

    # -- Gate 2: total/subtotal keyword rejection ------------------------------
    text_strs = [
        str(ws.cell(row_idx, c).value).strip()
        for c in range(c1, c2 + 1)
        if isinstance(ws.cell(row_idx, c).value, str) and str(ws.cell(row_idx, c).value).strip()
    ]
    if text_strs:
        total_hits = [
            t for t in text_strs
            if re.search(r"\b(sub\s*total|subtotal|total|sum)\b", t, re.IGNORECASE)
        ]
        if total_hits and (len(total_hits) / len(text_strs)) >= 0.5:
            return None
        if len(text_strs) <= 2 and total_hits:
            return None

    # -- Gate 3: data-below confirmation ----------------------------------------
    # The row immediately below must look like a data row. Skipped when the
    # candidate is the last row of the block, or when the caller already knows
    # a data block exists below (above-block lookback path).
    if require_data_below and row_idx < r2 and not _row_looks_like_data(ws, row_idx + 1, c1, c2):
        return None

    # -- Gate 4: semantic quality -----------------------------------------------
    short_labels = [
        t for t in text_strs
        if len(t) <= _HEADER_TEXT_MAX_LEN_FOR_DETECTION
    ]
    quality = _score_header_quality(short_labels) if short_labels else 0.0
    if quality < _HEADER_QUALITY_MIN_SCORE:
        return None

    # -- Composite confidence score
    fill_score = min(fill_ratio * _HEADER_SCORE_FILL_CAP, _HEADER_SCORE_FILL_CAP)
    has_arrows = any(
        isinstance(cell_v := ws.cell(row_idx, c).value, str)
        and bool(re.search(r"[↑↓]", cell_v))
        for c in range(c1, c2 + 1)
    )
    score = (
        fill_score                             # 0-10: label density
        + unique_ratio * 10.0                  # 0-10: label uniqueness
        - most_common_ratio * 5.0              # -0-5: repetition penalty
        + quality * 15.0                       # 0-15: semantic richness
        + (4.0 if has_arrows else 0.0)         # 0-4:  sort-arrow bonus
        + min(text_count / total_cols, 1.0) * 3.0 # 0-3:  text-dominance
    )
    return score


def _detect_header_rows(
    ws: Worksheet,
    r1: int,
    c1: int,
    r2: int,
    c2: int,
    merged_map: Dict[Tuple[int, int], Any],
) -> List[int]:
    """Unified header-row detection - single algorithm shared by both table
    extraction paths.

    Returns an ordered list of row indices selected as column headers.
    Empty list only when the block is completely empty.

    Five phases, each building on the previous:

    Phase 1 - Score.
        Every row in the block is scored via `_score_row_as_header`.
        Rows that fail any hard gate (structural, total-keyword, data-below,
        quality) are discarded.

    Phase 2 - Super-header promotion.
        Merged-cell category headers ("POLICY FACTS" spanning the full width)
        are replaced by the real column-header row directly below them.

    Phase 3 - Above-block lookback.
        When the block starts well below the sheet top, search for an orphaned
        header row above the block (separated by an empty row that split the
        connected block during segmentation).

    Phase 4 - Multi-header Jaccard validation.
        The topmost surviving row is the primary header. Secondary candidates
        are kept only when >= 40 % of their labels overlap the primary - this
        handles repeated-header tables while rejecting keyword-rich data rows.

    Phase 5 - Escalating last-resort fallbacks.
        5a: Relax the data-below requirement (tiny / single-row blocks).
        5b: First non-empty row with sufficiently distinct values.
        5c: First non-empty row unconditionally (fully merged/repetitive blocks).
    """
    # -- Phase 1: score all rows -------------------------------------------------
    scored: List[Tuple[int, float]] = []
    for rr in range(r1, r2 + 1):
        s = _score_row_as_header(ws, rr, c1, c2, r2)
        if s is not None:
            scored.append((rr, s))

    # -- Phase 2: super-header promotion -----------------------------------------
    promoted: List[Tuple[int, float]] = []
    seen_rows: Set[int] = set()
    for row_idx, score in scored:
        if _row_is_category_super_header(ws, row_idx, c1, c2) and row_idx + 1 <= r2:
            below_score = _score_row_as_header(ws, row_idx + 1, c1, c2, r2)
            if below_score is not None:
                real_row = row_idx + 1
                if real_row not in seen_rows:
                    promoted.append((real_row, max(score, below_score)))
                    seen_rows.add(real_row)
                continue  # discard the super-header itself
        if row_idx not in seen_rows:
            promoted.append((row_idx, score))
            seen_rows.add(row_idx)
    scored = promoted

    # -- Phase 3: above-block lookback -------------------------------------------
    # If there are rows above the block, a header row defined outside the
    # block (orphaned by an empty-row gap) may be the true header. Gate 3
    # (data-below) is bypassed here because the block itself confirms data
    # exists below this candidate.
    if r1 > 1:
        search_start = max(1, r1 - _HEADER_LOOKBACK_ROWS)
        lb_best: Optional[Tuple[int, float]] = None
        for rr in range(search_start, r1):
            s = _score_row_as_header(ws, rr, c1, c2, r2, require_data_below=False)
            if s is not None and (lb_best is None or s > lb_best[1]):
                lb_best = (rr, s)
        if lb_best is not None:
            current_best = max((s for _, s in scored), default=None)
            lb_row, lb_score = lb_best
            if current_best is None or lb_score >= current_best + _HEADER_PROMOTION_SCORE_DELTA:
                scored = [(lb_row, lb_score)] + [x for x in scored if x[0] != lb_row]

    if scored:
        # Sort by row position: topmost = primary header.
        scored.sort(key=lambda x: x[0])

        # -- Phase 4: multi-header Jaccard validation --------------------------------
        # Primary header is trusted unconditionally. Secondary candidates
        # (repeated headers at section breaks) are accepted only when >= 40 %
        # of their labels appear in the primary header's label set.
        primary_row = scored[0][0]
        primary_texts: Set[str] = {
            v.strip().lower()
            for c in range(c1, c2 + 1)
            if isinstance(v := ws.cell(primary_row, c).value, str) and v.strip()
        }
        validated = [primary_row]
        for cand_row, _ in scored[1:]:
            cand_texts: Set[str] = {
                v.strip().lower()
                for c in range(c1, c2 + 1)
                if isinstance(v := ws.cell(cand_row, c).value, str) and v.strip()
            }
            if primary_texts and cand_texts:
                union = len(primary_texts | cand_texts)
                similarity = len(primary_texts & cand_texts) / union if union else 0.0
            else:
                similarity = 0.0
            if similarity >= 0.4:
                validated.append(cand_row)
        return sorted(validated)

    # -- Phase 5: escalating last-resort fallbacks -------------------------------
    total_cols = c2 - c1 + 1
    min_cells = max(_HEADER_MIN_CELLS_FLOOR, min(_HEADER_MIN_CELLS_CAP, int(total_cols * 0.25)))

    # 5a: Relax the data-below requirement - some tiny blocks have no data row.
    for rr in range(r1, r2 + 1):
        ne, tc, _, _, mcr, _ = _row_stats_from_ws(ws, rr, c1, c2)
        if ne < min_cells or tc < 2 or mcr >= _ROW_REPEAT_RATIO_REJECT:
            continue
        short_labels = [
            str(ws.cell(rr, c).value).strip()
            for c in range(c1, c2 + 1)
            if isinstance(ws.cell(rr, c).value, str)
            and str(ws.cell(rr, c).value).strip()
            and len(str(ws.cell(rr, c).value).strip()) <= _HEADER_TEXT_MAX_LEN_FOR_DETECTION
        ]
        if _score_header_quality(short_labels) >= _HEADER_QUALITY_MIN_SCORE:
            return [rr]

    # 5b: First non-empty row whose values are sufficiently distinct.
    for rr in range(r1, r2 + 1):
        ne, _, _, _, mcr, _ = _row_stats_from_ws(ws, rr, c1, c2)
        if ne > 0 and mcr < 0.85:
            return [rr]

    # 5c: Ultimate fallback - first non-empty row regardless of content.
    for rr in range(r1, r2 + 1):
        for c in range(c1, c2 + 1):
            cell_val = merged_map.get((rr, c)) if (rr, c) in merged_map else ws.cell(rr, c).value
            if cell_val not in (None, ""):
                return [rr]

    return []


def _build_headers_from_row(ws: Worksheet, row_idx: int, c1: int, c2: int, merged_map: Dict[Tuple[int, int], Any]) -> List[Dict[str, Any]]:
    headers = []
    for c in range(c1, c2 + 1):
        raw = ws.cell(row_idx, c).value
        if (row_idx, c) in merged_map:
            raw = merged_map[(row_idx, c)]
        # Treat pandas-generated "Unnamed: N" placeholder column names as None
        if _is_placeholder_coord_value(raw):
            raw = None
        text = str(raw).strip() if raw is not None else None
        headers.append({"text": text, "cell": a1(row_idx, c)})
    return headers


def _build_rows_from_range(
    ws: Worksheet,
    start_row: int,
    end_row: int,
    c1: int,
    c2: int,
    headers: List[Dict[str, Any]],
    merged_map: Dict[Tuple[int, int], Any],
) -> List[List[Dict[str, Any]]]:
    header_indices = [(idx, h) for idx, h in enumerate(headers) if h.get("text")]
    rows = []
    last_row_with_values = None
    for r in range(start_row, end_row + 1):
        row_obj = []
        for idx, h in header_indices:
            c = c1 + idx
            val = ws.cell(r, c).value
            if (r, c) in merged_map:
                val = merged_map[(r, c)]
            row_obj.append({"header": h["text"], "value": val, "cell": a1(r, c)})
        if any(v["value"] not in (None, "") for v in row_obj):
            rows.append(row_obj)
            last_row_with_values = r
    return rows


def extract_tables_from_block(ws: Worksheet, tl, br, context_below_row_limit: Optional[int] = None) -> List[Dict[str, Any]]:
    r1, c1 = tl
    r2, c2 = br

    # Build merged cell map scoped to the block range for efficiency.
    merged_map: Dict[Tuple[int, int], Any] = {}
    if hasattr(ws, "merged_cells"):
        for merged_range in ws.merged_cells.ranges:
            min_row, min_col, max_row, max_col = (
                merged_range.min_row,
                merged_range.min_col,
                merged_range.max_row,
                merged_range.max_col,
            )
            if max_row < r1 or min_row > r2 or max_col < c1 or min_col > c2:
                continue
            value = ws.cell(min_row, min_col).value
            for rr in range(min_row, max_row + 1):
                for cc in range(min_col, max_col + 1):
                    merged_map[(rr, cc)] = value

    # Detect all header rows using the unified algorithm.
    header_rows = _detect_header_rows(ws, r1, r2, c1, c2, merged_map)

    if not header_rows:
        return []
    tables: List[Dict[str, Any]] = []

    for idx, header_row in enumerate(header_rows):
        next_header = header_rows[idx + 1] if idx + 1 < len(header_rows) else None
        end_row = (next_header - 1) if next_header else r2

        header_cells = [
            (c, ws.cell(header_row, c).value)
            for c in range(c1, c2 + 1)
            if ws.cell(header_row, c).value not in (None, "")
        ]
        if not header_cells:
            continue
        span_c1 = min(c for c, _ in header_cells)
        span_c2 = max(c for c, _ in header_cells)

        headers = _build_headers_from_row(ws, header_row, span_c1, span_c2, merged_map)
        rows = _build_rows_from_range(ws, header_row + 1, end_row, span_c1, span_c2, headers, merged_map)

        # --- Detect sparse trailing rows that are really footnotes / context
        # If the table has >=4 header columns and the last N rows have values in
        # only 1-2 columns (while real data rows typically fill more), treat them
        # as below-table context instead of data rows.
        num_headers = len([h for h in headers if h.get("text")])
        context_below: List[Dict[str, Any]] = []
        if num_headers >= 4 and rows:
            trailing_context_rows: List[List[Dict[str, Any]]] = []
            while rows:
                last = rows[-1]
                filled = sum(1 for cell in last if cell.get("value") not in (None, ""))
                if filled <= 2:
                    trailing_context_rows.insert(0, rows.pop())
                else:
                    break

            # Convert the sparse trailing rows into context_below entries
            for trow in trailing_context_rows:
                for cell in trow:
                    val = cell.get("value")
                    if val not in (None, ""):
                        entry = {"cell": cell.get("cell"), "value": str(val).strip()}
                        if entry["value"] not in {e.get("value") for e in context_below}:
                            context_below.append(entry)

        # Compute range using header row and last data row with values (if any)
        last_data_row = header_row
        for row in rows:
            for cell in row:
                parsed = _parse_cell_ref(cell.get("cell") or "")
                if parsed:
                    last_data_row = max(last_data_row, parsed[0])

        table_range = f"{a1(header_row, span_c1)}:{a1(last_data_row, span_c2)}"

        # Scan beyond the block boundary for floating footnotes / disclaimers
        # that sit below the last data row.
        # context_below_row_limit, when set, prevents the scan from bleeding
        # into the next table block on multi-table sheets.
        sheet_max_row = ws.max_row or end_row
        scan_end = min(sheet_max_row, last_data_row + 10)
        if context_below_row_limit is not None:
            scan_end = min(scan_end, context_below_row_limit - 1)
        for scan_row in range(last_data_row + 1, scan_end + 1):
            row_has_value = False
            for col in range(span_c1, span_c2 + 1):
                val = ws.cell(scan_row, col).value
                if val and str(val).strip():
                    entry = {"cell": a1(scan_row, col), "value": str(val).strip()}
                    if entry["value"] not in {e.get("value") for e in context_below}:
                        context_below.append(entry)
                    row_has_value = True
            # Stop scanning if we hit 2 consecutive fully-empty rows
            if not row_has_value and scan_row > last_data_row + 1:
                prev_had = any(
                    ws.cell(scan_row - 1, c).value not in (None, "")
                    for c in range(span_c1, span_c2 + 1)
                )
                if not prev_had:
                    break

        # Context: collect text above the header row within the original block bounds
        # Produce structured context_above with cell references (matching extract_table output)
        context_above: List[Dict[str, Any]] = []
        for rr in range(r1, header_row):
            for cc in range(c1, c2 + 1):
                val = ws.cell(rr, cc).value
                if val and str(val).strip() and not _is_placeholder_coord_value(val):
                    context_above.append({"cell": a1(rr, cc), "value": str(val).strip()})
        seen = set()
        context_above_unique: List[Dict[str, Any]] = []
        header_texts = {h["text"] for h in headers if h.get("text")}
        for entry in context_above:
            val_text = entry["value"]
            if val_text in header_texts:
                continue
            if val_text not in seen:
                context_above_unique.append(entry)
                seen.add(val_text)

        # Build plain-text context from above and below entries
        all_context_texts = [e["value"] for e in context_above_unique]
        all_context_texts.extend([e["value"] for e in context_below])
        context = "\n".join(all_context_texts) if all_context_texts else None

        # --- Compute header confidence score
        total_cols_span = span_c2 - span_c1 + 1
        _hc_stats = _row_stats_from_ws(ws, header_row, span_c1, span_c2)
        _hc_ne, _hc_txt, _hc_num, _hc_uq, _hc_mc, _hc_ml = _hc_stats
        _hc_fill = (_hc_ne / total_cols_span) if total_cols_span else 0.0
        _hc_text_ratio = (_hc_txt / _hc_ne) if _hc_ne else 0.0
        _hc_data_rows = len(rows)
        header_confidence = round(min(1.0, (
            min(_hc_fill, 1.0) * 0.30
            + min(_hc_uq, 1.0) * 0.25
            + _hc_text_ratio * 0.20
            + (1.0 - _hc_mc) * 0.10
            + min(_hc_data_rows / 5, 1.0) * 0.15
        )), 3)

        result = {
            "type": "table",
            "range": table_range,
            "headers": headers,
            "rows": rows,
            "header_confidence": header_confidence,
        }
        if context:
            result["context"] = context
        if context_above_unique:
            result["context_above"] = context_above_unique
        if context_below:
            result["context_below"] = context_below
        tables.append(result)

    return tables
