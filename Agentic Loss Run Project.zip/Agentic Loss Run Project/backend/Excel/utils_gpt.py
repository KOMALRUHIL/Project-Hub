import ast
import asyncio
import atexit
import httpx
import json
import logging
import os
import threading
import random
import re

from config_runtime import call_active_inputs_helper
from constants import (
    API_CALL_TIMEOUT_SECONDS,
    API_MAX_RETRY_ATTEMPTS,
    API_RETRY_BASE_DELAY,
    API_RETRY_MAX_DELAY,
    API_USE_CASE,
    LLM_ERROR_LOG_PATH,
    MAX_CONCURRENT_API_CALLS,
)
from utils import sanitize_text_for_safety, log_cli

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Per-call timeout (seconds). Covers the full round-trip including reading
# the response body. If the API hasn't replied in this window the call is
# aborted and retried.
# ---------------------------------------------------------------------------
API_CALL_TIMEOUT: float = API_CALL_TIMEOUT_SECONDS
_api_semaphore = threading.Semaphore(MAX_CONCURRENT_API_CALLS)
_reasoning_effort_notice_lock = threading.Lock()
_reasoning_effort_notice_cache: set[tuple[str, str]] = set()

# ---------------------------------------------------------------------------
# Persistent background event loop - a single asyncio event loop runs on a dedicated
# daemon thread for the lifetime of the process. All async work (httpx calls,
# sleeps, etc.) is submitted to this loop via run_coroutine_threadsafe().
#
# This avoids the "Event loop is closed" bug that occurs when asyncio.run()
# is used repeatedly: each asyncio.run() creates a new loop and **closes** it
# on exit, invalidating the transports held by the shared httpx.AsyncClient.
# ---------------------------------------------------------------------------
_bg_loop = asyncio.new_event_loop()
_bg_thread = threading.Thread(target=_bg_loop.run_forever, daemon=True, name="api-event-loop")
_bg_thread.start()

def _shutdown_bg_loop() -> None:
    """Gracefully stop the background event loop at interpreter exit."""
    _bg_loop.call_soon_threadsafe(_bg_loop.stop)
    _bg_thread.join(timeout=5)

atexit.register(_shutdown_bg_loop)

# ---------------------------------------------------------------------------
# Persistent httpx.AsyncClient - reused across all API calls to avoid
# connection-setup overhead (~50-100ms per call on Windows). Lazily
# initialised on first use and shut down via atexit.
# ---------------------------------------------------------------------------
_persistent_client: httpx.AsyncClient | None = None
_persistent_client_lock = threading.Lock()


def _get_persistent_client() -> httpx.AsyncClient:
    """Return the shared httpx.AsyncClient, creating it on first call."""
    global _persistent_client
    if _persistent_client is not None and not _persistent_client.is_closed:
        return _persistent_client
    with _persistent_client_lock:
        # Double-check after acquiring the lock
        if _persistent_client is not None and not _persistent_client.is_closed:
            return _persistent_client
        timeout = httpx.Timeout(
            timeout=API_CALL_TIMEOUT,      # overall default
            connect=30.0,                  # connection establishment
            read=API_CALL_TIMEOUT,         # waiting for the response body
            write=60.0,                    # sending the request body
            pool=60.0,                     # waiting for a connection from the pool
        )
        _persistent_client = httpx.AsyncClient(timeout=timeout)
        return _persistent_client


def _close_persistent_client() -> None:
    """Shut down the shared httpx.AsyncClient if it was created."""
    global _persistent_client
    if _persistent_client is not None:
        try:
            # Close the client on the background loop where it was created.
            if _bg_loop.is_running():
                fut = asyncio.run_coroutine_threadsafe(
                    _persistent_client.aclose(), _bg_loop
                )
                fut.result(timeout=5)
            else:
                # Loop already stopped (unlikely) - best-effort.
                asyncio.run(_persistent_client.aclose())
        except Exception:
            pass
        _persistent_client = None


atexit.register(_close_persistent_client)


class ContextLengthExceededError(Exception):
    """Raised when the API returns a context_length_exceeded error (HTTP 400)."""
    pass


class UnsupportedReasoningEffortError(Exception):
    """Raised when the backend rejects the reasoning_effort request parameter."""
    pass


def _supports_reasoning_effort(model_name: str) -> bool:
    """Return True when the deployment appears to support GPT-5 reasoning effort."""
    normalized_name = (model_name or "").lower()
    return "gpt-5" in normalized_name


def _print_reasoning_effort_notice(model_name: str, reasoning_effort: str) -> None:
    """Print a once-per-model CLI notice when reasoning effort is sent."""
    normalized_model = str(model_name or "").strip() or "<unknown-model>"
    normalized_effort = str(reasoning_effort or "").strip().lower() or "medium"
    cache_key = (normalized_model, normalized_effort)

    with _reasoning_effort_notice_lock:
        if cache_key in _reasoning_effort_notice_cache:
            return
        _reasoning_effort_notice_cache.add(cache_key)

    log_cli(
        f"[LLM] Invoking {normalized_model} with reasoning_effort='{normalized_effort}'."
    )


def print_llm_startup_notice() -> None:
    """Eagerly print the LLM model / reasoning-effort notice at CLI startup.

    Call this once from `main.py` so the notice appears at the very top of
    the run output instead of mid-stream when the first API call fires.
    The internal cache is primed so the message is never repeated later.
    """
    from models import get_active_model, get_utility_model  # local import to avoid circular deps
    model_cfg = get_active_model()
    model_name = model_cfg.get("model_name", "<unknown-model>")
    effort = str(call_active_inputs_helper("get_agentic_reasoning_effort", default="medium") or "medium")
    _print_reasoning_effort_notice(model_name, effort)

    utility_cfg = get_utility_model()
    utility_name = utility_cfg.get("model_name", "<unknown-model>")
    utility_effort = str(call_active_inputs_helper("get_utility_reasoning_effort", default="low") or "low")
    log_cli(f"[LLM] Utility model (relevancy / validation): {utility_name} (reasoning_effort='{utility_effort}')")


def exponential_backoff(base_delay=API_RETRY_BASE_DELAY, max_delay=API_RETRY_MAX_DELAY, factor=2, jitter=True):
    delay = base_delay
    while True:
        yield delay
        if jitter:
            # Adding jitter to spread out the retries
            delay = min(max_delay, delay * factor) * (0.5 + random.random() / 2)
        else:
            delay = min(max_delay, delay * factor)


def call_api_with_retries(model_name, params, headers, json, max_attempts=API_MAX_RETRY_ATTEMPTS, endpoint_url=None):
    """Synchronous wrapper around the async HTTP call.

    Internally uses ``httpx.AsyncClient`` for true async I/O with a
    per-call timeout of ``API_CALL_TIMEOUT`` seconds.
    """
    if not endpoint_url:
        if str(model_name).startswith("http"):
            endpoint_url = model_name
        else:
            azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT") or os.getenv("AZURE_OPENAI_BASE_URL")
            openai_key = os.getenv("OPENAI_API_KEY")
            if azure_endpoint:
                endpoint = azure_endpoint.rstrip("/")
                deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME") or model_name
                endpoint_url = f"{endpoint}/openai/deployments/{deployment}/chat/completions"
            elif openai_key:
                endpoint_url = "https://api.openai.com/v1/chat/completions"
            else:
                endpoint_url = f"https://cortex.aws.lmig.com/rest/v2/azure/openai/deployments/{model_name}/chat/completions"

    _api_semaphore.acquire()
    try:
        future = asyncio.run_coroutine_threadsafe(
            _async_call_api(endpoint_url, params, headers, json, max_attempts),
            _bg_loop,
        )
        return future.result()
    finally:
        _api_semaphore.release()


async def _async_call_api(endpoint_url, params, headers, json_body, max_attempts=API_MAX_RETRY_ATTEMPTS):
    """Core async implementation using the persistent httpx.AsyncClient."""
    retries = exponential_backoff()
    client = _get_persistent_client()

    for attempt in range(max_attempts):
        try:
            resp = await client.post(
                endpoint_url,
                params=params,
                headers=headers,
                json=json_body,
            )
            resp.raise_for_status()
            response = resp.json()

            # Always extract token usage first - even filtered calls consume tokens.
            usage = response.get('usage', {}) or {}
            input_tokens = usage.get('prompt_tokens', 0) or 0
            output_tokens = usage.get('completion_tokens', 0) or 0

            # Check for content filter
            filter_results = response.get('choices', [{}])[0].get('content_filter_results', {})
            filtered_categories = [k for k, v in filter_results.items() if isinstance(v, dict) and v.get('filtered')]
            if filtered_categories:
                log_cli(f"Content filtered in categories: {filtered_categories}. Disregarding.")
                return "", input_tokens, output_tokens

            content = response.get('choices', [{}])[0].get('message', {}).get('content', "")

            return content, input_tokens, output_tokens

        except httpx.HTTPStatusError as e:
            status_code = e.response.status_code if e.response is not None else None
            response_text = e.response.text[:1000] if e.response is not None else ""

            log_cli(
                f"API call failed with HTTP {status_code}: {e}."
                + (f" Response: {response_text}" if response_text else "")
            )

            # Detect context_length_exceeded specifically so callers can reduce payload and retry
            if status_code == 400 and response_text and "context_length_exceeded" in response_text:
                raise ContextLengthExceededError(
                    f"Input tokens exceed the model context limit. Response: {response_text}"
                )

            if (
                status_code == 400
                and response_text
                and "reasoning_effort" in response_text.lower()
            ):
                raise UnsupportedReasoningEffortError(response_text)

            # Do not retry non-rate-limit 4xx errors
            if status_code is not None and 400 <= status_code < 500 and status_code != 429:
                return "", 0, 0

            delay = next(retries)
            log_cli(f"[{threading.current_thread().name}] Retrying in {delay:.2f} seconds...")
            await asyncio.sleep(delay)

        except (httpx.TimeoutException, httpx.ConnectError) as e:
            delay = next(retries)
            log_cli(
                f"[{threading.current_thread().name}] API call timed out or connection failed ({type(e).__name__}: {e}). "
                f"Retrying in {delay:.2f} seconds... (attempt {attempt + 1}/{max_attempts})"
            )
            await asyncio.sleep(delay)

        except Exception as e:
            delay = next(retries)
            log_cli(f"[{threading.current_thread().name}] API call failed with error: {e}. Retrying in {delay:.2f} seconds...")
            await asyncio.sleep(delay)

    endpoint_url = (
        f"https://cortex.aws.lmig.com/rest/v2/azure/openai/deployments/"
        f"{model_name}/chat/completions"
    )
    log_cli(
        f"[FATAL] API call to model='{model_name}' ({endpoint_url}) "
        f"failed after {max_attempts} attempts. Returning empty response."
    )
    return "", 0, 0


def _is_valid_json(text: str) -> bool:
    try:
        json.loads(text)
        return True
    except Exception:
        return False


def _extract_balanced_json(text: str, start_idx: int) -> str | None:
    stack = []
    in_string = False
    escape = False
    for i in range(start_idx, len(text)):
        ch = text[i]
        if in_string:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_string = False
            continue

        if ch == '"':
            in_string = True
            continue

        if ch in "[{":
            stack.append(ch)
        elif ch in "]}":
            if not stack:
                continue
            open_ch = stack.pop()
            if (open_ch == "{" and ch != "}") or (open_ch == "[" and ch != "]"):
                return None
            if not stack:
                return text[start_idx:i + 1]
    return None


def _safe_eval_arithmetic(node: ast.AST) -> int | float:
    """Recursively evaluate a simple arithmetic AST without ``eval()``.

    Only supports numeric literals and the four basic operators (+, -, *, /).
    Raises ``ValueError`` for any unsupported AST node.
    """
    if isinstance(node, ast.Expression):
        return _safe_eval_arithmetic(node.body)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    # ast.Num is deprecated but needed for Python <3.8 compatibility
    if isinstance(node, ast.Num):  # type: ignore[attr-defined]
        return node.n  # type: ignore[attr-defined]
    if isinstance(node, ast.UnaryOp):
        operand = _safe_eval_arithmetic(node.operand)
        if isinstance(node.op, ast.USub):
            return -operand
        if isinstance(node.op, ast.UAdd):
            return +operand
        raise ValueError(f"Unsupported unary op: {type(node.op).__name__}")
    if isinstance(node, ast.BinOp):
        left = _safe_eval_arithmetic(node.left)
        right = _safe_eval_arithmetic(node.right)
        if isinstance(node.op, ast.Add):
            return left + right
        if isinstance(node.op, ast.Sub):
            return left - right
        if isinstance(node.op, ast.Mult):
            return left * right
        if isinstance(node.op, ast.Div):
            if right == 0:
                raise ValueError("division by zero")
            return left / right
        raise ValueError(f"Unsupported binary op: {type(node.op).__name__}")
    raise ValueError(f"Unsupported AST node: {type(node).__name__}")


# Pre-compiled regex for stripping thousands-separator commas in numbers.
# Compiled once at module level to avoid thrashing Python's internal 512-entry
# regex cache when _normalize_numeric_expressions is called under heavy load.
_THOUSANDS_SEP_RE = re.compile(r'(?<![^\w])(\d{1,3})(?:,\d{3})+(?![^\w])')


def _normalize_numeric_expressions(text: str) -> str:
    """Attempt to evaluate simple arithmetic expressions that appear as JSON values

    (e.g. ``"total": 1+2`` -> ``"total": 3``) and strip thousands-separator commas
    inside numbers (e.g. ``1,000`` -> ``1000`` when it is clearly a number).
    Returns the (possibly unchanged) text.
    """
    if not text:
        return text

    # Replace arithmetic expressions used as JSON values: digits/operators between
    # a colon (or array comma/bracket) and the next comma / brace / bracket.
    def _eval_expr(m: re.Match) -> str:
        expr = m.group(1).strip()
        try:
            result = ast.literal_eval(expr)
            if isinstance(result, (int, float)):
                return m.group(0).replace(expr, str(result))
        except Exception:
            pass
        # If not a literal, try safe arithmetic of simple numeric expressions.
        # Length-limited to mitigate risk from LLM-derived content.
        if re.fullmatch(r'[\d\s\+\-\*\/\.\(\)]+', expr) and len(expr) <= 50:
            try:
                tree = ast.parse(expr, mode='eval')
                result = _safe_eval_arithmetic(tree)
                if isinstance(result, (int, float)):
                    return m.group(0).replace(expr, str(result))
            except (ValueError, TypeError, SyntaxError):
                pass
        return m.group(0)

    # Match numeric-looking expressions after : or [ or ,
    text = re.sub(r'(?<=[:,\[])\s*([\d\s\+\-\*\/\.\(\)]+)(?=[,\]\}])', _eval_expr, text)

    # Strip thousands-separator commas inside numbers: e.g. 1,000,000 -> 1000000
    # Uses module-level pre-compiled _THOUSANDS_SEP_RE (Issue #13 fix).
    text = _THOUSANDS_SEP_RE.sub(lambda m: m.group(0).replace(",", ""), text)

    return text


def _try_normalize_as_json(text: str) -> str | None:
    """Try normalizing numeric expressions; return valid JSON or None."""
    normalized = _normalize_numeric_expressions(text)
    if normalized != text and _is_valid_json(normalized):
        log_cli("[WARN] LLM output had numeric expressions. Evaluated to numbers.")
        return normalized
    return None


def _coerce_json_text(raw_output: str) -> str | None:
    if raw_output is None:
        return None
    text = str(raw_output).strip()
    if not text:
        return None

    fence_match = re.search(r"```(?:json)?\s*(.*?)\s*```", text, flags=re.DOTALL | re.IGNORECASE)
    if fence_match:
        text = fence_match.group(1).strip()

    # Short-circuit: try parsing as-is before any normalization
    if _is_valid_json(text):
        return text

    # Only normalize when initial parse failed
    result = _try_normalize_as_json(text)
    if result is not None:
        return result

    for i, ch in enumerate(text):
        if ch in "[{":
            candidate = _extract_balanced_json(text, i)
            if candidate and _is_valid_json(candidate):
                return candidate
            # Only normalize the candidate when initial parse failed
            if candidate:
                result = _try_normalize_as_json(candidate)
                if result is not None:
                    return result
    return None


def gpt_call(
    prompt,
    model_name,
    api_version,
    temperature=0,
    skip_json_coercion=False,
    system_message=None,
    reasoning_effort_override=None,
):
    """Call the Cortex LLM API.

    Parameters
    ----------
    prompt : str
        The user-message content sent to the model.
    model_name : str
        Deployed model name (e.g. ``"gpt-5-2"``).
    api_version : str
        API version string.
    temperature : int | float
        Sampling temperature (ignored for gpt-5 variants).
    skip_json_coercion : bool
        When ``True`` the raw text is returned without JSON extraction.
    system_message : str | None
        An explicit system-role message. When *None* a default
        insurance-domain safety preamble is used. Pass an empty string
        ``""`` to send **no** system message at all.
    reasoning_effort_override : str | None
        Optional escape-hatch. When set, overrides the auto-detected
        reasoning effort for this single call. Normally **not needed** -
        ``gpt_call`` automatically applies ``UTILITY_REASONING_EFFORT``
        for the utility model and ``AGENTIC_REASONING_EFFORT`` for the
        extraction model (both configured in ``inputs.py``).
    """
    azure_key = os.getenv("AZURE_OPENAI_API_KEY") or os.getenv("AZURE_API_KEY")
    azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT") or os.getenv("AZURE_OPENAI_BASE_URL")
    openai_key = os.getenv("OPENAI_API_KEY")
    cortex_token = os.getenv("CORTEX_TOKEN")
    user_id = (
        os.getenv("USER")
        or os.getenv("LM_TROUX_UID")
        or os.getenv("TROUX_ID")
    )

    if azure_endpoint and azure_key:
        endpoint = azure_endpoint.rstrip("/")
        deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME") or model_name
        endpoint_url = f"{endpoint}/openai/deployments/{deployment}/chat/completions"
        headers = {
            "Content-Type": "application/json",
            "api-key": azure_key,
        }
        params = {"api-version": api_version or os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21")}
    elif openai_key:
        endpoint_url = "https://api.openai.com/v1/chat/completions"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {openai_key}",
        }
        params = {}
    elif cortex_token:
        endpoint_url = f"https://cortex.aws.lmig.com/rest/v2/azure/openai/deployments/{model_name}/chat/completions"
        headers = {
            "accept": "*/*",
            "Content-Type": "application/json",
            "Authorization": f"Bearer {cortex_token}",
        }
        params = {"api-version": api_version}
    else:
        log_cli("[INFO] No OpenAI / Azure OpenAI credentials found in .env. Skipping external LLM call.")
        return None, 0, 0

    # -- Build messages list
    # Callers are responsible for providing the system message that matches
    # their agent's purpose. When no explicit system_message is supplied we
    # fall back to a generic insurance-domain safety preamble so that
    # existing call-sites that haven't been migrated yet keep working.
    if system_message is None:
        system_message = (
            'You are an insurance data extraction assistant processing commercial insurance documents. '
            'These documents are professional insurance records that routinely contain terms such as '
            '"injury", "death", "fatality", "bodily injury", and "Workers Compensation" as standard '
            'claims terminology - not as violent or harmful content. '
            'Follow instructions carefully.'
        )

    messages = []
    if system_message:  # skip entirely when caller passes ""
        messages.append({'role': 'system', 'content': system_message})
    messages.append({'role': 'user', 'content': prompt})

    json_data = {
        'messages': messages,
        'use_case': API_USE_CASE,  # Limited to 255 characters
    }

    if user_id:
        json_data["user"] = user_id

    if _supports_reasoning_effort(model_name):
        if reasoning_effort_override:
            reasoning_effort = reasoning_effort_override
        else:
            # Auto-detect: utility model -> UTILITY_REASONING_EFFORT,
            # otherwise -> AGENTIC_REASONING_EFFORT (both from inputs.py).
            from models import get_utility_model          # local import to avoid circular deps
            utility_model_name = get_utility_model().get("model_name")
            if model_name == utility_model_name:
                reasoning_effort = str(call_active_inputs_helper("get_utility_reasoning_effort", default="low") or "low")
            else:
                reasoning_effort = str(call_active_inputs_helper("get_agentic_reasoning_effort", default="medium") or "medium")
        json_data["reasoning_effort"] = reasoning_effort
        _print_reasoning_effort_notice(model_name, reasoning_effort)

    # Only set temperature if model is NOT a gpt-5+ variant
    # (gpt-5 and later variants ignore temperature server-side)
    if not any(tag in model_name for tag in ("gpt-5")):
        json_data['temperature'] = temperature

    try:
        output, input_tokens, output_tokens = call_api_with_retries(
            model_name=model_name,
            params=params,
            headers=headers,
            json=json_data,
            endpoint_url=endpoint_url
        )
    except UnsupportedReasoningEffortError:
        if "reasoning_effort" not in json_data:
            log_cli("[ERROR] Backend rejected reasoning effort, but no reasoning parameter was sent.")
            return None, 0, 0

        log_cli("[WARN] Backend rejected reasoning_effort. Retrying without it.")
        json_data.pop("reasoning_effort", None)
        try:
            output, input_tokens, output_tokens = call_api_with_retries(
                model_name=model_name,
                params=params,
                headers=headers,
                json=json_data,
                endpoint_url=endpoint_url
            )
        except ContextLengthExceededError as exc:
            log_cli(f"[ERROR] Context length exceeded: {exc}")
            return None, 0, 0
    except ContextLengthExceededError as exc:
        log_cli(f"[ERROR] Context length exceeded: {exc}")
        return None, 0, 0

    if not output and not skip_json_coercion and input_tokens == 0:
        # Only attempt sanitized-prompt retry when we got zero tokens back,
        # meaning the request itself failed (not a content-filter on the
        # output). When input_tokens > 0 the model DID run but the output
        # was content-filtered; re-sending a sanitised prompt won't change
        # the output filter and just wastes a duplicate LLM call.
        sanitized_prompt = sanitize_text_for_safety(prompt)
        if sanitized_prompt != prompt:
            log_cli("[WARN] Retrying with sanitized prompt due to empty/filtered output.")
            # Update the user message (always the last entry in the messages list)
            json_data["messages"][-1]["content"] = sanitized_prompt
            output_retry, input_tokens_retry, output_tokens_retry = call_api_with_retries(
                model_name=model_name,
                params=params,
                headers=headers,
                json=json_data
            )
            if output_retry:
                output = output_retry
                input_tokens += input_tokens_retry
                output_tokens += output_tokens_retry

    # --- Enhanced error handling for filtered/invalid JSON output ---
    if not output:
        log_cli("[ERROR] LLM output was empty or filtered. Skipping this chunk.")
        return None, input_tokens, output_tokens

    # Code-generation callers (e.g. extraction logic generator) set skip_json_coercion=True
    # so the raw text is returned as-is without JSON extraction stripping away Python code.
    if skip_json_coercion:
        return output, input_tokens, output_tokens

    if not _is_valid_json(output):
        extracted = _coerce_json_text(output)
        if extracted:
            log_cli("[WARN] LLM output was not strict JSON. Using extracted JSON payload.")
            return extracted, input_tokens, output_tokens

        log_cli("[ERROR] LLM output was not valid JSON. Logging and skipping.")
        try:
            with open(LLM_ERROR_LOG_PATH, "a", encoding="utf-8") as f:
                f.write(f"Prompt:\n{prompt}\nOutput:\n{output}\n\n")
        except OSError as _log_err:
            log_cli(f"[WARN] Could not write to LLM error log: {_log_err}")
        return None, input_tokens, output_tokens

    return output, input_tokens, output_tokens
