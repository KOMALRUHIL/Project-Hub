"""Pipeline inputs: schema definition + extraction instructions + relevancy config.

This file contains the main pieces that change from use-case to use-case:

  1. **Output Schema** (``ClaimRecord``) - defines every column, type,
     format, and constraint for the extraction output DataFrame.
  2. **Extraction Instructions** (``EXTRACTION_INSTRUCTIONS``) - domain
     rules for how to interpret source data and populate schema fields.
  3. **Relevancy Configuration** - file-name keywords for fast-pass
     filtering and LLM-based relevancy instructions for classifying
     whether a file/sheet contains data worth extracting.
  4. **Pipeline Model Selection** (``AGENTIC_MODEL``) - the active LLM
     configuration used across the agentic pipeline.

All agents (code generation, validation, etc.) receive these as plain text
via ``get_schema_text()``, ``get_instructions_text()``,
``get_relevancy_keywords()``, ``get_relevancy_instructions()``, and
``get_sheet_relevancy_instructions()``.

To adapt the pipeline for a different use-case, edit THIS file only.
"""

from __future__ import annotations

from typing import Any, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field


# -----------------------------------------------------------------------------
# Pipeline model selection
# -----------------------------------------------------------------------------
# Single source of truth for the active LLM used by the pipeline. Change this
# value here instead of setting AGENTIC_MODEL in .env.
#
# Valid options:
#   GPT_4_1, GPT_4_1_MINI, GPT_5, GPT_5_MINI, GPT_5_1, GPT_5_2, GPT_5_4
# -----------------------------------------------------------------------------

AGENTIC_MODEL: str = "GPT_5"


# -----------------------------------------------------------------------------
# CLI logging mode
# -----------------------------------------------------------------------------
# Single source of truth for the pipeline's default CLI logging behavior.
# Change this value to control the default logging mode everywhere.
#
# Valid options:
#   concise, verbose
# -----------------------------------------------------------------------------

CLI_LOG_MODE: Literal["concise", "verbose"] = "verbose"


def get_cli_log_mode_setting() -> str:
    """Return the configured default CLI log mode for the pipeline."""
    mode = str(CLI_LOG_MODE).strip().lower()
    if mode not in {"concise", "verbose"}:
        return "concise"
    return mode


# -----------------------------------------------------------------------------
# Utility model - used for lightweight LLM tasks
# -----------------------------------------------------------------------------
# Relevancy detection, sheet classification, and validation code generation
# are simple classification / code-gen tasks that don't need the full
# extraction model. A cheaper mini model saves 3-6x on token cost.
#
# Valid options (same as AGENTIC_MODEL above):
#   GPT_4_1, GPT_4_1_MINI, GPT_5, GPT_5_MINI, GPT_5_1, GPT_5_2, GPT_5_4
# -----------------------------------------------------------------------------

UTILITY_MODEL: str = "GPT_5"


def get_utility_model_key() -> str:
    """Return the configured model key for lightweight utility tasks."""
    return UTILITY_MODEL.strip().upper()


# -----------------------------------------------------------------------------
# Pipeline reasoning effort selection
# -----------------------------------------------------------------------------
# Explicit reasoning setting for reasoning-capable models. This is mainly
# relevant for GPT-5 family deployments. Valid options:
#   low, medium, high
#
# AGENTIC_REASONING_EFFORT - used by the extraction code-generation model.
# UTILITY_REASONING_EFFORT - used by lightweight utility tasks (relevancy
#                            detection, sheet classification, validation
#                            code generation). "low" is recommended since
#                            these tasks are simple classification / code-gen
#                            and don't benefit from deep reasoning.
# -----------------------------------------------------------------------------

AGENTIC_REASONING_EFFORT: Literal["low", "medium", "high"] = "medium"
UTILITY_REASONING_EFFORT: Literal["low", "medium", "high"] = "medium"


def get_agentic_model_key() -> str:
    """Return the configured active model key for the pipeline."""
    return AGENTIC_MODEL.strip().upper()


def get_agentic_reasoning_effort() -> str:
    """Return the configured reasoning effort for the extraction model, defaulting safely to medium."""
    effort = str(AGENTIC_REASONING_EFFORT).strip().lower()
    if effort not in {"low", "medium", "high"}:
        return "medium"
    return effort


def get_utility_reasoning_effort() -> str:
    """Return the configured reasoning effort for utility-model tasks, defaulting to low."""
    effort = str(UTILITY_REASONING_EFFORT).strip().lower()
    if effort not in {"low", "medium", "high"}:
        return "low"
    return effort


# -----------------------------------------------------------------------------
# Schema model
# -----------------------------------------------------------------------------


class ClaimRecord(BaseModel):
    """Schema for a single extracted insurance claim record.

    Every column in the output DataFrame corresponds to a field on this model.
    """

    model_config = ConfigDict(extra="forbid")

    claim_id: Optional[str] = Field(
        None,
        description=(
            "Claim identifier from the source. "
            "Typically numeric or alphanumeric, but not always. "
            "Long purely-numeric IDs (10-18 digits) are extremely common in "
            "insurance systems and are ALWAYS valid claim identifiers - do "
            "NOT misinterpret them as dates, dollar amounts, or phone numbers. "
            "This field is optional - set to None if no claim number column exists."
        ),
    )
    claimant: Optional[str] = Field(
        None,
        description=(
            "Name of the claimant or injured party. "
            "Typically a person or entity name - not always present for a given claim. "
            "NEVER put numeric amounts, dates, flag values (Y/N), "
            "or status codes here - those belong in other columns."
        ),
    )
    policy_number: Optional[str] = Field(
        None,
        description=(
            "Policy number associated with the claim. "
            "Can be numeric (e.g. '12345') or alphanumeric (e.g. 'POL-2024-001'). "
            "NEVER use flag values (Y/N), status codes, or date values here."
        ),
    )
    policy_effective_date: Optional[str] = Field(
        None,
        description="Policy effective date in MM/DD/YYYY format.",
        json_schema_extra={"format": "MM/DD/YYYY"},
    )
    policy_expiration_date: Optional[str] = Field(
        None,
        description="Policy expiration date in MM/DD/YYYY format.",
        json_schema_extra={"format": "MM/DD/YYYY"},
    )
    line_of_business: Optional[Literal["property", "auto", "general liability", "workers compensation", "umbrella"]] = Field(
        None,
        description="Line of business. Must be one of: property, auto, general liability, workers compensation, umbrella.",
    )
    subline: Optional[str] = Field(
        None,
        description=(
            "Sub-classification within the line of business. "
            "For auto: must be 'AL' (Auto Liability) or 'APD' (Auto Physical Damage). Cannot be None."
            "All other lines can be the appropriate value or null."
            "For workers compensation: use descriptive values such as 'Medical', "
            "'Indemnity', or 'Employer's Liability'; normalize coded source values "
            "like 'MO', 'IN', and 'EL' to those descriptive labels. "
            "For other lines: free text or None."
        ),
    )
    accident_date: Optional[str] = Field(
        None,
        description="Date the accident / loss occurred in MM/DD/YYYY format.",
        json_schema_extra={"format": "MM/DD/YYYY"},
    )
    report_date: Optional[str] = Field(
        None,
        description="Date the claim was reported in MM/DD/YYYY format.",
        json_schema_extra={"format": "MM/DD/YYYY"},
    )
    accident_state: Optional[str] = Field(
        None,
        description=(
            "2-letter US state code where the accident occurred (e.g. 'MA'). "
            "Canada district/province codes are also acceptable if the claim is from Canada (e.g. 'ON' for Ontario). "
            "2-letter state or province code where the accident occurred "
            "(e.g. 'MA', 'ON', 'AB'). Accepts US states, Canadian provinces, "
            "and other internationally recognized 2-letter region codes."
        ),
        json_schema_extra={"format": "2-letter code"},
    )
    driver: Optional[str] = Field(
        None,
        description=(
            "Driver name. Populate ONLY for Auto APD claims; otherwise None. "
            "Must be a person name containing letters - not a flag, date, or number."
        ),
    )
    garage_state: Optional[str] = Field(
        None,
        description="Garage state. Populate ONLY for Auto APD claims; otherwise None. 2-letter US/Canada code.",
        json_schema_extra={"format": "2-letter code"},
    )
    coverage_state: Optional[str] = Field(
        None,
        description="Coverage state. Populate ONLY for General Liability claims; otherwise None. 2-letter US/Canada code.",
        json_schema_extra={"format": "2-letter code"},
    )

    claim_description: Optional[str] = Field(
        None,
        description=(
            "Narrative description of the claim / accident / injury. "
            "Dates, medical terms, abbreviations, and shorthand embedded "
            "within the narrative are perfectly valid (e.g. 'back injury "
            "surgery 1/21/2025', 'C&R 5/9/22', 'Stipped 6/14/24 Left "
            "shoulder'). "
            "NEVER put ONLY single-letter flags, bare numeric amounts, "
            "or standalone dates with no descriptive text here."
        ),
    )
    total_incurred: Optional[float] = Field(
        None,
        description="Total incurred = incurred losses + incurred ALAE - recoveries. Must be >= 0.",
        ge=0,
    )
    total_paid: Optional[float] = Field(
        None,
        description="Total paid = paid losses + paid ALAE - recoveries. Must be >= 0.",
        ge=0,
    )
    incurred_alae: Optional[float] = Field(
        None,
        description="Total incurred Allocated Loss Adjustment Expenses. Must be >= 0.",
        ge=0,
    )
    paid_alae: Optional[float] = Field(
        None,
        description="Total paid Allocated Loss Adjustment Expenses. Must be >= 0.",
        ge=0,
    )
    total_recoveries: Optional[float] = Field(
        None,
        description="Total recoveries (subrogation, salvage, etc.). Report as positive number. Must be >= 0.",
        ge=0,
    )
    status: Optional[Literal["O", "C", "R", "S"]] = Field(
        None,
        description="Claim status: 'O' (Open), 'C' (Closed), or 'R' (Reopened) or 'S' (Subrogated).",
    )
    prior_carrier: Optional[str] = Field(
        None,
        description=(
            "Name of the prior insurance carrier. "
            "Must be a company name containing letters - not a flag, date, or number."
        ),
    )
    evaluation_date: Optional[str] = Field(
        None,
        description="Date the loss run was valued / evaluated in MM/DD/YYYY format.",
        json_schema_extra={"format": "MM/DD/YYYY"},
    )
    page_num_or_sheet_name: Optional[str] = Field(
        None,
        description="The Excel sheet name where the claim row was found.",
    )


def _field_description_line(name: str, field_info: Any) -> str:
    """Build a single human-readable line describing a schema field."""
    annotation = field_info.annotation

    # Resolve Optional[X] -> X
    type_str = "string"
    args = getattr(annotation, "__args__", ())
    inner = args[0] if args else annotation

    if inner is float:
        type_str = "float"
    elif inner is str:
        type_str = "string"
    elif hasattr(inner, "__args__"):
        # Literal
        type_str = f"one of {list(inner.__args__)}"

    parts = [f"- **{name}** ({type_str})"]

    # Format hint
    extra = getattr(field_info, "json_schema_extra", None) or {}
    fmt = extra.get("format")
    if fmt:
        parts.append(f" Format: {fmt}.")

    # Constraints
    meta = getattr(field_info, "metadata", [])
    for m in meta:
        if hasattr(m, "ge") and m.ge is not None:
            parts.append(f" Must be >= {m.ge}.")

    # Description
    desc = getattr(field_info, "description", None)
    if desc:
        parts.append(f" {desc}")

    return "".join(parts)


def get_schema_text() -> str:
    """Serialise the ClaimRecord schema into a prompt-friendly text block.

    This text is passed to the coding agent so it knows exactly what columns
    to produce and what format / type / constraints each column must satisfy.
    """
    lines = ["# Output DataFrame Schema", ""]
    lines.append("Each row in the output DataFrame represents one extracted claim.")
    lines.append("The DataFrame must have exactly these columns:\n")

    for name, field_info in ClaimRecord.model_fields.items():
        lines.append(_field_description_line(name, field_info))

    lines.append("")
    lines.append("All columns are nullable (None / NaN is acceptable when the source has no value).")
    lines.append("Do NOT include commas in numeric values.")
    lines.append("If no claims are found in the segment, return an empty DataFrame with these columns.")

    return "\n".join(lines)


def get_column_names() -> List[str]:
    """Return the ordered list of column names from the schema."""
    return list(ClaimRecord.model_fields.keys())


# =============================================================================
# OUTPUT COLUMN ORDERING CONFIGURATION
# =============================================================================
# Single source of truth for all column name strings referenced across the
# pipeline. Change values here to adapt to a new schema - no edits needed
# in pipeline.py or extraction.py.
# =============================================================================

# The schema field placed as the leftmost column in every output DataFrame.
# Set to "" to disable special leading-column treatment.
LEADING_SCHEMA_COLUMN: str = "claim_id"

# Non-schema metadata columns appended to the right of every output DataFrame.
# The pipeline stamps these automatically on each extracted row.
ACCOUNT_NAME_COLUMN: str = "AccountName"
FILE_SOURCE_COLUMN: str = "file_path"
METADATA_COLUMNS: List[str] = [ACCOUNT_NAME_COLUMN, FILE_SOURCE_COLUMN]


def get_leading_schema_column() -> str:
    """Return the schema column placed leftmost in the output DataFrame."""
    return LEADING_SCHEMA_COLUMN


def get_account_name_column() -> str:
    """Return the metadata column that holds the account / company name."""
    return ACCOUNT_NAME_COLUMN


def get_file_source_column() -> str:
    """Return the metadata column that holds the source file name."""
    return FILE_SOURCE_COLUMN


def get_output_file_suffix() -> str:
    """Return the output file suffix/filename for claims extraction."""
    return "excel_claims.csv"


def get_output_column_order() -> List[str]:
    """Return the canonical output column order.

    Layout: [leading schema column] + [remaining schema columns] + [metadata columns]
    """
    schema_cols = get_column_names()
    leading_col = get_leading_schema_column()
    if leading_col and leading_col in schema_cols:
        leading = [leading_col]
        rest = [f for f in schema_cols if f != leading_col]
    else:
        leading = []
        rest = list(schema_cols)
    return leading + rest + list(METADATA_COLUMNS)


# -----------------------------------------------------------------------------
# EXTRACTION INSTRUCTIONS (Input #2)
# -----------------------------------------------------------------------------
# Domain-specific rules for how to interpret source data and populate schema
# fields. To change extraction behaviour, edit the text below - no code
# changes are needed anywhere else.
# -----------------------------------------------------------------------------

EXTRACTION_INSTRUCTIONS = r"""
# Task
- Your task is to extract all prior claims from this document, but only the individual itemized claims - not summaries.

- **Avoid Aggregated Data:**
  Ignore any text or table that aggregates claims by year, policy, peril, coverage type, property, account, or other field.
  Exclude information labeled as "Totals," "Subtotals," "Coverage Summary," "Line of Business Summary," "Summary Page," or similar, as these represent summary data-not individual claims.
  Aggregated rows often list the number of claims or incidents for a coverage or location, or show totals within an account or policy-do not include these.

- **Check Granularity:**
  Before extracting data, always check the granularity.
  If the loss run only provides grouped data by policy, coverage, or effective year without individual claim details such as a unique claim ID, date of loss, and claim description, exclude it.
  Especially if there is not a unique claim ID, then that is a big red flag.
  You need to be ultra aware of this risk and check your output before responding.

- **Avoid Mistakes with Summary Rows:**
  Do not mistake summary rows for individual claims just because the claim/incident count is "1."
  For example, if claims all have the same date or if descriptions refer only to coverage types (e.g. Auto comprehensive, WC medical), this is most likely aggregated data and should be ignored entirely.
  Always verify that each row has detailed, individual claim-level data before including it.

- **Repeat & Split Claims:**
  - Claims can be split into multiple instances for reasons such as separate claimants, sublines, or coverage components, or something else, but they are all tied to the same underlying claim event.
  - It is common for each instance of a claim to appear as its own row, or as indented sub-rows grouped above or below a main claim row, or for there to be a suffix field, or suffix in the claim number indicating it is the same event as other claim number.
  - If a claim is shown both as detailed coverage-level (granular) rows and an overall single total row for that single claim/event, KEEP ONLY the overall total row and disregard the granular split rows to avoid double counting.
  - If the claim is shown only as split coverage rows (no overall total for the claim), keep just those split rows.
  - If the claim is shown only as a single overall total (no split coverage rows), keep just that overall total row.

# Claim ID Selection & Normalization
## Step 1 - Pick the right source column
  - If multiple columns look like claim identifiers (e.g., "Claim Number", "Claim ID",
    "Incident ID", "Claim Reference"), pick the one with the **longest values** on average.
    Example: "Claim ID" = 456930 vs "Claim Number" = WC1234048 -> use "Claim Number".
  - If both "Claim Reference" and "Claim Occurrence Number" exist, use "Claim Reference".
  - NEVER merge values from two identifier columns into one field.

## Step 2 - Normalize with regex
  After selecting the column, strip sub-claim suffixes so rows from the same event
  share one claim_id. Apply `re.sub(r'[-\/\.]\s*[A-Za-z0-9]{1,3}$', '', raw_id).strip()`
  to remove trailing segments like "-01", "-M", "/02", ".03".

  - If multiple rows share a base ID with different suffixes -> they all get the base ID.
  - If only one row has a suffix (e.g., "WC1234048-01") -> still strip it to "WC1234048".
  - For IDs that vary in an internal segment too (e.g., "15-2-M-85802-01- / 703355" vs
    "15-2-K-85802-02- / 703355"), normalize to the shared base ("15-2-85802 / 703355").

# Prior Carrier / Evaluation Date Background
- The prior carrier is who insured the company during this claim, and we would like to know the name.
- The name might appear in the header, logo, or on the page.
- The evaluation date is when these claims were last valued by the prior carrier.
- Evaluation date is often labeled as "valued as of", "valuation date", "losses valued as of", or similar, and can sometimes appear in the file name.

# Line of Business Background
- The lines you are interested in are: "property", "auto", "general liability", "workers compensation", or "umbrella".
- Each claim MUST be assigned to one of these - no other options.
- Any mention of umbrella coverage (e.g., "auto umbrella", "GL umbrella", etc.) should be listed as the line; not umbrella. So in those cases, "auto" and "general liability"
- Products Liability is General Liability.
- Sometimes the file name or the policy prefix can help identify the line of business (e.g., CP for property, BA/BAU/CA/CAU for auto, GL/CGL/CLP for general liability, WC/WCP for workers compensation)

- **Subline Details:**
  A subline is a specific coverage area within a broader line of business.
  Workers' Compensation: Medical, Indemnity, or Employer's Liability.
  Property: Building, Contents, Business Interruption, and Equipment Breakdown.
  General Liability: Bodily Injury, Property Damage, and Products Liability.
  Unknown: null

  Subline for auto claims is very important.
  Auto Sublines: ONLY "APD" or "AL" nothing else
  Auto APD: coverage that applies to the insured's own property or person. typically lists insured as claimant.
  Auto AL: coverage that applies to a third party that suffered loss due to the insured's liability.
  When deciding auto subline, a helpful rule is:
    - AL is when a person is the claimant
    - APD is when an entity is the claimant

# Accident Date / Status Background
- Accident Date is when the claim incident happened.
- Status can be O, C, R, or S (Open, Closed, Reopened, or Subrogated). Sometimes explicitly stated; other times inferred from date fields:
    - Populated closed date field typically indicates Closed (C)
    - Populated reopened date field typically indicates Reopened (R)
    - Neither populated usually indicates Open (O)

# Financials Background
Loss runs can be messy. Different carriers often use inconsistent or non-standard labels for the same financial concepts, so you must carefully interpret label names
and context to map them into the financial outputs we expect below. Do not assume a field's meaning from its label, but rather use it and the context around it to reason
correctly and report the financials with perfect accuracy.

## IMPORTANT: Prefer existing carrier totals (do not calculate if totals are provided)
- **If the loss run provides a direct column for any required output (e.g., "Total Incurred", "Net Incurred", "Total Paid", "Expense Incurred/ALAE Incurred",
  "Expense Paid/Paid ALAE", "Recoveries/Subro/Salvage"), you MUST use those values as-is.**
- **Do NOT recompute totals "just to verify"** if a clearly-labeled total column is present.
- **Do NOT build totals from components** (paid + reserve, losses + expenses, etc.) when a trustworthy total already exists.
- **Only switch to calculation when:**
    - The needed output column is not present at all, OR
    - the total is ambiguous/unclean and components are clearly defined.

## When calculation is necessary (fallback only)
- If you must compute, output the **final numeric value** (not a formula), and ensure it matches the definitions below.
- Use the most directly compatible components available

Think of claim money in three buckets:
  1) **Losses**
    - Money paid (or expected to be paid) to the claimant for injury or damage.
    - Example coverages / buckets you may see:
      - **Workers' Comp (WC):** Indemnity + Medical
      - **Auto:** Comp + Coll + UM + PIP + BI + PD
      - **General Liability (GL):** BI + PD
    - These loss buckets contribute to the claim's total cost.

  2) **Expenses (ALAE)**
    - **ALAE (Allocated Loss Adjustment Expenses)** = costs directly tied to handling a specific claim (legal, investigation, independent adjuster, rehab/medical management, etc.).
    - If there is a single **Expense** field, use it.
    - If there are unfamiliar "other" expense fields, you may lump them into ALAE along with legal/rehab.
    - If only **Paid ALAE** is available (no incurred ALAE), then **Incurred ALAE = Paid ALAE**.

  3) **Recoveries**
    - Money that comes back and **reduces net cost** (subrogation, salvage, reinsurance, etc.).
    - Often shown as **negative numbers** in loss runs because they reduce cost. **In your output, report recoveries as a positive number.**

Paid is what has actually been disbursed so far.
- Total Paid includes paid losses + paid expenses minus recoveries
- Paid does **not** include reserves.

Reserves
- **Reserves** (also called **Outstanding** or **OS**) = money set aside for expected future payments that have not been paid yet.
- Reserves are included in **incurred** values, not paid values.

Deductibles
- Deductibles are amounts the insured pays out of pocket before insurance coverage applies.
- Do not subtract deductibles from incurred or paid values. Report the full incurred and paid amounts as if the deductible was not there.

Incurred
- Incurred = total expected cost of the claim to date
- Incurred = Paid + Reserves

Be aware of a total incurred column that is then further broken down by claim cost (losses) and then expenses. Correctly assign to the right financial values.

Prefer **Net** values over **Gross**
Recoveries should already be subtracted in net totals (or you may need to subtract them if you're building totals yourself).
Deductibles should not be included in the reporting at all.

You are focused on these five outputs. Not all will be explicitly shown, so use the rules above to derive them when needed.
  1) **Total Net Incurred**
    - The insurer's total incurred cost so far: **incurred losses + incurred ALAE - recoveries**.
    - Prefer a column that already provides this total.
    - If it is indicated that a deductible was paid, you should not reflect that in the net incurred value. So if the net incurred is 2000, but the deductible
      paid by the company was 500, the net incurred is still 2000. You should not report a value that subtracts the deductible from the net incurred. So in the example, the net incurred should NOT be 1500.

  2) **Total Paid**
    - Total amount actually paid so far: **paid losses + paid ALAE - recoveries**.
    - If the claim is closed, **Total Paid** is typically equal (or very close) to **Total Net Incurred**.
    - Prefer a combined net total paid column if provided; otherwise add paid components together.

  3) **Incurred ALAE**
    - Total expenses incurred to date (paid expenses + expense reserves if shown).
    - Often labeled: **Expense Incurred**, **ALAE Incurred**, or **Expenses**.

  4) **Paid ALAE**
    - Expenses actually paid so far.
    - If the claim is closed, **Paid ALAE** is typically equal (or very close) to **Incurred ALAE**.

  5) **Total Recoveries**
    - Total recovered from outside sources (subro, salvage, etc.).
    - Output as a **positive** number even if shown negative on the loss run.

Fallback computation guides (use ONLY if totals are not provided):
- **Total Net Incurred**
  = (sum paid loss) + (sum loss reserves) + (sum paid expense) + (sum expense reserves, if present) - (recoveries)

- **Total Paid**
  = (sum paid loss) + (sum paid expense) - (recoveries)

When coverage types are broken out (WC/Auto/GL), those coverage payments generally roll up into these totals. But still prefer a pre-summed column if it exists.

If a column indicates an amount is from a **deductible** or **retention**, **do not subtract it from totals**.

- You are **not required** to separately report **paid loss** or **incurred loss**-only the five values above.
- Even if there is **no indemnity/loss payment**, you must still report expenses:
  - Example: If Total Net Incurred = 2,000 and Total Paid = 2,000 and everything is expenses, then:
    - Incurred ALAE = 2,000
    - Paid ALAE = 2,000
  - Paid can occasionally be slightly higher than incurred due to adjustments/fees/rounding-**use the actual reported numbers**.

# Policy Background
  A claim is tied to a policy period for that line of business. The period is typically a 12 month window with the effective date being the same month
  and day as the expiration date but 1 year earlier (Effective: 01/01/2023, Expiration 01/01/2024). The policy number is the unique value that identifies the policy.
  If a company has been with the prior carrier for multiple years, it is common to have the same policy number each year, but the effective and expiration dates
  will progress with time. This means you can see claims from different policy years all under the same policy number, but they should have different effective and
  expiration dates depending on when the claim occurred.

  Sometimes an insurer will list the entire loss history dates which spans multiple years.
  For example: 05/12/2020 - 01/30/2025. Then with each claim they may only state the policy year for each claim. In the example, if the policy year for
  one of those claims is 2022, then the effective date would be 05/12/2022, due to the loss history date and the expiration date would be 05/12/2023.

  Make sure to map each claim to the correct policy effective date, expiration date, and policy number. The policy number can sometimes be labeled as SAI number.
  IMPORTANT: The claim's accident date must be in the 12 month window of the policy period. Consider this as you assess the policy period for a claim.

# Other Background
- For WC/GL, there is usually a claimant column with names, but for Auto sometimes there may only be a Driver column that lists names.
- Claim Description: If there are multiple columns with claim description info, the one with the most detailed information should be used.
- Driver: ONLY for Auto APD claims; otherwise it should be null
- Accident State: If you come across a situation where you have columns for "event" state and "jurisdiction" state, use event state.
- Garage State: ONLY for Auto APD claims; otherwise must be null.
- Coverage State: ONLY for General Liability claims; otherwise must be null.

# Policies With No Claims
- If a policy period or summary is listed indicating that the financial fields are 0.0, but don't mention any specific itemized claims, then DO NOT include those in your output.
- If there is a claims section, but it is clearly empty and does not list detailed claims information, do not include those in the output at all.
- Your output should never include a claim where ALL financial fields are 0.0 AND all identifying/descriptive fields (claimant name, claim number, accident date,
  claim description, etc.) are also null or empty. That is NOT a claim - it is a blank or summary row. However, if a row has all-zero financials but contains a valid claimant name,
  claim number, accident date, or description, it IS a real claim (e.g. a closed claim with no payments) and MUST be included.

# Full Context
- Make sure to use all context from the file to extract claims. Key fields like line of business or the named insured or policy number or policy dates or evaluation dates (and maybe more...)
  can be present in the file name or the sheet name or other context within the file.
- Make sure to account for this and reason through when some fields need to be added to all claims.
- If a claim has a field in a column that is also in other context, make sure to prioritize the one specifically tied to the claim. For example, if the evaluation date is in the file name
  but each claim has a evaluate date value in a column, use the column value since it is tied directly to the single claim.

# Main Goal
Capture **all** individual claims in the document following the logic and rules.
Do not make up claims that are not present - it is perfectly normal for a company to not have claims during a period.
Do not make mistakes. Capture all claims with perfect accuracy.
"""


def get_instructions_text() -> str:
    """Return the extraction instructions text."""
    return EXTRACTION_INSTRUCTIONS


# -----------------------------------------------------------------------------
# RELEVANCY CONFIGURATION (Input #3)
# -----------------------------------------------------------------------------
# Controls which files are relevant for extraction. The pipeline uses a
# two-tier approach:
#
#   Tier 1 - **Filename keyword check** (instant, no LLM cost).
#            If ANY keyword below appears in the file name, the file is
#            immediately accepted. Case-insensitive substring matching.
#
#   Tier 2 - **LLM-based content classification** (only when Tier 1 misses).
#            The file's sample rows are sent to the LLM along with the
#            relevancy instructions below. The LLM decides if the content
#            matches the extraction use-case.
#
# To adapt for a different use-case, change the keywords and rewrite the
# instructions to describe what "relevant" means for your domain.
# -----------------------------------------------------------------------------

RELEVANCY_FILENAME_KEYWORDS: List[str] = [
    # -------------------------------------------------------------------------
    # Claims / Loss Run keywords
    # -------------------------------------------------------------------------
    # These keywords, if found in the file name, instantly mark the file as
    # relevant (no LLM call needed). Case-insensitive substring match.
    # -------------------------------------------------------------------------
    "loss run",
    "loss runs",
    "lossrun",
    "lossruns",
    "lrun",
    "loss summary",
    "loss summaries",
    "lr",
    "lrs",
]


RELEVANCY_INSTRUCTIONS: str = """
A file IS relevant for extraction if its content clearly presents historical
insurance claims or losses, for example:
- **Important**: A file can be a summary or statement saying there were no
  prior losses for a given period - that is still relevant.
- Tables or lists of multiple claims or losses.
- Claim-level fields such as:
  - claim number / claim id / claim reference
  - loss date / date of loss / reported date
  - total incurred / incurred loss / net incurred / gross incurred
  - paid loss / total paid / paid to date
  - reserves (outstanding reserve, case reserve, loss reserve)
  - ALAE / allocated loss adjustment expense / expense incurred / expense paid
  - recoveries / subrogation / salvage / deductibles
- Report titles or headings such as:
  - loss run, loss runs, loss history, loss summary, loss detail, loss report
  - schedule of losses, claims experience, claims summary
  - losses valued as of, valuation date, valued as of
- Summary tables like:
  - summary of losses, loss summary by year, claims by year, claims by policy year
  - number of claims, claim count, total number of claims, frequency, severity

A file is NOT relevant if it is mainly:
- Applications for an insurance carrier.
  - **Important**: It is very common for an insurance application to have a
    loss summary or history section that is not filled out because they attach
    other files that are loss run reports. This section could also be filled
    out very briefly, but if it is not a clearly detailed form of prior claims,
    then it is not relevant.
- Policy documents (declarations, endorsements, coverage forms, certificates)
  with no historical claim rows.
- An Experience Rating or Experience Modifier, which does not include
  information about claims.
- Quotes, proposals, rating worksheets, pricing exhibits without actual past
  claims.
- Invoices, bills, remittance advice, or general accounting/financial reports.
- Pure exposure/premium schedules (vehicles, locations, payroll) with no claim
  history.
- Any document that only mentions "claims" or "loss" in a generic way (e.g.,
  disclaimers) but does not show historical claim-level or loss summary data.

If you are not clearly seeing claim-level or loss-summary data, you must
answer that it is NOT relevant.
"""


SHEET_RELEVANCY_INSTRUCTIONS: str = """
A sheet IS relevant for extraction if it contains:
- Individual claim-level data (rows representing distinct claims, incidents,
  or claimants)
- Claim-level fields such as: claim number, claim id, claimant name, loss
  date, reported date, claim description, incident description, cause of loss
- Financial detail at the claim level: incurred, paid, reserves per claim
- Even if the sheet shows "no claims" or "no losses" for a policy period,
  it IS still relevant (it indicates a clean history)

A sheet is NOT relevant if it:
- Contains only policy-level summary data aggregated by policy period, line
  of business, or peril WITHOUT individual claim identifiers (no claim number,
  no claimant, no claim description)
- Has headers like: Policy No., Effective Year, Expiration Date, Major Peril,
  Type Of Loss, Line of Business, Deductible - with only aggregated financial
  totals (not per-claim)
- Is a coverage summary, premium schedule, declarations, policy overview, or
  exposure schedule
- Contains metadata, instructions, table of contents, or index information
- Is a pivot/summary view that shows counts or totals by policy year but no
  individual claims
"""


def get_relevancy_keywords() -> List[str]:
    """Return the list of file-name keywords for fast-pass relevancy (claims)."""
    return RELEVANCY_FILENAME_KEYWORDS


def get_relevancy_instructions() -> str:
    """Return the file-level relevancy instructions for LLM classification."""
    return RELEVANCY_INSTRUCTIONS


def get_sheet_relevancy_instructions() -> str:
    """Return the sheet-level relevancy instructions for LLM classification."""
    return SHEET_RELEVANCY_INSTRUCTIONS


# -----------------------------------------------------------------------------
# SHEET CONTEXT AGENT CONFIGURATION (Input #4)
# -----------------------------------------------------------------------------
# Controls the Sheet Context Agent which performs three-outcome classification
# on each sheet: parse_full_sheet, is_still_relevant, sheet_summary.
#
# This replaces the binary sheet classification and enables cross-sheet
# context propagation - metadata-only sheets (cover pages, policy info tabs)
# contribute their context to the extraction of claim tables on other sheets.
# -----------------------------------------------------------------------------

# Enable/disable the Sheet Context Agent. When False, the pipeline falls
# back to the legacy binary sheet classification.
SHEET_CONTEXT_AGENT_ENABLED: bool = True


def get_sheet_context_agent_enabled() -> bool:
    """Return whether the Sheet Context Agent is enabled."""
    return SHEET_CONTEXT_AGENT_ENABLED
