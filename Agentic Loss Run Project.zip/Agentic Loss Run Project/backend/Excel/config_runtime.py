"""Runtime selection helpers for the active pipeline input configuration.

This module lets the pipeline switch between different input configuration
modules (for example `inputs_claims` and `inputs_no_claims`) without
hard-coding one module name across the codebase.
"""

from __future__ import annotations

from importlib import import_module
from threading import Lock
from types import ModuleType

_DEFAULT_INPUTS_MODULE = "inputs_claims"
_active_inputs_module_name = _DEFAULT_INPUTS_MODULE
_inputs_module_lock = Lock()


def set_active_inputs_module(module_name: str) -> str:
    """Set and return the active input configuration module name."""
    normalized = str(module_name or "").strip() or _DEFAULT_INPUTS_MODULE
    # Validate eagerly so callers fail fast on typos.
    import_module(normalized)

    global _active_inputs_module_name
    with _inputs_module_lock:
        _active_inputs_module_name = normalized
    return normalized


def get_active_inputs_module_name() -> str:
    """Return the currently active input configuration module name."""
    with _inputs_module_lock:
        return _active_inputs_module_name


def get_active_inputs_module() -> ModuleType:
    """Return the currently active input configuration module."""
    return import_module(get_active_inputs_module_name())


def call_active_inputs_helper(helper_name: str, *args, default=None, **kwargs):
    """Call a helper from the active input module if it exists.

    Returns ``default`` when the helper is not defined.
    """
    module = get_active_inputs_module()
    helper = getattr(module, helper_name, None)
    if helper is None:
        return default
    return helper(*args, **kwargs)
