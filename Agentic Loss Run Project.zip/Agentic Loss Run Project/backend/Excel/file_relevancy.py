"""Generic file relevancy filter - classifies Excel files as relevant or not.

Uses a **two-tier** approach to decide whether an Excel file should be sent
through the downstream extraction pipeline:

    Tier 1 - **Filename keyword check** (instant, zero LLM cost).
             If any user-configured keyword appears in the file name the file
             is immediately accepted.

    Tier 2 - **LLM-based content classification** (only when Tier 1 misses).
             A small sample of rows from each sheet is sent to the model along
             with the user-provided relevancy instructions.

The relevancy keywords and instructions are configured in `inputs.py` -
no domain-specific logic lives in this module.
"""

from __future__ import annotations

import concurrent.futures
import json
import os
import re
from typing import Any, Dict, List, Tuple

import pandas as pd

import models
from constants import MAX_CONCURRENT_API_CALLS
from utils_gpt import gpt_call
from prompts import (
    RELEVANCY_DETECTION_SYSTEM_TEMPLATE,
    RELEVANCY_DETECTION_USER_TEMPLATE,
    SHEET_RELEVANCY_DETECTION_SYSTEM_TEMPLATE,
    SHEET_RELEVANCY_DETECTION_USER_TEMPLATE,
)
from utils import as_extended_path_str as _as_extended_path_str
from utils import log_cli
from utils import read_csv_with_detected_delimiter

# - Configuration -----------------------------------------------------------


def get_relevancy_model() -> Dict[str, Any]:
    """Return a cheaper model config for relevancy / classification tasks.

    Controlled by `UTILITY_MODEL` in `inputs.py`. Defaults to
    GPT_4_1_MINI which is 3-6x cheaper than the full extraction model.
    """
    return models.get_utility_model()


# How many rows per sheet to sample for the detection prompt
_SAMPLE_ROWS = 100

# How many sheets to include at most (avoids huge payloads on workbooks with
# # dozens of sheets)
_MAX_SHEETS = 10

RELEVANCY_STATUS_RELEVANT = "relevant"
RELEVANCY_STATUS_NOT_RELEVANT = "not_relevant"
RELEVANCY_STATUS_FALLBACK_INFRA_FAILURE = "fallback_infra_failure"


# - Helpers ------------------------------------------------------------------


def _excel_engine_for_path(file_path: str) -> str | None:
    """Return the explicit pandas engine for the given Excel format.

    Uses **calamine** (Rust-based) for ``.xlsx`` / ``.xlsm`` files which is
    significantly faster than the default openpyxl reader for large workbooks.
    Legacy ``.xls`` and binary ``.xlsb`` still use their dedicated engines.
    """
    lower_path = (file_path or "").lower()
    if lower_path.endswith(".xls"):
        return "xlrd"
    if lower_path.endswith(".xlsb"):
        return "pyxlsb"
    if lower_path.endswith((".xlsx", ".xlsm")):
        return "calamine"
    return None


# - Tier 1: Filename keyword check -------------------------------------------


def _filename_tokens(file_name: str) -> List[str]:
    """Tokenize a filename into lowercase alphanumeric tokens.

    Splits on any non-alphanumeric character, so boundaries like underscores,
    dashes, spaces, periods, parentheses, etc. are all treated consistently.

    Examples:
      "ACME_LR_2025.xlsx" -> ["acme", "lr", "2025", "xlsx"]
      "loss-run (final).xlsx" -> ["loss", "run", "final", "xlsx"]
    """
    name = (file_name or "").lower()
    return [t for t in re.split(r"[^a-z0-9]+", name) if t]


def _keyword_tokens(keyword: str) -> List[str]:
    """Tokenize a keyword using the same rules as filenames."""
    kw = (keyword or "").strip().lower()
    return [t for t in re.split(r"[^a-z0-9]+", kw) if t]


def _check_filename_keywords(file_name: str, keywords: List[str]) -> bool:
    """Return True if any keyword matches *file_name* (case-insensitive, no substring).

    Matching behavior (simple + predictable):
      - A 1-token keyword matches if it equals a filename token (exact match).
      - A multi-token keyword (e.g., "loss run") matches if those tokens appear
        adjacent in the filename token sequence (exact phrase match).
    """
    if not keywords:
        return False

    tokens = _filename_tokens(file_name)
    if not tokens:
        return False

    token_set = set(tokens)

    for kw in keywords:
        ktoks = _keyword_tokens(kw)
        if not ktoks:
            continue

        # Single token: exact match against token set
        if len(ktoks) == 1:
            if ktoks[0] in token_set:
                return True
            continue

        # Multi-token phrase: exact adjacency match
        n = len(ktoks)
        for i in range(len(tokens) - n + 1):
            if tokens[i : i + n] == ktoks:
                return True

    return False


# - Tier 2 helpers: extract sample rows --------------------------------------


def _df_to_row_dicts(df: pd.DataFrame) -> List[Dict[str, str]]:
    """Convert the first rows of a DataFrame into a list of column-indexed dicts.

    Each dict maps ``col_<idx>`` -> stringified non-null value. Empty rows
    (all-null) are omitted. This helper is shared by
    ``_extract_text_snippets_from_excel`` and ``classify_workbook_sheets`` so
    that the per-row serialisation logic is defined in exactly one place.
    """
    rows: List[Dict[str, str]] = []
    for _, row in df.iterrows():
        row_dict = {}
        for col_idx, val in enumerate(row):
            if pd.isna(val):
                continue
            row_dict[f"col_{col_idx}"] = str(val).strip()
        if row_dict:
            rows.append(row_dict)
    return rows


def _build_sheet_snippets(
    file_path: str,
    precomputed_snippets: List[Dict[str, Any]] | None = None,
    *,
    log_context: str = "snippet extraction",
) -> List[Dict[str, Any]]:
    """Build per-sheet sample snippets for an Excel / CSV file.

    This is the **single** implementation used by
    ``_extract_text_snippets_from_excel``, ``classify_workbook_sheets``,
    and ``sheet_context_agent.classify_sheets_with_context``.

    When *precomputed_snippets* is provided and non-empty the file is
    NOT re-opened, avoiding redundant I/O.

    The ``pd.ExcelFile`` handle is always closed in a ``finally`` block
    to prevent file-handle leaks on Windows.
    """
    if precomputed_snippets is not None and len(precomputed_snippets) > 0:
        return precomputed_snippets

    ext_path = _as_extended_path_str(file_path)
    snippets: List[Dict[str, Any]] = []
    lower_path = file_path.lower()

    if lower_path.endswith(".csv"):
        try:
            df = read_csv_with_detected_delimiter(file_path, nrows=_SAMPLE_ROWS)
        except Exception as exc:
            log_cli(f" [WARN] Could not open {file_path} for {log_context}: {exc}")
            return snippets

        if df.empty:
            return snippets

        rows = _df_to_row_dicts(df)
        if rows:
            snippets.append({"sheet": "Sheet1", "rows": rows})
        return snippets

    xls = None
    try:
        excel_engine = _excel_engine_for_path(file_path)
        if excel_engine:
            xls = pd.ExcelFile(ext_path, engine=excel_engine)
        else:
            xls = pd.ExcelFile(ext_path)

        sheet_names = xls.sheet_names[:_MAX_SHEETS]

        for sheet_name in sheet_names:
            try:
                df = pd.read_excel(xls, sheet_name=sheet_name, header=None, nrows=_SAMPLE_ROWS)
            except Exception:
                continue

            if df.empty:
                continue

            rows = _df_to_row_dicts(df)
            if rows:
                snippets.append({"sheet": sheet_name, "rows": rows})
    except Exception as exc:
        log_cli(f" [WARN] Could not open {file_path} for {log_context}: {exc}")
    finally:
        if xls is not None:
            try:
                xls.close()
            except Exception:
                pass

    return snippets


def _extract_text_snippets_from_excel(file_path: str) -> List[Dict[str, Any]]:
    """Return a list of ``{"sheet": ..., "rows": [...]}`` dicts.

    Each entry contains up to ``_SAMPLE_ROWS`` row-dicts from the head of
    the sheet, giving the LLM enough context to decide whether the file
    contains data relevant for extraction.
    """
    return _build_sheet_snippets(file_path, log_context="relevancy detection")


# - Prompt builder -----------------------------------------------------------


def _build_relevancy_detection_prompt(
    snippets_json: str,
    relevancy_instructions: str,
) -> tuple[str, str]:
    """Assemble the system + user messages for file relevancy detection.

    Parameters
    ----------
    snippets_json : str
        JSON-encoded list of ``{"sheet": ..., "rows": [...]}`` dicts.
    relevancy_instructions : str
        User-provided relevancy criteria from ``inputs.py``.

    Returns
    -------
    Tuple[str, str]
        ``(system_message, user_message)``
    """
    system_message = RELEVANCY_DETECTION_SYSTEM_TEMPLATE.format(
        relevancy_instructions=relevancy_instructions,
    )
    user_message = RELEVANCY_DETECTION_USER_TEMPLATE.format(input=snippets_json)
    return system_message, user_message


# - Sheet-level LLM classification -------------------------------------------


def classify_workbook_sheets(
    file_path: str,
    file_name: str | None = None,
    sheet_relevancy_instructions: str = "",
    precomputed_snippets: List[Dict[str, Any]] | None = None,
) -> Tuple[Dict[str, bool], int, int]:
    """Classify each sheet in an Excel workbook as relevant or not.

    Uses a single LLM call that sends sample rows from all sheets and asks
    the model to classify each one individually.

    Parameters
    ----------
    file_path:
        Full path to the Excel file.
    file_name:
        Optional display name (used only for logging).
    sheet_relevancy_instructions:
        User-provided criteria for what makes a sheet relevant.
    precomputed_snippets:
        Optional pre-extracted sheet snippets from a prior
        ``detect_relevant_file`` call. When provided, the Excel file
        is NOT re-opened, saving I/O and pandas overhead.

    Returns
    -------
    sheet_classifications : dict
        ``{sheet_name: True/False}`` for each sheet.
    input_tokens : int
    output_tokens : int
    """
    display = file_name or os.path.basename(file_path)
    ext_path = _as_extended_path_str(file_path)

    if file_path.lower().endswith(".csv"):
        return {"Sheet1": True}, 0, 0

    # - Use shared snippet builder (handles file-open + close) -----------
    sheet_snippets = _build_sheet_snippets(
        file_path,
        precomputed_snippets=precomputed_snippets,
        log_context="sheet classification",
    )

    sheet_names = [s["sheet"] for s in sheet_snippets] if sheet_snippets else []

    if len(sheet_names) < 2 and sheet_names:
        return {name: True for name in sheet_names}, 0, 0

    if not sheet_snippets:
        return {name: True for name in sheet_names}, 0, 0

    # - Build prompt and call LLM ----------------------------------------
    snippets_json = json.dumps(sheet_snippets, ensure_ascii=False, default=str)
    system_message = SHEET_RELEVANCY_DETECTION_SYSTEM_TEMPLATE.format(
        sheet_relevancy_instructions=sheet_relevancy_instructions,
    )
    user_message = SHEET_RELEVANCY_DETECTION_USER_TEMPLATE.format(input=snippets_json)

    _rel_model = get_relevancy_model()
    raw_output, in_tokens, out_tokens = gpt_call(
        prompt=user_message,
        model_name=_rel_model["model_name"],
        api_version=_rel_model["api_version"],
        system_message=system_message,
    )

    # - Parse response ---------------------------------------------------
    classifications: Dict[str, bool] = {}

    if not raw_output:
        log_cli(f" [WARN] Sheet classification LLM returned empty for {display}; assuming all sheets are relevant.")
        return {name: True for name in sheet_names}, in_tokens, out_tokens

    try:
        result = json.loads(raw_output)
        sheets_dict = result.get("sheets", result)

        if isinstance(sheets_dict, dict):
            for sname, info in sheets_dict.items():
                if isinstance(info, dict):
                    classifications[sname] = bool(info.get("is_relevant", True))
                elif isinstance(info, bool):
                    classifications[sname] = info
        elif isinstance(sheets_dict, list):
            for entry in sheets_dict:
                if isinstance(entry, dict) and "sheet" in entry:
                    classifications[entry["sheet"]] = bool(entry.get("is_relevant", True))

    except (json.JSONDecodeError, TypeError) as exc:
        log_cli(f" [WARN] Could not parse sheet classification for {display}; {exc}; assuming all sheets are relevant.")
        return {name: True for name in sheet_names}, in_tokens, out_tokens

    # Ensure every sheet has a classification - default to True (safe).
    for name in sheet_names:
        if name not in classifications:
            classifications[name] = True

    return classifications, in_tokens, out_tokens


# - Internal helpers ---------------------------------------------------------


def _detect_relevant_file(
    file_path: str,
    file_name: str | None = None,
    keywords: List[str] | None = None,
    exclusion_keywords: List[str] | None = None,
    relevancy_instructions: str = "",
) -> Tuple[str, bool, str, int, int, List[Dict[str, Any]]]:
    """Determine whether *file_path* is relevant for extraction.

    Three-tier approach:
      0. If any exclusion keyword matches the file name -> instant reject.
      1. If any keyword matches the file name -> instant accept (0 tokens).
      2. Otherwise, sample rows are sent to the LLM for classification.

    Parameters
    ----------
    file_path:
        Full path to the Excel file.
    file_name:
        Optional display name (used only for logging).
    keywords:
        List of keywords for Tier-1 filename matching.
    exclusion_keywords:
        List of keywords for Tier-0 filename exclusion.
    relevancy_instructions:
        User-provided relevancy criteria for the LLM (Tier 2).

    Returns
    -------
    relevancy_status : str
        One of: ``relevant``, ``not_relevant``, ``fallback_infra_failure``.
    is_relevant : bool
        ``True`` if the file is classified as relevant.
    reason : str
        One-sentence explanation.
    input_tokens : int
        Prompt tokens consumed (0 for keyword match).
    output_tokens : int
        Completion tokens consumed (0 for keyword match).
    cached_snippets : list
        Extracted sheet snippets (reusable by ``classify_workbook_sheets``).
        Empty list for keyword matches (no file was opened).
    """
    display = file_name or os.path.basename(file_path)
    keywords = keywords or []
    exclusion_keywords = exclusion_keywords or []

    # - Tier 0: filename exclusion soft-reject -------------------------------
    # When the filename matches an exclusion keyword, the file is normally
    # rejected. However, for multi-sheet workbooks, one or more sheets
    # may still belong to this pass (e.g. "Acme Loss Run.xlsx" with a
    # hidden "Vehicle Schedule" tab). In that case we peek at sheet names
    # - if any sheet name matches the pass's relevancy keywords we let the
    # file through so sheet-level classification can separate the sheets.
    # This is cheap: only sheet names are read, no LLM call.
    if exclusion_keywords and _check_filename_keywords(display, exclusion_keywords):
        override = False
        if keywords and not display.lower().endswith(".csv"):
            try:
                ext_path = _as_extended_path_str(file_path)
                excel_engine = _excel_engine_for_path(file_path)
                xls = pd.ExcelFile(ext_path, engine=excel_engine) if excel_engine else pd.ExcelFile(ext_path)
                try:
                    sheet_names = xls.sheet_names
                    if len(sheet_names) > 1:
                        for sname in sheet_names:
                            if _check_filename_keywords(sname, keywords):
                                override = True
                                log_cli(
                                    f" ⚡ Exclusion override: {display} matched exclusion keyword "
                                    f"but sheet '{sname}' matched relevancy keyword - keeping file."
                                )
                                break
                finally:
                    xls.close()
            except Exception:
                pass  # if we can't read sheet names, fall through to hard reject

        if not override:
            return RELEVANCY_STATUS_NOT_RELEVANT, False, "Filename matched exclusion keyword.", 0, 0, []

    # - Tier 1: filename keyword fast-pass -----------------------------------
    if _check_filename_keywords(display, keywords):
        # Extract snippets eagerly so downstream classify_workbook_sheets()
        # can reuse them without re-opening the excel file (Bug #1 fix).
        snippets = _extract_text_snippets_from_excel(file_path)
        return RELEVANCY_STATUS_RELEVANT, True, "Filename matched relevancy keyword.", 0, 0, snippets

    # - Tier 2: LLM-based content classification -----------------------------
    snippets = _extract_text_snippets_from_excel(file_path)
    if not snippets:
        log_cli(f" [WARN] No readable content in {display}; assuming relevant.")
        return (
            RELEVANCY_STATUS_FALLBACK_INFRA_FAILURE,
            True,
            "Could not extract text; defaulting to relevant.",
            0,
            0,
            [],
        )

    payload = json.dumps(snippets, ensure_ascii=False, default=str)

    system_message, user_message = _build_relevancy_detection_prompt(
        payload,
        relevancy_instructions,
    )

    _rel_model = get_relevancy_model()
    raw_output, in_tokens, out_tokens = gpt_call(
        prompt=user_message,
        model_name=_rel_model["model_name"],
        api_version=_rel_model["api_version"],
        system_message=system_message,
    )

    # Default: treat as relevant if the LLM fails to respond
    if not raw_output:
        log_cli(f" [WARN] Relevancy detection LLM returned empty for {display}; assuming relevant.")
        return (
            RELEVANCY_STATUS_FALLBACK_INFRA_FAILURE,
            True,
            "LLM returned empty; defaulting to relevant.",
            in_tokens,
            out_tokens,
            snippets,
        )

    try:
        result = json.loads(raw_output)
        is_relevant = bool(result.get("is_relevant", True))
        reason = str(result.get("reason", ""))
        relevancy_status = (
            RELEVANCY_STATUS_RELEVANT if is_relevant else RELEVANCY_STATUS_NOT_RELEVANT
        )
    except (json.JSONDecodeError, TypeError):
        log_cli(f" [WARN] Could not parse relevancy detection response for {display}; assuming relevant.")
        relevancy_status = RELEVANCY_STATUS_FALLBACK_INFRA_FAILURE
        is_relevant = True
        reason = "Unparseable LLM response; defaulting to relevant."

    return relevancy_status, is_relevant, reason, in_tokens, out_tokens, snippets


def filter_relevant_files(
    file_jobs: List[Dict[str, str]],
    keywords: List[str] | None = None,
    exclusion_keywords: List[str] | None = None,
    relevancy_instructions: str = "",
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], int, int]:
    """Run relevancy detection on every file job and split into two lists.

    Parameters
    ----------
    file_jobs:
        List of dicts with keys ``company``, ``file_name``, ``file_path``.
    keywords:
        List of filename keywords for Tier-1 fast-pass.
    exclusion_keywords:
        List of filename keywords that force-skip a file (Tier-0 reject).
        If any keyword appears in the file name, the file is immediately
        marked as NOT relevant regardless of other signals.
    relevancy_instructions:
        User-provided relevancy criteria for LLM (Tier 2).

    Returns
    -------
    relevant_jobs : list
        Jobs that ARE relevant and should proceed to extraction.
    skipped_jobs : list
        Jobs that are NOT relevant (with an extra ``skip_reason`` key).
    total_input_tokens : int
    total_output_tokens : int
    """
    relevant_jobs: List[Dict[str, Any]] = []
    skipped_jobs: List[Dict[str, Any]] = []
    total_in = 0
    total_out = 0
    keywords = keywords or []
    exclusion_keywords = exclusion_keywords or []

    def _classify(job: Dict[str, str]):
        return job, _detect_relevant_file(
            job["file_path"],
            job["file_name"],
            keywords=keywords,
            exclusion_keywords=exclusion_keywords,
            relevancy_instructions=relevancy_instructions,
        )

    # Limit parallelism: legacy .xls (xlrd) and .xlsb (pyxlsb) are NOT
    # thread-safe. When any job uses a legacy format, cap workers at 4
    # to reduce the probability of concurrent reads on the same engine.
    _has_legacy = any(
        job["file_path"].lower().endswith((".xls", ".xlsb"))
        for job in file_jobs
        if not job["file_path"].lower().endswith(".xlsx")
    )
    max_workers = min(len(file_jobs), 4 if _has_legacy else MAX_CONCURRENT_API_CALLS)
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {pool.submit(_classify, job): job for job in file_jobs}
        for future in concurrent.futures.as_completed(futures):
            try:
                job, (relevancy_status, is_relevant, reason, in_tok, out_tok, cached_snippets) = future.result()
            except Exception as exc:
                job = futures[future]
                relevancy_status = RELEVANCY_STATUS_FALLBACK_INFRA_FAILURE
                is_relevant = True
                reason = (
                    "Relevancy detection failed; defaulting to relevant so extraction "
                    "does not lose records."
                )
                in_tok = 0
                out_tok = 0
                cached_snippets = []
                log_cli(
                    f" [WARN] Relevancy classification crashed for "
                    f"{job['company']} | {job['file_name']}: {exc}. {reason}"
                )

            total_in += in_tok
            total_out += out_tok

            company = job["company"]
            file_name = job["file_name"]

            if is_relevant:
                enriched = dict(job)
                enriched["relevancy_status"] = relevancy_status
                enriched["relevancy_reason"] = reason
                enriched["detection_input_tokens"] = in_tok
                enriched["detection_output_tokens"] = out_tok
                enriched["_cached_snippets"] = cached_snippets
                relevant_jobs.append(enriched)
                if relevancy_status == RELEVANCY_STATUS_FALLBACK_INFRA_FAILURE:
                    log_cli(f" ⚠️ Fallback-kept file: {company} | {file_name} - {reason}")
                else:
                    log_cli(f" ✔ Relevant file detected: {company} | {file_name} - {reason}")
            else:
                skipped = dict(job)
                skipped["relevancy_status"] = relevancy_status
                skipped["relevancy_reason"] = reason
                skipped["skip_reason"] = reason
                skipped["detection_input_tokens"] = in_tok
                skipped["detection_output_tokens"] = out_tok
                skipped_jobs.append(skipped)
                log_cli(f" ✘ NOT relevant (skipped): {company} | {file_name} - {reason}")

    return relevant_jobs, skipped_jobs, total_in, total_out
