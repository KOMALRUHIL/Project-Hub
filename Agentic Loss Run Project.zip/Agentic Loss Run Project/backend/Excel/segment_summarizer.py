from __future__ import annotations

import json
import datetime
import random
import re
import warnings
from collections import Counter
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import pandas as pd
from openpyxl.utils import get_column_letter

from constants import CLI_PREVIEW_ITEM_LIMIT, SHEET_TOKEN_THRESHOLD
from row_segmentation import (
    Row,
    classify_row_type,
    _parse_cell_row,
    _row_index,
    _header_row,
    _iter_rows,
    _row_values,
)
from utils import (
    as_extended_path as _as_extended_path,
    is_blank_value as _is_blank_value,
    load_json as _load_json,
    parse_numeric_value as _parse_numeric_value,
    write_json as _write_json,
)

MAX_SAMPLE_ROWS_PER_COLUMN = 15

# Deterministic RNG instance for reproducible sampling. Using a local
# instance avoids resetting the global `random` state, which could
# affect any other code that relies on `random`.
_rng = random.Random(42)

# Sentinel values commonly seen in messy spreadsheet data. If a column
# contains any of these they are included in the "edge" slice so the coding
# agent can see data-quality quirks.
_EDGE_SENTINELS: frozenset[str] = frozenset({
    "", "unknown", "n/a", "na", "none", "null", "-", "--", "0", "tbd",
    "not available", "not applicable", "pending",
})


def _parse_date_value(value: Any) -> Optional[datetime.datetime]:
    if _is_blank_value(value):
        return None
    if isinstance(value, (datetime.date, datetime.datetime)):
        if isinstance(value, datetime.datetime):
            return value
        return datetime.datetime.combine(value, datetime.time.min)
    if not isinstance(value, str):
        return None
    text = value.strip()
    if not text:
        return None
    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            category=FutureWarning,
            message=r".*un-recognized timezone.*",
        )
        warnings.filterwarnings(
            "ignore",
            category=UserWarning,
            message=r".*Could not infer format.*",
        )
        parsed = pd.to_datetime(text, format="mixed", errors="coerce")
    if pd.isna(parsed):
        return None
    if isinstance(parsed, pd.Timestamp):
        # Pandas can represent years that Python's datetime cannot (e.g., year 0).
        try:
            py_dt = parsed.to_pydatetime()
        except (ValueError, OverflowError):
            return None
        # Extra safety in case conversion ever succeeds with out-of-range values.
        if not (1 <= py_dt.year <= 9999):
            return None
        return py_dt
    return None


def _header_names_and_cells(headers: Sequence[Dict[str, Any]], max_cols: int, header_row: Optional[int]) -> Tuple[List[str], List[Optional[str]]]:
    names: List[str] = []
    cells: List[Optional[str]] = []
    for idx in range(max_cols):
        header = headers[idx] if idx < len(headers) else {}
        name = header.get("text")
        if name is None or str(name).strip() == "":
            name = f"column_{idx + 1}"
        cell_ref = header.get("cell")
        if not cell_ref and header_row is not None:
            cell_ref = f"{get_column_letter(idx + 1)}{header_row}"
        names.append(str(name))
        cells.append(cell_ref)
    return names, cells


# -----------------------------------------------------------------------------
# Smart-30 sampling helpers
# -----------------------------------------------------------------------------


def _smart_sample_numeric(
    values: List[float],
    budget: int = MAX_SAMPLE_ROWS_PER_COLUMN,
) -> List[Dict[str, Any]]:
    """Return up to *budget* representative numeric samples with frequencies.

    Strategy:
    - 10 most frequent values (with counts)
    - 10 random distinct values from the remainder
    - 5 edge values (min, max, zero, largest-negative, near-median)
    - 5 random tail values
    """
    if not values:
        return []

    freq = Counter(values)
    distinct = sorted(freq.keys())

    # If everything fits, return all with frequencies
    if len(distinct) <= budget:
        return [
            {"value": v, "freq": freq[v]}
            for v in distinct
        ]

    selected: Dict[float, int] = {} # value -> freq

    # --- 1. Top 10 most frequent
    top_n = min(10, budget)
    for val, _cnt in freq.most_common(top_n):
        selected[val] = freq[val]

    # --- 2. Edge values
    edges: List[float] = []
    edges.append(min(distinct))  # min
    edges.append(max(distinct))  # max
    negatives = [v for v in distinct if v < 0]
    if negatives:
        edges.append(min(negatives))  # largest-magnitude negative
    if 0.0 in freq:
        edges.append(0.0)
    # Near-median
    mid_idx = len(distinct) // 2
    edges.append(distinct[mid_idx])
    for e in edges:
        if e not in selected and len(selected) < budget:
            selected[e] = freq[e]

    # --- 3. Random tail
    remaining = [v for v in distinct if v not in selected]
    tail_budget = budget - len(selected)
    if tail_budget > 0 and remaining:
        tail = _rng.sample(remaining, min(tail_budget, len(remaining)))
        for v in tail:
            selected[v] = freq[v]

    return [
        {"value": v, "freq": selected[v]}
        for v in sorted(selected.keys())
    ]


def _smart_sample_dates(
    date_values: List[datetime.datetime],
    budget: int = MAX_SAMPLE_ROWS_PER_COLUMN,
) -> List[Dict[str, Any]]:
    """Return up to *budget* representative date samples with frequencies."""
    if not date_values:
        return []

    as_str = [
        v.date().isoformat() if isinstance(v, datetime.datetime) else str(v)
        for v in date_values
    ]
    freq = Counter(as_str)
    distinct = sorted(freq.keys())

    if len(distinct) <= budget:
        return [{"value": v, "freq": freq[v]} for v in distinct]

    selected: Dict[str, int] = {}

    # Top 10 most frequent
    for val, _cnt in freq.most_common(min(10, budget)):
        selected[val] = freq[val]

    # Edges: earliest, latest, mid
    for edge in (distinct[0], distinct[-1], distinct[len(distinct) // 2]):
        if edge not in selected and len(selected) < budget:
            selected[edge] = freq[edge]

    # Fill remainder randomly
    remaining = [v for v in distinct if v not in selected]
    tail_budget = budget - len(selected)
    if tail_budget > 0 and remaining:
        tail = _rng.sample(remaining, min(tail_budget, len(remaining)))
        for v in tail:
            selected[v] = freq[v]

    return [{"value": v, "freq": selected[v]} for v in sorted(selected.keys())]


_ID_LIKE_RE = re.compile(
    r"^[A-Z]{0,5}[-\s]?\d{3,9}$"  # e.g. ABC-1234567, WC001234
    r"|^\d{3,}[-/]?[A-Z0-9]*$"  # e.g. 123456-A
    r"|^[0-9a-fA-F]{8,}$",       # hex / UUID fragments
    re.IGNORECASE,
)


def _is_id_like(values: List[str]) -> bool:
    """Heuristic: True if >=60 % of non-empty values look like IDs / codes."""
    if len(values) < 3:
        return False
    matches = sum(1 for v in values if _ID_LIKE_RE.match(v.strip()))
    return (matches / len(values)) >= 0.6


def _smart_sample_text(
    text_values: List[str],
    budget: int = MAX_SAMPLE_ROWS_PER_COLUMN,
) -> Tuple[List[Dict[str, Any]], str]:
    """Return up to *budget* representative text samples with frequencies.

    Also returns a ``sample_strategy`` label ("categorical", "id_like", or
    "free_text") so the coding agent can interpret the samples correctly.
    """
    if not text_values:
        return [], "categorical"

    freq = Counter(text_values)
    distinct = sorted(freq.keys(), key=lambda v: (-freq[v], v))
    cardinality = len(distinct)

    # If everything fits, send all
    if cardinality <= budget:
        return (
            [{"value": v, "freq": freq[v]} for v in distinct],
            "all_values",
        )

    # --- Detect column sub-type
    is_id = _is_id_like(text_values)
    # Categorical = high repetition (top-10 values cover >=50 % of rows)
    top10_coverage = sum(c for _, c in freq.most_common(10)) / max(1, len(text_values))
    is_categorical = (not is_id) and top10_coverage >= 0.50

    selected: Dict[str, int] = {}

    if is_id:
        # --- ID-like: show format diversity + prefix frequencies
        strategy = "id_like"
        # Shortest 5 + longest 5 to show format range
        by_len = sorted(distinct, key=len)
        for v in by_len[:5] + by_len[-5:]:
            if v not in selected and len(selected) < budget:
                selected[v] = freq[v]
        # Fill remainder randomly for format variety
        remaining = [v for v in distinct if v not in selected]
        fill = budget - len(selected)
        if fill > 0 and remaining:
            for v in _rng.sample(remaining, min(fill, len(remaining))):
                selected[v] = freq[v]

    elif is_categorical:
        # --- Categorical: top-freq + tail + edge sentinels
        strategy = "categorical"
        top_n = min(15, budget)
        for val, _cnt in freq.most_common(top_n):
            selected[val] = freq[val]

        # Edge sentinels that actually appear
        for v in distinct:
            if v.strip().lower() in _EDGE_SENTINELS and v not in selected and len(selected) < budget:
                selected[v] = freq[v]

        # Random tail
        remaining = [v for v in distinct if v not in selected]
        tail_budget = budget - len(selected)
        if tail_budget > 0 and remaining:
            for v in _rng.sample(remaining, min(tail_budget, len(remaining))):
                selected[v] = freq[v]

    else:
        # --- Free-text: diverse lengths + diverse content
        strategy = "free_text"
        by_len = sorted(distinct, key=len)
        n = len(by_len)

        # 5 short, 5 long
        short_vals = by_len[:5]
        long_vals = by_len[-5:] if n > 5 else []

        # 10 near median length
        lengths = [len(v) for v in by_len]
        if lengths:
            median_len = lengths[n // 2]
            near_median = sorted(distinct, key=lambda v: abs(len(v) - median_len))
        else:
            near_median = []

        # 10 diverse (digits, punctuation-heavy, non-ASCII, etc.)
        def _diversity_score(v: str) -> int:
            score = 0
            if re.search(r"\d", v):
                score += 1
            if re.search(r"[^\w\s]", v):
                score += 1 # punctuation-heavy
            if any(ord(ch) > 127 for ch in v):
                score += 1 # non-ASCII
            if "\n" in v or "\r" in v:
                score += 1 # multiline
            if len(v) > 200:
                score += 1 # very long
            return score

        diverse_sorted = sorted(distinct, key=_diversity_score, reverse=True)

        # Assemble, deduplicating as we go
        for pool in (short_vals, long_vals, near_median[:10], diverse_sorted[:10]):
            for v in pool:
                if v not in selected and len(selected) < budget:
                    selected[v] = freq[v]

        # Fill any remaining slots randomly
        remaining = [v for v in distinct if v not in selected]
        fill = budget - len(selected)
        if fill > 0 and remaining:
            for v in _rng.sample(remaining, min(fill, len(remaining))):
                selected[v] = freq[v]

    return (
        [{"value": v, "freq": selected[v]} for v in sorted(selected.keys(), key=lambda v: (-selected[v], v))],
        strategy,
    )


# -----------------------------------------------------------------------------
# Main column summariser
# -----------------------------------------------------------------------------


def _summarize_column(values: List[Any]) -> Dict[str, Any]:
    """Summarise a single column's values with smart-30 sampling.

    Returns a dict with keys: non_null_type, sample_type, sample_rows, stats.
    ``sample_rows`` entries are dicts ``{"value": ..., "freq": N}`` so the
    coding agent can see both representative examples *and* their prevalence.
    """
    total = len(values)
    non_null = [v for v in values if not _is_blank_value(v)]
    nan_percentage = round((1 - (len(non_null) / max(1, total))) * 100, 2)

    numeric_values = [v for v in (_parse_numeric_value(v) for v in non_null) if v is not None]
    date_values = [v for v in (_parse_date_value(v) for v in non_null) if v is not None]

    numeric_ratio = len(numeric_values) / max(1, len(non_null)) if non_null else 0
    date_ratio = len(date_values) / max(1, len(non_null)) if non_null else 0

    non_null_type: Optional[str]
    if non_null and numeric_ratio >= 0.8:
        non_null_type = "number"
    elif non_null and date_ratio >= 0.8:
        non_null_type = "date"
    elif non_null:
        non_null_type = "text"
    else:
        non_null_type = None

    # --- Smart sampling by detected type
    sample_rows: List[Dict[str, Any]] = []
    sample_type: str = "smart_30"

    if non_null_type == "number":
        sample_rows = _smart_sample_numeric(numeric_values, budget=MAX_SAMPLE_ROWS_PER_COLUMN)
    elif non_null_type == "date":
        sample_rows = _smart_sample_dates(date_values, budget=MAX_SAMPLE_ROWS_PER_COLUMN)
    elif non_null_type == "text":
        text_vals = [str(v) for v in non_null]
        sample_rows, sample_type = _smart_sample_text(text_vals, budget=MAX_SAMPLE_ROWS_PER_COLUMN)

    # --- Distinct count (computed from full population, not samples)
    if non_null_type == "number":
        distinct_count = len(set(numeric_values))
    elif non_null_type == "date":
        distinct_count = len(set(
            v.date().isoformat() if isinstance(v, datetime.datetime) else str(v)
            for v in date_values
        ))
    elif non_null_type == "text":
        distinct_count = len(set(str(v) for v in non_null))
    else:
        distinct_count = 0

    stats: Dict[str, Any] = {
        "nan_percentage": nan_percentage,
        "distinct_count": distinct_count,
    }

    if non_null_type == "text":
        lengths = [len(str(v)) for v in non_null]
        stats["text"] = {
            "length_min": min(lengths) if lengths else None,
            "length_max": max(lengths) if lengths else None,
            "length_avg": round(sum(lengths) / max(1, len(lengths)), 2) if lengths else None,
        }
    elif non_null_type == "date":
        if date_values:
            min_dt = min(date_values)
            max_dt = max(date_values)
            stats["date"] = {
                "min": min_dt.date().isoformat(),
                "max": max_dt.date().isoformat(),
            }
    elif non_null_type == "number":
        if numeric_values:
            zero_pct = round((sum(1 for v in numeric_values if v == 0) / max(1, len(numeric_values))) * 100, 2)
            neg_pct = round((sum(1 for v in numeric_values if v < 0) / max(1, len(numeric_values))) * 100, 2)
            stats["number"] = {
                "min": min(numeric_values),
                "max": max(numeric_values),
                "mean": round(sum(numeric_values) / max(1, len(numeric_values)), 2),
                "zero_percentage": zero_pct,
                "negative_percentage": neg_pct,
            }

    return {
        "non_null_type": non_null_type,
        "sample_type": sample_type,
        "sample_rows": sample_rows,
        "stats": stats,
    }


def _summarize_table_block(block: Dict[str, Any]) -> Dict[str, Any]:
    headers = block.get("segments", [{}])[0].get("headers", []) if block.get("segments") else []
    header_row = _header_row(headers)

    rows = list(_iter_rows(block.get("segments", [])))
    row_numbers = [_row_index(r) for r in rows]
    row_numbers_non_null = [r for r in row_numbers if r is not None]

    if row_numbers_non_null:
        data_run_start = min(row_numbers_non_null)
    elif header_row is not None:
        data_run_start = header_row + 1
    else:
        data_run_start = 1

    max_cols = max([len(headers)] + [len(row) for row in rows]) if rows else len(headers)
    header_names, header_cells = _header_names_and_cells(headers, max_cols, header_row)

    row_entries: List[Dict[str, Any]] = []
    for idx, row in enumerate(rows):
        row_num = row_numbers[idx]
        row_idx = row_num if row_num is not None else data_run_start + idx
        row_type = classify_row_type(row, headers, row_idx, data_run_start)
        row_entries.append({
            "row_index": row_idx,
            "row_type": row_type,
            "row_values": _row_values(row, max_cols),
        })

    row_groups: List[Dict[str, Any]] = []
    current_group: List[Dict[str, Any]] = []
    current_type: Optional[str] = None
    group_id = 0

    def _flush_group() -> None:
        nonlocal group_id, current_group, current_type
        if not current_group:
            return
        group_id += 1
        start_row = current_group[0]["row_index"]
        end_row = current_group[-1]["row_index"]
        columns: List[Dict[str, Any]] = []
        for col_idx in range(max_cols):
            col_values = [entry["row_values"][col_idx] for entry in current_group]
            col_summary = _summarize_column(col_values)
            columns.append({
                "header_cell": header_cells[col_idx],
                "header_name": header_names[col_idx],
                **col_summary,
            })
        row_groups.append({
            "row_group_id": group_id,
            "row_type": current_type,
            "row_range": {"start": start_row, "end": end_row},
            "columns": columns,
        })
        current_group = []

    for entry in row_entries:
        if current_type is None:
            current_type = entry["row_type"]
        if entry["row_type"] != current_type:
            _flush_group()
            current_type = entry["row_type"]
        current_group.append(entry)

    _flush_group()

    return {
        "table_range": block.get("range"),
        "header_row": header_row,
        "row_groups": row_groups,
    }


def _collect_sheet_context(sheet: Dict[str, Any]) -> Dict[str, Any]:
    """Collect non-table context from a sheet: floating text, key-value pairs,
    and text lines. This context is attached to every table summary on the
    sheet so that each segment prompt has access to carrier names, evaluation
    dates, policy numbers, and other metadata that often live outside the
    claim table itself.

    Every text entry now includes its Excel cell reference (e.g. "A1") so
    the coding agent can pull data via cell references easily.

    Context is split into ``context_above`` (text that appears above or
    around tables) and ``context_below`` (footnotes, disclaimers and other
    floating text that appears after the last data row of a table).
    """
    text_blocks: List[Dict[str, Any]] = []
    context_above_table: List[Dict[str, Any]] = []
    context_below_table: List[Dict[str, Any]] = []
    key_value_pairs: List[Dict[str, Any]] = []
    non_table_rows: List[Dict[str, Any]] = []

    # Establish sheet-level table bounds so non-table text can be mapped to
    # above/below context buckets relative to the detected tables.
    table_ranges = [
        _parse_table_range(block.get("range"))
        for block in sheet.get("blocks", [])
        if block.get("type") == "table"
    ]
    table_ranges = [r for r in table_ranges if r is not None]
    table_min_row = min([r[0] for r in table_ranges], default=None)
    table_max_row = max([r[2] for r in table_ranges], default=None)

    def _add_context_entry(
        value: Any,
        *,
        cell: Optional[str] = None,
        preferred_bucket: Optional[str] = None,
    ) -> None:
        if value is None:
            return
        text = str(value).strip()
        if not text:
            return

        entry: Dict[str, Any] = {"value": text}
        if cell:
            entry["cell"] = cell

        # Preserve explicit table-provided bucket when available.
        if preferred_bucket == "above":
            context_above_table.append(entry)
            return
        if preferred_bucket == "below":
            context_below_table.append(entry)
            return

        # Otherwise infer from row position relative to detected table region.
        row_idx = _parse_cell_row(cell) if cell else None
        if row_idx is not None and table_max_row is not None and row_idx > table_max_row:
            context_below_table.append(entry)
            return
        if row_idx is not None and table_min_row is not None and row_idx < table_min_row:
            context_above_table.append(entry)
            return

        # Default for in-band / unknown positions: treat as above/around context.
        context_above_table.append(entry)

    for block in sheet.get("blocks", []):
        block_type = block.get("type")

        if block_type == "table":
            # --- Structured context (new format) ---
            # The segmentation step now emits ``context_above`` and
            # ``context_below`` as lists of {cell, value} dicts.
            ctx_above = block.get("context_above")
            if ctx_above and isinstance(ctx_above, list):
                for entry in ctx_above:
                    if isinstance(entry, dict) and entry.get("value"):
                        _add_context_entry(
                            entry["value"],
                            cell=entry.get("cell"),
                            preferred_bucket="above",
                        )

            ctx_below = block.get("context_below")
            if ctx_below and isinstance(ctx_below, list):
                for entry in ctx_below:
                    if isinstance(entry, dict) and entry.get("value"):
                        _add_context_entry(
                            entry["value"],
                            cell=entry.get("cell"),
                            preferred_bucket="below",
                        )

            # --- Legacy plain-text fallback ---
            # Older segmented files may only have the "context" string.
            if not ctx_above:
                context_str = block.get("context")
                if context_str and isinstance(context_str, str):
                    for line in context_str.strip().splitlines():
                        line = line.strip()
                        if line:
                            _add_context_entry(line, preferred_bucket="above")
            continue

        # Non-table blocks: key_values, text_lines, floating_text
        for segment in block.get("segments", []):
            seg_type = segment.get("row_type") or block_type

            headers = segment.get("headers", [])
            rows = segment.get("rows", [])

            if seg_type in ("key_values", "key-value"):
                # Key-value blocks: 2-column rows where col-0 is a label
                for row in rows:
                    if len(row) >= 2:
                        key_cell = row[0] if isinstance(row[0], dict) else {}
                        val_cell = row[1] if isinstance(row[1], dict) else {}
                        key_text = key_cell.get("value")
                        val_text = val_cell.get("value")
                        if key_text is not None and str(key_text).strip():
                            key_str = str(key_text).strip()
                            value_str = str(val_text).strip() if val_text is not None else None
                            key_value_pairs.append({
                                "key": key_str,
                                "key_cell": key_cell.get("cell"),
                                "value": value_str,
                                "value_cell": val_cell.get("cell"),
                            })
                            # Promote key-value metadata into contextual text so
                            # coding prompts can consume it via context_above/below.
                            line = f"{key_str}: {value_str}" if value_str else key_str
                            _add_context_entry(line, cell=key_cell.get("cell"))
                    elif len(row) == 1:
                        cell = row[0] if isinstance(row[0], dict) else {}
                        val = cell.get("value")
                        if val is not None and str(val).strip():
                            text_entry = {
                                "cell": cell.get("cell"),
                                "value": str(val).strip(),
                            }
                            text_blocks.append(text_entry)
                            _add_context_entry(text_entry["value"], cell=text_entry.get("cell"))

            elif seg_type in ("text_lines", "floating_text"):
                for row in rows:
                    row_cells: List[Dict[str, Any]] = []
                    for cell in row:
                        if isinstance(cell, dict):
                            val = cell.get("value")
                            if val is not None and str(val).strip():
                                text_entry = {
                                    "cell": cell.get("cell"),
                                    "value": str(val).strip(),
                                }
                                text_blocks.append(text_entry)
                                _add_context_entry(text_entry["value"], cell=text_entry.get("cell"))
                                row_cells.append({
                                    "cell": cell.get("cell"),
                                    "value": str(val).strip(),
                                })
                    if row_cells:
                        non_table_rows.append({"cells": row_cells})

            else:
                # Unknown block type - capture any text content
                for row in rows:
                    for cell in row:
                        if isinstance(cell, dict):
                            val = cell.get("value")
                            if val is not None and str(val).strip():
                                text_entry = {
                                    "cell": cell.get("cell"),
                                    "value": str(val).strip(),
                                }
                                text_blocks.append(text_entry)
                                _add_context_entry(text_entry["value"], cell=text_entry.get("cell"))

    # --- Deduplicate each list by value while preserving order ---
    def _dedup(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        seen: set = set()
        out: List[Dict[str, Any]] = []
        for item in items:
            val = item.get("value", "")
            if val and val not in seen:
                seen.add(val)
                out.append(item)
        return out

    return {
        "context_above": _dedup(context_above_table),
        "context_below": _dedup(context_below_table),
        "text_blocks": _dedup(text_blocks),
        "key_value_pairs": key_value_pairs,
        "non_table_rows": non_table_rows,
    }


# -----------------------------------------------------------------------------
# Fix 2: Overlap deduplication helpers
# -----------------------------------------------------------------------------


def _parse_table_range(range_str: Optional[str]) -> Optional[Tuple[int, int, int, int]]:
    """Parse an Excel range like 'A2:BL111' into (min_row, min_col, max_row, max_col)."""
    if not range_str or not isinstance(range_str, str):
        return None
    m = re.match(r"^([A-Z]+)(\d+):([A-Z]+)(\d+)", range_str.strip().upper())
    if not m:
        return None
    from openpyxl.utils import column_index_from_string
    return (
        int(m.group(2)),
        column_index_from_string(m.group(1)),
        int(m.group(4)),
        column_index_from_string(m.group(3)),
    )


def _range_contains(outer: Tuple[int, int, int, int], inner: Tuple[int, int, int, int]) -> bool:
    """Return True if *outer* fully contains *inner* (rows of inner within outer)."""
    return outer[0] <= inner[0] and outer[2] >= inner[2]


def _range_row_count(r: Tuple[int, int, int, int]) -> int:
    return r[2] - r[0] + 1


def _range_col_count(r: Tuple[int, int, int, int]) -> int:
    return r[3] - r[1] + 1


def _range_area(r: Tuple[int, int, int, int]) -> int:
    return _range_row_count(r) * _range_col_count(r)


def _deduplicate_table_blocks(blocks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Remove table blocks whose row range is fully contained by a larger table
    on the same sheet. This prevents auxiliary side-tables from generating
    duplicate segments for rows already covered by the main table.
    """
    table_blocks = [(i, b) for i, b in enumerate(blocks) if b.get("type") == "table"]
    if len(table_blocks) <= 1:
        return blocks # nothing to deduplicate

    parsed: List[Tuple[int, Optional[Tuple[int, int, int, int]]]] = []
    for i, b in table_blocks:
        parsed.append((i, _parse_table_range(b.get("range"))))

    to_remove = set()
    for idx_a, (i_a, r_a) in enumerate(parsed):
        if r_a is None:
            continue
        for idx_b, (i_b, r_b) in enumerate(parsed):
            if idx_a == idx_b or r_b is None or i_b in to_remove:
                continue
            # If r_a fully contains r_b's rows and r_a is strictly larger,
            # mark r_b for removal.
            if _range_contains(r_a, r_b) and _range_area(r_a) > _range_area(r_b):
                to_remove.add(i_b)

    if not to_remove:
        return blocks
    return [b for i, b in enumerate(blocks) if i not in to_remove]


# -----------------------------------------------------------------------------
# Fix 3: Merge adjacent micro-tables with compatible column structure
# -----------------------------------------------------------------------------


def _header_signature(block: Dict[str, Any]) -> Optional[Tuple[str, ...]]:
    """Return a normalised tuple of header names for a table block.
    Two tables with the same header signature are likely fragments of one
    logical table that was split on subtotal rows.
    """
    segments = block.get("segments", [])
    if not segments:
        return None
    headers = segments[0].get("headers", [])
    if not headers:
        return None
    return tuple(
        str(h.get("text", "")).strip().lower()
        for h in headers
    )


def _merge_compatible_adjacent_blocks(blocks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Merge adjacent table blocks that share the same header signature.

    When a subtotal row causes the table detector to split one logical table
    into several small tables each with 1-header + N-data rows, we merge them
    back. The subtotal rows (which become the data rows in the tiny fragment
    tables) will later be classified as total/non_informative by the row-type
    detector and excluded from extraction.
    """
    if len(blocks) <= 1:
        return blocks

    merged: List[Dict[str, Any]] = []
    i = 0
    while i < len(blocks):
        current = blocks[i]
        if current.get("type") != "table":
            merged.append(current)
            i += 1
            continue

        current_sig = _header_signature(current)
        if current_sig is None:
            merged.append(current)
            i += 1
            continue

        # Accumulate compatible adjacent tables
        combined_segments = list(current.get("segments", []))
        combined_range = current.get("range", "")
        j = i + 1
        while j < len(blocks):
            next_block = blocks[j]
            if next_block.get("type") != "table":
                break
            next_sig = _header_signature(next_block)
            if next_sig is None or next_sig != current_sig:
                break

            # Merge: append next block's rows into current, skip its headers
            for seg in next_block.get("segments", []):
                # Re-use the original headers from the first block
                merged_seg = {
                    "row_type": seg.get("row_type", "data_group"),
                    "headers": combined_segments[0].get("headers", []),
                    "rows": seg.get("rows", []),
                }
                combined_segments.append(merged_seg)
            # Expand the range string
            next_range = next_block.get("range", "")
            if combined_range and next_range:
                r1 = _parse_table_range(combined_range)
                r2 = _parse_table_range(next_range)
                if r1 and r2:
                    from openpyxl.utils import get_column_letter
                    new_min_row = min(r1[0], r2[0])
                    new_min_col = min(r1[1], r2[1])
                    new_max_row = max(r1[2], r2[2])
                    new_max_col = max(r1[3], r2[3])
                    combined_range = (
                        f"{get_column_letter(new_min_col)}{new_min_row}:"
                        f"{get_column_letter(new_max_col)}{new_max_row}"
                    )
            j += 1

        merged.append({
            "type": "table",
            "range": combined_range,
            "context": current.get("context"),
            "segments": combined_segments,
        })
        i = j

    return merged


def summarize_segmented_payload(
    payload: Dict[str, Any],
    sheet_classifications: Optional[Dict[str, bool]] = None,
    context_sheet_summaries: Optional[List[Dict[str, str]]] = None,
) -> List[Dict[str, Any]]:
    """Summarize a segmented Excel payload into per-table summaries.

    Parameters
    ----------
    payload:
        The full segmented JSON payload (``{"sheets": [...]}``)
    sheet_classifications:
        Optional dict ``{sheet_name: is_relevant}`` from the LLM-based
        sheet classifier in ``file_relevancy.py``. Sheets marked
        ``False`` are skipped. When ``None``, all sheets are
        processed (backwards-compatible).
    context_sheet_summaries:
        Optional list of ``{"source_sheet": str, "summary": str}`` dicts
        from metadata-only sheets (parse_full_sheet=False &
        is_still_relevant=True). These are injected into every
        extractable table's context so the coding agent can use
        cross-sheet metadata (evaluation dates, carrier names, etc.).
    """
    summaries: List[Dict[str, Any]] = []

    # Per-file metadata attached to every table summary so the output
    # JSON is self-describing (which source workbook produced it and when).
    source_file = payload.get("source_file", "")
    generated_at = datetime.datetime.now(datetime.timezone.utc).isoformat()

    sheets = payload.get("sheets", [])

    # --- Identify sheets that should be skipped for extraction ---
    skipped_sheet_names: List[str] = []
    if sheet_classifications and len(sheets) >= 2:
        # Only filter when 2+ sheets exist (single-sheet always processes)
        skipped_sheet_names = [
            name for name, should_extract in sheet_classifications.items()
            if not should_extract
        ]
        # Safety: only skip sheets if at least one sheet remains extractable.
        any_extractable_sheet = any(
            sheet_classifications.get(s.get("sheet_name", ""), True)
            for s in sheets
        )
        if not any_extractable_sheet:
            skipped_sheet_names = []  # Don't skip everything

    if skipped_sheet_names:
        from tqdm import tqdm as _tqdm
        preview = skipped_sheet_names[:CLI_PREVIEW_ITEM_LIMIT]
        remaining = len(skipped_sheet_names) - len(preview)
        suffix = f", ... (+{remaining} more)" if remaining > 0 else ""
        _tqdm.write(
            f"  ⚡ Skipping non-extractable sheet(s): "
            f"{', '.join(preview)}{suffix}"
        )

    for sheet in sheets:
        sheet_name = sheet.get("sheet_name", "")

        # Skip sheets classified as non-extractable by the agent.
        if sheet_name in skipped_sheet_names:
            continue

        # Collect sheet-level context once, attach to every table on this sheet
        sheet_context = _collect_sheet_context(sheet)

        blocks = sheet.get("blocks", [])
        blocks = _deduplicate_table_blocks(blocks)
        blocks = _merge_compatible_adjacent_blocks(blocks)

        for block in blocks:
            if block.get("type") not in ("table", "key_values", "key-value"):
                continue

            table_summary = _summarize_table_block(block)
            table_summary["context_around_table"] = sheet_context

            # --- Inject cross-sheet context from metadata-only sheets ---
            if context_sheet_summaries:
                table_summary["context_from_other_sheets"] = context_sheet_summaries

            summaries.append({
                "source_file": source_file,
                "generated_at": generated_at,
                "sheet": sheet_name,
                **table_summary,
            })

    return summaries


def save_total_detection_summary_to_company_folder(
    segmented_path: Path,
    company_name: str,
    base_output_dir: str,
    sheet_classifications: Optional[Dict[str, bool]] = None,
    context_sheet_summaries: Optional[List[Dict[str, str]]] = None,
) -> Path:
    payload = _load_json(segmented_path)
    summaries = summarize_segmented_payload(
        payload,
        sheet_classifications=sheet_classifications,
        context_sheet_summaries=context_sheet_summaries,
    )
    company_dir = Path(base_output_dir) / company_name
    output_name = f"{segmented_path.stem}_totals_summary.json"
    output_path = company_dir / output_name
    _write_json(output_path, summaries)
    return output_path


# -----------------------------------------------------------------------------
# Segment Payload Builder (merged from segment_context_builder.py)
# -----------------------------------------------------------------------------
# These functions build per-segment prompt payloads for the coding agent.
# Each segment (row_group within a table) gets its own isolated context:
# 1. The row_group summary (header names, column types, sample rows, row range)
# 2. The sheet-level context around the table (key-value pairs, text blocks)
# 3. The Pydantic schema text (what the output DataFrame must look like)
# 4. The extraction instructions text (domain rules for interpretation)
# -----------------------------------------------------------------------------

import logging as _logging
import tiktoken as _tiktoken

_payload_logger = _logging.getLogger(__name__ + ".payload_builder")

# -----------------------------------------------------------------------------
# Token-based sheet routing helpers
# -----------------------------------------------------------------------------
# We use cl100k_base (GPT-4 / GPT-4o family tokeniser) for counting.
try:
    _token_enc = _tiktoken.get_encoding("cl100k_base")
except Exception:
    _token_enc = None


def _count_tokens(text: str) -> int:
    """Return the approximate token count for *text*."""
    if _token_enc is not None:
        return len(_token_enc.encode(text, disallowed_special=()))
    # Rough fallback: 1 token ≈ 4 characters
    return len(text) // 4


def count_tokens_per_sheet(
    segmented_payload: Dict[str, Any],
) -> Dict[str, int]:
    """Return `{sheet_name: token_count}` for every sheet in the payload.

    Token count is computed by serialising each sheet's JSON to a string
    and counting tokens. This gives a faithful estimate of how large the
    sheet data is when sent to the LLM.
    """
    result: Dict[str, int] = {}
    for sheet in segmented_payload.get("sheets", []):
        name = sheet.get("sheet_name", "")
        sheet_json = json.dumps(sheet, ensure_ascii=False, separators=(",", ":"))
        result[name] = _count_tokens(sheet_json)
    return result


def build_raw_table_summaries_from_segmented(
    segmented_payload: Dict[str, Any],
    sheet_names: Optional[Iterable[str]] = None,
    context_sheet_summaries: Optional[List[Dict[str, str]]] = None,
) -> List[Dict[str, Any]]:
    """Build table-summary-like dicts directly from raw *_segmented.json* data.

    For sheets whose token count is below the threshold we skip the lossy
    summarisation step and instead pass the **full raw rows** so the coding
    agent sees every value.

    The returned list has the same top-level keys that
    ``summarize_segmented_payload`` produces (``source_file``, ``sheet``,
    ``table_range``, ``header_row``, ``row_groups``,
    ``context_around_table``, ``context_from_other_sheets``) except that
    each ``row_group`` contains a ``raw_rows`` key with the verbatim row
    data instead of column-level statistics / samples.

    Parameters
    ----------
    segmented_payload:
        The full ``_segmented.json`` payload.
    sheet_names:
        If given, only process sheets whose name is in this set.
        ``None`` means process all sheets.
    context_sheet_summaries:
        Cross-sheet metadata to inject (same as in
        ``summarize_segmented_payload``).
    """
    allowed: Optional[frozenset[str]] = (
        frozenset(sheet_names) if sheet_names is not None else None
    )
    source_file = segmented_payload.get("source_file", "")
    generated_at = __import__("datetime").datetime.now(
        __import__("datetime").timezone.utc
    ).isoformat()

    summaries: List[Dict[str, Any]] = []
    for sheet in segmented_payload.get("sheets", []):
        sheet_name = sheet.get("sheet_name", "")
        if allowed is not None and sheet_name not in allowed:
            continue

        sheet_context = _collect_sheet_context(sheet)
        blocks = sheet.get("blocks", [])

        for block in blocks:
            if block.get("type") not in ("table", "key_values", "key-value"):
                continue

            segments = block.get("segments", [])
            table_range = block.get("range", "")

            import re as _re # needed for cell-ref parsing below

            # Derive header row from the first segment's headers
            header_row: Optional[int] = None
            if segments:
                first_seg = segments[0]
                headers = first_seg.get("headers", [])
                if headers:
                    cell_ref = headers[0].get("cell", "")
                    # Extract row number from cell ref like "A13"
                    m = _re.search(r"(\d+)$", cell_ref)
                    if m:
                        header_row = int(m.group(1))

            # Build row_groups from segments - keep raw rows
            row_groups: List[Dict[str, Any]] = []
            for seg in segments:
                rows = seg.get("rows", [])
                if not rows:
                    continue
                headers = seg.get("headers", [])
                header_names = [h.get("text", "") for h in headers]

                # Determine row range from cell references
                first_row_num = None
                last_row_num = None
                for row in rows:
                    for cell in row:
                        cell_ref = cell.get("cell", "")
                        m = _re.search(r"(\d+)$", cell_ref)
                        if m:
                            rn = int(m.group(1))
                            if first_row_num is None or rn < first_row_num:
                                first_row_num = rn
                            if last_row_num is None or rn > last_row_num:
                                last_row_num = rn

                row_groups.append({
                    "row_group_id": len(row_groups) + 1,
                    "row_type": seg.get("row_type", "data"),
                    "row_range": {
                        "start": first_row_num or 0,
                        "end": last_row_num or 0,
                    },
                    "header_names": header_names,
                    "raw_rows": rows,
                })

            table_entry: Dict[str, Any] = {
                "source_file": source_file,
                "generated_at": generated_at,
                "sheet": sheet_name,
                "table_range": table_range,
                "header_row": header_row,
                "row_groups": row_groups,
                "context_around_table": sheet_context,
                "_uses_raw_rows": True, # marker for downstream code
            }
            if context_sheet_summaries:
                table_entry["context_from_other_sheets"] = context_sheet_summaries

            summaries.append(table_entry)

    return summaries


_ROW_GROUP_ALWAYS_SKIP_TYPES = {"total", "sub_total", "grand_total", "count"}


def _row_group_row_count(row_group: Dict[str, Any]) -> int:
    """Return the inclusive row count for a summarized row-group."""
    row_range = row_group.get("row_range") or {}
    if not isinstance(row_range, dict):
        return 0
    start = int(row_range.get("start", 0) or 0)
    end = int(row_range.get("end", 0) or 0)
    return max(0, end - start + 1)


def _select_extractable_row_groups(table: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Select row-groups for extraction while preserving whole-table fallbacks.

    Normal flow extracts explicit data groups and skips totals/counts.
    If a table has no explicit data groups and every remaining group was marked
    ``non_informative``, keep those groups as a fallback so a false-negative
    row classifier cannot silently drop an entire table.
    """
    row_groups = [rg for rg in (table.get("row_groups") or []) if isinstance(rg, dict)]
    if not row_groups:
        return []

    explicit_candidates = [
        rg for rg in row_groups
        if rg.get("row_type", "data") not in _ROW_GROUP_ALWAYS_SKIP_TYPES.union({"non_informative"})
    ]
    if explicit_candidates:
        return explicit_candidates

    fallback_candidates = [
        rg for rg in row_groups
        if rg.get("row_type", "data") == "non_informative" and _row_group_row_count(rg) > 0
    ]
    return fallback_candidates


def count_payload_candidate_rows(table_summaries: List[Dict[str, Any]]) -> int:
    """Return the total row count currently eligible for extraction payloads."""
    total = 0
    for table in table_summaries:
        if not isinstance(table, dict):
            continue
        for row_group in _select_extractable_row_groups(table):
            total += _row_group_row_count(row_group)
    return total


def build_segment_payload(
    table_summary: Dict[str, Any],
    row_group: Dict[str, Any],
    schema_text: str,
    instructions_text: str,
    *,
    file_path: str = "",
    sheet_name: str = "",
) -> Dict[str, Any]:
    """Build a fully self-contained payload for one segment.

    This version assumes `table_summary` and `row_group` are already
    in the summarized/compacted form you want. No extra trimming is done.
    """
    return {
        "file_path": Path(file_path).name if file_path else "",
        "sheet_name": sheet_name or table_summary.get("sheet", ""),
        "table_range": table_summary.get("table_range"),
        "header_row": table_summary.get("header_row"),
        "segment_summary": row_group, # use row_group exactly as given
        "sheet_context": table_summary.get("context_around_table") or {},
        "context_from_other_sheets": table_summary.get("context_from_other_sheets") or [],
        "schema": schema_text,
        "instructions": instructions_text,
    }


def build_all_segment_payloads(
    table_summaries: List[Dict[str, Any]],
    schema_text: str,
    instructions_text: str,
    file_path: str = "",
) -> List[Dict[str, Any]]:
    """Build payloads for every data segment across all tables."""
    payloads: List[Dict[str, Any]] = []
    skipped = 0

    for table in table_summaries:
        if not isinstance(table, dict):
            continue

        sheet_name = table.get("sheet", "")
        row_groups = table.get("row_groups", [])
        selected_row_groups = _select_extractable_row_groups(table)

        # Skip tables that have no row groups (header-only tables)
        if not row_groups:
            _payload_logger.debug(
                "Skipping header-only table on sheet '%s' (range=%s)",
                sheet_name,
                table.get("table_range"),
            )
            skipped += 1
            continue

        if not selected_row_groups:
            for rg in row_groups:
                if not isinstance(rg, dict):
                    continue
                _payload_logger.debug(
                    "Skipping non-data segment on sheet '%s' rows=%s (type=%s)",
                    sheet_name,
                    rg.get("row_range"),
                    rg.get("row_type", "data"),
                )
            skipped += 1
            continue

        for rg in row_groups:
            if not isinstance(rg, dict):
                continue

            if rg not in selected_row_groups:
                _payload_logger.debug(
                    "Skipping non-data segment on sheet '%s' rows=%s (type=%s)",
                    sheet_name,
                    rg.get("row_range"),
                    rg.get("row_type", "data"),
                )
                skipped += 1
                continue

            payload = build_segment_payload(
                table_summary=table,
                row_group=rg,
                schema_text=schema_text,
                instructions_text=instructions_text,
                file_path=file_path,
                sheet_name=sheet_name,
            )
            payloads.append(payload)

        if skipped:
            _payload_logger.info(
                "Filtered out %d non-data/header-only segment(s); %d segment(s) remain.",
                skipped,
                len(payloads),
            )

    return payloads


def payload_to_json_str(payload: Dict[str, Any]) -> str:
    """Serialise a segment payload to a compact JSON string.

    The schema and instructions are kept as top-level strings rather than
    being nested in the JSON - this avoids double-encoding.
    """
    prompt_data = {
        "file_path": payload.get("file_path", ""),
        "sheet_name": payload.get("sheet_name", ""),
        "table_range": payload.get("table_range"),
        "header_row": payload.get("header_row"),
        "segment_summary": payload.get("segment_summary"),
        "sheet_context": payload.get("sheet_context"),
        "context_from_other_sheets": payload.get("context_from_other_sheets") or [],
    }
    # Include type_hint when provided by the inputs module
    type_hint = payload.get("type_hint")
    if type_hint:
        prompt_data["type_hint"] = type_hint
    return json.dumps(prompt_data, ensure_ascii=False, separators=(",", ":"))
