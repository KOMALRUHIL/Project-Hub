"""Code execution for LLM-generated extraction modules.

Supports two execution modes controlled by `constants.SANDBOX_ENABLED`:

    1. **Sandbox mode** (`SANDBOX_ENABLED = True`) - runs generated code
       inside an isolated Docker container via `llm-sandbox`. The sandbox
       infrastructure (pool, security policy, Docker session management) is
       loaded lazily only when this mode is active.

    2. **Legacy mode** (`SANDBOX_ENABLED = False`, the default) - writes
       generated code to a temp file and imports it with `importlib`. No
       Docker required.

When sandbox mode is active and a sandbox execution fails,
`SANDBOX_FALLBACK_TO_LEGACY` controls whether a silent fallback to the
legacy executor is attempted (`True`) or the error is raised immediately
(`False`). Set to `False` in production to avoid double-execution.

Configuration lives centrally in `constants.py`.
"""

from __future__ import annotations

import atexit
import importlib
import importlib.util
import os
import sys
import tempfile
import threading
import uuid
import warnings
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

from block_detection import clear_chunkable_copy_cache, evict_chunkable_copy, get_or_create_chunkable_copy
from constants import (
    SANDBOX_ENABLED,
    SANDBOX_FALLBACK_TO_LEGACY,
)
from utils import as_extended_path_str as _as_extended_path
from utils import log_cli


# -----------------------------------------------------------------------------
# Sandbox internals - loaded lazily only when SANDBOX_ENABLED is True
# -----------------------------------------------------------------------------
_sandbox_available: Optional[bool] = None
_sandbox_status_reason: Optional[str] = None
_sandbox_cli_notice_shown = False

# These are populated by _check_sandbox_available() on first call:
_SandboxSession = None
_SecurityPolicy = None
_SecurityPattern = None
_RestrictedModule = None
_SecurityIssueSeverity = None
_create_pool_manager = None
_PoolConfig = None
_pool = None
_pool_initialised = False


def _set_sandbox_status(available: bool, reason: str) -> bool:
    global _sandbox_available, _sandbox_status_reason
    _sandbox_available = available
    _sandbox_status_reason = reason
    return available


def get_sandbox_status_message() -> str:
    """Return a human-friendly sandbox status line for CLI output."""
    is_available = _check_sandbox_available()
    if is_available:
        return "📦 Sandbox mode: ENABLED - generated code runs in isolated Docker containers"
    reason = _sandbox_status_reason or "generated code runs locally instead"
    return f"⚠️ Sandbox mode: DISABLED - {reason}"


def _print_cli_sandbox_notice_once(reason: Optional[str] = None) -> None:
    global _sandbox_cli_notice_shown
    if _sandbox_cli_notice_shown:
        return
    details = reason or _sandbox_status_reason or "sandbox is unavailable"
    print(
        "⚠️  Sandbox environment was not invoked; "
        f"generated code will run locally instead ({details})."
    )
    _sandbox_cli_notice_shown = True


def _check_sandbox_available() -> bool:
    """Return True when sandbox execution is both enabled and available."""
    global _sandbox_available
    global _SandboxSession, _SecurityPolicy, _SecurityPattern
    global _RestrictedModule, _SecurityIssueSeverity
    global _create_pool_manager, _PoolConfig

    if _sandbox_available is not None:
        return _sandbox_available

    if not SANDBOX_ENABLED:
        return _set_sandbox_status(False, "disabled via constants.py (SANDBOX_ENABLED=False)")

    try:
        from llm_sandbox import SandboxSession  # type: ignore[import-not-found]
        from llm_sandbox.security import (  # type: ignore[import-not-found]
            SecurityPolicy, SecurityPattern, RestrictedModule, SecurityIssueSeverity,
        )
        _SandboxSession = SandboxSession
        _SecurityPolicy = SecurityPolicy
        _SecurityPattern = SecurityPattern
        _RestrictedModule = RestrictedModule
        _SecurityIssueSeverity = SecurityIssueSeverity

        try:
            from llm_sandbox.pool import create_pool_manager, PoolConfig  # type: ignore[import-not-found]
            _create_pool_manager = create_pool_manager
            _PoolConfig = PoolConfig
        except ImportError:
            _create_pool_manager = None
            _PoolConfig = None

        print("[SANDBOX] llm-sandbox is available - Docker sandbox execution enabled")
        return _set_sandbox_status(True, "llm-sandbox is available")
    except ImportError:
        return _set_sandbox_status(False, "llm-sandbox is not installed")
    except Exception as exc:
        return _set_sandbox_status(False, f"initialisation error: {exc}")


def get_sandbox_pool():
    """Return a shared container pool (lazy-init). Returns None when unavailable."""
    global _pool, _pool_initialised
    if _pool_initialised:
        return _pool
    _pool_initialised = True

    if not _check_sandbox_available():
        return None
    if _create_pool_manager is None or _PoolConfig is None:
        return None

    from constants import SANDBOX_POOL_MAX_SIZE, SANDBOX_POOL_MIN_SIZE
    try:
        _pool = _create_pool_manager(
            backend="docker",
            config=_PoolConfig(
                max_pool_size=SANDBOX_POOL_MAX_SIZE,
                min_pool_size=SANDBOX_POOL_MIN_SIZE,
                enable_prewarming=True,
            ),
            lang="python",
            libraries=["openpyxl", "pandas", "xlrd"],
        )
        return _pool
    except Exception:
        _pool = None
        return None


def close_sandbox_pool() -> None:
    """Shut down the shared container pool if it was created."""
    global _pool, _pool_initialised
    if _pool is not None:
        try:
            _pool.close()
        except Exception:
            pass
    _pool = None
    _pool_initialised = False


# -----------------------------------------------------------------------------
# Sandbox runner (only invoked when SANDBOX_ENABLED=True)
# -----------------------------------------------------------------------------

def _run_in_sandbox(code: str, file_path: str) -> pd.DataFrame:
    """Execute generated code inside a Docker sandbox. Raises on failure."""
    import io
    import textwrap
    from constants import (
        SANDBOX_CPU_COUNT, SANDBOX_MEMORY_LIMIT,
        SANDBOX_TIMEOUT_SECONDS, SANDBOX_VERBOSE,
    )

    _SANDBOX_WRAPPER_EPILOGUE = textwrap.dedent("""\
    # --- Sandbox harness (auto-appended) -----------------------------------
    import sys as _sys
    import traceback as _traceback

    try:
        _df = extract_segment(_SANDBOX_INPUT_PATH)
        if not isinstance(_df, __import__('pandas').DataFrame):
            print("ERROR:extract_segment returned non-DataFrame: " + type(_df).__name__, file=_sys.stderr)
            _sys.exit(1)

        _csv_output = _df.to_csv(index=False)
        print("_SANDBOX_CSV_START_")
        print(_csv_output, end="")
        print("_SANDBOX_CSV_END_")

    except Exception as _e:
        print("ERROR:" + _traceback.format_exc(), file=_sys.stderr)
        _sys.exit(1)
    """)

    ext = os.path.splitext(file_path)[1] or ".xlsx"
    sandbox_file_path = f"/sandbox/input_file{ext}"

    header = (
        f'_SANDBOX_INPUT_PATH = "{sandbox_file_path}"\n'
        f'import pandas as pd\nimport openpyxl\n\n'
    )
    full_script = header + code + "\n" + _SANDBOX_WRAPPER_EPILOGUE

    from constants import SANDBOX_CPU_COUNT as _cpu, SANDBOX_MEMORY_LIMIT as _mem
    security_policy = None
    if _SecurityPolicy is not None:
        security_policy = _SecurityPolicy(
            severity_threshold=_SecurityIssueSeverity.MEDIUM,
            restricted_modules=[
                _RestrictedModule(name="subprocess", description="Process execution not allowed", severity=_SecurityIssueSeverity.HIGH),
                _RestrictedModule(name="socket", description="Network operations not allowed", severity=_SecurityIssueSeverity.HIGH),
                _RestrictedModule(name="ctypes", description="FFI not allowed", severity=_SecurityIssueSeverity.HIGH),
            ],
            patterns=[
                _SecurityPattern(pattern=r"os\.system", description="System command execution", severity=_SecurityIssueSeverity.HIGH),
                _SecurityPattern(pattern=r"os\.popen", description="Process pipe execution", severity=_SecurityIssueSeverity.HIGH),
                _SecurityPattern(pattern=r"__import__\s*\(", description="Dynamic import not allowed", severity=_SecurityIssueSeverity.MEDIUM),
            ],
        )

    pool = get_sandbox_pool()
    session_kwargs: Dict[str, Any] = {
        "lang": "python",
        "verbose": SANDBOX_VERBOSE,
        "runtime_configs": {
            "timeout": SANDBOX_TIMEOUT_SECONDS,
            "mem_limit": SANDBOX_MEMORY_LIMIT,
            "cpu_count": SANDBOX_CPU_COUNT,
            "network_mode": "none",
        },
    }
    if security_policy is not None:
        session_kwargs["security_policy"] = security_policy
    if pool is not None:
        session_kwargs["pool"] = pool

    with _SandboxSession(**session_kwargs) as session:
        session.copy_to_runtime(file_path, sandbox_file_path)
        result = session.run(full_script)
        if result.exit_code != 0:
            raise RuntimeError(f"Sandbox execution failed (exit {result.exit_code}): {(result.stderr or '').strip()}")
        stdout = result.stdout or ""
        csv_start = stdout.find("_SANDBOX_CSV_START_")
        csv_end = stdout.find("_SANDBOX_CSV_END_")
        if csv_start == -1 or csv_end == -1:
            raise RuntimeError(f"Sandbox did not produce CSV markers. stdout={stdout[:500]!r}")
        csv_text = stdout[csv_start + len("_SANDBOX_CSV_START_"):csv_end].strip()
        if not csv_text:
            return pd.DataFrame()
        return pd.read_csv(io.StringIO(csv_text))


# -----------------------------------------------------------------------------
# Legacy (unsandboxed) executor
# -----------------------------------------------------------------------------

# Reusable temp directory - created once, cleaned up at process exit.
# Individual module files are deleted after each call, but the directory
# itself persists to avoid the overhead of mkdtemp()/rmtree() per call.
_legacy_tmp_dir: str | None = None
_legacy_tmp_dir_lock = threading.Lock()


def _get_or_convert_file(file_path: str) -> Tuple[Path, List[Path]]:
    """Return the shared prepared workbook path used across segmentation/execution."""
    return get_or_create_chunkable_copy(Path(file_path))


def clear_converted_file_cache() -> None:
    """Clear cached prepared workbook artifacts created for execution.

    Kept as a public compatibility wrapper because the pipeline imports this
    symbol from `sandbox_executor` even though the underlying cache now lives
    in `block_detection` as the chunkable-copy cache.
    """
    clear_chunkable_copy_cache()


def evict_converted_file_cache(file_path: str) -> None:
    """Evict a single file's cached conversion artifacts.

    Called after extraction completes for a file to release temp files
    immediately instead of waiting for process exit. Thread-safe so it
    can be called from concurrent Send workers without affecting other
    files still being processed.
    """
    evict_chunkable_copy(Path(file_path))


atexit.register(clear_converted_file_cache)


def _get_legacy_tmp_dir() -> str:
    """Lazily create (or return) the shared temp directory for legacy execution."""
    global _legacy_tmp_dir
    with _legacy_tmp_dir_lock:
        if _legacy_tmp_dir is None or not os.path.isdir(_legacy_tmp_dir):
            import tempfile
            _legacy_tmp_dir = tempfile.mkdtemp(prefix="segment_code_")
        return _legacy_tmp_dir


def _cleanup_legacy_tmp_dir() -> None:
    global _legacy_tmp_dir
    if _legacy_tmp_dir is not None:
        try:
            import shutil
            shutil.rmtree(_legacy_tmp_dir, ignore_errors=True)
        except OSError:
            pass
        _legacy_tmp_dir = None


atexit.register(_cleanup_legacy_tmp_dir)


def _run_legacy(code: str, file_path: str) -> pd.DataFrame:
    """Write generated code to the shared temp dir, import it, and call ``extract_segment()``. """
    module_name = f"_generated_segment_{uuid.uuid4().hex[:12]}"
    tmp_dir = _get_legacy_tmp_dir()
    module_path = os.path.join(tmp_dir, f"{module_name}.py")

    try:
        with open(module_path, "w", encoding="utf-8") as f:
            f.write(code)

        spec = importlib.util.spec_from_file_location(module_name, module_path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Cannot create module spec from {module_path}")

        mod = importlib.util.module_from_spec(spec)

        try:
            with warnings.catch_warnings():
                warnings.filterwarnings("ignore", message=r".*infer_datetime_format.*", category=FutureWarning)
                warnings.filterwarnings("ignore", message=r".*infer_datetime_format.*", category=UserWarning)
                warnings.filterwarnings("ignore", message=r".*Could not infer format.*", category=UserWarning)
                if hasattr(pd.errors, "SettingWithCopyWarning"):
                    warnings.filterwarnings("ignore", category=pd.errors.SettingWithCopyWarning)
                warnings.filterwarnings("ignore", message=r".*SettingWithCopyWarning.*", category=FutureWarning)
                spec.loader.exec_module(mod)
        except Exception as import_err:
            raise RuntimeError(f"Module-level error in generated code: {import_err}") from import_err

        # Do NOT register in sys.modules - exec_module() works without it
        # and registering is thread-unsafe: Concurrent legacy executions
        # can collide on sys.modules, and pop() can cause ModuleNotFoundError
        # in code that still holds a reference to the module.

        if not hasattr(mod, "extract_segment"):
            raise AttributeError("Generated module does not define extract_segment()")

        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", message=r".*infer_datetime_format.*", category=FutureWarning)
            warnings.filterwarnings("ignore", message=r".*infer_datetime_format.*", category=UserWarning)
            warnings.filterwarnings("ignore", message=r".*Could not infer format.*", category=UserWarning)
            if hasattr(pd.errors, "SettingWithCopyWarning"):
                warnings.filterwarnings("ignore", category=pd.errors.SettingWithCopyWarning)
            warnings.filterwarnings("ignore", message=r".*SettingWithCopyWarning.*", category=FutureWarning)
            result = mod.extract_segment(_as_extended_path(file_path))

        if not isinstance(result, pd.DataFrame):
            raise TypeError(f"extract_segment() returned {type(result).__name__}, expected pd.DataFrame")
        return result

    finally:
        try:
            os.remove(module_path)
        except OSError:
            pass


# -----------------------------------------------------------------------------
# Public API - unified executor
# -----------------------------------------------------------------------------

def execute_generated_code(code: str, file_path: str) -> pd.DataFrame:
    """Execute LLM-generated extraction code and return the resulting DataFrame.

    When sandbox is enabled and available, runs in Docker. On sandbox
    failure, behaviour depends on `SANDBOX_FALLBACK_TO_LEGACY`:
        - `True` -> silently falls back to the legacy executor (may double
          execution time for that segment).
        - `False` -> raises immediately so the segment retry loop handles it.
    """
    prepared_path, cleanup_paths = _get_or_convert_file(file_path)
    prepared_file_path = _as_extended_path(str(prepared_path))

    try:
        if _check_sandbox_available():
            try:
                return _run_in_sandbox(code, prepared_file_path)
            except Exception as sandbox_exc:
                if SANDBOX_FALLBACK_TO_LEGACY:
                    log_cli(f"[SANDBOX] Execution failed ({sandbox_exc}). Falling back to legacy executor.")
                    _print_cli_sandbox_notice_once(f"sandbox execution failed: {sandbox_exc}")
                    return _run_legacy(code, prepared_file_path)
                else:
                    raise  # Let the caller (segment retry loop) handle it
        else:
            _print_cli_sandbox_notice_once()
            return _run_legacy(code, prepared_file_path)
    finally:
        for temp_path in cleanup_paths:
            try:
                if temp_path.exists():
                    temp_path.unlink()
            except Exception:
                pass


def validate_code_in_sandbox(code: str) -> Optional[Exception]:
    """Validate generated code structurally. Returns None if clean.

    Only checks for compile-time errors and obvious structural issues
    via AST inspection. Does NOT execute the code (Bug #5 fix).
    Full runtime validation happens naturally when the code is executed
    in the segment_execute step.
    """
    import ast as _ast

    try:
        # Compile check - catches syntax errors
        compile(code, "<generated>", "exec")
    except SyntaxError:
        return None  # Syntax errors are handled separately by the caller

    # AST-level check for obviously broken module-level constructs
    # (e.g., bare expressions that would fail at import time).
    try:
        tree = _ast.parse(code, "<generated>", "exec")
        # Check for module-level bare raise/assert that would fail immediately
        for node in _ast.iter_child_nodes(tree):
            if isinstance(node, _ast.Raise):
                return RuntimeError("Module contains a bare 'raise' at top level")
    except SyntaxError:
        return None  # Already handled above
    except Exception as exc:
        return exc

    return None
