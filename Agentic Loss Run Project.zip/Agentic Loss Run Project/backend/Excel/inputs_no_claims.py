"""Pipeline inputs: schema definition + extraction instructions + relevancy config.

This file contains the main pieces that change from use-case to use-case:

    1. **Output Schema** (``ClaimRecord``) -- defines every column, type,
       format, and constraint for the extraction output DataFrame.
    2. **Extraction Instructions** (``EXTRACTION_INSTRUCTIONS``) -- domain
       rules for how to interpret source data and populate schema fields.
    3. **Relevancy Configuration** -- file-name keywords for fast-pass
       filtering and LLM-based relevancy instructions for classifying
       whether a file/sheet contains data worth extracting.
    4. **Pipeline Model Selection** (``AGENTIC_MODEL``) -- the active LLM
       configuration used across the agentic pipeline.

All agents (code generation, validation, etc.) receive these as plain text
via ``get_schema_text()``, ``get_instructions_text()``,
``get_relevancy_keywords()``, ``get_relevancy_instructions()``, and
``get_sheet_relevancy_instructions()``.

To adapt the pipeline for a different use-case, edit THIS file only.
"""

from __future__ import annotations

from typing import Any, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field


# ---------------------------------------------------------------------------
# Pipeline model selection
# ---------------------------------------------------------------------------
# Single source of truth for the active LLM used by the pipeline. Change this
# value here instead of setting AGENTIC_MODEL in .env.
#
# Valid options:
#   GPT_4_1, GPT_4_1_MINI, GPT_5, GPT_5_MINI, GPT_5_1, GPT_5_2, GPT_5_4
# ---------------------------------------------------------------------------

AGENTIC_MODEL: str = "GPT_5"


# ---------------------------------------------------------------------------
# CLI logging mode
# ---------------------------------------------------------------------------
# Single source of truth for the pipeline's default CLI logging behavior.
# Change this value to control the default logging mode everywhere.
#
# Valid options:
#   concise, verbose
# ---------------------------------------------------------------------------

CLI_LOG_MODE: Literal["concise", "verbose"] = "verbose"


def get_cli_log_mode_setting() -> str:
    """Return the configured default CLI log mode for the pipeline."""
    mode = str(CLI_LOG_MODE).strip().lower()
    if mode not in {"concise", "verbose"}:
        return "concise"
    return mode


# ---------------------------------------------------------------------------
# Utility model - used for lightweight LLM tasks
# ---------------------------------------------------------------------------
# Relevancy detection, sheet classification, and validation code generation
# are simple classification / code-gen tasks that don't need the full
# extraction model. A cheaper mini model saves 3-6x on token cost.
#
# Valid options (same as AGENTIC_MODEL above):
#   GPT_4_1, GPT_4_1_MINI, GPT_5, GPT_5_MINI, GPT_5_1, GPT_5_2, GPT_5_4
# ---------------------------------------------------------------------------

UTILITY_MODEL: str = "GPT_5"


def get_utility_model_key() -> str:
    """Return the configured model key for lightweight utility tasks."""
    return UTILITY_MODEL.strip().upper()


# ---------------------------------------------------------------------------
# Pipeline reasoning effort selection
# ---------------------------------------------------------------------------
# Explicit reasoning setting for reasoning-capable models. This is mainly
# relevant for GPT-5 family deployments. Valid options:
#   low, medium, high
#
# AGENTIC_REASONING_EFFORT - used by the extraction code-generation model.
# UTILITY_REASONING_EFFORT - used by lightweight utility tasks (relevancy
#                            detection, sheet classification, validation
#                            code generation). "low" is recommended since
#                            these tasks are simple classification / code-gen
#                            and don't benefit from deep reasoning.
# ---------------------------------------------------------------------------

AGENTIC_REASONING_EFFORT: Literal["low", "medium", "high"] = "medium"
UTILITY_REASONING_EFFORT: Literal["low", "medium", "high"] = "medium"


def get_agentic_model_key() -> str:
    """Return the configured active model key for the pipeline."""
    return AGENTIC_MODEL.strip().upper()


def get_agentic_reasoning_effort() -> str:
    """Return the configured reasoning effort for the extraction model, defaulting safely to medium."""
    effort = str(AGENTIC_REASONING_EFFORT).strip().lower()
    if effort not in {"low", "medium", "high"}:
        return "medium"
    return effort


def get_utility_reasoning_effort() -> str:
    """Return the configured reasoning effort for utility-model tasks, defaulting to low."""
    effort = str(UTILITY_REASONING_EFFORT).strip().lower()
    if effort not in {"low", "medium", "high"}:
        return "low"
    return effort


# ---------------------------------------------------------------------------
# Schema model
# ---------------------------------------------------------------------------


class ClaimRecord(BaseModel):
    """Schema for a single policy period with no claims.

    Every column in the output DataFrame corresponds to a field on this model.
    """

    model_config = ConfigDict(extra="forbid")

    policy_effective_year: Optional[int] = Field(
        None,
        description=(
            "Format YYYY; the policy year that did not have a claim. "
            "This is the year component of the policy effective date. "
            "For example, if the policy effective date is 05/12/2022, "
            "the policy_effective_year is 2022."
        ),
    )
    line_of_business: Optional[Literal["property", "auto", "general liability", "workers compensation", "umbrella"]] = Field(
        None,
        description=(
            "Line of business. Must be one of: 'auto', 'property', 'general liability', "
            "'workers compensation', or 'umbrella'. "
            "Use lowercase for all values."
        ),
    )
    prior_carrier: Optional[str] = Field(
        None,
        description=(
            "The name of the prior insurance carrier or agency for the policy. "
            "Must be a company name containing letters - not a flag, date, or number. "
            "Might appear in the header, logo, or sometimes hidden in contact details "
            "or emails attached to the file."
        ),
    )
    evaluation_date: Optional[str] = Field(
        None,
        description=(
            "Format MM/DD/YYYY. The date of the claim loss run evaluation. "
            "Often labeled as 'valued as of', 'valuation date', 'losses valued as of', "
            "or similar, and can sometimes appear in the file name."
        ),
        json_schema_extra={"format": "MM/DD/YYYY"},
    )


# ---------------------------------------------------------------------------
# Utility: serialise the schema for inclusion in prompts
# ---------------------------------------------------------------------------


def _field_description_line(name: str, field_info: Any) -> str:
    """Build a single human-readable line describing a schema field."""
    annotation = field_info.annotation

    # Resolve Optional[X] -> X
    type_str = "string"
    args = getattr(annotation, "__args__", ())
    inner = args[0] if args else annotation

    if inner is float:
        type_str = "float"
    elif inner is int:
        type_str = "int"
    elif inner is str:
        type_str = "string"
    elif hasattr(inner, "__args__"):
        # Literal
        type_str = f"one of {list(inner.__args__)}"

    parts = [f"- **{name}** ({type_str})"]

    # Format hint
    extra = getattr(field_info, "json_schema_extra", None) or {}
    fmt = extra.get("format")
    if fmt:
        parts.append(f" Format: {fmt}.")

    # Constraints
    meta = getattr(field_info, "metadata", [])
    for m in meta:
        if hasattr(m, "ge") and m.ge is not None:
            parts.append(f" Must be >= {m.ge}.")

    # Description
    desc = getattr(field_info, "description", None)
    if desc:
        parts.append(f" {desc}")

    return "".join(parts)


def get_schema_text() -> str:
    """Serialise the ClaimRecord schema into a prompt-friendly text block.

    This text is passed to the coding agent so it knows exactly what columns
    to produce and what format / type / constraints each column must satisfy.
    """
    lines = ["# Output Dataframe Schema", ""]
    lines.append("Each row in the output DataFrame represents one policy period with no claims.")
    lines.append("The DataFrame must have exactly these columns:\n")

    for name, field_info in ClaimRecord.model_fields.items():
        lines.append(_field_description_line(name, field_info))

    lines.append("")
    lines.append("All columns are nullable (None / NaN is acceptable when the source has no value).")
    lines.append("Do NOT include commas in numeric values.")
    lines.append("If no policy periods without claims are found in the segment, return an empty DataFrame with these columns.")

    return "\n".join(lines)


def get_column_names() -> List[str]:
    """Return the ordered list of column names from the schema."""
    return list(ClaimRecord.model_fields.keys())


# ===========================================================================
# OUTPUT COLUMN ORDERING CONFIGURATION
# ===========================================================================
# Single source of truth for all column name strings referenced across the
# pipeline. Change values here to adapt to a new schema - no edits needed
# in pipeline.py or extraction.py.
# ===========================================================================

# The schema field placed as the leftmost column in every output DataFrame.
# Set to "" to disable special leading-column treatment.
LEADING_SCHEMA_COLUMN: str = "policy_effective_year"

# Non-schema metadata columns appended to the right of every output DataFrame.
# The pipeline stamps these automatically on each extracted row.
ACCOUNT_NAME_COLUMN: str = "AccountName"
FILE_SOURCE_COLUMN: str = "file_path"
METADATA_COLUMNS: List[str] = [ACCOUNT_NAME_COLUMN, FILE_SOURCE_COLUMN]

# Output CSV filename for the no-claims extraction.
# The final output will be saved as this filename in the account directory.
OUTPUT_CSV_FILENAME: str = "excel_policies_no_claims.csv"


def get_leading_schema_column() -> str:
    """Return the schema column placed leftmost in the output DataFrame."""
    return LEADING_SCHEMA_COLUMN


def get_account_name_column() -> str:
    """Return the metadata column that holds the account / company name."""
    return ACCOUNT_NAME_COLUMN


def get_file_source_column() -> str:
    """Return the metadata column that holds the source file name."""
    return FILE_SOURCE_COLUMN


def get_output_csv_filename() -> str:
    """Return the configured output CSV filename."""
    return OUTPUT_CSV_FILENAME


def get_output_file_suffix() -> str:
    """Return the output file suffix/filename for no-claims extraction."""
    return OUTPUT_CSV_FILENAME


def get_output_column_order() -> List[str]:
    """Return the canonical output column order.

    Layout: [leading schema column] + [remaining schema columns] + [metadata columns]
    """
    schema_cols = get_column_names()
    leading_col = LEADING_SCHEMA_COLUMN
    if leading_col and leading_col in schema_cols:
        leading = [leading_col]
        rest = [f for f in schema_cols if f != leading_col]
    else:
        leading = []
        rest = list(schema_cols)
    return leading + rest + list(METADATA_COLUMNS)


# ===========================================================================
# EXTRACTION INSTRUCTIONS (Input #2)
# ===========================================================================
# Domain-specific rules for how to interpret source data and populate schema
# fields. To change extraction behaviour, edit the text below - no code
# changes are needed anywhere else.
# ===========================================================================

EXTRACTION_INSTRUCTIONS = """
# Task
Your task as an experienced underwriter is to conduct a thorough analysis and identify all insurance policy periods in which no claims were reported/filed. Begin by reviewing each policy,
comparing policy numbers and effective dates with any associated claims. Your goal is to find policy years that do not have any claims linked to them during the covered window or that have no information
about claims despite being listed on the document as a policy.

**Important note about these files:** These loss runs can be very tricky to interpret - you must try to catch all unstructured ness and ambiguity in the documents and use your best judgement
to interpret the data correctly. The documents are often very messy, with inconsistent formatting, missing headers, and a mix of structured tables and unstructured text. You must be extremely careful
to understand the context of each piece of information and how it relates to the policies and claims. Pay close attention to clear rows that may list policies without claims, but also consider
the possibility of highly unstructured tables with subtotals or totals for different breakdowns like line of business or policy period. Ensure that you are trying many possible ways to capture
the claim-free policies, and not just looking for perfectly structured tables with clear headers. Use all the clues in the document, including file names, headers, footers, and any unstructured text that may indicate claim-free periods.

For example if there is a column that clearly has claim or incident count with a 0, you might try to first clearly get the line of business and policy effective year but if it doesn't
align perfectly in that row, you could try a separate pass that interprets the table differently. Try most basic code configurations first but then also allow for more nuanced and
complex interpretations of the tables if the first pass doesn't yield many claim-free policies. The documents can be very inconsistent so you must be flexible and creative in how you
interpret the data, but also careful to stay grounded in the actual evidence on the page and not make assumptions that aren't supported by the document.

**Important Note on Policies and Policy Years:**
- Policies may repeat over multiple years, having different effective dates.
- Claims are tied to a specific policy period by effective date.
- Most policies cover 12 months. If a period is longer, break it into separate 12-month windows.
- **Important:** Pay particular attention to scenarios where an insurer issues the same policy number for multiple, consecutive years. For example, it could say Policy ABC123 from 2019-2023.
This means there were Policies with effective dates in 2019, 2020, 2021, and 2022 for that policy number. In these cases, carefully evaluate each distinct policy year using the effective and expiration dates.
If there is a property claim in 2019 on the page and it shows the policy extending from 2019-2023, then it is safe to assume the policy years from 2020-2023 had 0 property claims and should be included in your output.
If there are no claims shown within a 12-month policy period, then put that as a policy with no claims.

**Important Note on Lines of Business:**
Each policy may include coverage for multiple lines of business (you are only looking for Auto, Property, General Liability, Workers Compensation, or Umbrella). Do not include other lines of business,
it should only be those. Products Liability is General Liability. It is essential to recognize that a policy period could have claims for one line of business but not for others. It also could have claims for multiple lines.
Carefully review the loss run to determine exactly which lines of business are represented, it may or may not be all of them, and focus your analysis on those lines. If a policy period has no claims for a
specific line of business referenced in the loss run, list that period as claim-free for that line, even if other lines under the same policy number have reported losses. Your results must clearly indicate
the correct line of business for each claim-free policy period.

You may have to use the file name to understand which types of losses are being shown in this loss run. That file name may include something like AL or Prop or WC or UMB or other abbreviations about which
type of losses are shown in the loss run. You also may need to use context clues about the other claims in the document, for example if only auto claims are shown and there's a policy period with no claims
without any reference to a line of business, then it is most likely referencing no auto claims.

There also might be blanket statements in cells not tables that say something like "no prior losses" and point to a specific lob / policy period. Make sure to account for those and try to tie those statements
to a specific line of business and policy period if possible.

**How to handle huge tables of claims**:
- Prefer policy-level or year-level summary evidence over detailed claim-row evidence. If the document contains a summary, subtotal, annual rollup, policy-period table, or any view that directly lists policy years,
  effective dates, or policy terms, treat that as the primary source for identifying claim-free periods.
- Detailed claim tables with claim numbers, loss dates, descriptions, paid/incurred amounts, or reserve fields are secondary evidence.
- If a detailed claim table shows claims tied to policy years within a clearly established continuous policy range for the same policy number and the same line of business, you may infer that missing interior years within
  that range had 0 claims only when the document supports that those missing years existed as policy periods.
  - Example: if the document shows the same policy continuing from 2020 through 2024 for Property, and claims appear for 2020, 2021, and 2024, then it is reasonable to infer that 2022 and 2023 were claim-free for
    Property because they are interior years inside the documented continuous range.
- Do NOT infer claim-free years outside the observed or documented range. In the example above, do NOT assume 2019 or 2025 had no claims.
- Do NOT treat missing claim rows by themselves as proof of no claims. Absence of a detailed claim row is only useful when paired with evidence that the policy year existed and falls inside a documented range.
- Be especially cautious when the table is purely claim detail. Detailed rows often omit claim-free years entirely, but like above if there is evidence, use it wisely.
- If a large table includes subtotal rows, blank-claim rows, policy-period rollups, or rows with effective dates but no claim number / claim id, examine those carefully because they may indicate a policy period with no claims.

**Evidence Priority Rule:**
- When deciding whether a policy year had no claims, use this order of trust:
  1. Explicit statements that there were no claims / no losses
  2. Policy-year summaries, annual rollups, subtotal rows, or schedule-style policy-period views
  3. Continuous policy date ranges combined with observed claim years
  4. Detailed individual claim rows only as supporting evidence
- If stronger evidence conflicts with weaker evidence, trust the stronger evidence.

**Some information may be tricky to find:**
- **Prior insurance carrier:** Might appear in the header, logo, or sometimes hidden in contact details or emails attached to the file.

You must be perfectly accurate. No mistakes.

**Final Checks:**
- Ensure the effective dates are split into their year-by-year windows if the policy is spanning multiple years.
- Ensure you have analyzed for the correct line of business for each policy period. Use context clues from the file name and the other claims in the document to determine which lines of business are being shown.
- Ensure any inferred claim-free year falls inside a policy period or continuous policy range explicitly supported by the document.
- Do NOT infer claim-free years outside the earliest and latest supported policy years for that policy number and line of business.
- If using a detailed claim table to infer a missing year, confirm that the missing year is an interior gap within a documented continuous range, not an extrapolation beyond the range.
- Prefer omission over guessing when the document does not clearly establish policy continuity.
"""


def get_instructions_text() -> str:
    """Return the extraction instructions text."""
    return EXTRACTION_INSTRUCTIONS


# ===========================================================================
# RELEVANCY CONFIGURATION (Input #3)
# ===========================================================================
# Controls which files are relevant for extraction. The pipeline uses a
# two-tier approach:
#
#   Tier 1 - **Filename keyword check** (instant, no LLM cost).
#            If ANY keyword below appears in the file name, the file is
#            immediately accepted. Case-insensitive substring matching.
#
#   Tier 2 - **LLM-based content classification** (only when Tier 1 misses).
#            The file's sample rows are sent to the LLM along with the
#            relevancy instructions below. The LLM decides if the content
#            matches the extraction use-case.
#
# To adapt for a different use-case, change the keywords and rewrite the
# instructions to describe what "relevant" means for your domain.
# ===========================================================================

RELEVANCY_FILENAME_KEYWORDS: List[str] = [
    # Keywords that, if found in the file name, instantly mark the file as
    # relevant (no LLM call needed). Case-insensitive substring match.
    "loss run",
    "loss runs",
    "lossrun",
    "lossruns",
    "lrun",
    "loss summary",
    "loss summaries",
    "lr",
    "lrs"
]



RELEVANCY_INSTRUCTIONS: str = """
A file IS relevant for extraction if its content clearly presents historical
insurance claims or losses, for example:
- **Important**: A file can be a summary or statement saying there were no
  prior losses for a given period - that is still relevant.
- Tables or lists of multiple claims or losses.
- Claim-level fields such as:
  - claim number / claim id / claim reference
  - loss date / date of loss / reported date
  - total incurred / incurred loss / net incurred / gross incurred
  - paid loss / total paid / paid to date
  - reserves (outstanding reserve, case reserve, loss reserve)
  - ALAE / allocated loss adjustment expense / expense incurred / expense paid
  - recoveries / subrogation / salvage / deductibles
- Report titles or headings such as:
  - loss run, loss runs, loss history, loss summary, loss detail, loss report
  - schedule of losses, claims experience, claims summary
  - losses valued as of, valuation date, valued as of
- Summary tables like:
  - summary of losses, loss summary by year, claims by year, claims by policy year
  - number of claims, claim count, total number of claims, frequency, severity

A file is NOT relevant if it is mainly:
- Applications for an insurance carrier.
  - **Important**: It is very common for an insurance application to have a
    loss summary or history section that is not filled out because they attach
    other files that are loss run reports. This section could also be filled
    out very briefly, but if it is not a clearly detailed form of prior claims,
    then it is not relevant.
- Policy documents (declarations, endorsements, coverage forms, certificates)
  with no historical claim rows.
- An Experience Rating or Experience Modifier, which does not include
  information about claims.
- Quotes, proposals, rating worksheets, pricing exhibits without actual past
  claims.
- Invoices, bills, remittance advice, or general accounting/financial reports.
- Pure exposure/premium schedules (vehicles, locations, payroll) with no claim
  history.
- Any document that only mentions "claims" or "loss" in a generic way (e.g.,
  disclaimers) but does not show historical claim-level or loss summary data.

If you are not clearly seeing claim-level or loss-summary data, you must
answer that it is NOT relevant.
"""


SHEET_RELEVANCY_INSTRUCTIONS: str = """
A sheet IS relevant for extraction if it contains:
- Policy-period, policy-year, or schedule-style data that helps determine
  whether a policy had no claims
- Policy identifiers and timing fields such as: policy number, effective
  date, expiration date, policy year, term, valuation date, line of business,
  prior carrier, or insured/account name
- Explicit statements such as "no claims", "no losses", "loss free", "clean
  loss history", or similar wording tied to a policy period or line of
  business
- Annual rollups, policy summaries, or multi-year policy schedules that show
  which policy periods exist, even when they do not list individual claims
- Claim detail only when it helps confirm which policy periods had claims so
  the remaining supported policy periods can be identified as claim-free

A sheet is NOT relevant if it:
- Is a coverage summary, premium schedule, declarations, policy overview, or
  exposure schedule with no usable evidence about whether a policy period had
  claims or no claims
- Contains metadata, instructions, table of contents, or index information
- Is unrelated administrative content with no policy-period dates, policy
  identifiers, loss-history statements, or claim evidence
"""


def get_relevancy_keywords() -> List[str]:
    """Return the list of file-name keywords for fast-pass relevancy."""
    return RELEVANCY_FILENAME_KEYWORDS


def get_relevancy_instructions() -> str:
    """Return the file-level relevancy instructions for LLM classification."""
    return RELEVANCY_INSTRUCTIONS


def get_sheet_relevancy_instructions() -> str:
    """Return the sheet-level relevancy instructions for LLM classification."""
    return SHEET_RELEVANCY_INSTRUCTIONS


# ===========================================================================
# SHEET CONTEXT AGENT CONFIGURATION (Input #4)
# ===========================================================================
# Controls the Sheet Context Agent which performs three-outcome classification
# on each sheet: parse_full_sheet, is_still_relevant, sheet_summary.
#
# This replaces the binary sheet classification and enables cross-sheet
# context propagation - metadata-only sheets (cover pages, policy info tabs)
# contribute their context to the extraction of claim tables on other sheets.
# ===========================================================================

# Enable/disable the Sheet Context Agent. When False, the pipeline falls
# back to the legacy binary sheet classification.
SHEET_CONTEXT_AGENT_ENABLED: bool = True


def get_sheet_context_agent_enabled() -> bool:
    """Return whether the Sheet Context Agent is enabled."""
    return SHEET_CONTEXT_AGENT_ENABLED
