"""Pipeline inputs for EXPOSURE extraction mode.

This module mirrors inputs.py but with exposure-specific configuration:

1. **Output Schema** (`ExposureRecord`) - defines every column for the
   exposure output DataFrame (flattened superset of all exposure types).
2. **Extraction Instructions** - domain rules for exposure extraction.
3. **Relevancy Configuration** - file-name keywords and LLM instructions
   for identifying exposure-relevant files/sheets.
4. **Pipeline Model Selection** - active LLM configuration.
5. **Output Format** - JSON (nested by exposure type) instead of CSV.

This file provides the SAME accessor functions as inputs.py so it can be
hot-swapped at runtime via `sys.modules['inputs'] = inputs_exposures`.
"""

from __future__ import annotations

from typing import Any, List, Literal, Optional

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Pipeline model selection
# ---------------------------------------------------------------------------

AGENTIC_MODEL: str = "GPT_5"

AGENTIC_REASONING_EFFORT: Literal["low", "medium", "high"] = "medium"

UTILITY_MODEL: str = "GPT_5"
UTILITY_REASONING_EFFORT: Literal["low", "medium", "high"] = "medium"

CLI_LOG_MODE: Literal["concise", "verbose"] = "verbose"


def get_agentic_model_key() -> str:
    """Return the configured active model key for the pipeline."""
    return AGENTIC_MODEL.strip().upper()


def get_agentic_reasoning_effort() -> str:
    """Return the configured reasoning effort, defaulting safely to medium."""
    effort = str(AGENTIC_REASONING_EFFORT).strip().lower()
    if effort not in {"low", "medium", "high"}:
        return "medium"
    return effort


def get_utility_model_key() -> str:
    """Return the configured model key for lightweight utility tasks."""
    return UTILITY_MODEL.strip().upper()


def get_utility_reasoning_effort() -> str:
    """Return the configured reasoning effort for utility-model tasks."""
    effort = str(UTILITY_REASONING_EFFORT).strip().lower()
    if effort not in {"low", "medium", "high"}:
        return "low"
    return effort


def get_cli_log_mode_setting() -> str:
    """Return the configured default CLI log mode for the pipeline."""
    mode = str(CLI_LOG_MODE).strip().lower()
    if mode not in {"concise", "verbose"}:
        return "concise"
    return mode


# ---------------------------------------------------------------------------
# Schema model
# ---------------------------------------------------------------------------

class ExposureRecord(BaseModel):
    """Schema for a single extracted exposure record.

    Every row in the output DataFrame represents one exposure item (vehicle,
    WC class, GL hazard, property location, or other exposure). The `type`
    field determines which bucket this row belongs to. Fields not relevant
    to a given type should be `None`.
    """

    type: Optional[Literal["gl", "wc", "auto", "property", "other"]] = Field(
        None,
        description=(
            "Exposure type bucket. Must be one of: gl, wc, auto, property, other. "
            "Determines which exposure category this record belongs to."
        ),
    )
    lob: Optional[str] = Field(
        None,
        description=(
            "Line of business inference: GL, WC, Auto, Property, Umbrella, or Other."
        ),
    )
    class_code: Optional[str] = Field(
        None,
        description=(
            "Classification code. For GL: numeric 3-5 digit GL class code (e.g. 91580, 95410). "
            "For WC: workers comp class code. For auto: vehicle class/symbol. "
            "Must be NUMERIC ONLY for GL - do NOT use loss-run cause codes like COPI, COMED. "
            "If no numeric class code exists, omit or set to None."
        ),
    )
    sic: Optional[str] = Field(
        None,
        description="SIC code (exactly 4 digits, range 0100-9999) if present.",
    )
    description: Optional[str] = Field(
        None,
        description="Short description of the exposure (<=140 characters).",
    )
    context: Optional[str] = Field(
        None,
        description=(
            "Concise surrounding phrase or row excerpt from the source document "
            "(<=160 characters). Must be verbatim or closely paraphrased from source."
        ),
    )
    reasoning: Optional[str] = Field(
        None,
        description=(
            "Brief explanation of why this is a meaningful exposure driver "
            "(<=140 characters)."
        ),
    )
    page: Optional[int] = Field(
        None,
        description="Page number from the source document (integer).",
    )
    doc: Optional[str] = Field(
        None,
        description=(
            "Source document name. Strip any chunk labels or parentheticals. "
            "Must correspond to the actual file name from which this data was extracted."
        ),
    )
    sheet: Optional[str] = Field(
        None,
        description="Sheet name for Excel workbooks. Omit for non-Excel documents.",
    )
    location_number: Optional[str] = Field(
        None,
        description=(
            "Location number as digits only (e.g. '1', '12'). "
            "Accept labels like LOC, Location but output ONLY the number. "
            "If the specific row has a blank or empty location field, set to None."
        ),
    )
    address: Optional[str] = Field(
        None,
        description="Location or premises address (NOT garaging location for vehicles).",
    )

    # -- Vehicle fields (type=auto) -----------------------------------------
    vin: Optional[str] = Field(
        None,
        description=(
            "Vehicle Identification Number. VINs are typically 17 characters "
            "but may be 15-18 characters depending on vehicle type (e.g. trailers, "
            "older vehicles, heavy equipment). Accept any alphanumeric VIN between "
            "15 and 18 characters. Do NOT discard or flag VINs solely because they "
            "are not exactly 17 characters."
        ),
    )
    year: Optional[int] = Field(None, description="Vehicle model year.")
    make: Optional[str] = Field(
        None,
        description=(
            "Vehicle make/manufacturer. Keep compound names together "
            "(e.g. 'BIG TEX', 'FREIGHTLINER', 'PETERBILT')."
        ),
    )
    model_name: Optional[str] = Field(
        None,
        description=(
            "Vehicle model. BODY TYPE is NOT the same as MODEL. "
            "If document shows body type but model is blank, leave as None."
        ),
    )
    gvwr: Optional[str] = Field(None, description="Gross Vehicle Weight Rating.")
    use: Optional[str] = Field(None, description="Vehicle use type.")
    garaging_location: Optional[str] = Field(
        None,
        description=(
            "Where vehicle is garaged/kept overnight. Synonyms: Garaging Address, "
            "Terminal, Vehicle Location, Yard."
        ),
    )
    category: Optional[Literal[
        "private_passenger", "light_truck", "medium_truck", "heavy_truck",
        "x_heavy_truck", "heavy_truck_tractor", "x_heavy_truck_tractor",
        "trailer", "special", "unknown"
    ]] = Field(None, description="Vehicle category classification.")

    # -- WC fields (type=wc) ------------------------------------------------
    payroll: Optional[float] = Field(
        None,
        description="Payroll/remuneration amount (numeric, no $ or commas).",
    )
    employees: Optional[int] = Field(None, description="Employee count.")
    state: Optional[str] = Field(
        None,
        description="Two-letter US state code (e.g. CA, TX, FL).",
        json_schema_extra={"format": "2-letter US state code"},
    )
    policy_year: Optional[str] = Field(
        None,
        description="Policy year or term (e.g. '2024-2025').",
    )

    # -- GL fields (type=gl) ------------------------------------------------
    exposure_basis: Optional[str] = Field(
        None,
        description="Exposure basis: payroll, sales, area, units, receipts, total cost, etc.",
    )
    exposure_value: Optional[float] = Field(
        None,
        description=(
            "Numeric exposure amount. Always capture the dollar amount shown next to "
            "each class code. If blank or 'If Any', set to None."
        ),
    )

    # -- Property fields (type=property) ------------------------------------
    building_value: Optional[float] = Field(
        None,
        description=(
            "Building/structure value. Synonyms: Building, Bldg, Coverage A, Structure."
        ),
    )
    contents_value: Optional[float] = Field(
        None,
        description=(
            "Business personal property/contents value. "
            "Synonyms: Contents, BPP, Coverage B."
        ),
    )
    business_income_value: Optional[float] = Field(
        None,
        description=(
            "Business income/time element value. "
            "Synonyms: Business Income, BI, Time Element, Income."
        ),
    )

    class Config:
        extra = "forbid"


# ---------------------------------------------------------------------------
# Utility: serialize the schema for inclusion in prompts
# ---------------------------------------------------------------------------

def _field_description_line(name: str, field_info: Any) -> str:
    """Build a single human-readable line describing a schema field."""
    annotation = field_info.annotation

    type_str = "string"
    origin = getattr(annotation, "__origin__", None)
    args = getattr(annotation, "__args__", ())
    inner = args[0] if args else annotation

    if inner is float:
        type_str = "float"
    elif inner is int:
        type_str = "integer"
    elif inner is str:
        type_str = "string"
    elif hasattr(inner, "__args__"):
        type_str = f"one of {list(inner.__args__)}"

    parts = [f"- **{name}** ({type_str})"]

    extra = getattr(field_info, "json_schema_extra", None) or {}
    fmt = extra.get("format")
    if fmt:
        parts.append(f" Format: {fmt}.")

    meta = getattr(field_info, "metadata", [])
    for m in meta:
        if hasattr(m, "ge") and m.ge is not None:
            parts.append(f" Must be >= {m.ge}.")

    desc = getattr(field_info, "description", None)
    if desc:
        parts.append(f" {desc}")

    return "".join(parts)


def get_schema_text() -> str:
    """Serialize the ExposureRecord schema into a prompt-friendly text block."""
    lines = ["# Output DataFrame Schema", ""]
    lines.append("Each row in the output DataFrame represents one extracted exposure.")
    lines.append("The DataFrame must have exactly these columns:\n")

    for name, field_info in ExposureRecord.model_fields.items():
        lines.append(_field_description_line(name, field_info))

    lines.append("")
    lines.append("All columns are nullable (None / NaN is acceptable when the source has no value).")
    lines.append("Do NOT include commas in numeric values.")
    lines.append("If no exposures are found in the segment, return an empty DataFrame with these columns.")

    return "\n".join(lines)


def get_column_names() -> List[str]:
    """Return the ordered list of column names from the schema."""
    return list(ExposureRecord.model_fields.keys())


# ---------------------------------------------------------------------------
# OUTPUT COLUMN ORDERING CONFIGURATION
# ---------------------------------------------------------------------------

LEADING_SCHEMA_COLUMN: str = "type"

ACCOUNT_NAME_COLUMN: str = "AccountName"
FILE_SOURCE_COLUMN: str = "file_path"
METADATA_COLUMNS: List[str] = [ACCOUNT_NAME_COLUMN, FILE_SOURCE_COLUMN]

# Output format configuration - JSON for exposures
OUTPUT_FILE_SUFFIX: str = "_exposures_raw.json"
OUTPUT_FORMAT: str = "json"


def get_leading_schema_column() -> str:
    """Return the schema column placed leftmost in the output DataFrame."""
    return LEADING_SCHEMA_COLUMN


def get_account_name_column() -> str:
    """Return the metadata column that holds the account / company name."""
    return ACCOUNT_NAME_COLUMN


def get_file_source_column() -> str:
    """Return the metadata column that holds the source file name."""
    return FILE_SOURCE_COLUMN


def get_metadata_columns() -> List[str]:
    """Return the ordered list of trailing non-schema metadata columns."""
    return list(METADATA_COLUMNS)


def get_output_file_suffix() -> str:
    """Return the file suffix for the output (e.g. '_exposures_raw.json')."""
    return OUTPUT_FILE_SUFFIX


def get_output_csv_filename() -> str:
    """Return the output filename used by the pipeline for exposures."""
    return "exposures.json"


def get_output_format() -> str:
    """Return the output format: 'csv' or 'json'."""
    return OUTPUT_FORMAT


def get_output_column_order() -> List[str]:
    """Return the canonical output column order."""
    schema_cols = get_column_names()
    leading_col = LEADING_SCHEMA_COLUMN
    if leading_col and leading_col in schema_cols:
        leading = [leading_col]
        rest = [f for f in schema_cols if f != leading_col]
    else:
        leading = []
        rest = list(schema_cols)
    return leading + rest + list(METADATA_COLUMNS)


# ---------------------------------------------------------------------------
# EXTRACTION INSTRUCTIONS (Input #2)
# ---------------------------------------------------------------------------

EXTRACTION_INSTRUCTIONS = """
# Task
Your task is to extract ALL exposure details from this spreadsheet segment.
Each distinct exposure item (vehicle, WC class, GL hazard, property location,
or other exposure) should produce one row in the output DataFrame.

# Exposure Types
Classify each exposure into one of these types:
- **gl**: General Liability exposures - GL class codes, hazard codes, premises/operations
- **wc**: Workers Compensation - WC class codes, payroll by state/class
- **auto**: Vehicles ONLY - individual vehicles with a VIN (or year/make/model).
  Driver schedules (name, DOB, license number) are NOT auto - classify as **other**.
  Historical aggregate unit counts (e.g. "Auto 24-25: 385 units") are NOT auto - classify as **other**.
- **property**: Property locations - building values, contents, business income by location
- **other**: Any exposure that doesn't fit the above (umbrella, inland marine, driver schedules, aggregate summaries, etc.)

## Type Hint from Filename/Sheet Name
The segment_json may include a "type_hint" field derived from keyword matching on
the filename and sheet name. When present, treat it as a STRONG prior for the type
classification - it indicates the most likely exposure type for the entire segment.
However, always verify against the actual column headers and row data before assigning
the type. If the data clearly contradicts the hint, go with the data.

# Key Extraction Rules

## General
- One row per distinct schedule line / vehicle / WC class / GL hazard / property row.
- Avoid duplication - do not reconstruct implied totals if explicit totals exist.
- Provide context AND reasoning for every record (mandatory).
- Keep numbers as raw digits (strip $, commas). Integer where possible, else float.
- For location_number: accept LOC, Loc, Location labels but OUTPUT ONLY THE DIGITS.
- Multi-year experience tables: separate row per policy year (no summing across years).

## Vehicles (type=auto)
- Extract EVERY SINGLE vehicle row in the schedule - do NOT skip, summarize, or truncate.
- If a schedule has 50 vehicles, you MUST return 50 separate rows.
- Vehicle schedules often span multiple pages - extract from ALL pages in this segment.
- If you see sequential numbering (VEH #1, #2, ... #70), every number must appear.
- NEVER stop early due to repetitiveness - every row matters for accurate counts.
- Multi-subsidiary/multi-location vehicle schedules: extract from ALL divisions.
- BODY TYPE is NOT the same as MODEL. If model is blank, leave model_name as None.
- Model names CAN be purely numeric (e.g. "337", "537", "338" for Peterbilt/Hino trucks). Do NOT discard or leave blank when the source cell contains a numeric model.
- Keep compound manufacturer names together (BIG TEX, PETERBILT, FREIGHTLINER).

## Workers Compensation (type=wc)
- Distinguish WC payroll from GL payroll correctly.
- Include state code when visible - critical for multi-state WC.
- Extract policy_year from headers/titles when available.
- Do NOT aggregate class codes into summaries.
- When multiple payroll/wage columns exist (e.g. "Current Amount", "Net WC Wages",
  "Estimated Wages"), prefer the forward-looking or estimated/projected column
  (typically the rightmost wage column). This represents the exposure basis used
  for insurance rating.
- Each row should have ONE exposure_value - the best payroll figure for that
  state + class code combination.

## General Liability (type=gl)
- class_code MUST be NUMERIC ONLY (3-5 digits, e.g. 91589, 95410, 80113).
- Do NOT use loss-run cause codes (COPI, COMED, PRDPD) or loss type descriptions
  as class_code. Those belong in description, not class_code.
- ALWAYS capture exposure_value (the dollar amount next to each GL class code).
- exposure_basis: payroll, sales, area, units, receipts, total cost, etc.

## Property (type=property)
- ALWAYS split into building_value, contents_value, business_income_value when available.
- Look for synonyms: Building/Bldg/Coverage A, Contents/BPP/Coverage B, BI/Time Element.
- Prefer per-location rows; avoid double counting TOTAL rows.

## Anti-Hallucination Rules
- ONLY extract values that are EXPLICITLY VISIBLE in the source data.
- DO NOT infer, guess, or fabricate any values not directly present.
- If a field is not shown in the document, leave it as None.
- DO NOT use external knowledge or databases to fill in missing values.
- Better to have None fields than incorrect fabricated data.

## Location Extraction Rules
- Extract location_number ONLY if the specific row has an explicit value.
- If a row has blank location number, set location_number to None.
- DO NOT infer location from other rows on the same page/sheet.

## Document Type Filtering
- Do NOT extract from: policy handbooks, blank templates, corrective action notices,
  vehicle use policy agreements, training materials, or procedural documents.
- Only extract from documents with actual exposure data tables/values.
"""


def get_instructions_text() -> str:
    """Return the extraction instructions text."""
    return EXTRACTION_INSTRUCTIONS


# ---------------------------------------------------------------------------
# FILENAME / SHEET-NAME -> EXPOSURE-TYPE HINT
# ---------------------------------------------------------------------------

# Each entry: (keyword, matched_type). Keywords are matched case-insensitively
# against the filename (without extension) and sheet name. Order matters: the
# FIRST match wins, so put more-specific phrases before generic ones.
_TYPE_HINT_KEYWORDS: List[tuple] = [
    # -- AUTO --
    ("vehicle schedule", "auto"),
    ("auto schedule", "auto"),
    ("fleet schedule", "auto"),
    ("vehicle list", "auto"),
    ("fleet list", "auto"),
    ("vehicle", "auto"),
    ("fleet", "auto"),
    ("vin", "auto"),
    ("automobile", "auto"),
    ("truck", "auto"),
    ("trailer", "auto"),

    # -- WORKERS COMPENSATION --
    ("workers comp", "wc"),
    ("workers' comp", "wc"),
    ("worker comp", "wc"),
    ("wc payroll", "wc"),
    ("wc schedule", "wc"),
    ("wc class", "wc"),
    ("wc exposure", "wc"),
    ("payroll by state", "wc"),
    ("wage", "wc"),
    # bare "wc" checked separately since it's short and could false-match
    ("experience mod", "wc"),
    ("mod worksheet", "wc"),

    # -- GENERAL LIABILITY --
    ("general liability", "gl"),
    ("gl exposure", "gl"),
    ("gl schedule", "gl"),
    ("gl class", "gl"),
    ("gl payroll", "gl"),
    ("gl sales", "gl"),
    ("hazard", "gl"),
    ("premises", "gl"),
    ("operations", "gl"),

    # -- PROPERTY --
    ("statement of values", "property"),
    ("property schedule", "property"),
    ("property location", "property"),
    ("location schedule", "property"),
    ("building value", "property"),
    ("sov", "property"),
    ("real property", "property"),
    ("bpp", "property"),
]

# Short standalone tokens that need word-boundary matching to avoid false
# positives (e.g. "wc" inside "switch").
_TYPE_HINT_SHORT_TOKENS: List[tuple] = [
    ("wc", "wc"),
    ("gl", "gl"),
]

import re as _re  # local import to keep top-of-file imports clean


def get_type_hint(file_name: str, sheet_name: str) -> str:
    """Derive an exposure-type hint from filename and sheet name keywords.

    Returns a short guidance string for the LLM (e.g.
    `"Based on the filename/sheet name, this segment likely contains AUTO
    exposures."`), or an empty string if no strong keyword match is found.

    This function is only defined in inputs_exposures (not inputs.py), so it
    is automatically unavailable in loss-run mode.
    """
    # Combine filename (without extension) + sheet name for matching
    import os
    name_base = os.path.splitext(file_name)[0] if file_name else ""
    combined = f"{name_base} | {sheet_name}".lower()

    # 1) Try phrase/substring keywords (first match wins)
    for keyword, exp_type in _TYPE_HINT_KEYWORDS:
        if keyword in combined:
            return _format_hint(exp_type, keyword, file_name, sheet_name)

    # 2) Try short token keywords with word-boundary matching
    for token, exp_type in _TYPE_HINT_SHORT_TOKENS:
        if _re.search(rf"\b{_re.escape(token)}\b", combined):
            return _format_hint(exp_type, token, file_name, sheet_name)

    return ""


_TYPE_LABELS = {
    "auto": "AUTO (vehicle)",
    "wc": "WORKERS COMPENSATION",
    "gl": "GENERAL LIABILITY",
    "property": "PROPERTY",
}


def _format_hint(exp_type: str, matched_keyword: str,
                 file_name: str, sheet_name: str) -> str:
    label = _TYPE_LABELS.get(exp_type, exp_type.upper())
    return (
        f"FILENAME/SHEET HINT: Based on the keyword '{matched_keyword}' found "
        f"in the file name ('{file_name}') / sheet name ('{sheet_name}'), "
        f"this segment likely contains {label} exposures. "
        f"Use this as guidance when classifying the 'type' field, but still "
        f"verify against the actual column headers and data content."
    )


# ---------------------------------------------------------------------------
# RELEVANCY CONFIGURATION (Input #3)
# ---------------------------------------------------------------------------

RELEVANCY_FILENAME_KEYWORDS: List[str] = [
    "acord", "application", "schedule", "exposure", "exposures",
    "vehicle", "vehicles", "fleet", "auto schedule",
    "property", "property schedule", "location", "locations",
    "payroll", "class code", "class codes",
    "mod worksheet", "experience rating", "experience mod",
    "sov", "statement of values",
    "wc schedule", "gl schedule",
    "sales", "revenue", "revenues", "receipts",
    "gl payroll", "gl sales",
]

RELEVANCY_FILENAME_EXCLUSIONS: List[str] = [
    "loss run", "loss runs",
    "loss summary",
    "large loss",
    "claims",
    "driver list", "driver information", "driver schedule",
    "mvr", "mvr report",
]

RELEVANCY_INSTRUCTIONS: str = """
A file IS relevant for extraction if its content presents insurance exposure
data, for example:
- Vehicle / fleet schedules with VINs, makes, models, GVWRs
- Workers Compensation class codes with payroll amounts by state
- General Liability classification schedules with class codes and exposure values
- GL exposure basis data: sales, revenues, receipts, payroll broken down by
  class code, location, or subsidiary - these ARE GL exposures even if the
  file title says "sales" or "revenue"
- Property location schedules with building values, contents, business income
- ACORD applications with exposure data (GL classifications, vehicle schedules, etc.)
- Statements of Values (SOV) with property details
- Experience modification worksheets with payroll/class data
- Any schedule, list, or table of insurable exposures

A file is NOT relevant if it is mainly:
- Loss runs, claims history, or claims data (individual claim records)
- Driver lists, driver rosters, or MVR (Motor Vehicle Record) reports that
  contain only driver names, license numbers, DOB, and MVR scores WITHOUT
  any vehicle schedule data, VINs, or exposure dollar values
- Policy documents (declarations, endorsements, coverage forms, certificates)
  with no exposure schedules or data tables
- Invoices, bills, remittance advice
- General accounting reports that are NOT tied to insurance exposure bases
  (e.g. internal P&L, balance sheets unrelated to insured operations)
- Employee handbooks, training materials, procedural documents
- Blank templates or forms without filled-in data
- Documents with only narrative text and no exposure data tables
"""

SHEET_NAME_EXCLUSIONS: List[str] = [
    "out of service",
]

SHEET_RELEVANCY_INSTRUCTIONS: str = """
A sheet IS relevant for extraction if it contains:
- Vehicle schedule rows (VINs, makes, models, year, GVWR)
- Workers Compensation class codes with payroll/employee data
- General Liability classification codes with exposure values
- Property location data (addresses, building values, contents, business income)
- Exposure summaries with class codes and dollar amounts
- ACORD application sections with filled exposure data

A sheet is NOT relevant if it:
- Contains only claim-level data (loss runs, individual claims)
- Has only policy-level summary without exposure detail
- Contains metadata, instructions, table of contents, or index information
- Is a blank template or form without data
- Contains only narrative text, disclaimers, or acknowledgments
- Is a certificate of insurance or declarations page without exposure detail
- Lists vehicles or equipment that are "out of service", retired, decommissioned,
  or otherwise no longer active - these are not current exposures
"""


def get_relevancy_keywords() -> List[str]:
    """Return the list of file-name keywords for fast-pass relevancy."""
    return RELEVANCY_FILENAME_KEYWORDS


def get_relevancy_exclusion_keywords() -> List[str]:
    """Return the list of file-name keywords for fast-reject exclusion."""
    return RELEVANCY_FILENAME_EXCLUSIONS


def get_relevancy_instructions() -> str:
    """Return the file-level relevancy instructions for LLM classification."""
    return RELEVANCY_INSTRUCTIONS


def get_sheet_relevancy_instructions() -> str:
    """Return the sheet-level relevancy instructions for LLM classification."""
    return SHEET_RELEVANCY_INSTRUCTIONS


def get_sheet_name_exclusions() -> List[str]:
    """Return sheet-name substrings that should always be excluded."""
    return SHEET_NAME_EXCLUSIONS


def get_sheet_context_agent_enabled() -> bool:
    """Return whether the Sheet Context Agent is enabled."""
    return True


# ===========================================================================
# OUTPUT WRITER (Input #6)
# ===========================================================================

def get_output_writer():
    """Return a callable(df, path) that writes the final per-account output.

    Uses `postprocess_exposures.write_exposure_json` to convert the flat
    DataFrame into nested JSON by exposure type bucket, with deduplication
    and normalization applied.
    """
    from postprocess_exposures import write_exposure_json
    return write_exposure_json
