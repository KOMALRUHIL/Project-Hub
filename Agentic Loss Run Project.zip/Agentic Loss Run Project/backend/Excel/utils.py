"""Shared utility functions used across the pipeline.

Centralises helpers that were previously duplicated across multiple modules:

- **Windows long-path handling** (`as_extended_path_str`, `as_extended_path`)
- **Content-safety text sanitization** (`sanitize_text_for_safety`)
- **Blank-value and numeric-value detection** (`is_blank_value`, `parse_numeric_value`)
"""

from __future__ import annotations

import csv
import datetime
import json
import os
import re
from pathlib import Path
from typing import Any, Dict, Optional

import pandas as pd


# -----------------------------------------------------------------------------
# Windows long-path helpers
# -----------------------------------------------------------------------------

def as_extended_path_str(path: str) -> str:
    """Prepend `\\?\\` on Windows for paths near or above the 260-char MAX_PATH limit.

    Accepts a *string* path and returns a *string* path.
    """
    if os.name != "nt":
        return path
    s = os.path.abspath(path)
    if len(s) < 240:
        return s
    if s.startswith("\\\\?\\") or s.startswith("//?/"):
        return s
    if s.startswith("\\\\"):
        return "\\\\?\\UNC\\" + s.lstrip("\\")
    return "\\\\?\\" + s


def as_extended_path(path: Path) -> Path:
    """Prepend `\\?\\` on Windows for paths near or above the 260-char MAX_PATH limit.

    Accepts a `Path` object and returns a `Path` object.
    """
    if os.name != "nt":
        return path
    resolved = path.resolve()
    if len(str(resolved)) < 240:
        return resolved
    s = str(resolved)
    if s.startswith("\\\\?\\") or s.startswith("//?/"):
        return Path(s)
    if s.startswith("\\\\"):
        return Path("\\\\?\\UNC\\" + s.lstrip("\\"))
    return Path("\\\\?\\" + s)


# -----------------------------------------------------------------------------
# Content-safety text sanitization
# -----------------------------------------------------------------------------

# Only redacts truly graphic/violent terms AND terms that may trigger
# Azure OpenAI's "sexual" content filter when present in insurance claims
# data (e.g. body-part descriptions in Workers' Comp injury narratives).
# Does NOT redact standard insurance vocabulary (injury, death, fatality)
# - those are critical extraction fields present in every WC / GL loss run.
_SAFETY_REDACTION_PATTERNS = [
    # --- Violence-related ---
    r"\bkill(?:ed|ing)?\b",
    r"\bmurder(?:ed|ing)?\b",
    r"\bhomicide\b",
    r"\bsuicide\b",
    r"\bassault\b",
    r"\brape(?:d)?\b",
    r"\bshoot(?:ing|s|er|ers)?\b",
    r"\bshot\b",
    r"\bgun(?:s)?\b",
    r"\bfirearm(?:s)?\b",
    r"\bstab(?:bed|bing)?\b",
    r"\bgore\b",
    # --- Sexual-category triggers (body parts / sensitive terms in claims) ---
    r"\bgroin\b",
    r"\bgenital(?:s|ia)?\b",
    r"\bbreast(?:s)?\b",
    r"\bbuttock(?:s)?\b",
    r"\btesticle(?:s)?\b",
    r"\bscrotum\b",
    r"\bpenis\b",
    r"\bvagina(?:l)?\b",
    r"\bnipple(?:s)?\b",
    r"\bsexual(?:ly)?\b",
    r"\bmolest(?:ed|ing|ation)?\b",
    r"\bfondle(?:d|ing)?\b",
    r"\bindecen(?:t|cy)\b",
    r"\bnaked\b",
    r"\bnude\b",
    r"\bnudity\b",
    r"\bundress(?:ed|ing)?\b",
    r"\bexhibition(?:ism|ist)?\b",
    r"\bsodomy\b",
    r"\bprostitut(?:e|ion|ing)\b",
    r"\bpornograph(?:y|ic)\b",
    r"\bintercourse\b",
    r"\berotic\b",
    r"\blingerie\b",
    r"\bstrip(?:ped|ping)?\s+(?:naked|nude|down)\b",
    r"\bimproper\s+(?:touching|contact|conduct)\b",
]

# Pre-compiled combined regex - avoids per-pattern re.sub() calls and prevents
# thrashing Python's internal 512-entry regex cache under heavy load (Issue #16).
_SAFETY_RE = re.compile("|".join(_SAFETY_REDACTION_PATTERNS), re.IGNORECASE)


def sanitize_text_for_safety(text: Any) -> Any:
    """Replace graphic/violent terms with `[redacted]`.

    Accepts any type; non-string values are returned unchanged.
    """
    if not isinstance(text, str):
        return text
    if not text:
        return text
    return _SAFETY_RE.sub("[redacted]", text)


# -----------------------------------------------------------------------------
# Blank-value and numeric-value helpers
# -----------------------------------------------------------------------------

def is_blank_value(value: Any) -> bool:
    """Return `True` if `value` is `None`, empty string, or `NaN`."""
    if value is None:
        return True
    if isinstance(value, str) and not value.strip():
        return True
    try:
        if pd.isna(value):
            return True
    except Exception:
        pass
    return False


def parse_numeric_value(value: Any) -> Optional[float]:
    """Attempt to parse *value* as a float; return `None` on failure."""
    if is_blank_value(value):
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        if not pd.isna(value):
            return float(value)
        return None
    if isinstance(value, str):
        cleaned = value.strip()
        if not cleaned:
            return None
        cleaned = cleaned.replace(",", "").replace("$", "")
        cleaned = cleaned.replace("(", "-").replace(")", "")
        cleaned = cleaned.strip()
        if cleaned in {"-", "--"}:
            return None
        numeric = pd.to_numeric(cleaned, errors="coerce")
        if not pd.isna(numeric):
            return float(numeric)
    return None


# -----------------------------------------------------------------------------
# JSON I/O helpers (consolidated from row_segmentation / segment_summarizer)
# -----------------------------------------------------------------------------

def _json_default(value: Any) -> Any:
    """Default JSON serializer for types not handled by `json.dump`."""
    if isinstance(value, (datetime.datetime, datetime.date, datetime.time)):
        return value.isoformat()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, pd.Timestamp):
        return value.isoformat()
    if isinstance(value, (datetime.timedelta, pd.Timedelta)):
        return str(value)
    if hasattr(value, "item"):
        try:
            return value.item()
        except Exception:
            pass
    raise TypeError(f"Object of type {value.__class__.__name__} is not JSON serializable")


def load_json(path: Path) -> Dict[str, Any]:
    """Read a JSON file, handling Windows long paths."""
    path_to_open = as_extended_path(path)
    with open(path_to_open, "r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: Path, data: Any) -> None:
    """Write data as JSON, handling Windows long paths and datetime objects."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path_to_open = as_extended_path(path)
    with open(path_to_open, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False, default=_json_default)


def fmt_duration(seconds: float) -> str:
    """Format a duration in seconds as a human-readable string (e.g. '2m 15s')."""
    seconds = max(0.0, float(seconds or 0.0))
    total = int(round(seconds))
    h, rem = divmod(total, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h}h {m}m {s}s"
    return f"{m}m {s}s"


def log_cli(message: Any) -> None:
    """Write a CLI/status message without breaking tqdm progress rendering."""
    text = str(message)
    try:
        from tqdm import tqdm

        tqdm.write(text)
    except Exception:
        print(text)


# -----------------------------------------------------------------------------
# CSV delimiter sniffing + robust CSV read
# -----------------------------------------------------------------------------

_CSV_CANDIDATE_DELIMITERS = [",", ";", "\t", "|", ":"]
_CSV_SAMPLE_BYTES = 16384
_CSV_FALLBACK_DELIMITER = ","
_CSV_ENCODING_CANDIDATES = ["utf-8-sig", "utf-8", "cp1252", "latin-1"]


def detect_csv_format(
    file_path: str | Path,
    sample_bytes: int = _CSV_SAMPLE_BYTES,
    fallback_delimiter: str = _CSV_FALLBACK_DELIMITER,
) -> tuple[str, str]:
    """Peek at a CSV file and return `(delimiter, encoding)`:

    Uses `csv.Sniffer` first, then a small frequency/consistency heuristic
    if Sniffer cannot decide.
    """
    path_str = as_extended_path_str(str(file_path))

    sample_text = ""
    detected_encoding = "utf-8"

    for enc in _CSV_ENCODING_CANDIDATES:
        try:
            with open(path_str, "r", encoding=enc, newline="") as f:
                sample_text = f.read(sample_bytes)
                detected_encoding = enc
                break
        except Exception:
            continue

    if not sample_text:
        return fallback_delimiter, detected_encoding

    try:
        dialect = csv.Sniffer().sniff(sample_text, delimiters="".join(_CSV_CANDIDATE_DELIMITERS))
        delimiter = getattr(dialect, "delimiter", None)
        if delimiter in _CSV_CANDIDATE_DELIMITERS:
            return delimiter, detected_encoding
    except Exception:
        pass

    lines = [ln for ln in sample_text.splitlines() if ln.strip()][:30]
    if not lines:
        return fallback_delimiter, detected_encoding

    best_delim = fallback_delimiter
    best_score = float("-inf")

    for delim in _CSV_CANDIDATE_DELIMITERS:
        counts = [ln.count(delim) for ln in lines]
        non_zero = [c for c in counts if c > 0]
        if not non_zero:
            continue

        # Prefer delimiters that appear on many lines, with stable counts.
        spread_penalty = max(non_zero) - min(non_zero)
        score = (sum(non_zero) + (len(non_zero) * 2)) - spread_penalty

        if score > best_score:
            best_score = score
            best_delim = delim

    return best_delim, detected_encoding


def read_csv_with_detected_delimiter(file_path: str | Path, **read_csv_kwargs: Any) -> pd.DataFrame:
    """Read a CSV after detecting delimiter/encoding via a lightweight peek."""
    delimiter, encoding = detect_csv_format(file_path)
    delimiter_display = "\\t" if delimiter == "\t" else delimiter
    log_cli(
        f" CSV ingest: {Path(str(file_path)).name} | delimiter='{delimiter_display}' | encoding={encoding}"
    )
    path_str = as_extended_path_str(str(file_path))
    return pd.read_csv(path_str, sep=delimiter, encoding=encoding, **read_csv_kwargs)
