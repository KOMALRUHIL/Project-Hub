"""
Post-process the output of detect_occurrence_and_duplicate.py.

Input expectations:
- A row-level extraction output DataFrame/CSV that already includes:
  - occurrence_number (Int64)
  - duplicate_number (Int64, optional but commonly present)
  - remove (Int64/boolean-ish; 1 means drop)
- Original extraction columns (claim_id, claimant, dates, states, financials, etc.)

Outputs:
- occurrence-level aggregated dataset (1 row per occurrence_number)

Design goals:
- Remove duplicate rows flagged by detection (remove==1)
- Merge same-occurrence rows into a single record:
  - financials: sum across kept rows (per occurrence)
  - non-financial fields: keep "best" value (most frequent; tie -> longest string; else first non-null)
  - provenance: keep sets of source pages/sheets, file paths (optional)
"""

from __future__ import annotations

import os
import json
from typing import Iterable, Optional

import numpy as np
import pandas as pd

FINANCIAL_COLS = [
    "total_incurred",
    "total_paid",
    "incurred_alae",
    "paid_alae",
    "total_recoveries",
]

# A reasonable default list; we only use those that exist in the incoming df
PREFERRED_NONFIN_COLS = [
    "claim_id",
    "claimant",
    "policy_number",
    "policy_effective_date",
    "policy_expiration_date",
    "line_of_business",
    "subline",
    "accident_date",
    "report_date",
    "accident_state",
    "driver",
    "garage_state",
    "coverage_state",
    "claim_description",
    "status",
    "prior_carrier",
    "evaluation_date",
    "page_num_or_sheet_name",
    "file_path",
    "AccountName",
]

META_COLS = ["occurrence_number", "duplicate_number", "remove"]


def _to_num(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce")


def _safe_sum(series: pd.Series) -> float:
    s = _to_num(series).dropna()
    return float(s.sum()) if not s.empty else np.nan


def _best_text_value(values: Iterable) -> object:
    """
    Pick a "best" non-null value from a group:
    1) most frequent
    2) tie-break: longest string repr (keeps richer descriptions)
    3) final tie-break: first occurrence
    Returns pd.NA if nothing usable.
    """
    vals = [v for v in values if not pd.isna(v)]
    if not vals:
        return pd.NA

    # frequency
    vc = pd.Series(vals).value_counts(dropna=False)
    top_freq = int(vc.iloc[0])
    top_vals = vc[vc == top_freq].index.tolist()

    if len(top_vals) == 1:
        return top_vals[0]

    # tie-break: longest string representation
    def _strlen(x) -> int:
        try:
            return len(str(x))
        except Exception:
            return 0

    top_vals_sorted = sorted(top_vals, key=_strlen, reverse=True)
    return top_vals_sorted[0]


def _best_date(values: Iterable) -> object:
    """
    Prefer the latest non-null date when aggregating date fields like evaluation_date.
    For accident_date/report_date you may prefer earliest; if so, adjust per-column below.
    """
    s = pd.to_datetime(pd.Series(list(values)), errors="coerce")
    if s.notna().any():
        return s.max().strftime("%m/%d/%Y") if hasattr(s.max(), "date") else s.max()
    return pd.NA


def aggregate_by_occurrence(
    df: pd.DataFrame,
    *,
    drop_removed: bool = True,
    occurrence_col: str = "occurrence_number",
    keep_input_order: bool = True,
    drop_id_cols: bool = True, # drops occurrence/duplicate/remove from final output
) -> pd.DataFrame:
    if occurrence_col not in df.columns:
        raise KeyError(f"Missing required column: {occurrence_col}")

    input_cols = list(df.columns) # capture original column order

    work = df.copy()

    # normalize remove to boolean-like
    if drop_removed and "remove" in work.columns:
        remove_flag = work["remove"].fillna(0)
        # accept Int64 0/1 or bools
        keep = ~(remove_flag.astype(int) == 1)
        work = work.loc[keep].copy()

    # ensure occurrence is not NA
    work = work.loc[work[occurrence_col].notna()].copy()

    # preserve first-seen order of occurrences from the input
    if keep_input_order:
        work["_orig_occ_order"] = pd.factorize(work[occurrence_col], sort=False)[0]

    fin_cols = [c for c in FINANCIAL_COLS if c in work.columns]
    nonfin_cols = [c for c in PREFERRED_NONFIN_COLS if c in work.columns]

    def _norm_value_for_compare(v: object) -> object:
        """Normalize values so we can compare distinctness reliably."""
        if pd.isna(v):
            return None
        # normalize whitespace/casing for strings
        if isinstance(v, str):
            s = " ".join(v.split())
            return s if s != "" else None
        return v

    def _distinct_values(values: Iterable) -> list[object]:
        """Ordered distinct normalized values (preserves first-seen order)."""
        seen = set()
        out = []
        for v in values:
            nv = _norm_value_for_compare(v)
            if nv is None:
                continue
            key = (type(nv).__name__, nv)
            if key in seen:
                continue
            seen.add(key)
            out.append(nv)
        return out

    def agg_group(g: pd.DataFrame) -> pd.Series:
        out = {}
        changes: dict[str, dict[str, object]] = {}

        # carry group keys (do NOT read g[occurrence_col]; grouping cols may be excluded)
        out[occurrence_col] = int(g.name)

        if "duplicate_number" in g.columns:
            out["duplicate_number"] = _best_text_value(g["duplicate_number"].tolist())

        if keep_input_order and "_orig_occ_order" in g.columns:
            out["_orig_occ_order"] = int(g["_orig_occ_order"].min())

        # financials sum
        for c in fin_cols:
            out[c] = _safe_sum(g[c])

        # non-financial best-values (+ change tracking)
        for c in nonfin_cols:
            if c in fin_cols:
                continue

            raw_vals = g[c].tolist()

            if c in ["evaluation_date"]:
                chosen = _best_date(raw_vals)
            elif c in ["accident_date", "report_date", "policy_effective_date", "policy_expiration_date"]:
                s = pd.to_datetime(g[c], errors="coerce")
                chosen = s.min().strftime("%m/%d/%Y") if s.notna().any() else _best_text_value(raw_vals)
            elif c == "page_num_or_sheet_name":
                # If all non-null values look like page numbers, keep the earliest (lowest)
                non_null = [v for v in raw_vals if not pd.isna(v)]
                nums = []
                for v in non_null:
                    try:
                        nums.append(int(str(v).strip()))
                    except (ValueError, TypeError):
                        nums = []
                        break
                if nums:
                    chosen = str(min(nums))
                else:
                    chosen = _best_text_value(raw_vals)
            else:
                chosen = _best_text_value(raw_vals)

            out[c] = chosen
            distinct = _distinct_values(raw_vals)

            # Normalize chosen for comparison (dates in this file are emitted as MM/DD/YYYY strings)
            chosen_norm = _norm_value_for_compare(chosen)

            # Only record when there was a real conflict (2+ distinct values)
            if len(distinct) >= 2:
                changes[c] = {
                    "chosen": chosen_norm,
                    "candidates": distinct[:20], # cap to keep column size manageable
                    "candidate_count": len(distinct),
                }

        out["merged_updates"] = json.dumps(changes, ensure_ascii=False) if changes else pd.NA

        return pd.Series(out)

    result = (
        work.groupby(occurrence_col, dropna=False, sort=False)
        .apply(agg_group, include_groups=False)
        .reset_index(drop=True)
    )

    # sort back to input order of first-seen occurrences
    if keep_input_order and "_orig_occ_order" in result.columns:
        result = (
            result.sort_values("_orig_occ_order", kind="stable")
            .drop(columns=["_orig_occ_order"])
            .reset_index(drop=True)
        )

    # drop ids if requested
    if drop_id_cols:
        drop_cols = [c for c in ["occurrence_number", "duplicate_number", "remove"] if c in result.columns]
        result = result.drop(columns=drop_cols)

    # ALWAYS preserve original input column order (then append any extras not in the input)
    ordered = [c for c in input_cols if c in result.columns]
    extras = [c for c in result.columns if c not in ordered]
    result = result[ordered + extras]

    print("            ✔️ Complete")
    return result


if __name__ == "__main__":
    # Example CLI usage with CSVs (Windows-friendly paths)
    input_path = os.path.join("extraction_output", "zzz_test_deduped.csv")

    if not os.path.exists(input_path):
        raise FileNotFoundError(f"Could not find input file: {input_path}")

    df = pd.read_csv(input_path)

    occ_out = aggregate_by_occurrence(df)

    base_dir = os.path.dirname(input_path)
    stem, ext = os.path.splitext(os.path.basename(input_path))
    occ_path = os.path.join(base_dir, f"{stem}_occurrence_aggregated{ext}")
    occ_out.to_csv(occ_path, index=False)

    print(f"Input rows: {len(df):,}")
    print(f"Occurrence rows: {len(occ_out):,}")
    print(f"Saved: {occ_path}")
