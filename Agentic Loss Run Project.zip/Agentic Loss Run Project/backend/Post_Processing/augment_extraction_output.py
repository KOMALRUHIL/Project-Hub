"""
Augment an occurrence-level aggregated extraction output with "header-like" metadata
that is often present on early pages of a loss run (esp. PDFs) but missing on later pages.

Called after aggregate_extraction_output.aggregate_by_occurrence(df).

Grouping:
  - AccountName + file_path

Ordering:
  - page_num_or_sheet_name is always a string representing a page number (e.g., "1")
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, Optional, Tuple

import numpy as np
import pandas as pd

AUGMENT_FIELDS_DEFAULT = (
    "evaluation_date",
    "prior_carrier",
    "policy_number",
    "policy_effective_date",
    "policy_expiration_date",
)


@dataclass(frozen=True)
class AugmentConfig:
    group_cols: Tuple[str, ...] = ("AccountName", "file_path")
    order_col: str = "page_num_or_sheet_name"
    accident_date_col: str = "accident_date"

    fields: Tuple[str, ...] = AUGMENT_FIELDS_DEFAULT

    # Only propagate values to rows within this many pages of the nearest "source" value.
    max_page_distance: int = 5

    # Prefer values observed in the first N pages when multiple candidates exist.
    seed_pages: int = 3

    # Policy date inference behavior
    infer_policy_year: bool = True
    first_half_month_max: int = 6  # Jan..Jun => infer prior policy year, else same as loss year

    # Audit / explainability
    audit_col: str = "augmentation"


def _is_blank(v: Any) -> bool:
    if pd.isna(v):
        return True
    if isinstance(v, str) and v.strip() == "":
        return True
    return False


def _best_nonblank(values: Iterable[Any]) -> Any:
    vals = [v for v in values if not _is_blank(v)]
    if not vals:
        return pd.NA
    vc = pd.Series(vals).value_counts(dropna=False)
    top = vc[vc == vc.iloc[0]].index.tolist()
    if len(top) == 1:
        return top[0]
    # tie-break: longest string repr
    top.sort(key=lambda x: len(str(x)), reverse=True)
    return top[0]


def _page_to_int(page_str: Any) -> Optional[int]:
    """
    page_num_or_sheet_name is always a string like "1". Still, be defensive.
    Returns int page, or None if unparsable.
    """
    if pd.isna(page_str):
        return None
    s = str(page_str).strip()
    if not s:
        return None
    try:
        return int(s)
    except Exception:
        # last resort: extract first integer substring
        digits = "".join(ch if ch.isdigit() else " " for ch in s).split()
        if digits:
            try:
                return int(digits[0])
            except Exception:
                return None
    return None


def _infer_policy_year_from_loss(loss_dt: pd.Timestamp, first_half_month_max: int) -> int:
    if int(loss_dt.month) <= int(first_half_month_max):
        return int(loss_dt.year) - 1
    return int(loss_dt.year)


def _most_common_month_day_from_any_policy_dates(
    g: pd.DataFrame, cols: Tuple[str, ...] = ("policy_effective_date", "policy_expiration_date")
) -> Optional[Tuple[int, int]]:
    """
    Look across BOTH effective + expiration columns in this group and return the most common (month, day)
    among parseable full dates (MM/DD/YYYY).
    """
    mds: list[Tuple[int, int]] = []
    for col in cols:
        if col not in g.columns:
            continue
        for v in g[col].tolist():
            if _is_blank(v):
                continue
            dt = pd.to_datetime(v, errors="coerce")
            if pd.notna(dt) and int(dt.year) >= 1900:
                mds.append((int(dt.month), int(dt.day)))

    if not mds:
        return None

    vc = pd.Series(mds).value_counts()
    return vc.index[0]


def _normalize_full_dates_inplace(g: pd.DataFrame, col: str) -> None:
    """
    If the value is parseable as a full date (year >= 1900), normalize to MM/DD/YYYY.
    Otherwise leave as-is.
    """
    if col not in g.columns:
        return

    out_vals = []
    for raw in g[col].tolist():
        if _is_blank(raw):
            out_vals.append(raw)
            continue
        dt = pd.to_datetime(raw, errors="coerce")
        if pd.notna(dt) and int(dt.year) >= 1900:
            out_vals.append(dt.strftime("%m/%d/%Y"))
        else:
            out_vals.append(raw)
    g[col] = out_vals


def _normalize_or_infer_policy_dates(g: pd.DataFrame, cfg: AugmentConfig) -> pd.DataFrame:
    """
    Normalize existing policy dates to ISO. Then, for blank effective/expiration dates:
    - compute ONE group-level most common MM/DD from ANY existing valid policy date
      (effective OR expiration) in the group
    - infer YYYY for row from accident_date via _infer_policy_year_from_loss
    - fill blanks in BOTH policy_effective_date and policy_expiration_date using that same MM/DD
    - append audit messages into cfg.audit_col for rows that were filled
    If the group has no valid policy dates at all, keep blanks blank.
    """
    if not cfg.infer_policy_year:
        return g
    if cfg.accident_date_col not in g.columns:
        return g

    g = g.copy()
    loss_dt = pd.to_datetime(g[cfg.accident_date_col], errors="coerce")

    # 1) normalize any existing full dates to ISO
    _normalize_full_dates_inplace(g, "policy_effective_date")
    _normalize_full_dates_inplace(g, "policy_expiration_date")

    # 2) find ONE MM/DD seed for the entire group from either column
    md = _most_common_month_day_from_any_policy_dates(g)
    if md is None:
        return g  # no valid policy dates anywhere => keep blanks blank

    m, d = md

    def fill_col(col: str) -> None:
        if col not in g.columns:
            return

        current = g[col].tolist()
        filled_mask = pd.Series(False, index=g.index)

        for i, raw in enumerate(current):
            if not _is_blank(raw):
                continue
            ld = loss_dt.iloc[i]
            if pd.isna(ld):
                continue  # can't infer without loss date
            year = _infer_policy_year_from_loss(ld, cfg.first_half_month_max)
            try:
                current[i] = pd.Timestamp(year=year, month=m, day=d).strftime("%m/%d/%Y")
                filled_mask.iloc[i] = True
            except Exception:
                # e.g., Feb 29 in non-leap year => leave blank
                pass

        g[col] = current

        # audit
        if filled_mask.any():
            msgs = pd.Series(
                [f"{col}: <blank> -> inferred using group MM/DD ({m:02d}/{d:02d}) + loss-year"] * len(g),
                index=g.index,
            )
            _append_audit(g, cfg, filled_mask, msgs)

    fill_col("policy_effective_date")
    fill_col("policy_expiration_date")

    return g


def _fill_field_within_page_window(g: pd.DataFrame, cfg: AugmentConfig, field: str) -> pd.DataFrame:
    if field not in g.columns or cfg.order_col not in g.columns:
        return g

    g = g.copy()
    g["_page_int"] = g[cfg.order_col].apply(_page_to_int)

    if g["_page_int"].isna().all():
        candidate = _best_nonblank(g[field].tolist())
        if not pd.isna(candidate):
            mask = g[field].apply(_is_blank)
            msg = pd.Series([f"{field}: <blank> -> {candidate!r} (group fill, no page parsed)"] * len(g), index=g.index)
            _append_audit(g, cfg, mask, msg)
            g.loc[mask, field] = candidate
        return g.drop(columns=["_page_int"])

    g = g.sort_values(["_page_int"], kind="stable").reset_index(drop=True)

    # Build list of (page_int, value) for all non-blank source rows
    source_rows = g.loc[~g[field].apply(_is_blank), ["_page_int", field]].dropna(subset=["_page_int"])
    if source_rows.empty:
        return g.drop(columns=["_page_int"])

    src_pages = source_rows["_page_int"].astype(int).tolist()
    src_values = source_rows[field].tolist()

    def nearest_source_backward(p: int):
        """Return (value, src_page, distance) of the nearest non-blank source at or before page p."""
        backward = [(i, src_pages[i]) for i in range(len(src_pages)) if src_pages[i] <= p]
        if not backward:
            return None, None, None
        best_idx, best_page = max(backward, key=lambda x: x[1])  # closest page <= p
        return src_values[best_idx], best_page, p - best_page

    fill_values = []
    fill_mask = []
    audit_msgs = []

    for _, row in g.iterrows():
        if not _is_blank(row[field]):
            fill_values.append(row[field])
            fill_mask.append(False)
            audit_msgs.append("")
            continue

        p = row["_page_int"]
        if pd.isna(p):
            fill_values.append(row[field])
            fill_mask.append(False)
            audit_msgs.append("")
            continue

        p = int(p)
        val, sp, dist = nearest_source_backward(p)
        if val is None:
            # No source before this page - leave blank
            fill_values.append(row[field])
            fill_mask.append(False)
            audit_msgs.append("")
            continue

        if dist <= cfg.max_page_distance:
            fill_values.append(val)
            fill_mask.append(True)
            audit_msgs.append(f"{field}: <blank> -> {val!r} (src page {sp}, dist {dist})")
        else:
            fill_values.append(row[field])   # keep blank
            fill_mask.append(False)
            audit_msgs.append("")

    mask_series = pd.Series(fill_mask, index=g.index)
    msg_series = pd.Series(audit_msgs, index=g.index)
    _append_audit(g, cfg, mask_series, msg_series)
    g[field] = fill_values

    return g.drop(columns=["_page_int"])


def _append_audit(g: pd.DataFrame, cfg: AugmentConfig, mask: pd.Series, messages: pd.Series) -> None:
    """
    Append per-row audit messages into cfg.audit_col, separated by '; '.
    Expects mask to be aligned to g.index and messages to be same length as g.
    """
    if cfg.audit_col not in g.columns:
        g[cfg.audit_col] = ""

    # only update rows where something happened
    idx = g.index[mask]
    if len(idx) == 0:
        return

    existing = g.loc[idx, cfg.audit_col].astype(str)
    add = messages.loc[idx].astype(str)

    # if existing is blank, replace; else append with separator
    combined = np.where(existing.str.strip().eq(""), add, existing + "; " + add)
    g.loc[idx, cfg.audit_col] = combined


def augment_extraction_output(df: pd.DataFrame, cfg: Optional[AugmentConfig] = None) -> pd.DataFrame:
    """
    Augment occurrence-level aggregated df by filling missing header-like fields within each
    (AccountName, file_path) group, using page proximity to avoid bleeding across sections.

    Policy effective/expiration logic:
      1) First, try page-window fills within (AccountName, file_path).
      2) Then, for any still-blank values, infer at AccountName level.
      All other augmentation remains at (AccountName, file_path) level only.
    """
    cfg = cfg or AugmentConfig()
    out = df.copy()

    if out.empty:
        if cfg.audit_col not in out.columns:
            out[cfg.audit_col] = ""
        return out

    if cfg.audit_col not in out.columns:
        out[cfg.audit_col] = ""

    group_cols = [c for c in cfg.group_cols if c in out.columns]
    if not group_cols:
        raise KeyError(
            f"Expected grouping columns {cfg.group_cols} to exist. Present columns: {list(out.columns)}"
        )

    POLICY_FIELDS = ("policy_effective_date", "policy_expiration_date")

    # --- Stage 1: page-window fill for POLICY fields at (AccountName, file_path) ---
    def process_policy_page_window(g: pd.DataFrame) -> pd.DataFrame:
        g2 = g.copy()
        if cfg.audit_col not in g2.columns:
            g2[cfg.audit_col] = ""
        for f in POLICY_FIELDS:
            if f in g2.columns:
                g2 = _fill_field_within_page_window(g2, cfg, f)
        return g2

    out = pd.concat(
        [process_policy_page_window(g) for _, g in out.groupby(group_cols, dropna=False, sort=False)],
        ignore_index=True,
    )

    # --- Stage 2: Account-level normalization/inference for remaining blank policy dates ---
    acct_cols = [c for c in ("AccountName",) if c in out.columns]
    if not acct_cols:
        raise KeyError(
            "Expected grouping column 'AccountName' to exist for account-level policy augmentation. "
            f"Present columns: {list(out.columns)}"
        )

    def process_account_policy(g: pd.DataFrame) -> pd.DataFrame:
        g2 = g.copy()
        if cfg.audit_col not in g2.columns:
            g2[cfg.audit_col] = ""
        return _normalize_or_infer_policy_dates(g2, cfg)

    out = pd.concat(
        [process_account_policy(g) for _, g in out.groupby(acct_cols, dropna=False, sort=False)],
        ignore_index=True,
    )

    # --- Stage 3: page-window fill for NON-POLICY fields at (AccountName, file_path) ---
    def process_other_fields(g: pd.DataFrame) -> pd.DataFrame:
        g2 = g.copy()
        if cfg.audit_col not in g2.columns:
            g2[cfg.audit_col] = ""
        for f in cfg.fields:
            if f in POLICY_FIELDS:
                continue  # already handled in stages 1 & 2
            g2 = _fill_field_within_page_window(g2, cfg, f)
        return g2

    out = pd.concat(
        [process_other_fields(g) for _, g in out.groupby(group_cols, dropna=False, sort=False)],
        ignore_index=True,
    )

    print("✅ Complete")
    return out


if __name__ == "__main__":
    import os

    # Example CLI usage with CSVs (Windows-friendly paths)
    # Expected input: occurrence-aggregated output (1 row per occurrence),
    # e.g., produced by aggregate_extraction_output.aggregate_by_occurrence(df)
    input_path = os.path.join("extraction_output", "zzz_test_deduped_occurrence_aggregated.csv")

    if not os.path.exists(input_path):
        raise FileNotFoundError(f"Could not find input file: {input_path}")

    df = pd.read_csv(input_path)

    before_nonnull = {}
    for c in AUGMENT_FIELDS_DEFAULT:
        if c in df.columns:
            before_nonnull[c] = int(df[c].notna().sum())

    out = augment_extraction_output(df)

    after_nonnull = {}
    for c in AUGMENT_FIELDS_DEFAULT:
        if c in out.columns:
            after_nonnull[c] = int(out[c].notna().sum())

    base_dir = os.path.dirname(input_path)
    stem, ext = os.path.splitext(os.path.basename(input_path))
    out_path = os.path.join(base_dir, f"{stem}_augmented{ext}")
    out.to_csv(out_path, index=False)

    print(f"Input rows: {len(df):,}")
    print(f"Output rows: {len(out):,}")
    print(f"Saved: {out_path}")

    # Quick fill-rate summary
    if before_nonnull:
        print("\nFill-rate deltas (non-null counts):")
        for c in sorted(before_nonnull.keys()):
            b = before_nonnull[c]
            a = after_nonnull.get(c, b)
            delta = a - b
            print(f"  {c}: {b:,} -> {a:,} (Δ {delta:+,})")
