"""Unified orchestrator that routes files to the correct extraction pipeline.

For each company folder under `input_data/`:
 * Excel/CSV files (.xlsx, .xls, .xlsm, .xlsb, .csv) -> Excel agentic pipeline
 * PDF files (.pdf) and DOCX files (.docx) -> PDF chunking pipeline

Both pipelines produce raw claims DataFrames which are appended together.
The combined output then flows through the Post_Processing pipeline
(clean -> augment -> dedupe -> aggregate) and is saved per-account under
`extraction_output/<AccountName>/`.
"""

import asyncio
import os
import sys
from pathlib import Path
from typing import Optional

import pandas as pd

# Work around Python 3.11 ProactorEventLoop self-pipe cancellation errors on Windows.
# The PDF pipeline calls asyncio.run() multiple times; each teardown triggers a
# harmless but noisy CancelledError on the ProactorEventLoop self-pipe.
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

# -------------------------------------------------------------------------
# Edit COMPANY_NAMES here - single source of truth for all pipelines
# -------------------------------------------------------------------------
COMPANY_NAMES: list[str] = ["Nobert Plating Co"]
# -------------------------------------------------------------------------
# Resolve project paths
# -------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent
INPUT_DATA_DIR = PROJECT_ROOT / "input_data"
OUTPUT_DATA_DIR = PROJECT_ROOT / "output_data"
EXTRACTION_DATA_DIR = PROJECT_ROOT / "extraction_output"

EXCEL_DIR = PROJECT_ROOT / "Excel"
PDF_DIR = PROJECT_ROOT / "PDF"
POST_PROCESSING_DIR = PROJECT_ROOT / "Post_Processing"

EXCEL_EXTENSIONS = {".xlsx", ".xls", ".xlsm", ".xlsb", ".csv"}
PDF_EXTENSIONS = {".pdf", ".docx"}


# -------------------------------------------------------------------------
# Helpers
# -------------------------------------------------------------------------

def _is_truly_empty(df: Optional[pd.DataFrame]) -> bool:
    """True if df is None or an empty DataFrame with no columns."""
    return df is None or (isinstance(df, pd.DataFrame) and df.empty and len(df.columns) == 0)


def _sort_claims_for_output(df: pd.DataFrame) -> pd.DataFrame:
    """Sort by AccountName, file_path, then page_num_or_sheet_name."""
    out = df.copy()
    if "page_num_or_sheet_name" in out.columns:
        out["page_num_sort"] = pd.to_numeric(out["page_num_or_sheet_name"], errors="coerce")
        out["is_numeric"] = out["page_num_sort"].notna()
        sort_cols = [c for c in ["AccountName", "file_path", "is_numeric", "page_num_sort", "page_num_or_sheet_name"] if c in out.columns]
        ascending = [True, True, False, True, True][: len(sort_cols)]
        out = out.sort_values(by=sort_cols, ascending=ascending, na_position="last").drop(
            columns=["page_num_sort", "is_numeric"], errors="ignore"
        )
    else:
        sort_cols = [c for c in ["AccountName", "file_path"] if c in out.columns]
        if sort_cols:
            out = out.sort_values(by=sort_cols, kind="stable")
    return out


def classify_company_files(company_names: list[str]) -> tuple[list[str], list[str]]:
    """Scan each company folder and classify into excel / pdf buckets.

    Returns two lists: (excel_companies, pdf_companies).
    A company can appear in both lists if the folder contains both file types.
    """
    excel_companies: list[str] = []
    pdf_companies: list[str] = []

    for company in company_names:
        company_dir = INPUT_DATA_DIR / company
        if not company_dir.is_dir():
            print(f"[WARNING] Input folder not found for '{company}', skipping.")
            continue

        has_excel = False
        has_pdf = False

        for file in company_dir.iterdir():
            if file.is_file():
                ext = file.suffix.lower()
                if ext in EXCEL_EXTENSIONS:
                    has_excel = True
                if ext in PDF_EXTENSIONS:
                    has_pdf = True
                if has_excel and has_pdf:
                    break

        if has_excel:
            excel_companies.append(company)
        if has_pdf:
            pdf_companies.append(company)

        if not has_excel and not has_pdf:
            print(f"[WARNING] No supported files found for '{company}', skipping.")

    return excel_companies, pdf_companies


# -------------------------------------------------------------------------
# Excel Extraction (returns raw claims DataFrame)
# -------------------------------------------------------------------------

def _collect_frames_from_state(run_state: dict, run_key: str) -> pd.DataFrame:
    """Extract and concatenate DataFrames from an Excel pipeline run state."""
    frames: list[pd.DataFrame] = []
    state = run_state.get(run_key, {})
    file_work_items = state.get("file_work_items", [])
    for item in file_work_items:
        extracted_df = item.get("extracted_df")
        if isinstance(extracted_df, pd.DataFrame) and not extracted_df.empty:
            company_name = str(item.get("company", "")).strip()
            if "AccountName" not in extracted_df.columns and company_name:
                extracted_df = extracted_df.copy()
                extracted_df["AccountName"] = company_name
            frames.append(extracted_df)
    if frames:
        return pd.concat(frames, ignore_index=True)
    return pd.DataFrame()


def run_excel_extraction(company_names: list[str]) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Run the Excel agentic extraction pipeline.

    Returns (claims_df, no_claims_df).
    """
    print("\n" + "=" * 72)
    print("EXCEL AGENTIC EXTRACTION")
    print(f"Companies: {company_names}")
    print("=" * 72 + "\n")

    _saved_modules = sys.modules.copy()
    original_cwd = os.getcwd()

    excel_dir_str = str(EXCEL_DIR)
    if excel_dir_str not in sys.path:
        sys.path.insert(0, excel_dir_str)

    os.chdir(EXCEL_DIR)

    try:
        from pipeline import run_dual_agentic_langgraph_pipeline  # type: ignore[import-not-found]
        from sandbox_executor import get_sandbox_status_message  # type: ignore[import-not-found]
        from utils_gpt import print_llm_startup_notice  # type: ignore[import-not-found]
        from constants_gpt import get_cli_log_mode  # type: ignore[import-not-found]

        print(f"\n{get_sandbox_status_message()}")
        print(f"CLI log mode: {get_cli_log_mode()}")
        print_llm_startup_notice()
        print()

        run_results = run_dual_agentic_langgraph_pipeline(
            company_names=company_names,
            input_data_dir=str(INPUT_DATA_DIR),
            output_data_dir=str(OUTPUT_DATA_DIR),
            extraction_data_dir=str(EXTRACTION_DATA_DIR),
        )

        claims_df = _collect_frames_from_state(run_results, "claims")
        no_claims_df = _collect_frames_from_state(run_results, "no_claims")

        return claims_df, no_claims_df

    finally:
        os.chdir(original_cwd)
        if excel_dir_str in sys.path:
            sys.path.remove(excel_dir_str)
        sys.modules.clear()
        sys.modules.update(_saved_modules)


# -------------------------------------------------------------------------
# PDF Extraction (returns raw claims DataFrame)
# -------------------------------------------------------------------------

def run_pdf_extraction(company_names: list[str]) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Run the PDF chunking extraction pipeline.

    Returns (claims_df, no_claims_df).
    """
    print("\n" + "=" * 72)
    print("PDF CHUNKING EXTRACTION")
    print(f"Companies: {company_names}")
    print("=" * 72 + "\n")

    _saved_modules = sys.modules.copy()
    original_cwd = os.getcwd()

    pdf_dir_str = str(PDF_DIR)
    if pdf_dir_str not in sys.path:
        sys.path.insert(0, pdf_dir_str)

    os.chdir(PDF_DIR)

    try:
        from docx_to_pdf import convert_docx_to_pdf  # type: ignore[import-not-found]
        from detect_loss_runs import detect_loss_runs  # type: ignore[import-not-found]
        from pdf_to_images import turn_pdf_to_images  # type: ignore[import-not-found]
        from ocr import run_ocr  # type: ignore[import-not-found]
        from determine_pdf_cutoff import determine_page_cutoffs  # type: ignore[import-not-found]
        from extract_import import extract_claims, extract_policies_no_claims  # type: ignore[import-not-found]
        from metrics import save_metrics_json as pdf_save_metrics  # type: ignore[import-not-found]

        input_data_dir = str(INPUT_DATA_DIR)
        output_data_dir = str(OUTPUT_DATA_DIR)

        # Convert all DOCX to PDF
        print("\nConverting DOCX to PDF....")
        convert_docx_to_pdf(input_data_dir, company_names)

        # Detect which documents are loss runs
        print("\nDetecting which input files are loss runs....")
        is_file_loss_run_dict = detect_loss_runs(output_data_dir, company_names)

        # Convert PDF pages to images
        print("\nCreating images of each PDF page...")
        turn_pdf_to_images(company_names, input_data_dir, output_data_dir)

        # OCR each PDF page to generate page_response.json used by chunking/extraction
        print("\nRunning OCR on PDF pages...")
        run_ocr(company_names, input_data_dir, output_data_dir, use_cached=True)

        # Determine page groupings
        print("\nDetermining PDF page groupings based on context limits...")
        pages_to_join_dict = determine_page_cutoffs(output_data_dir, company_names, is_file_loss_run_dict)

        # Extract claims
        print("\nBeginning Loss Run Extraction....")
        print("\n Extracting Key Claim-Level Details....")
        claims_df = extract_claims(output_data_dir, company_names, pages_to_join_dict, is_file_loss_run_dict)
        if _is_truly_empty(claims_df):
            print("  ⚠️ PDF claims extraction returned an empty DataFrame.")
            claims_df = pd.DataFrame()

        # Extract policies without claims
        print("\n Extracting Policies Without Claims....")
        no_claims_df = extract_policies_no_claims(output_data_dir, company_names, pages_to_join_dict, is_file_loss_run_dict)
        if _is_truly_empty(no_claims_df):
            print("  ⚠️ No policies without claims found.")
            no_claims_df = pd.DataFrame()

        # Save PDF metrics per account
        print("\n Saving PDF Metrics....")
        for company in company_names:
            account_dir = EXTRACTION_DATA_DIR / company
            account_dir.mkdir(parents=True, exist_ok=True)
            metrics_path = str(account_dir / f"{company}_pdf_metrics.json")
            pdf_save_metrics(metrics_path)
            print(f"       Saved: {metrics_path}")

        return claims_df, no_claims_df

    finally:
        os.chdir(original_cwd)
        if pdf_dir_str in sys.path:
            sys.path.remove(pdf_dir_str)
        sys.modules.clear()
        sys.modules.update(_saved_modules)


# -------------------------------------------------------------------------
# Post-Processing Pipeline
# -------------------------------------------------------------------------

def run_post_processing(claims_df: pd.DataFrame, company_names: list[str]) -> None:
    """Run the post-processing pipeline on the combined claims DataFrame.

    Steps: clean -> augment -> dedupe -> aggregate -> save per-account.
    """
    print("\n" + "=" * 72)
    print("POST-PROCESSING PIPELINE")
    print("=" * 72 + "\n")

    # Add Post_Processing to sys.path for imports
    post_proc_parent = str(PROJECT_ROOT)
    if post_proc_parent not in sys.path:
        sys.path.insert(0, post_proc_parent)

    from Post_Processing import (
        process_claims_df,
        process_claim_free_policies_df,
        augment_extraction_output,
        find_occurrences_and_duplicates,
        aggregate_by_occurrence,
    )

    # 1) Sort raw output
    claims_sorted = _sort_claims_for_output(claims_df)

    # 2) Clean claim-level output
    print("\n Step 1: Cleaning Claims DataFrame")
    claims_clean_df = process_claims_df(claims_sorted)
    claims_clean_sorted = _sort_claims_for_output(claims_clean_df)
    print("        ✅ Complete")

    if claims_clean_sorted.empty:
        print("\n  ⚠️ No valid claims rows remain after cleaning - skipping remaining claims post-processing steps.")
        return

    # 3) Augment with header-like metadata
    print("\n Step 2: Augmenting Clean Claim-Level Output")
    claims_aug_df = augment_extraction_output(claims_clean_sorted)
    claims_aug_sorted = _sort_claims_for_output(claims_aug_df)

    # Drop augmentation audit column
    if "augmentation" in claims_aug_sorted.columns:
        claims_aug_sorted = claims_aug_sorted.drop(columns=["augmentation"])

    # 4) Occurrence + duplicate detection
    print("\n Step 3: Detecting Occurrences + Duplicates")
    claims_deduped_df = find_occurrences_and_duplicates(claims_aug_sorted)
    claims_deduped_sorted = _sort_claims_for_output(claims_deduped_df)

    # 5) Aggregate to occurrence-level
    print("\n Step 4: Aggregating to Occurrence Level")
    occ_agg_df = aggregate_by_occurrence(claims_deduped_sorted)

    # Drop merged_updates column
    if "merged_updates" in occ_agg_df.columns:
        claims_final_df = occ_agg_df.drop(columns=["merged_updates"])
    else:
        claims_final_df = occ_agg_df

    # 6) Save per-account outputs for ALL intermediate steps
    print("\n Step 5: Saving Intermediate + Final Outputs Per Account")
    if "AccountName" in claims_final_df.columns:
        for account_name, account_df in claims_final_df.groupby("AccountName", dropna=False):
            account_dir = EXTRACTION_DATA_DIR / str(account_name)
            account_dir.mkdir(parents=True, exist_ok=True)

            # Save clean output
            account_clean = claims_clean_sorted[
                claims_clean_sorted["AccountName"] == account_name
            ] if "AccountName" in claims_clean_sorted.columns else pd.DataFrame()
            if not account_clean.empty:
                clean_path = account_dir / f"{account_name}_claims_clean.csv"
                account_clean.to_csv(clean_path, index=False)
                print(f"       Saved: {clean_path}")

            # Save augmented output
            account_aug = claims_aug_sorted[
                claims_aug_sorted["AccountName"] == account_name
            ] if "AccountName" in claims_aug_sorted.columns else pd.DataFrame()
            if not account_aug.empty:
                aug_path = account_dir / f"{account_name}_claims_augmented.csv"
                account_aug.to_csv(aug_path, index=False)
                print(f"       Saved: {aug_path}")

            # Save deduped output
            account_deduped = claims_deduped_sorted[
                claims_deduped_sorted["AccountName"] == account_name
            ] if "AccountName" in claims_deduped_sorted.columns else pd.DataFrame()
            if not account_deduped.empty:
                deduped_path = account_dir / f"{account_name}_claims_deduped.csv"
                account_deduped.to_csv(deduped_path, index=False)
                print(f"       Saved: {deduped_path}")

            # Save final aggregated output
            final_path = account_dir / f"{account_name}_claims_final.csv"
            account_df.to_csv(final_path, index=False)
            print(f"       Saved: {final_path}")
    else:
        # No AccountName column - save as single file
        output_dir = EXTRACTION_DATA_DIR / "combined"
        output_dir.mkdir(parents=True, exist_ok=True)

        claims_clean_sorted.to_csv(output_dir / "claims_clean.csv", index=False)
        print(f"       Saved: {output_dir / 'claims_clean.csv'}")

        claims_aug_sorted.to_csv(output_dir / "claims_augmented.csv", index=False)
        print(f"       Saved: {output_dir / 'claims_augmented.csv'}")

        claims_deduped_sorted.to_csv(output_dir / "claims_deduped.csv", index=False)
        print(f"       Saved: {output_dir / 'claims_deduped.csv'}")

        final_path = output_dir / "claims_final.csv"
        claims_final_df.to_csv(final_path, index=False)
        print(f"       Saved: {final_path}")

    print("\n ✅ Claims post-processing complete")


def run_no_claims_post_processing(no_claims_df: pd.DataFrame) -> None:
    """Clean the combined no-claims (policies without claims) DataFrame and save per-account."""
    print("\n" + "=" * 72)
    print("NO-CLAIMS POST-PROCESSING")
    print("=" * 72 + "\n")

    post_proc_parent = str(PROJECT_ROOT)
    if post_proc_parent not in sys.path:
        sys.path.insert(0, post_proc_parent)

    from Post_Processing import process_claim_free_policies_df

    print("\n Cleaning Policies Without Claims")
    no_claims_clean_df = process_claim_free_policies_df(no_claims_df)

    if _is_truly_empty(no_claims_clean_df):
        print("  ⚠️ No valid policies without claims after cleaning.")
        return

    # Save per-account
    print("\n Saving No-Claims Output Per Account")
    if "AccountName" in no_claims_clean_df.columns:
        for account_name, account_df in no_claims_clean_df.groupby("AccountName", dropna=False):
            account_dir = EXTRACTION_DATA_DIR / str(account_name)
            account_dir.mkdir(parents=True, exist_ok=True)

            no_claims_path = account_dir / f"{account_name}_no_claims.csv"
            account_df.to_csv(no_claims_path, index=False)
            print(f"       Saved: {no_claims_path}")
    else:
        output_dir = EXTRACTION_DATA_DIR / "combined"
        output_dir.mkdir(parents=True, exist_ok=True)
        no_claims_path = output_dir / "no_claims.csv"
        no_claims_clean_df.to_csv(no_claims_path, index=False)
        print(f"       Saved: {no_claims_path}")

    print("\n ✅ No-claims post-processing complete")


# -------------------------------------------------------------------------
# Main Entry Point
# -------------------------------------------------------------------------

def main():
    """Entry point: extract from Excel & PDF, combine, and post-process."""
    company_names = list(COMPANY_NAMES)

    # Classify companies by file type
    excel_companies, pdf_companies = classify_company_files(company_names)

    print(f"\nCompanies with Excel files ({len(excel_companies)}): {excel_companies}")
    print(f"Companies with PDF/DOCX files ({len(pdf_companies)}): {pdf_companies}")

    # --- Stage 1: Run Excel extraction ---
    excel_claims_df = pd.DataFrame()
    excel_no_claims_df = pd.DataFrame()
    if excel_companies:
        excel_claims_df, excel_no_claims_df = run_excel_extraction(excel_companies)
        print(f"\n[INFO] Excel extraction: {len(excel_claims_df)} claims rows, {len(excel_no_claims_df)} no-claims rows")
    else:
        print("\n[INFO] No companies with Excel files found. Skipping Excel pipeline.")

    # --- Stage 2: Run PDF extraction ---
    pdf_claims_df = pd.DataFrame()
    pdf_no_claims_df = pd.DataFrame()
    if pdf_companies:
        pdf_claims_df, pdf_no_claims_df = run_pdf_extraction(pdf_companies)
        print(f"\n[INFO] PDF extraction: {len(pdf_claims_df)} claims rows, {len(pdf_no_claims_df)} no-claims rows")

        # Save PDF claims per account as pdf_Claims.csv
        if not _is_truly_empty(pdf_claims_df) and "AccountName" in pdf_claims_df.columns:
            for account_name, account_df in pdf_claims_df.groupby("AccountName", dropna=False):
                account_dir = EXTRACTION_DATA_DIR / str(account_name)
                account_dir.mkdir(parents=True, exist_ok=True)
                pdf_claims_path = account_dir / f"{account_name}_pdf_Claims.csv"
                account_df.to_csv(pdf_claims_path, index=False)
                print(f"       Saved: {pdf_claims_path}")

        # Save PDF no-claims per account as pdf_policies_no_claims.csv
        if not _is_truly_empty(pdf_no_claims_df) and "AccountName" in pdf_no_claims_df.columns:
            for account_name, account_df in pdf_no_claims_df.groupby("AccountName", dropna=False):
                account_dir = EXTRACTION_DATA_DIR / str(account_name)
                account_dir.mkdir(parents=True, exist_ok=True)
                pdf_no_claims_path = account_dir / f"{account_name}_pdf_policies_no_claims.csv"
                account_df.to_csv(pdf_no_claims_path, index=False)
                print(f"       Saved: {pdf_no_claims_path}")
    else:
        print("\n[INFO] No companies with PDF/DOCX files found. Skipping PDF pipeline.")

    # --- Stage 3: Combine claims outputs ---
    claims_frames = [
        df for df in [excel_claims_df, pdf_claims_df]
        if not _is_truly_empty(df)
    ]

    if claims_frames:
        combined_claims_df = pd.concat(claims_frames, ignore_index=True)
        print(f"\n[INFO] Combined claims: {len(combined_claims_df)} total rows")

        # --- Save raw concatenated extraction output per account ---
        print("\n Saving raw extraction output (pre-post-processing)...")
        if "AccountName" in combined_claims_df.columns:
            for account_name, account_df in combined_claims_df.groupby("AccountName", dropna=False):
                account_dir = EXTRACTION_DATA_DIR / str(account_name)
                account_dir.mkdir(parents=True, exist_ok=True)
                raw_path = account_dir / f"{account_name}_final_raw.csv"
                account_df.to_csv(raw_path, index=False)
                print(f"       Saved: {raw_path}")
        else:
            output_dir = EXTRACTION_DATA_DIR / "combined"
            output_dir.mkdir(parents=True, exist_ok=True)
            raw_path = output_dir / "final_raw.csv"
            combined_claims_df.to_csv(raw_path, index=False)
            print(f"       Saved: {raw_path}")

        # --- Stage 4a: Run claims post-processing ---
        run_post_processing(combined_claims_df, company_names)
    else:
        print("\n[WARNING] No claims extracted from either pipeline.")

    # --- Stage 4b: Combine and post-process no-claims outputs ---
    no_claims_frames = [
        df for df in [excel_no_claims_df, pdf_no_claims_df]
        if not _is_truly_empty(df)
    ]

    if no_claims_frames:
        combined_no_claims_df = pd.concat(no_claims_frames, ignore_index=True)
        print(f"\n[INFO] Combined no-claims: {len(combined_no_claims_df)} total rows")

        run_no_claims_post_processing(combined_no_claims_df)
    else:
        print("\n[INFO] No policies-without-claims extracted from either pipeline.")

    print("\n" + "=" * 72)
    print("ALL PIPELINES COMPLETE")
    print("=" * 72)


if __name__ == "__main__":
    main()
