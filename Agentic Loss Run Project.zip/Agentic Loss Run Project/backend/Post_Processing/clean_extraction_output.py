import pandas as pd
import re
import string
import warnings
from .constants import CLAIM_LEVEL_VALID_JSON_FIELDS, NO_CLAIMS_VALID_JSON_FIELDS

STATE_LIST = ['AB', 'ABW', 'AD', 'AE', 'AF', 'AFG', 'AG', 'AGO', 'AI', 'AIA', 'AK', 'AL', 'ALA', 'ALB', 'AM', 'AND', 'ANT', 'AO', 'AQ', 'AR', 'ARE', 'ARG', 'ARM', 'AS', 'ASM', 'AT', 'ATA', 'ATF', 'ATG', 'AU', 'AUS', 'AUT', 'AW', 'AX', 'AZ', 'AZE', 'BA', 'BB', 'BC', 'BD', 'BDI', 'BE', 'BEL', 'BEN', 'BES', 'BF', 'BFA', 'BG', 'BGD', 'BGR', 'BH', 'BHR', 'BHS', 'BI', 'BIH', 'BJ', 'BL', 'BLM', 'BLR', 'BLZ', 'BM', 'BMU', 'BN', 'BO', 'BOL', 'BQ', 'BR', 'BRA', 'BRB', 'BRN', 'BS', 'BT', 'BTN', 'BV', 'BVT', 'BW', 'BWA', 'BY', 'BZ', 'CA', 'CAF', 'CAN', 'CC', 'CCK', 'CD', 'CF', 'CG', 'CH', 'CHE', 'CHL', 'CHN', 'CI', 'CIV', 'CK', 'CL', 'CM', 'CMR', 'CN', 'CO', 'COD', 'COG', 'COK', 'COL', 'COM', 'CPV', 'CR', 'CRI', 'CT', 'CU', 'CUB', 'CUW', 'CV', 'CW', 'CX', 'CXR', 'CY', 'CYM', 'CYP', 'CZ', 'CZE', 'DC', 'DE', 'DEU', 'DJ', 'DJI', 'DK', 'DM', 'DMA', 'DNK', 'DO', 'DOM', 'DZ', 'DZA', 'EC', 'ECU', 'EE', 'EG', 'EGY', 'EH', 'ER', 'ERI', 'ES', 'ESH', 'ESP', 'EST', 'ET', 'ETH', 'FI', 'FIN', 'FJ', 'FJI', 'FK', 'FL', 'FLK', 'FM', 'FO', 'FR', 'FRA', 'FRO', 'FSM', 'GA', 'GAB', 'GB', 'GBR', 'GD', 'GE', 'GEO', 'GF', 'GG', 'GGY', 'GH', 'GHA', 'GI', 'GIB', 'GIN', 'GL', 'GLP', 'GM', 'GMB', 'GN', 'GNB', 'GNQ', 'GP', 'GQ', 'GR', 'GRC', 'GRD', 'GRL', 'GS', 'GT', 'GTM', 'GU', 'GUF', 'GUM', 'GUY', 'GW', 'GY', 'HI', 'HK', 'HKG', 'HM', 'HMD', 'HN', 'HND', 'HR', 'HRV', 'HT', 'HTI', 'HU', 'HUN', 'IA', 'ID', 'IDN', 'IE', 'IL', 'IM', 'IMN', 'IN', 'IND', 'IO', 'IOT', 'IQ', 'IR', 'IRL', 'IRN', 'IRQ', 'IS', 'ISL', 'ISR', 'IT', 'ITA', 'JAM', 'JE', 'JEY', 'JM', 'JO', 'JOR', 'JP', 'JPN', 'KAZ', 'KE', 'KEN', 'KG', 'KGZ', 'KH', 'KHM', 'KI', 'KIR', 'KM', 'KN', 'KNA', 'KOR', 'KP', 'KR', 'KS', 'KW', 'KWT', 'KY', 'KZ', 'LA', 'LAO', 'LB', 'LBN', 'LBR', 'LBY', 'LC', 'LCA', 'LI', 'LIE', 'LK', 'LKA', 'LR', 'LS', 'LSO', 'LT', 'LTU', 'LU', 'LUX', 'LV', 'LVA', 'LY', 'MA', 'MAC', 'MAF', 'MAR', 'MB', 'MC', 'MCO', 'MD', 'MDA', 'MDG', 'MDV', 'ME', 'MEX', 'MF', 'MG', 'MH', 'MHL', 'MI', 'MK', 'MKD', 'ML', 'MLI', 'MLT', 'MM', 'MMR', 'MN', 'MNE', 'MNG', 'MNP', 'MO', 'MOZ', 'MP', 'MQ', 'MR', 'MRT', 'MS', 'MSR', 'MT', 'MTQ', 'MU', 'MUS', 'MV', 'MW', 'MWI', 'MX', 'MY', 'MYS', 'MYT', 'MZ', 'NA', 'NAM', 'NB', 'NC', 'NCL', 'ND', 'NE', 'NER', 'NF', 'NFK', 'NG', 'NGA', 'NH', 'NI', 'NIC', 'NIU', 'NJ', 'NL', 'NLD', 'NM', 'NO', 'NOR', 'NP', 'NPL', 'NR', 'NRU', 'NS', 'NT', 'NU', 'NV', 'NY', 'NZ', 'NZL', 'OH', 'OK', 'OM', 'OMN', 'ON', 'OR', 'PA', 'PAK', 'PAN', 'PCN', 'PE', 'PER', 'PF', 'PG', 'PH', 'PHL', 'PK', 'PL', 'PLW', 'PM', 'PN', 'PNG', 'POL', 'PR', 'PRI', 'PRK', 'PRT', 'PRY', 'PS', 'PSE', 'PT', 'PW', 'PY', 'PYF', 'QA', 'QAT', 'QC', 'RE', 'REU', 'RI', 'RO', 'ROU', 'RS', 'RU', 'RUS', 'RW', 'RWA', 'SA', 'SAU', 'SB', 'SC', 'SD', 'SDN', 'SE', 'SEN', 'SG', 'SGP', 'SGS', 'SH', 'SHN', 'SI', 'SJ', 'SJM', 'SK', 'SL', 'SLB', 'SLE', 'SLV', 'SM', 'SMR', 'SN', 'SO', 'SOM', 'SPM', 'SR', 'SRB', 'SS', 'SSD', 'ST', 'STP', 'SUR', 'SV', 'SVK', 'SVN', 'SWE', 'SWZ', 'SX', 'SXM', 'SY', 'SYC', 'SYR', 'SZ', 'TC', 'TCA', 'TCD', 'TD', 'TF', 'TG', 'TGO', 'TH', 'THA', 'TJ', 'TJK', 'TK', 'TKL', 'TKM', 'TL', 'TLS', 'TM', 'TN', 'TO', 'TON', 'TR', 'TT', 'TTO', 'TUN', 'TUR', 'TUV', 'TV', 'TW', 'TWN', 'TX', 'TZ', 'TZA', 'UA', 'UG', 'UGA', 'UKR', 'UM', 'UMI', 'URY', 'US', 'USA', 'UT', 'UY', 'UZ', 'UZB', 'VA', 'VAT', 'VC', 'VCT', 'VE', 'VEN', 'VG', 'VGB', 'VI', 'VIR', 'VN', 'VNM', 'VT', 'VU', 'VUT', 'WA', 'WF', 'WI', 'WLF', 'WS', 'WSM', 'WV', 'WY', 'YE', 'YEM', 'YT', 'ZA', 'ZAF', 'ZM', 'ZMB', 'ZW', 'ZWE']

def _clean_date_str(s: pd.Series) -> pd.Series:
    """Convert anything parseable to MM/DD/YYYY as string; else NaN."""
    # Vectorized: much faster than per-cell pd.to_datetime in apply
    dt = pd.to_datetime(s, errors="coerce", format="mixed")
    out = dt.dt.strftime("%m/%d/%Y")
    # strftime returns object with NaN for NaT; normalize to pd.NA
    return pd.Series(out, index=s.index).where(~dt.isna(), pd.NA)

def _clean_lob(s: pd.Series) -> pd.Series:
    allowed = {
        "auto": "auto",
        "property": "property",
        "general liability": "general liability",
        "workers compensation": "workers compensation",
        "umbrella": "umbrella",
    }
    txt = s.astype("string").str.strip().str.lower()
    mapped = txt.map(allowed)
    return mapped

def to_str_strip(s: pd.Series) -> pd.Series:
    return s.astype("string").str.strip()

def _clean_id_str(s: pd.Series) -> pd.Series:
    """Policy/claim numbers as string; drop trailing .0 from floats."""
    txt = s.astype("string").str.strip()
    # Only strip trailing ".0" when the whole string is an integer with ".0"
    mask = txt.str.match(r"^\d+\.0$", na=False)
    txt = txt.where(~mask, txt.str[:-2])
    return txt

def _clean_status(s: pd.Series) -> pd.Series:
    mapping = {
        "o": "O", "open": "O",
        "c": "C", "closed": "C",
        "r": "R", "reopen": "R", "re-open": "R", "reopened": "R",
        "s": "S", "subrogated": "S",
    }
    txt = s.astype("string").str.strip().str.lower()
    return txt.map(mapping).astype("string")

def _to_float_with_default(s: pd.Series, default: float = 0.0) -> pd.Series:
    out = pd.to_numeric(s, errors="coerce")
    out = out.fillna(default)
    return out.astype(float)

def _clean_state_col(s: pd.Series) -> pd.Series:
    txt = s.astype("string").str.strip().str.upper()
    txt = txt.str.replace(r"\n*\s+", "", regex=True).str.strip()
    return txt.where(txt.isin(STATE_LIST), pd.NA).astype("string")

def _count_changes(before: pd.Series, after: pd.Series) -> int:
    """Count number of rows where value actually changed (ignoring NaN==NaN)."""
    # Avoid reset_index/copies; align on index and compare with NA-equality
    b = before
    a = after
    same = (b.eq(a)) | (b.isna() & a.isna())
    return int((~same).sum())

def _print_if_changes(changed: int, msg: str) -> None:
    if changed > 0:
        print(msg)

def process_claims_df(claims_df: pd.DataFrame) -> pd.DataFrame:
    df = claims_df.copy()

    # --- identify rows that are "empty" other than AccountName / file_path ---
    protected_cols = {"AccountName", "file_path"}
    candidate_cols = [c for c in df.columns if c not in protected_cols]

    if candidate_cols:
        empty_mask = df[candidate_cols].isna().all(axis=1)
    else:
        empty_mask = pd.Series(True, index=df.index)

    df_empty = df[empty_mask].copy()        # do not touch these rows
    df_keep = df[~empty_mask].copy()        # apply all cleaning logic only here
    df = df_keep

    # --- Dates: "MM/DD/YYYY" as string ---
    date_cols = [
        "policy_effective_date",
        "policy_expiration_date",
        "evaluation_date",
        "accident_date",
        "report_date",
    ]
    for col in date_cols:
        if col in df.columns:
            before = df[col].copy()
            df[col] = _clean_date_str(df[col]).astype("string")
            changed = _count_changes(before, df[col])
            _print_if_changes(changed, f"            Date cleaning: changed {changed} rows in '{col}'")

    # --- line_of_business normalization ---
    if "line_of_business" in df.columns:
        before = df["line_of_business"].copy()
        df["line_of_business"] = _clean_lob(df["line_of_business"]).astype("string")
        changed = _count_changes(before, df["line_of_business"])
        _print_if_changes(changed, f"            LOB cleaning: changed {changed} rows in 'line_of_business'")

        before_count = len(df)
        df = df.dropna(subset=["line_of_business"])
        dropped = before_count - len(df)
        _print_if_changes(dropped, f"            LOB cleaning: dropped {dropped} rows with unrecognized line_of_business")

    # --- prior_carrier as string ---
    if "prior_carrier" in df.columns:
        before = df["prior_carrier"].copy()
        df["prior_carrier"] = to_str_strip(df["prior_carrier"])
        changed = _count_changes(before, df["prior_carrier"])
        _print_if_changes(changed, f"            Prior carrier cleaning: changed {changed} rows in 'prior_carrier'")

    # --- policy_number and claim_id as strings with .0 removed ---
    if "policy_number" in df.columns:
        before = df["policy_number"].copy()
        df["policy_number"] = _clean_id_str(df["policy_number"])
        changed = _count_changes(before, df["policy_number"])
        _print_if_changes(changed, f"            ID cleaning: changed {changed} rows in 'policy_number'")

    if "claim_id" in df.columns:
        before = df["claim_id"].copy()
        df["claim_id"] = _clean_id_str(df["claim_id"])
        changed = _count_changes(before, df["claim_id"])
        _print_if_changes(changed, f"            ID cleaning: changed {changed} rows in 'claim_id'")

        # Drop phantom rows where claim_id is a narrative overflow sentence or summary total
        narrative_verbs = ["struck", "hit", "collided", "backed into", "rear ended", "rear-ended", "passenger", "vehicle", "driver", "client vehicle", "damaged", "injured", "slipped", "fell", "grand total", "total claims", "subtotal"]
        cid_lower = df["claim_id"].astype(str).str.lower()
        is_bogus = cid_lower.apply(lambda s: any(v in s for v in narrative_verbs) or (len(s.split()) >= 4 and not bool(re.search(r'\d{3,}', s))) or s in ["total", "totals", "grand total", "summary"])
        if is_bogus.any():
            dropped_count = int(is_bogus.sum())
            df = df[~is_bogus].copy()
            _print_if_changes(dropped_count, f"            Dropped {dropped_count} phantom footer / narrative overflow rows from claims")

    # --- subline as string; for auto, only "AL" or "APD" ---
    if "subline" in df.columns:
        before_all = df["subline"].copy()
        df["subline"] = to_str_strip(df["subline"])
        changed_strip = _count_changes(before_all, df["subline"])
        _print_if_changes(changed_strip, f"            Subline cleaning (strip): changed {changed_strip} rows in 'subline'")

        if "line_of_business" in df.columns:
            is_auto = df["line_of_business"].eq("auto")
            if is_auto.any():
                before_auto = df.loc[is_auto, "subline"]
                sub = df.loc[is_auto, "subline"].astype("string").str.strip().str.upper()

                # Keep original logic:
                # - {"AL", "AUTO LIABILITY"} -> "AL"
                # - {"APD", "AUTO PHYSICAL DAMAGE", "PD"} -> "APD"
                # - everything else -> "APD"
                sub = sub.where(~sub.isna(), pd.NA)
                al_mask = sub.isin(["AL", "AUTO LIABILITY"])
                apd_mask = sub.isin(["APD", "AUTO PHYSICAL DAMAGE", "PD"])
                sub_out = pd.Series(pd.NA, index=sub.index, dtype="string")
                sub_out[al_mask] = "AL"
                sub_out[apd_mask] = "APD"
                sub_out[~(al_mask | apd_mask) & ~sub.isna()] = "APD"

                df.loc[is_auto, "subline"] = sub_out
                changed_auto = _count_changes(before_auto, df.loc[is_auto, "subline"])
                _print_if_changes(changed_auto, f"            Subline cleaning (auto-only): changed {changed_auto} rows in 'subline' for auto LOB")

    # --- financials as float with default 0.0 ---
    float_cols = [
        "total_incurred",
        "total_paid",
        "incurred_alae",
        "paid_alae",
        "total_recoveries",
    ]
    for col in float_cols:
        if col in df.columns:
            before = df[col].copy()
            df[col] = _to_float_with_default(df[col], 0.0)
            changed = _count_changes(before, df[col].astype("string"))
            _print_if_changes(changed, f"            Financial cleaning: changed {changed} rows in '{col}'")

    # --- status ---
    if "status" in df.columns:
        before = df["status"].copy()
        df["status"] = _clean_status(df["status"]).astype("string")
        changed = _count_changes(before, df["status"])
        _print_if_changes(changed, f"            Status cleaning: changed {changed} rows in 'status'")

    # --- adjust paid values for closed claims within $2 difference ---
    if "status" in df.columns:
        # Check for closed claims (after status cleaning standardizes to "C")
        is_closed = df["status"] == "C"

        # Adjust total_paid to match total_incurred if within $2
        if "total_incurred" in df.columns and "total_paid" in df.columns:
            diff = (df["total_incurred"] - df["total_paid"]).abs()
            within_threshold = is_closed & (diff <= 2) & (diff > 0)
            before = df["total_paid"].copy()
            df.loc[within_threshold, "total_paid"] = df.loc[within_threshold, "total_incurred"]
            changed = (before != df["total_paid"]).sum()
            _print_if_changes(changed, f"            Adjusting for small reporting differences: changed {changed} rows in 'total_paid' to match 'total_incurred'")

        # Adjust paid_alae to match incurred_alae if within $2
        if "incurred_alae" in df.columns and "paid_alae" in df.columns:
            diff = (df["incurred_alae"] - df["paid_alae"]).abs()
            within_threshold = is_closed & (diff <= 2) & (diff > 0)
            before = df["paid_alae"].copy()
            df.loc[within_threshold, "paid_alae"] = df.loc[within_threshold, "incurred_alae"]
            changed = (before != df["paid_alae"]).sum()
            _print_if_changes(changed, f"            Adjusting for small reporting differences: changed {changed} rows in 'paid_alae' to match 'incurred_alae'")

    # --- claimant, driver, claim_description as string ---
    for col in ["claimant", "driver", "claim_description"]:
        if col in df.columns:
            before = df[col].copy()
            df[col] = to_str_strip(df[col])
            changed = _count_changes(before, df[col])
            _print_if_changes(changed, f"            Text cleaning: changed {changed} rows in '{col}'")

    # --- state columns: 2-letter codes ---
    for col in ["accident_state", "garage_state", "coverage_state"]:
        if col in df.columns:
            before = df[col].copy()
            df[col] = _clean_state_col(df[col])
            changed = _count_changes(before, df[col])
            _print_if_changes(changed, f"            State cleaning: changed {changed} rows in '{col}'")

    # --- garage_state and driver NaN if not auto ---
    if "line_of_business" in df.columns:
        not_auto = ~df["line_of_business"].eq("auto")

        if "garage_state" in df.columns:
            before = df["garage_state"].copy()
            df.loc[not_auto, "garage_state"] = pd.NA
            changed = _count_changes(before, df["garage_state"])
            _print_if_changes(changed, f"            Non-auto adjustment: changed {changed} rows in 'garage_state'")

        if "driver" in df.columns:
            before = df["driver"].copy()
            df.loc[not_auto, "driver"] = pd.NA
            changed = _count_changes(before, df["driver"])
            _print_if_changes(changed, f"            Non-auto adjustment: changed {changed} rows in 'driver'")

    # --- coverage_state NaN if not general liability ---
    if "line_of_business" in df.columns and "coverage_state" in df.columns:
        not_gl = ~df["line_of_business"].eq("general liability")
        before = df["coverage_state"].copy()
        df.loc[not_gl, "coverage_state"] = pd.NA
        changed = _count_changes(before, df["coverage_state"])
        _print_if_changes(changed, f"            Non-GL adjustment: changed {changed} rows in 'coverage_state'")

    # --- page_num_or_sheet_name as string ---
    if "page_num_or_sheet_name" in df.columns:
        before = df["page_num_or_sheet_name"].copy()
        df["page_num_or_sheet_name"] = _clean_id_str(df["page_num_or_sheet_name"])
        changed = _count_changes(before, df["page_num_or_sheet_name"])
        _print_if_changes(changed, f"            ID cleaning: changed {changed} rows in 'page_num_or_sheet_name'")

    out = df.sort_index()
    print("            [OK] Complete")
    return out

def process_claim_free_policies_df(no_claims_df: pd.DataFrame) -> pd.DataFrame:
    df = no_claims_df.copy()

    # --- identify rows that are "empty" other than AccountName / file_path ---
    protected_cols = {"AccountName", "file_path"}
    candidate_cols = [c for c in df.columns if c not in protected_cols]

    if candidate_cols:
        empty_mask = df[candidate_cols].isna().all(axis=1)
    else:
        empty_mask = pd.Series(True, index=df.index)

    before_count = len(df)
    df = df[~empty_mask].copy()
    dropped = before_count - len(df)
    _print_if_changes(dropped, f"            Dropped {dropped} rows with all NaN except AccountName/file_path")

    # If empty, return an empty DataFrame with expected columns
    expected_cols = ['AccountName'] + list(NO_CLAIMS_VALID_JSON_FIELDS) + ['file_path']
    if df.empty:
        return pd.DataFrame(columns=expected_cols)

    # --- Drop rows where policy_effective_year is NaN ---
    if "policy_effective_year" in df.columns:
        before_count = len(df)
        df = df.dropna(subset=["policy_effective_year"], how="any")
        dropped = before_count - len(df)
        _print_if_changes(dropped, f"            Dropped {dropped} rows with missing policy_effective_year")

    # --- Drop duplicates ---
    before_count = len(df)
    df = df.drop_duplicates()
    dropped = before_count - len(df)
    _print_if_changes(dropped, f"            Dropped {dropped} duplicate rows (using all columns)")

    # --- line_of_business normalization ---
    if "line_of_business" in df.columns:
        before = df["line_of_business"].copy()
        df["line_of_business"] = _clean_lob(df["line_of_business"]).astype("string")
        changed = _count_changes(before, df["line_of_business"])
        _print_if_changes(changed, f"            LOB cleaning: changed {changed} rows in 'line_of_business'")

    if df.empty:
        return pd.DataFrame(columns=expected_cols)

    # --- Dates: "MM/DD/YYYY" as string ---
    date_cols = ["evaluation_date"]
    for col in date_cols:
        if col in df.columns:
            before = df[col].copy()
            df[col] = _clean_date_str(df[col]).astype("string")
            changed = _count_changes(before, df[col])
            _print_if_changes(changed, f"            Date cleaning: changed {changed} rows in '{col}'")

    # --- prior_carrier as string ---
    if "prior_carrier" in df.columns:
        before = df["prior_carrier"].copy()
        df["prior_carrier"] = to_str_strip(df["prior_carrier"])
        changed = _count_changes(before, df["prior_carrier"])
        _print_if_changes(changed, f"            Prior carrier cleaning: changed {changed} rows in 'prior_carrier'")

    # --- policy_effective_year as string with .0 removed ---
    if "policy_effective_year" in df.columns:
        before = df["policy_effective_year"].copy()
        df["policy_effective_year"] = _clean_id_str(df["policy_effective_year"])
        changed = _count_changes(before, df["policy_effective_year"])
        _print_if_changes(changed, f"            ID cleaning: changed {changed} rows in 'policy_effective_year'")

    # --- Final column order ---
    final_order = ['AccountName'] + [col for col in NO_CLAIMS_VALID_JSON_FIELDS if col in df.columns] + ['file_path']
    final_order = [col for col in final_order if col in df.columns]
    df = df[final_order].sort_index()

    print("            ✔️ Complete")
    return df
