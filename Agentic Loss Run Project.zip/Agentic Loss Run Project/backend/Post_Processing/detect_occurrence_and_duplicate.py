import os
import re
from collections import Counter
from difflib import SequenceMatcher

import numpy as np
import pandas as pd


FINANCIAL_COLS = [
    "total_incurred",
    "total_paid",
    "incurred_alae",
    "paid_alae",
    "total_recoveries",
]

REQUIRED_COLS = [
    "claim_id",
    "claimant",
    "policy_number",
    "policy_effective_date",
    "policy_expiration_date",
    "line_of_business",
    "subline",
    "accident_date",
    "report_date",
    "accident_state",
    "driver",
    "garage_state",
    "coverage_state",
    "claim_description",
    "total_incurred",
    "total_paid",
    "incurred_alae",
    "paid_alae",
    "total_recoveries",
    "status",
    "prior_carrier",
    "evaluation_date",
    "page_num_or_sheet_name",
    "file_path",
]

LOB_CANON = {
    "auto": "auto",
    "general liability": "general liability",
    "workers compensation": "workers compensation",
    "property": "property",
    "unknown": "unknown",
}

VALID_LOBS = set(LOB_CANON.values())


class UnionFind:
    def __init__(self, n: int):
        self.parent = list(range(n))
        self.rank = [0] * n

    def find(self, x: int) -> int:
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a: int, b: int) -> int:
        """
        Union a and b. Returns the new root.
        """
        ra = self.find(a)
        rb = self.find(b)
        if ra == rb:
            return ra

        if self.rank[ra] < self.rank[rb]:
            self.parent[ra] = rb
            return rb
        elif self.rank[ra] > self.rank[rb]:
            self.parent[rb] = ra
            return ra
        else:
            self.parent[rb] = ra
            self.rank[ra] += 1
            return ra


def normalize_text(value):
    """
    With your guarantees, keep this lightweight and deterministic.
    Use only when you truly expect free-text (claimant/driver/description).
    """
    if pd.isna(value):
        return pd.NA
    s = str(value).strip()
    if not s:
        return pd.NA
    s = s.lower()
    s = s.replace("&", " and ")
    s = re.sub(r"\s+", " ", s).strip()
    return s


def normalize_lob(value):
    if pd.isna(value):
        return pd.NA
    s = str(value).strip().lower()
    if not s:
        return pd.NA
    s = re.sub(r"\s+", " ", s)
    canon = LOB_CANON.get(s, s)
    return canon if canon in VALID_LOBS else "unknown"


def normalize_state(value):
    """
    States are always 2-letter uppercase codes per your note.
    Validate and return; otherwise NA.
    """
    if pd.isna(value):
        return pd.NA
    s = str(value).strip().upper()
    if len(s) == 2 and s.isalpha():
        return s
    return pd.NA


def normalize_money(value):
    """
    Financials are always numbers per your note.
    Coerce to float; invalid -> NaN.

    Accepts either a scalar or a pandas Series.
    """
    if isinstance(value, pd.Series):
        return pd.to_numeric(value, errors="coerce")

    if pd.isna(value):
        return np.nan
    return pd.to_numeric(value, errors="coerce")


def normalize_date_series(series: pd.Series) -> pd.Series:
    """
    Dates are always MM/DD/YYYY per your note.
    """
    return pd.to_datetime(series, format="%m/%d/%Y", errors="coerce").dt.normalize()


def date_key(ts):
    if pd.isna(ts):
        return pd.NA
    return ts.strftime("%Y-%m-%d")


def normalize_claim_id(value):
    """
    Normalize claim_id for matching:
      - strip, uppercase
      - remove internal whitespace
      - keep hyphens (useful for suffix parsing like ABC-001)
    """
    if pd.isna(value):
        return pd.NA
    s = str(value).strip().upper()
    if not s:
        return pd.NA
    s = re.sub(r"\s+", "", s)
    return s


def _split_claim_id_suffix(s: str):
    """
    Split claim id into (prefix, suffix_int) when it ends in a separator + digits.
    Supports: '-', '_', '/', '#'
    ABC-12 -> ("ABC", 12)
    0001_0002 -> ("0001", 2)
    Returns (None, None) if not in that pattern.
    """
    if s is None:
        return None, None
    m = re.fullmatch(r"^(.*?)([-_/#])(\d+)$", s)
    if not m:
        return None, None
    prefix = m.group(1) + m.group(2)  # keep separator as part of prefix
    suffix = int(m.group(3))
    return prefix, suffix


def claim_id_last_digit_off_by_one(a, b) -> bool:
    """
    True when:
      - both claim ids are non-null strings
      - they are identical except for the final character
      - final characters are digits and differ by exactly 1
    """
    if pd.isna(a) or pd.isna(b):
        return False

    sa = str(a).strip()
    sb = str(b).strip()
    if len(sa) < 2 or len(sb) < 2:
        return False
    if len(sa) != len(sb):
        return False
    if sa[:-1] != sb[:-1]:
        return False

    ca = sa[-1]
    cb = sb[-1]
    if not (ca.isdigit() and cb.isdigit()):
        return False

    return abs(int(ca) - int(cb)) == 1


def claim_id_suffix_off_by_one(a, b) -> bool:
    """
    True when both ids share the same prefix up to a separator, and the trailing numeric suffix differs by 1.
    Examples:
      ABC-12 vs ABC-13 -> True
      100-0001 vs 100-0002 -> True
      ABC-12 vs ABD-13 -> False
    """
    if pd.isna(a) or pd.isna(b):
        return False

    sa = str(a).strip()
    sb = str(b).strip()

    pa, na = _split_claim_id_suffix(sa)
    pb, nb = _split_claim_id_suffix(sb)
    if pa is None or pb is None:
        return False
    if pa != pb:
        return False
    return abs(int(na) - int(nb)) == 1


def _split_claim_id_suffix_with_width(s: str):
    """
    Split claim id into (prefix, suffix_int, suffix_width) when it ends in digits.

    Supports:
      - separator + digits: '-', '_', '/', '#'
        ABC-0001 -> ("ABC-", 1, 4)
      - NO separator (new):
        A2DK03001 -> ("A2DK03", 1, 3)
        A2DK0301 -> ("A2DK03", 1, 2)

    Returns (None, None, None) if not in that pattern.
    """
    if s is None:
        return None, None, None

    s = str(s).strip()
    if not s:
        return None, None, None

    # 1) With explicit separator
    m = re.fullmatch(r"^(.*?)([-_/#])(\d+)$", s)
    if m:
        prefix = m.group(1) + m.group(2)
        suffix_str = m.group(3)
        return prefix, int(suffix_str), len(suffix_str)

    # 2) No separator: trailing digits
    m2 = re.fullmatch(r"^(.*?)(\d+)$", s)
    if m2:
        prefix = m2.group(1)
        suffix_str = m2.group(2)
        return prefix, int(suffix_str), len(suffix_str)

    return None, None, None


def claim_id_compatible(a, b, *, min_width: int = 1) -> bool:
    """
    True when both ids share the same prefix and the trailing numeric suffix
    looks like a "sequence counter" and differs by <= max_gap.

    Now supports both:
      - separator suffixes (ABC-001)
      - no-separator suffixes (A2DK03001)

    Guardrails:
      - requires both suffix widths >= min_width
      - for NO-separator ids, requires a minimum prefix length to reduce false matches
    """
    if pd.isna(a) or pd.isna(b):
        return False

    sa = str(a).strip()
    sb = str(b).strip()

    pa, na, wa = _split_claim_id_suffix_with_width(sa)
    pb, nb, wb = _split_claim_id_suffix_with_width(sb)
    if pa is None or pb is None:
        return False
    if pa != pb:
        return False
    if wa < min_width or wb < min_width:
        return False

    # Extra guardrail for "no separator" style: require reasonably long prefix
    # (If the prefix already ends with a known separator, skip this check.)
    if not re.search(r"[-_/#]$", pa):
        if len(pa) < 5:
            return False

    return True  # same prefix is sufficient


def parse_location(value):
    """
    Returns:
      loc_type: 'page' | 'sheet' | 'unknown'
      page_num: int or None
      loc_token: normalized token
    """
    if pd.isna(value):
        return "unknown", None, pd.NA

    raw = str(value).strip()
    token = normalize_text(raw)

    if re.fullmatch(r"\d+(\.0+)?", raw):
        return "page", int(float(raw)), token

    m = re.fullmatch(r"page\s*(\d+)", raw.lower())
    if m:
        return "page", int(m.group(1)), token

    return "sheet", None, token


def non_null_equal(a, b) -> bool:
    return not pd.isna(a) and not pd.isna(b) and a == b


def text_similarity(a, b) -> float:
    if pd.isna(a) or pd.isna(b):
        return 0.0
    return SequenceMatcher(None, str(a), str(b)).ratio()


def _cheap_text_gate(a, b) -> bool:
    """
    Fast prefilter before SequenceMatcher.
    Returns True if it's worth computing expensive similarity.
    """
    if pd.isna(a) or pd.isna(b):
        return False
    sa = str(a)
    sb = str(b)
    if not sa or not sb:
        return False

    # length sanity: if wildly different, don't bother
    la, lb = len(sa), len(sb)
    if min(la, lb) / max(la, lb) < 0.6:
        return False

    # quick prefix check (after normalization you're already lowercase/space-normalized)
    # if the first 12 chars share almost nothing, likely not similar
    pa = sa[:12]
    pb = sb[:12]
    common = sum(1 for x, y in zip(pa, pb) if x == y)
    return common >= 3


def _text_similarity_gated(a, b) -> float:
    if not _cheap_text_gate(a, b):
        return 0.0
    return text_similarity(a, b)


def approx_equal(a, b, abs_tol=10.0, rel_tol=0.02) -> bool:
    if pd.isna(a) or pd.isna(b):
        return False
    diff = abs(float(a) - float(b))
    base = max(abs(float(a)), abs(float(b)), 1.0)
    return diff <= abs_tol or diff <= rel_tol * base


def same_local_context(row_a, row_b) -> bool:
    """
    Same-occurrence local rule:
      - same file_path always required
      - if both are pages -> within 3 pages
      - if both are sheets -> same sheet
      - otherwise fallback to exact location token match
    """
    if row_a["file_path_n"] != row_b["file_path_n"]:
        return False

    if row_a["loc_type"] == "page" and row_b["loc_type"] == "page":
        if row_a["page_num"] is None or row_b["page_num"] is None:
            return False
        return abs(row_a["page_num"] - row_b["page_num"]) <= 3

    if row_a["loc_type"] == "sheet" and row_b["loc_type"] == "sheet":
        return non_null_equal(row_a["loc_token"], row_b["loc_token"])

    return non_null_equal(row_a["loc_token"], row_b["loc_token"])


def local_support_count(row_a, row_b) -> int:
    support = 0
    # Strong-ish identity signals
    if non_null_equal(row_a["claimant_n"], row_b["claimant_n"]):
        support += 1
    if non_null_equal(row_a["policy_number_n"], row_b["policy_number_n"]):
        support += 1

    # Weaker/secondary signals
    if non_null_equal(row_a["report_date_key"], row_b["report_date_key"]):
        support += 1

    # Gated expensive call
    if _text_similarity_gated(row_a["claim_description_n"], row_b["claim_description_n"]) >= 0.88:
        support += 1

    if claim_id_last_digit_off_by_one(row_a["claim_id_n"], row_b["claim_id_n"]):
        support += 1

    return support


def row_specificity_score(row) -> int:
    fields = ["claimant_n", "driver_n", "coverage_state_n", "subline_n", "claim_id_n"]
    return sum(0 if pd.isna(row[f]) else 1 for f in fields)


def aggregate_matches(df, summary_idx, other_idxs) -> bool:
    """
    Aggregate (total) row check:

    - Ignores $0 financials (in both summary and detail) to avoid false matches driven by zeros.
    - Does not require "summary is less specific" since totals can be fully-populated in some loss runs.
    - Summary matches when it equals the sum of nearby rows across enough comparable non-zero columns.
    """
    if len(other_idxs) < 2:
        return False

    summary_row = df.loc[summary_idx]
    other_rows = df.loc[other_idxs]

    compared = 0
    matched = 0

    for col in FINANCIAL_COLS:
        s_val = summary_row.get(f"{col}_n", np.nan)

        # Skip if summary missing or summary is exactly 0 (don't use zeros as evidence of "total")
        if pd.isna(s_val) or float(s_val) == 0.0:
            continue

        detail_vals = other_rows.get(f"{col}_n").dropna()

        # Ignore 0s in detail as well
        detail_vals = detail_vals[detail_vals.astype(float) != 0.0]

        # If no non-zero detail values exist, can't compare this column
        if detail_vals.empty:
            continue

        others_sum = float(detail_vals.sum())

        compared += 1
        if approx_equal(s_val, others_sum):
            matched += 1

    # If we couldn't compare any non-zero financial columns, do not call it an aggregate row
    if compared == 0:
        return False

    # Require at least 2 matching columns when possible; if only 1 column was comparable, require that 1 to match
    if compared == 1:
        return matched == 1

    return matched >= 2


def safe_mode(values):
    vals = [v for v in values if not pd.isna(v)]
    if not vals:
        return pd.NA
    return Counter(vals).most_common(1)[0][0]


def safe_set(values):
    vals = [v for v in values if not pd.isna(v)]
    return set(vals)


def safe_sum(series):
    s = series.dropna()
    if s.empty:
        return np.nan
    return float(s.sum())


def page_range_gap(a_start, a_end, b_start, b_end):
    if any(v is None or pd.isna(v) for v in [a_start, a_end, b_start, b_end]):
        return None
    if a_end < b_start:
        return b_start - a_end
    if b_end < a_start:
        return a_start - b_end
    return 0


def eligible_duplicate_context(occ_a, occ_b) -> bool:
    """
    Duplicates are only eligible if:
    1) different files
    2) or different sheets in same file
    3) or page ranges > 3 apart in same file
    """
    if occ_a["file_path_n"] != occ_b["file_path_n"]:
        return True

    if occ_a["sheet_name"] is not pd.NA and occ_b["sheet_name"] is not pd.NA:
        if not pd.isna(occ_a["sheet_name"]) and not pd.isna(occ_b["sheet_name"]):
            return occ_a["sheet_name"] != occ_b["sheet_name"]

    gap = page_range_gap(
        occ_a["page_start"], occ_a["page_end"],
        occ_b["page_start"], occ_b["page_end"]
    )
    if gap is not None:
        return gap > 3

    return False


def eligible_state_match_or_unknown(occ_a, occ_b) -> bool:
    """
    State should not block duplicates when missing.
    Only block when BOTH states are present and different.
    """
    a = occ_a.get("accident_state_n", pd.NA)
    b = occ_b.get("accident_state_n", pd.NA)

    if pd.isna(a) or pd.isna(b):
        return True
    return a == b


def financials_close_occ(occ_a, occ_b) -> bool:
    compared = 0
    matched = 0

    for col in FINANCIAL_COLS:
        a = occ_a.get(col)
        b = occ_b.get(col)
        if pd.isna(a) or pd.isna(b):
            continue
        compared += 1
        if approx_equal(a, b):
            matched += 1

    if compared == 0:
        return False

    return matched >= min(2, compared)


def duplicate_support_count(occ_a, occ_b) -> int:
    support = 0

    # gated expensive call
    if _text_similarity_gated(occ_a["claim_description_n"], occ_b["claim_description_n"]) >= 0.88:
        support += 1

    if financials_close_occ(occ_a, occ_b):
        support += 1

    # FIX: avoid pd.NA in boolean context by requiring both non-missing
    if non_null_equal(occ_a.get("report_date_key", pd.NA), occ_b.get("report_date_key", pd.NA)):
        support += 1

    return support


def claim_id_sets_compatible(set_a, set_b) -> bool:
    """
    True if there exists at least one compatible claim id between two sets.
    Compatibility = exact match OR last-digit-off-by-one OR suffix-off-by-one.
    """
    if not set_a or not set_b:
        return False

    if set_a & set_b:
        return True

    for a in set_a:
        if pd.isna(a):
            continue
        for b in set_b:
            if pd.isna(b):
                continue
            if claim_id_compatible(a, b):
                return True

    return False


def eligible_claim_id_match_or_unknown(occ_a, occ_b) -> bool:
    """
    Claim ID should not block duplicates when missing.
    Only block when BOTH have claim ids present and they're incompatible.

    Compatibility here = any overlap OR last-digit-off-by-one across ids.
    """
    set_a = occ_a.get("claim_ids_set", set()) or set()
    set_b = occ_b.get("claim_ids_set", set()) or set()

    # If either side lacks claim ids, don't penalize (refer to support signals)
    if not set_a or not set_b:
        return True

    return claim_id_sets_compatible(set_a, set_b)


def build_occurrence_records(df, is_aggregate_row):
    records = []

    for occ_num, g in df.groupby("occurrence_number", dropna=False):
        idxs = list(g.index)
        agg_idxs = [i for i in idxs if bool(is_aggregate_row.loc[i])]

        # canonical source context
        file_path_n = safe_mode(g["file_path_n"].tolist())

        sheet_names = [x for x in g.loc[g["loc_type"] == "sheet", "loc_token"].tolist() if not pd.isna(x)]
        sheet_name = safe_mode(sheet_names) if sheet_names else pd.NA

        page_nums = [x for x in g["page_num"].tolist() if x is not None and not pd.isna(x)]
        page_start = min(page_nums) if page_nums else None
        page_end = max(page_nums) if page_nums else None

        # canonical values
        line_of_business_n = safe_mode(g["line_of_business_n"].tolist())
        accident_date_key = safe_mode(g["accident_date_key"].tolist())
        accident_state_n = safe_mode(g["accident_state_n"].tolist())
        policy_number_n = safe_mode(g["policy_number_n"].tolist())
        report_date_key = safe_mode(g["report_date_key"].tolist())
        claim_description_n = safe_mode(g["claim_description_n"].tolist())

        # NEW: account (optional; only if present)
        account_value = safe_mode(g["AccountName"].tolist()) if "AccountName" in g.columns else pd.NA

        claim_ids_set = safe_set(g["claim_id_n"].tolist())
        claimants_set = safe_set(g["claimant_n"].tolist())

        # financials:
        # if an aggregate row exists, prefer it to avoid double counting
        fin_values = {}
        if agg_idxs:
            best_agg_idx = max(
                agg_idxs,
                key=lambda i: df.loc[i, [f"{c}_n" for c in FINANCIAL_COLS]].notna().sum()
            )
            for col in FINANCIAL_COLS:
                val = df.loc[best_agg_idx, f"{col}_n"]
                if pd.isna(val):
                    detail_sum = safe_sum(g.loc[~g.index.isin(agg_idxs), f"{col}_n"])
                    fin_values[col] = detail_sum
                else:
                    fin_values[col] = val
        else:
            for col in FINANCIAL_COLS:
                if len(g) == 1:
                    fin_values[col] = g[f"{col}_n"].iloc[0]
                else:
                    fin_values[col] = safe_sum(g[f"{col}_n"])

        records.append({
            "occurrence_number": occ_num,
            "account_value": account_value,  # NEW
            "file_path_n": file_path_n,
            "sheet_name": sheet_name,
            "page_start": page_start,
            "page_end": page_end,
            "line_of_business_n": line_of_business_n,
            "accident_date_key": accident_date_key,
            "accident_state_n": accident_state_n,
            "policy_number_n": policy_number_n,
            "report_date_key": report_date_key,
            "claim_description_n": claim_description_n,
            "claim_ids_set": claim_ids_set,
            "claimants_set": claimants_set,
            **fin_values,
        })

    return pd.DataFrame(records)


def eligible_state_match_strict(occ_a, occ_b) -> bool:
    """
    STRICT per your updated rule:
      - if either missing -> NOT a duplicate
      - must be equal
    """
    a = occ_a.get("accident_state_n", pd.NA)
    b = occ_b.get("accident_state_n", pd.NA)
    if pd.isna(a) or pd.isna(b):
        return False
    return a == b


def duplicate_support_count_strict(occ_a, occ_b) -> int:
    """
    Post-gate confirmation signals. Keep conservative.
    """
    support = 0

    if occ_a["claimants_set"] & occ_b["claimants_set"]:
        support += 1

    if financials_close_occ(occ_a, occ_b):
        support += 1

    if _text_similarity_gated(occ_a["claim_description_n"], occ_b["claim_description_n"]) >= 0.92:
        support += 1

    return support


def state_compatible_or_unknown(a, b) -> bool:
    """
    Occurrence rule per your clarification:
      - OK if either state is missing
      - If BOTH present and different => NOT compatible
    """
    if pd.isna(a) or pd.isna(b):
        return True
    return a == b


def parse_file_path(value):
    """
    Split a file_path into:
      - file_base: the physical file path (before '::')
      - file_subpath: the logical sub-location (after '::'), e.g. Excel sheet name

    Example:
      "C:\\a\\b\\losses.xlsx::Claims" -> ("C:\\a\\b\\losses.xlsx", "Claims")
      "C:\\a\\b\\losses.pdf"         -> ("C:\\a\\b\\losses.pdf", NA)

    Returns raw (not normalized) strings; caller should normalize.
    """
    if pd.isna(value):
        return pd.NA, pd.NA

    s = str(value).strip()
    if not s:
        return pd.NA, pd.NA

    # split on the FIRST '::' only; sheet names could theoretically contain '::'
    if "::" in s:
        base, sub = s.split("::", 1)
        base = base.strip()
        sub = sub.strip()
        return (base if base else pd.NA), (sub if sub else pd.NA)

    return s, pd.NA


def process_claims_deduplication(df: pd.DataFrame) -> pd.DataFrame:
    """
    Simple v1 occurrence + duplicate detection.

    Output:
      original dataframe + occurrence_number + duplicate_number
    """
    df = df.copy().reset_index(drop=True)

    # Ensure all expected columns exist
    for col in REQUIRED_COLS:
        if col not in df.columns:
            df[col] = pd.NA

    original_columns = list(df.columns)

    # ---------------------------
    # 1) Normalize
    # ---------------------------
    # Only normalize true free-text fields with normalize_text.
    free_text_cols = [
        "claim_id",
        "claimant",
        "policy_number",
        "subline",
        "driver",
        "garage_state",
        "claim_description",
        "status",
        "prior_carrier",
        "page_num_or_sheet_name",
        "file_path",
    ]
    for col in free_text_cols:
        df[f"{col}_n"] = df[col].apply(normalize_text)

    # NEW: parse 'file_path' for '::' (e.g., Excel sheet suffix)
    base_and_sub = df["file_path"].apply(parse_file_path)
    df["file_path_n"] = base_and_sub.apply(lambda x: x[0])

    df["claim_id_n"] = df["claim_id"].apply(normalize_claim_id)

    # Structured fields:
    df["line_of_business_n"] = df["line_of_business"].apply(normalize_lob)

    # states already 2-letter codes
    df["accident_state_n"] = df["accident_state"].apply(normalize_state)
    df["coverage_state_n"] = df["coverage_state"].apply(normalize_state)
    df["garage_state_n"] = df["garage_state"].apply(normalize_state)

    date_cols = [
        "policy_effective_date",
        "policy_expiration_date",
        "accident_date",
        "report_date",
        "evaluation_date",
    ]
    for col in date_cols:
        df[f"{col}_n"] = normalize_date_series(df[col])
        df[f"{col}_key"] = df[f"{col}_n"].apply(date_key)

    for col in FINANCIAL_COLS:
        df[f"{col}_n"] = normalize_money(df[col])

    # location parse stays the same
    loc_parsed = df["page_num_or_sheet_name"].apply(parse_location)
    df["loc_type"] = loc_parsed.apply(lambda x: x[0])
    df["page_num"] = loc_parsed.apply(lambda x: x[1])
    df["loc_token"] = loc_parsed.apply(lambda x: x[2])

    # ---------------------------
    # 2) Occurrence detection
    # ---------------------------
    uf_rows = UnionFind(len(df))
    is_aggregate_row = pd.Series(False, index=df.index)

    # Speed: pull columns used in tight loops into arrays once
    file_path_n_arr = df["file_path_n"].to_numpy()
    lob_arr = df["line_of_business_n"].to_numpy()
    acc_date_key_arr = df["accident_date_key"].to_numpy()
    acc_state_arr = df["accident_state_n"].to_numpy()
    loc_type_arr = df["loc_type"].to_numpy()
    page_num_arr = df["page_num"].to_numpy()
    loc_token_arr = df["loc_token"].to_numpy()
    claim_id_arr = df["claim_id_n"].to_numpy()
    claimant_arr = df["claimant_n"].to_numpy()
    policy_arr = df["policy_number_n"].to_numpy()
    report_key_arr = df["report_date_key"].to_numpy()
    desc_arr = df["claim_description_n"].to_numpy()

    def _same_local_context_fast(a_idx: int, b_idx: int) -> bool:
        if file_path_n_arr[a_idx] != file_path_n_arr[b_idx]:
            return False

        a_lt = loc_type_arr[a_idx]
        b_lt = loc_type_arr[b_idx]

        if a_lt == "page" and b_lt == "page":
            a_p = page_num_arr[a_idx]
            b_p = page_num_arr[b_idx]
            if a_p is None or b_p is None or pd.isna(a_p) or pd.isna(b_p):
                return False
            return abs(int(a_p) - int(b_p)) <= 3

        if a_lt == "sheet" and b_lt == "sheet":
            return non_null_equal(loc_token_arr[a_idx], loc_token_arr[b_idx])

        return non_null_equal(loc_token_arr[a_idx], loc_token_arr[b_idx])

    # Cluster "anchored by claim_id" flag only (claimant anchoring removed)
    root_has_claim_id = df["claim_id_n"].notna().to_numpy(copy=True)

    def union_rows(a: int, b: int) -> None:
        """
        Union and merge cluster flags without scanning members.
        """
        ra = uf_rows.find(a)
        rb = uf_rows.find(b)
        if ra == rb:
            return

        has_id = root_has_claim_id[ra] or root_has_claim_id[rb]
        new_root = uf_rows.union(ra, rb)
        root_has_claim_id[new_root] = has_id

    def cluster_has_claim_id(idx: int) -> bool:
        return bool(root_has_claim_id[uf_rows.find(idx)])

    def allowed_to_union_under_claim_id_purity_fast(a_idx: int, b_idx: int) -> bool:
        a_id = claim_id_arr[a_idx]
        b_id = claim_id_arr[b_idx]

        a_anchored = cluster_has_claim_id(a_idx) or (not pd.isna(a_id))
        b_anchored = cluster_has_claim_id(b_idx) or (not pd.isna(b_id))

        # If neither side is claim-id-anchored, allow other signals to drive unions
        if not (a_anchored or b_anchored):
            return True

        # If either is missing an id, don't block (let other signals decide)
        if pd.isna(a_id) or pd.isna(b_id):
            return True

        # If both present, require they be compatible under the same notion used in 02 "strong"
        return (
            (a_id == b_id)
            or claim_id_compatible(a_id, b_id)
            or claim_id_last_digit_off_by_one(a_id, b_id)
            or claim_id_suffix_off_by_one(a_id, b_id)
        )

    # 01 (HARD): same file + same claim_id => union
    mask_claim = df["file_path_n"].notna() & df["claim_id_n"].notna()
    if mask_claim.any():
        grouped = df[mask_claim].groupby(["file_path_n", "claim_id_n"], dropna=False).groups
        for _, idxs in grouped.items():
            idxs = list(idxs)
            if len(idxs) >= 2:
                base = idxs[0]
                for other in idxs[1:]:
                    if not state_compatible_or_unknown(acc_state_arr[base], acc_state_arr[other]):
                        continue
                    # NEW: require local context so claims far apart in the same PDF don't merge
                    if not _same_local_context_fast(base, other):
                        continue
                    union_rows(base, other)

    mask_claim_lob_missing_date = (
        df["file_path_n"].notna() &
        df["line_of_business_n"].notna() &
        df["claim_id_n"].notna() &
        df["accident_date_key"].isna()
    )
    if mask_claim_lob_missing_date.any():
        grouped_missing_date = df[mask_claim_lob_missing_date].groupby(
            ["file_path_n", "line_of_business_n", "claim_id_n"],
            dropna=False
        ).groups

        for _, idxs in grouped_missing_date.items():
            idxs = list(idxs)
            if len(idxs) < 2:
                continue

            base = idxs[0]
            for other in idxs[1:]:
                if not state_compatible_or_unknown(acc_state_arr[base], acc_state_arr[other]):
                    continue
                if not _same_local_context_fast(base, other):
                    continue
                union_rows(base, other)

    # 02 (REVISED)
    mask = (
        df["file_path_n"].notna() &
        df["line_of_business_n"].notna() &
        df["accident_date_key"].notna()
    )
    if mask.any():
        grouped = df[mask].groupby(
            ["file_path_n", "line_of_business_n", "accident_date_key"],
            dropna=False
        ).groups

        for grp_key, idxs in grouped.items():
            idxs = list(idxs)
            for ii in range(len(idxs)):
                a = idxs[ii]
                for jj in range(ii + 1, len(idxs)):
                    b = idxs[jj]

                    state_ok = state_compatible_or_unknown(acc_state_arr[a], acc_state_arr[b])
                    local_ok = _same_local_context_fast(a, b)

                    a_claim = claim_id_arr[a]
                    b_claim = claim_id_arr[b]

                    purity_ok = allowed_to_union_under_claim_id_purity_fast(a, b)

                    # compute desc_sim only if we need it
                    desc_sim = _text_similarity_gated(desc_arr[a], desc_arr[b])

                    strong = (
                        non_null_equal(a_claim, b_claim) or
                        claim_id_last_digit_off_by_one(a_claim, b_claim) or
                        (desc_sim >= 0.92)
                    )

                    support = 0
                    if non_null_equal(policy_arr[a], policy_arr[b]):
                        support += 1
                    if non_null_equal(report_key_arr[a], report_key_arr[b]):
                        support += 1

                    if not state_ok:
                        continue
                    if not local_ok:
                        continue
                    if not purity_ok:
                        continue
                    if not strong:
                        continue

                    if support >= 1:
                        union_rows(a, b)

    # -------------------------------------------------------------
    # 02b (AUTO cross-file SAME OCCURRENCE - STRICT)
    # -------------------------------------------------------------
    # Updated per clarification:
    #   - accident_state may be missing on either side (OK)
    #   - but if BOTH present and different => immediate no
    # Still requires:
    #   - line_of_business == 'auto'
    #   - accident_date present
    #   - claim_id present on BOTH and compatible
    # -------------------------------------------------------------
    mask_auto_strict = (
        (df["line_of_business_n"] == "auto") &
        df["accident_date_key"].notna() &
        df["claim_id_n"].notna()
    )
    if mask_auto_strict.any():
        grouped_auto_strict = df[mask_auto_strict].groupby(
            ["line_of_business_n", "accident_date_key"],
            dropna=False
        ).groups

        for _, idxs in grouped_auto_strict.items():
            idxs = list(idxs)

            # exact-match unions first (fast path)
            sub = df.loc[idxs, ["claim_id_n"]]
            by_claim = sub.groupby("claim_id_n", dropna=False).groups
            for _, same_id_idxs in by_claim.items():
                same_id_idxs = list(same_id_idxs)
                if len(same_id_idxs) >= 2:
                    base = same_id_idxs[0]
                    for other in same_id_idxs[1:]:
                        # NEW: only union if states aren't conflicting
                        if not state_compatible_or_unknown(acc_state_arr[base], acc_state_arr[other]):
                            continue
                        union_rows(base, other)

            # off-by-one unions (bounded bucket)
            for ii in range(len(idxs)):
                a = idxs[ii]
                for jj in range(ii + 1, len(idxs)):
                    b = idxs[jj]

                    # only cross-file unions matter here; same-file already handled
                    if file_path_n_arr[a] == file_path_n_arr[b]:
                        continue

                    # NEW: state hard-no only when both present and different
                    if not state_compatible_or_unknown(acc_state_arr[a], acc_state_arr[b]):
                        continue

                    a_claim = claim_id_arr[a]
                    b_claim = claim_id_arr[b]
                    if claim_id_compatible(a_claim, b_claim):
                        union_rows(a, b)

    if mask.any():
        grouped = df[mask].groupby(
            ["file_path_n", "line_of_business_n", "accident_date_key"],
            dropna=False
        ).groups

        for _, idxs in grouped.items():
            idxs = list(idxs)
            for summary_idx in idxs:
                local_others = [
                    oi for oi in idxs
                    if oi != summary_idx and _same_local_context_fast(summary_idx, oi)
                ]

                summary_claim_id = claim_id_arr[summary_idx]
                if cluster_has_claim_id(summary_idx) or (not pd.isna(summary_claim_id)):
                    local_others = [
                        oi for oi in local_others
                        if claim_id_compatible(summary_claim_id, claim_id_arr[oi])
                    ]

                if aggregate_matches(df, summary_idx, local_others):
                    is_aggregate_row.loc[summary_idx] = True
                    for oi in local_others:
                        union_rows(summary_idx, oi)

    # Assign occurrence numbers
    occ_root_to_num = {}
    occurrence_numbers = []
    next_occ_num = 1

    for i in range(len(df)):
        root = uf_rows.find(i)
        if root not in occ_root_to_num:
            occ_root_to_num[root] = next_occ_num
            next_occ_num += 1
        occurrence_numbers.append(occ_root_to_num[root])

    df["occurrence_number"] = pd.Series(occurrence_numbers, dtype="Int64")

    # ---------------------------------------------
    # 3) Collapse to occurrence-level records
    # ---------------------------------------------
    occ_df = build_occurrence_records(df, is_aggregate_row).reset_index(drop=True)

    # ---------------------------------------------
    # 4) Duplicate detection across occurrences
    # ---------------------------------------------
    uf_occ = UnionFind(len(occ_df))

    mask_occ = (
        occ_df["line_of_business_n"].notna() &
        occ_df["accident_date_key"].notna()
    )

    if mask_occ.any():
        grouped = occ_df[mask_occ].groupby(
            ["line_of_business_n", "accident_date_key"],
            dropna=False
        ).groups

        for _, idxs in grouped.items():
            idxs = list(idxs)
            for i in range(len(idxs)):
                for j in range(i + 1, len(idxs)):
                    a = idxs[i]
                    b = idxs[j]

                    occ_a = occ_df.loc[a]
                    occ_b = occ_df.loc[b]

                    # Must be separated enough to be plausible duplicates
                    if not eligible_duplicate_context(occ_a, occ_b):
                        continue

                    # Account: block only when BOTH present and different (don't penalize missing)
                    if "account_value" in occ_df.columns:
                        if (not pd.isna(occ_a["account_value"])) and (not pd.isna(occ_b["account_value"])):
                            if occ_a["account_value"] != occ_b["account_value"]:
                                continue

                    # State mismatch blocks only when both present
                    if not eligible_state_match_or_unknown(occ_a, occ_b):
                        continue

                    # D0 (HARD CAP):
                    # If both have at least one claim id and any exact overlap, and the context says they are
                    # far enough apart (or different sheet / different file) to be plausible duplicates, union.
                    if (
                        occ_a["claim_ids_set"] and occ_b["claim_ids_set"] and
                        (occ_a["claim_ids_set"] & occ_b["claim_ids_set"]) and
                        eligible_duplicate_context(occ_a, occ_b)
                    ):
                        uf_occ.union(a, b)
                        continue

                    # Otherwise require support
                    if duplicate_support_count(occ_a, occ_b) >= 2:
                        uf_occ.union(a, b)

    # -------------------------------------------------------------
    # 4a) Duplicate detection pass #2 (optimized):
    # Exact claim-id duplicates across occurrences within an account,
    # even when accident_date is missing.
    #
    # Rule:
    #   - same LOB
    #   - same EXACT claim id
    #   - state compatible (only block when BOTH present and different)
    #   - ONLY if outside local context (eligible_duplicate_context == True)
    # -------------------------------------------------------------

    def _occ_claim_id_key(claim_ids_set):
        if not claim_ids_set:
            return pd.NA
        vals = [v for v in claim_ids_set if not pd.isna(v)]
        if len(vals) != 1:
            return pd.NA
        return vals[0]

    def _occ_local_context_key(occ_row) -> str:
        """
        Key representing the 'local context' used by eligible_duplicate_context.
        Occurrences with the same key are NOT eligible duplicates with each other.
        """
        fp = occ_row.get("file_path_n", pd.NA)
        sh = occ_row.get("sheet_name", pd.NA)
        ps = occ_row.get("page_start", None)
        pe = occ_row.get("page_end", None)

        fp_s = "" if pd.isna(fp) else str(fp)

        # If we have a sheet name, local context = file + sheet
        if not pd.isna(sh):
            return f"F={fp_s}|S={str(sh)}"

        # Otherwise, approximate local context using page ranges.
        # If pages unknown, treat as one context within the file.
        if ps is None or pe is None or pd.isna(ps) or pd.isna(pe):
            return f"F={fp_s}|P=NA"

        # Bucket pages in windows of 4 so that ranges within <=3 pages land together.
        # (eligible_duplicate_context requires a gap > 3 to be eligible)
        start_bucket = int(ps) // 4
        end_bucket = int(pe) // 4
        return f"F={fp_s}|P={start_bucket}-{end_bucket}"

    occ_df["_claim_id_key_exact"] = occ_df["claim_ids_set"].apply(_occ_claim_id_key)

    mask_claimid_dup = (
        occ_df["line_of_business_n"].notna() &
        occ_df["_claim_id_key_exact"].notna()
    )

    if mask_claimid_dup.any():
        # Precompute local context keys once (vectorized apply over slice is fine here)
        occ_df.loc[mask_claimid_dup, "_local_ctx_key"] = occ_df.loc[mask_claimid_dup].apply(
            _occ_local_context_key, axis=1
        )

        grouped2 = occ_df[mask_claimid_dup].groupby(
            ["line_of_business_n", "_claim_id_key_exact"],
            dropna=False
        ).groups

        for _, idxs in grouped2.items():
            idxs = list(idxs)
            if len(idxs) < 2:
                continue

            g = occ_df.loc[idxs, ["accident_state_n", "_local_ctx_key"]].copy()

            # Partition by state: known states separate; unknown can match any known/unknown
            unknown_idxs = g.index[g["accident_state_n"].isna()].tolist()

            for state_val, state_group in g[g["accident_state_n"].notna()].groupby("accident_state_n"):
                candidate_idxs = list(state_group.index) + unknown_idxs
                if len(candidate_idxs) < 2:
                    continue

                # group by local context; only need to union across DIFFERENT contexts
                by_ctx = occ_df.loc[candidate_idxs].groupby("_local_ctx_key", dropna=False).groups
                ctx_groups = [list(v) for v in by_ctx.values()]
                if len(ctx_groups) < 2:
                    continue  # only one context => not eligible

                # Pick one representative per context
                reps = [grp[0] for grp in ctx_groups]

                # Star-union: union rep[0] with other reps when eligible_duplicate_context says yes.
                pivot = reps[0]
                occ_pivot = occ_df.loc[pivot]
                for other in reps[1:]:
                    occ_other = occ_df.loc[other]
                    if not eligible_duplicate_context(occ_pivot, occ_other):
                        continue

                    # state compatibility is guaranteed within this bucket+unknown construction, but keep defensive:
                    if not eligible_state_match_or_unknown(occ_pivot, occ_other):
                        continue

                    # NEW: accident_date check (block only when BOTH present and different)
                    a_date = occ_pivot.get("accident_date_key", pd.NA)
                    b_date = occ_other.get("accident_date_key", pd.NA)
                    if (not pd.isna(a_date)) and (not pd.isna(b_date)) and (a_date != b_date):
                        continue
                    uf_occ.union(pivot, other)

                # Ensure all occurrences in each context attach to their rep (cheap, no pairwise)
                for grp in ctx_groups:
                    rep = grp[0]
                    for member in grp[1:]:
                        uf_occ.union(rep, member)

            # Also handle the "all unknown state" case (no known states)
            if g["accident_state_n"].notna().sum() == 0:
                by_ctx = occ_df.loc[idxs].groupby("_local_ctx_key", dropna=False).groups
                ctx_groups = [list(v) for v in by_ctx.values()]
                if len(ctx_groups) >= 2:
                    reps = [grp[0] for grp in ctx_groups]
                    pivot = reps[0]
                    occ_pivot = occ_df.loc[pivot]
                    for other in reps[1:]:
                        occ_other = occ_df.loc[other]
                        if eligible_duplicate_context(occ_pivot, occ_other):
                            uf_occ.union(pivot, other)
                    for grp in ctx_groups:
                        rep = grp[0]
                        for member in grp[1:]:
                            uf_occ.union(rep, member)

    # optional cleanup: don't leak helper columns
    occ_df = occ_df.drop(columns=["_claim_id_key_exact", "_local_ctx_key"], errors="ignore")

    # Assign duplicate numbers only to duplicate clusters of size >= 2
    root_members = {}
    for i in range(len(occ_df)):
        root = uf_occ.find(i)
        root_members.setdefault(root, []).append(i)

    root_to_dup_num = {}
    next_dup_num = 1
    for root, members in root_members.items():
        if len(members) >= 2:
            root_to_dup_num[root] = next_dup_num
            next_dup_num += 1

    occ_df["duplicate_number"] = pd.Series(
        [
            root_to_dup_num.get(uf_occ.find(i), pd.NA)
            for i in range(len(occ_df))
        ],
        dtype="Int64"
    )

    # Map duplicate numbers back to rows
    occ_to_dup = dict(zip(occ_df["occurrence_number"], occ_df["duplicate_number"]))
    df["duplicate_number"] = df["occurrence_number"].map(occ_to_dup).astype("Int64")

    # ---------------------------------------------
    # 4b) Compute remove flag
    # ---------------------------------------------
    # Rule A: aggregate-within-occurrence removal DISABLED (too many false positives).
    remove_aggregate_within_occurrence = pd.Series(False, index=df.index)

    # Rule B: if duplicated occurrences exist, keep ONE occurrence per duplicate_number:
    #   - keep latest evaluation_date (row-level; reduce to occurrence-level via max date)
    #   - NEW: prefer occurrence that has an accident_date (any row in the occurrence)
    #   - tie-break: higher occurrence-level total_incurred (from occ_df)
    #   - tie-break: more columns filled in (occurrence-level)
    #   - tie-break: longer claim description (occurrence-level)
    #   - tie-break: first row
    eval_by_occ = (
        df.groupby("occurrence_number", dropna=False)["evaluation_date_n"]
        .max()
        .rename("eval_max")
        .reset_index()
    )

    # NEW: prefer occurrences that have accident_date populated somewhere within the occurrence
    has_acc_date_by_occ = (
        df.groupby("occurrence_number", dropna=False)["accident_date_key"]
        .apply(lambda s: bool(s.notna().any()))
        .astype(int)  # 1 = has accident date, 0 = missing everywhere
        .rename("has_accident_date")
        .reset_index()
    )

    # Tie-breaker: occurrence-level completeness over ORIGINAL columns
    # (counts non-null cells across all rows in the occurrence, using the pre-normalized/original fields)
    row_filled_counts = df[original_columns].notna().sum(axis=1)

    completeness_by_occ = (
        row_filled_counts.groupby(df["occurrence_number"], dropna=False)
        .sum()
        .astype(int)
        .rename("filled_cell_count")
        .reset_index()
    )

    # Tie-breaker: max claim description length within the occurrence (normalized description)
    desc_len_by_occ = (
        df.groupby("occurrence_number", dropna=False)["claim_description_n"]
        .apply(lambda s: int(s.dropna().astype(str).str.len().max()) if s.notna().any() else 0)
        .rename("max_claim_desc_len")
        .reset_index()
    )

    occ_rank_df = (
        occ_df
        .merge(eval_by_occ, on="occurrence_number", how="left")
        .merge(has_acc_date_by_occ, on="occurrence_number", how="left")  # NEW
        .merge(completeness_by_occ, on="occurrence_number", how="left")
        .merge(desc_len_by_occ, on="occurrence_number", how="left")
    )

    winners = set()
    if "duplicate_number" in occ_rank_df.columns:
        # NEW: treat incurred within this % as "same" for winner selection
        INCURRED_REL_TOL = 0.03  # 3% (set to 0.02 for 2%)
        INCURRED_ABS_TOL = 0.0  # optional extra guardrail, e.g. 50.0 if you want

        for dup_num, g in occ_rank_df.groupby("duplicate_number", dropna=True):
            if g.empty:
                continue

            g2 = g.copy()
            g2["total_incurred_num"] = pd.to_numeric(g2["total_incurred"], errors="coerce")

            # NEW: if any occurrence has an accident date, only consider those as winners
            if "has_accident_date" in g2.columns and (g2["has_accident_date"] == 1).any():
                base_pool = g2[g2["has_accident_date"] == 1].copy()
            else:
                base_pool = g2

            # If we have any incurred values, filter to those within tol of the max (WITHIN base_pool)
            if base_pool["total_incurred_num"].notna().any():
                max_inc = float(base_pool["total_incurred_num"].max())
                rel_band = INCURRED_REL_TOL * max(abs(max_inc), 1.0)

                within_band = (
                    (base_pool["total_incurred_num"] - max_inc).abs()
                    <= max(INCURRED_ABS_TOL, rel_band)
                )

                candidates = base_pool[within_band].copy()
                if candidates.empty:
                    candidates = base_pool
            else:
                candidates = base_pool

            candidates_sorted = candidates.sort_values(
                by=[
                    "eval_max",
                    "has_accident_date",
                    "filled_cell_count",
                    "max_claim_desc_len",
                    "total_incurred_num",
                ],
                ascending=[False, False, False, False, False],
                na_position="last",
                kind="mergesort",
            )

            winners.add(int(candidates_sorted["occurrence_number"].iloc[0]))

    remove_due_to_duplicates = (
        df["duplicate_number"].notna() &
        (~df["occurrence_number"].isin(winners))
    ).fillna(False)

    df["remove"] = (remove_aggregate_within_occurrence | remove_due_to_duplicates).astype("Int64")

    # ---------------------------------------------
    # 5) Return original columns + outputs
    # ---------------------------------------------
    output = df[original_columns].copy()
    output["occurrence_number"] = df["occurrence_number"]
    output["duplicate_number"] = df["duplicate_number"]
    output["remove"] = df["remove"]

    return output


def find_occurrences_and_duplicates(
    df: pd.DataFrame,
    account_col: str = "AccountName",
    ensure_globally_unique_numbers: bool = True,
) -> pd.DataFrame:
    """
    Run occurrence + duplicate detection independently per account.

    If ensure_globally_unique_numbers=True, occurrence_number/duplicate_number are
    re-mapped so numbers never collide across accounts in the concatenated output.
    """
    df = df.copy()

    if account_col not in df.columns:
        raise KeyError(f"Missing required account column: {account_col}")

    outputs = []
    next_occ_base = 1
    next_dup_base = 1

    # Keep NaN accounts as their own group (dropna=False)
    for account_value, g in df.groupby(account_col, dropna=False, sort=False):
        g = g.copy()

        out_g = process_claims_deduplication(g)

        # Ensure the account value is preserved in output even if the engine doesn't touch it
        out_g[account_col] = account_value

        if ensure_globally_unique_numbers:
            # Rebase occurrence numbers
            occ_map = {}
            for occ in out_g["occurrence_number"].dropna().unique():
                occ = int(occ)
                if occ not in occ_map:
                    occ_map[occ] = next_occ_base
                    next_occ_base += 1
            out_g["occurrence_number"] = out_g["occurrence_number"].map(
                lambda x: pd.NA if pd.isna(x) else occ_map[int(x)]
            ).astype("Int64")

            # Rebase duplicate numbers (only those assigned)
            dup_map = {}
            if "duplicate_number" in out_g.columns:
                for dn in out_g["duplicate_number"].dropna().unique():
                    dn = int(dn)
                    if dn not in dup_map:
                        dup_map[dn] = next_dup_base
                        next_dup_base += 1
                out_g["duplicate_number"] = out_g["duplicate_number"].map(
                    lambda x: pd.NA if pd.isna(x) else dup_map[int(x)]
                ).astype("Int64")

        outputs.append(out_g)

    # Concatenate and keep original row order within each account group as produced above
    print("      ✅ Complete")
    return pd.concat(outputs, axis=0, ignore_index=True)


if __name__ == "__main__":
    input_path = os.path.join("extraction_output", "TEST_SPAR_EVAL_claims.csv")

    base_dir = os.path.dirname(input_path)
    base_name = os.path.basename(input_path)
    stem, ext = os.path.splitext(base_name)
    output_path = os.path.join(base_dir, f"{stem}_deduped{ext}")

    if not os.path.exists(input_path):
        raise FileNotFoundError(f"Could not find input file: {input_path}")

    df = pd.read_csv(input_path)
    result_df = find_occurrences_and_duplicates(df, account_col="AccountName")
    result_df.to_csv(output_path, index=False)

    print(f"Input rows: {len(df):,}")
    print(f"Unique occurrences: {result_df['occurrence_number'].nunique(dropna=True):,}")
    print(f"Rows with duplicate_number assigned: {result_df['duplicate_number'].notna().sum():,}")
    print(f"Rows marked remove: {int(result_df['remove'].fillna(0).sum()):,}")
    print(f"Saved deduped file to: {output_path}")
