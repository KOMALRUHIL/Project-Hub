# ==============================================================================
# Master Actuarial & Insurance Domain Loss Run Standards (15+ Years Domain Spec)
# ==============================================================================

import re
import difflib
from typing import Optional, Dict, List, Any

# ------------------------------------------------------------------------------
# Standard 28-Column Production Schema
# ------------------------------------------------------------------------------
STANDARD_28_COLUMNS = [
    "claim_id",               # 1. Unique claim identifier (Required)
    "claimant",               # 2. Claimant / Injured Party / Driver Name
    "date_of_loss",           # 3. Incident date (MM/DD/YYYY, Required)
    "date_reported",          # 4. Date reported to claim admin (>= date_of_loss)
    "date_closed",            # 5. Date closed (>= date_of_loss, blank if open)
    "state",                  # 6. US State 2-letter code (blank for non-US)
    "claim_status",           # 7. Raw carrier status (Open, Closed, Reopened)
    "cause_of_loss",          # 8. Cause of incident
    "nature_of_injury",       # 9. Injury / damage classification
    "body_part",              # 10. Affected anatomy
    "incurred_indemnity",     # 11. Incurred indemnity / PD (Gross, unsplit fallback)
    "incurred_medical",       # 12. Incurred medical / BI (Gross)
    "incurred_expense",       # 13. Incurred expense / ALAE (Gross)
    "paid_indemnity",         # 14. Paid indemnity / PD (Gross, = Incurred if closed)
    "paid_medical",           # 15. Paid medical / BI (Gross, = Incurred if closed)
    "paid_expense",           # 16. Paid expense / ALAE (Gross, = Incurred if closed)
    "recovery",               # 17. Subrogation / salvage recovery (Paid preferred)
    "claim_description",      # 18. Longest narrative description
    "coverage_subtype",       # 19. Line of business / subline
    "operating_department",   # 20. Insured department / division / unit
    "risk_class",             # 21. Payroll class code / vehicle type
    "country",                # 22. Loss country / jurisdiction (USA)
    "litigated",              # 23. Litigation indicator (Yes/No)
    "carrier",                # 24. Issuing insurance carrier
    "lob",                    # 25. Line of Business (LOB) - right before source file
    "source_file_name",       # 26. Source uploaded filename
    "sheet_name",             # 27. Excel worksheet / tab name (or N/A)
    "page_number"             # 28. Document / PDF page number (or N/A)
]

CLIENT_23_OUTPUT_FIELDS = STANDARD_28_COLUMNS
CLAIM_LEVEL_VALID_JSON_FIELDS = STANDARD_28_COLUMNS
NO_CLAIMS_VALID_JSON_FIELDS = ['policy_effective_year', 'line_of_business', 'prior_carrier', 'evaluation_date']

# ------------------------------------------------------------------------------
# Exhaustive Insurance Domain Nomenclature & Carrier Synonyms (500+ Variations)
# ------------------------------------------------------------------------------
EXHAUSTIVE_HEADER_SYNONYMS: Dict[str, List[str]] = {
    "claim_id": [
        "claim_id", "claim id", "claim #", "claim no", "claim no.", "claim number", "clm id", "clm #", 
        "clm no", "clm_num", "claimid", "claim_no", "claimnbr", "clmnbr", "claim_nbr", "file #", 
        "file number", "file no", "file no.", "record id", "record #", "loss reference", "loss ref", 
        "loss ref #", "claim reference", "claim ref", "tpa claim #", "tpa claim number", "carrier claim #", 
        "carrier claim number", "occurrence #", "occurrence number", "master claim #", "parent claim #", 
        "incident #", "incident number", "case #", "case number", "matter #", "matter number", "control #", 
        "control number", "tracking #", "docket #", "claim", "claimkey", "claim_key", "clm_id", "clm_no",
        "claim_reference_number", "claim_identifier", "policy_claim_no"
    ],
    
    "legacy_claim_id": [
        "legacy claim #", "legacy claim no", "legacy claim no.", "legacy claim number", "legacy claim id", 
        "legacy claim", "old claim #", "old claim no", "old claim number", "old claim id", "prior claim #", 
        "prior claim no", "prior claim number", "prior claim id", "previous claim #", "previous claim number", 
        "former claim #", "hist claim #", "historical claim #", "prior carrier claim #", "secondary claim #",
        "legacy_claim_id", "legacy_claim_no", "legacy_claim_number", "legacy_claim_#"
    ],
    
    "claimant": [
        "claimant", "claimant name", "claimant_name", "claimant full name", "insured / claimant", 
        "injured party", "injured person", "injured worker", "employee name", "employee", "plaintiff", 
        "driver name", "driver", "third party", "claimant / driver", "claimant / insured", "name of claimant", 
        "claimant (last, first)", "claimant last name", "patient name", "victim", "operator", "injured employee", 
        "damaged party", "claimant/plaintiff", "party name", "payee", "claimant_first_name", "claimant_last_name",
        "claimant_full_name", "injured_worker_name", "plaintiff_name", "driver_full_name"
    ],
    
    "date_of_loss": [
        "date_of_loss", "date of loss", "loss date", "loss_date", "dol", "d.o.l.", "d/l", "dl", "d.l.", "d/loss", "occurrence date", 
        "date of occurrence", "loss occurrence date", "loss/occurrence date", "accident date", 
        "date of accident", "accident_date", "incident date", "date of incident", "incident_date", 
        "date event", "event date", "date_event", "event_date", "date of event", "loss dt", "loss_dt", 
        "event dt", "event_dt", "accident dt", "accident_dt", "incident dt", "incident_dt", "acc date", 
        "acc dt", "acc_date", "acc_dt", "accdt", "lossdte", "loss_dte", "inj date", "injury date", 
        "date of injury", "doi", "d.o.i.", "loss day", "date occurred", "occurred date", "crash date", 
        "collision date", "damage date", "loss date time", "loss date/time", "date of loss/injury", 
        "date of loss / accident", "loss_occurrence_dt", "dt_loss", "dt_accident", "dt_event", "dt_occ",
        "occ_date", "occ_dt", "accident_day", "incident_day"
    ],
    
    "date_reported": [
        "date_reported", "date reported", "report date", "report_date", "reported date", "reported_date", 
        "d/r", "dr", "d.r.", "dor", "d.o.r.", "d/rep", "d/n", "dn",
        "date reported to claim admin", "date reported to carrier", "date reported to tpa", "date reported to insured", 
        "rep date", "rep_date", "rep dt", "rep_dt", "date of report", "entry date", "entry_date", "entered date", 
        "setup date", "set up date", "intake date", "notice date", "date of notice", "date notified", 
        "date received", "received date", "rcvd date", "date open", "opened date", "date created", 
        "create date", "record date", "reported dt", "rpt date", "rpt dt", "rpt_date", "rpt_dt", 
        "dtrpt", "dt_reported", "dt_notice", "dt_entry", "notification_date", "date_of_notice"
    ],
    
    "date_closed": [
        "date_closed", "date closed", "closed date", "closed_date", "close date", "close_date", 
        "d/c", "dc", "d.c.", "doc", "d.o.c.", "d/clsd",
        "cls date", "cls_date", "cls dt", "cls_dt", "date of close", "date of settlement", "settlement date", 
        "settled date", "date closed/reopened", "date closed / reopened", "date closed reopened", 
        "closed/reopened", "closed / reopened", "closed reopened", "date closed reopen", "date reopen", 
        "date reopened", "date closed/re-opened", "closed/re-opened", "date re-opened", "closed dt", 
        "closed_dt", "cld date", "term date", "termination date", "final disposition date", "disposition date", 
        "resolution date", "date resolved", "evaluation date", "eval date", "dt_closed", "dt_close"
    ],
    
    "state": [
        "state", "loss state", "loss_state", "accident state", "accident_state", "st", "loss st", 
        "accident st", "event state", "event_state", "state of loss", "state of accident", "state of benefit", 
        "state of jurisdiction", "jur", "jurisdiction", "jurisdiction state", "garage state", "garage_state", 
        "coverage state", "coverage_state", "venue state", "loss loc state", "loc state", "location state", 
        "prov", "province", "state code", "st_cd", "loss_st", "accident_st"
    ],
    
    "claim_status": [
        "claim_status", "claim status", "status", "clm status", "clm_status", "stat", "claim_stat", 
        "open/closed", "open / closed", "o/c", "status code", "current status", "claim disposition", 
        "disposition", "stage", "file status", "claim stage", "record status", "status description", 
        "claim condition", "open_closed_flag", "claim_state", "file_state"
    ],
    
    "cause_of_loss": [
        "cause_of_loss", "cause of loss", "cause", "loss cause", "loss_cause", "cause code", "cause_code", 
        "cause description", "cause desc", "accident cause", "cause of accident", "primary cause", 
        "loss reason", "peril", "type of loss", "loss type", "nature of loss", "how injury occurred", 
        "event cause", "occurrence cause", "cause category", "accident type", "loss event", "peril code",
        "cause_of_injury", "root_cause", "accident_category"
    ],
    
    "nature_of_injury": [
        "nature_of_injury", "nature of injury", "nature of loss", "injury nature", "injury type", 
        "injury description", "injury detail", "injury", "type of injury", "damage type", "nature of damage", 
        "type of damage", "harm type", "diagnosis", "injury category", "injury classification", 
        "specific injury", "nature code", "nature_of_damage", "injury_diagnosis", "damage_classification"
    ],
    
    "body_part": [
        "body_part", "body part", "part of body", "injured body part", "body part injured", "body location", 
        "affected anatomy", "anatomy", "body part affected", "body side", "part code", "body part code", 
        "injured part", "body_part_desc", "body_location_desc", "anatomical_site"
    ],
    
    "incurred_indemnity": [
        "incurred_indemnity", "incurred indemnity", "indemnity incurred", "indemnity_incurred", 
        "incurred pd", "pd incurred", "incurred property damage", "property damage incurred", 
        "incurred loss", "loss incurred", "total incurred indemnity", 
        "indemnity inc", "inc indemnity", "indemnity loss", "indemnity incurred amount", 
        "incurred indemnity loss", "incurred wage loss", "wage loss incurred", 
        "gross loss incurred", "indemnity reserve + paid",
        "gross_incurred_indemnity", "tot_inc_ind", "inc_ind", "indemnity_total_incurred"
    ],
    
    "incurred_medical": [
        "incurred_medical", "incurred medical", "medical incurred", "medical_incurred", "incurred bi", 
        "bi incurred", "incurred bodily injury", "bodily injury incurred", "inc medical", "med incurred", 
        "medical inc", "incurred med", "medical loss", "incurred medical amount", 
        "gross medical incurred", "total medical incurred", "medical reserve + paid", "incurred treatment", 
        "incurred med loss", "gross_incurred_medical", "tot_inc_med", "inc_med", "med_total_incurred"
    ],
    
    "incurred_expense": [
        "incurred_expense", "incurred expense", "expense incurred", "expense_incurred", "incurred alae", 
        "alae incurred", "incurred legal", "legal incurred", "exp incurred", "incurred_alae", "inc expense", 
        "expense inc", "incurred exp", "alae", "allocated loss adjustment expense incurred", 
        "incurred defense", "defense expense incurred", "incurred expense amount", "total expense incurred", 
        "incurred legal expense", "incurred alae expense", "gross_incurred_expense", "tot_inc_exp", "inc_exp"
    ],
    
    "paid_indemnity": [
        "paid_indemnity", "paid indemnity", "indemnity paid", "indemnity_paid", "paid pd", "pd paid", 
        "paid property damage", "property damage paid", "paid loss", "loss paid", 
        "indemnity paid amount", "paid indemnity loss", "indemnity payment", 
        "pd payment", "wage loss paid", "indemnity check total", "loss payment", "gross_paid_indemnity", 
        "tot_pd_ind", "pd_ind", "indemnity_total_paid", "losses paid"
    ],
    
    "paid_medical": [
        "paid_medical", "paid medical", "medical paid", "medical_paid", "paid bi", "bi paid", 
        "paid bodily injury", "bodily injury paid", "med paid", "paid med", "paid medical amount", 
        "gross medical paid", "total medical paid", "medical payment", "medical check total", 
        "treatment paid", "hospital paid", "gross_paid_medical", "tot_pd_med", "pd_med", "med_total_paid"
    ],
    
    "paid_expense": [
        "paid_expense", "paid expense", "expense paid", "expense_paid", "paid alae", "alae paid", 
        "paid legal", "legal paid", "exp paid", "paid_alae", "paid expense amount", "expense payment", 
        "paid exp", "allocated expense paid", "defense paid", "attorney fees paid", "adjuster expense paid", 
        "gross_paid_expense", "tot_pd_exp", "pd_exp", "exp_total_paid", "expenses paid"
    ],
    
    "net_paid_indemnity": [
        "net loss paid", "net paid loss", "net indemnity paid", "net_paid_indemnity", "net pd paid", "net paid pd", "net paid loss amount", "net losses paid"
    ],
    
    "net_paid_medical": [
        "net medical paid", "net paid medical", "net_paid_medical", "net bi paid", "net paid bi"
    ],
    
    "net_paid_expense": [
        "net expense paid", "net paid expense", "net alae paid", "net_paid_expense", "net exp paid", "net paid exp", "net expenses paid"
    ],

    "net_incurred_indemnity": [
        "net loss incurred", "net incurred loss", "net indemnity incurred", "net_incurred_indemnity", "net incurred indemnity", "net pd incurred", "net incurred pd"
    ],

    "net_incurred_medical": [
        "net medical incurred", "net incurred medical", "net bi incurred", "net_incurred_medical", "net incurred bi"
    ],

    "net_incurred_expense": [
        "net expense incurred", "net incurred expense", "net alae incurred", "net_incurred_expense", "net exp incurred", "net incurred exp"
    ],

    "total_net_incurred": [
        "net incurred", "total net incurred", "net total incurred", "total_net_incurred", "net_incurred", "net incurred amount", "net loss", "net total loss"
    ],

    "total_net_paid": [
        "net paid", "total net paid", "net total paid", "net_paid", "total_net_paid", "net paid amount", "net disbursements", "net total payments"
    ],
    
    "reserve_indemnity": [
        "loss balance", "loss reserve", "indemnity balance", "indemnity reserve", "os loss", "outstanding loss", "o/s loss", "reserve_indemnity",
        "loss bal", "loss res", "indemnity bal", "ind bal", "pd bal", "pd reserve", "loss os", "loss o/s"
    ],
    
    "reserve_medical": [
        "medical balance", "medical reserve", "os medical", "outstanding medical", "o/s medical", "reserve_medical",
        "med balance", "med reserve", "med bal", "med res", "bi balance", "bi reserve", "bi bal", "med os", "med o/s"
    ],
    
    "reserve_expense": [
        "expense balance", "expense reserve", "alae balance", "alae reserve", "os expense", "outstanding expense", "o/s expense", "reserve_expense",
        "exp balance", "exp reserve", "exp bal", "exp res", "expense bal", "alae bal", "legal balance", "legal reserve", "exp os", "exp o/s"
    ],
    
    "loss_collection": [
        "loss collection", "subrogation", "salvage", "loss_collection", "loss recovery", "subro loss", "loss subro", "loss recoveries", "loss coll", "pd salvage"
    ],
    
    "expense_collection": [
        "expense collection", "expense recovery", "alae recovery", "expense_collection", "exp collection", "exp recovery", "expense recoveries", "exp coll", "legal recovery"
    ],
    
    "total_incurred": [
        "incurred", "incurred total", "total incurred", "gross incurred", "incurred amount", "total_incurred", "gross_incurred", "gross loss", "total claim cost", "claim incurred"
    ],
    
    "total_paid": [
        "paid", "total paid", "gross paid", "paid amount", "total_paid", "gross_paid", "disbursements", "total disbursements", "claim paid", "losses paid", "total payments"
    ],
    
    "total_reserve": [
        "reserve", "total reserve", "outstanding", "total outstanding", "balance", "total balance", "case reserve", "total_reserve", "total_outstanding", "o/s total", "os total", "ending reserve", "open reserve"
    ],
    
    "deductible": [
        "deductible", "ded", "sir", "self insured retention", "retention", "policy deductible", "deductible amount", "sir amount", "deductible recovery", "deductible reimbursement", "ground up deductible"
    ],

    "ground_up_incurred": [
        "ground up incurred", "ground up loss", "total ground up", "gross ground up", "ground up", "ground_up_incurred", "ground_up_loss", "ground up total"
    ],

    "recovery": [
        "recovery", "recoveries", "total recoveries", "total_recoveries", "paid recovery", "incurred recovery", 
        "salvage", "subrogation", "subro", "subro recovery", "salvage recovery", "salvage / subro", 
        "subrogation / salvage", "subro / salvage", "salvage & subrogation", "subrogation & salvage", 
        "recovery amount", "deductible recovery", "reimbursement", "reimbursements", "third party recovery", 
        "net recovery", "tot_rec", "subro_salvage", "salvage_amount", "subrogation_amount",
        "loss collection", "expense collection", "collections", "total collections", "subrogation recovery", "coll", "colls"
    ],
    
    "claim_description": [
        "claim_description", "claim description", "full accident description", "accident description", 
        "loss description", "description", "desc", "loss desc", "claim desc", "accident summary", 
        "incident description", "incident summary", "loss narrative", "claim narrative", "notes", 
        "narrative", "comments", "claim details", "loss details", "accident details", "incident details", 
        "event description", "event summary", "circumstances", "facts of loss", "details", "loss_desc",
        "claim_details_narrative", "occurrence_summary"
    ],
    
    "coverage_subtype": [
        "coverage_subtype", "coverage subtype", "subline", "coverage subline", "coverage part", 
        "sub-coverage", "coverage", "coverage name", "policy coverage", "coverage type", 
        "coverage description", "subline code", "coverage code", "benefit type", "major coverage", 
        "minor coverage", "cov_code", "cov_desc", "policy_subline"
    ],
    
    "operating_department": [
        "operating_department", "operating department", "department", "dept", "operating division", 
        "division", "unit", "operating unit", "branch", "facility", "location name", "cost center", 
        "subsidiary", "profit center", "department name", "division name", "business unit", "dept_name",
        "operating_unit_name", "location_code"
    ],
    
    "risk_class": [
        "risk_class", "risk class", "class code", "class", "class_code", "payroll class", 
        "vehicle class", "vehicle type", "occupancy code", "governing class", "class description", 
        "classification", "naics", "sic code", "iso class", "class_cd", "risk_classification"
    ],
    
    "country": [
        "country", "country of loss", "jurisdiction country", "loss country", "nation", "accident country", 
        "event country", "country code", "country_cd", "loss_nation"
    ],
    
    "litigated": [
        "litigated", "litigation", "lawsuit", "suit", "suit filed", "attorney represented", 
        "attorney representation", "legal counsel", "represented by attorney", "litigated claim", 
        "lit status", "in suit", "lit_flag", "attorney_flag", "suit_flag"
    ],
    
    "carrier": [
        "carrier", "prior carrier", "carrier name", "insurance company", "insurance carrier", 
        "issuing carrier", "insurer", "underwriting company", "company name", "writing company", 
        "policy carrier", "tpa name", "claim admin", "carrier_name", "insurer_name", "admin_name"
    ],
    
    "lob": [
        "lob", "line of business", "line_of_business", "major lob", "policy lob", "insurance line", 
        "line", "product line", "line of insurance", "loi", "major_line", "lob_name"
    ],
    
    "source_file_name": [
        "source_file_name", "source file name", "filename", "file name", "source file", "input file", "doc_name"
    ],
    
    "sheet_name": [
        "sheet_name", "sheet name", "worksheet", "tab name", "sheet", "page name", "tab"
    ],
    
    "page_number": [
        "page_number", "page number", "page #", "page no", "page", "pg #", "pg no", "page_no"
    ]
}


# ------------------------------------------------------------------------------
# High-Performance Multi-Pass Domain Matcher
# ------------------------------------------------------------------------------
def match_header_semantic(raw_header: str) -> Optional[str]:
    """
    High-Performance 4-Pass Insurance Nomenclature Matcher:
    Pass 1: Direct exact match against 500+ curated insurance dictionary entries.
    Pass 2: Canonical token normalization (strips carrier prefixes, suffixes, punctuation).
    Pass 3: Domain Token Co-Occurrence Logic (e.g. 'medical' + 'incurred' -> 'incurred_medical').
    Pass 4: Compact Substring Heuristics (e.g. 'accdt', 'dtrpt', 'subro').
    """
    if not raw_header:
        return None
        
    s = str(raw_header).replace("\n", " ").replace("\r", " ").strip().lower()
    clean = re.sub(r"[^a-z0-9]", " ", s)
    tokens = set(clean.split())
    clean_str = " ".join(clean.split())
    if not clean_str:
        return None

    # PASS 1: Exact Synonym Dictionary Lookup
    for std_field, syn_list in EXHAUSTIVE_HEADER_SYNONYMS.items():
        std_clean = " ".join(re.sub(r"[^a-z0-9]", " ", std_field).split())
        if clean_str == std_clean:
            return std_field
        for syn in syn_list:
            syn_clean = " ".join(re.sub(r"[^a-z0-9]", " ", syn).split())
            if clean_str == syn_clean:
                return std_field

    # PASS 2: Stripped Token Normalization
    stripped = re.sub(r'^(clm|pol|sys|loss|claim|ins|occ|rec|hdr)[_.\s]+', '', clean_str)
    stripped = re.sub(r'[_.\s]+(amt|amount|val|value|dte|dt|date|txt|num|nbr|no|code|cd|desc|description)$', '', stripped)
    stripped = stripped.strip()
    
    if stripped and len(stripped) >= 3:
        for std_field, syn_list in EXHAUSTIVE_HEADER_SYNONYMS.items():
            for syn in syn_list:
                syn_clean = " ".join(re.sub(r"[^a-z0-9]", " ", syn).split())
                if stripped == syn_clean:
                    return std_field

    # PASS 3: Domain Token Co-Occurrence Logic
    has_medical = bool(tokens & {"medical", "med", "bi", "treatment", "hospital", "physician", "health", "bodily"})
    has_expense = bool(tokens & {"expense", "expenses", "exp", "alae", "legal", "defense", "adjuster", "attorney", "fee", "fees"})
    has_indemnity = bool(tokens & {"indemnity", "ind", "wage", "loss", "pd", "property", "direct"})
    has_incurred = bool(tokens & {"incurred", "inc", "gross", "incur", "incurrd"})
    has_paid = bool(tokens & {"paid", "pd", "pmt", "payment", "disbursed", "disbursement", "check"})
    has_reserve = bool(tokens & {"reserve", "balance", "outstanding", "os"})
    has_recovery = bool(tokens & {"recovery", "recoveries", "subro", "subrogation", "salvage", "reimbursement", "collection", "collections", "coll", "colls"})
    has_net = "net" in tokens

    # Deductible & Ground Up
    if "ground" in tokens and "up" in tokens:
        return "ground_up_incurred"
    if bool(tokens & {"deductible", "ded", "sir", "retention"}):
        return "deductible"

    # Collections / Recoveries
    if has_expense and has_recovery:
        return "expense_collection"
    if has_indemnity and has_recovery:
        return "loss_collection"
    if has_recovery:
        return "recovery"

    # Reserves / Balances
    if has_expense and has_reserve:
        return "reserve_expense"
    if has_indemnity and has_reserve:
        return "reserve_indemnity"
    if has_medical and has_reserve:
        return "reserve_medical"
    if has_reserve:
        return "total_reserve"

    # Net Incurred & Net Paid
    if has_net:
        if has_expense and has_paid:
            return "net_paid_expense"
        if has_expense and has_incurred:
            return "net_incurred_expense"
        if has_indemnity and has_paid:
            return "net_paid_indemnity"
        if has_indemnity and has_incurred:
            return "net_incurred_indemnity"
        if has_medical and has_paid:
            return "net_paid_medical"
        if has_medical and has_incurred:
            return "net_incurred_medical"
        if has_paid:
            return "total_net_paid"
        if has_incurred:
            return "total_net_incurred"

    # Gross Incurred & Paid
    if has_medical and has_incurred:
        return "incurred_medical"
    if has_medical and has_paid:
        return "paid_medical"

    if has_expense and has_incurred:
        return "incurred_expense"
    if has_expense and has_paid:
        return "paid_expense"

    # Specific Indemnity / Loss terms
    if has_indemnity and has_incurred:
        return "incurred_indemnity"
    if has_indemnity and has_paid:
        return "paid_indemnity"

    # Total / Net / Generic Incurred & Paid
    if clean_str in ["total", "total loss", "total incurred", "gross incurred", "gross loss", "incurred amount", "incurred"]:
        return "total_incurred"
    if clean_str in ["paid", "total paid", "gross paid", "paid amount", "losses paid"]:
        return "total_paid"

    # Standalone Incurred / Paid fallback
    if "incurred" in tokens:
        return "total_incurred"
    if "paid" in tokens:
        return "total_paid"

    # Date Co-Occurrence
    has_date_term = bool(tokens & {"date", "dt", "dte", "day", "time"})
    has_loss_term = bool(tokens & {"loss", "accident", "event", "incident", "occurrence", "occ", "injury", "crash", "collision"})
    has_closed_term = bool(tokens & {"closed", "close", "settled", "settlement", "reopened", "reopen", "term", "disposition", "resolved"})
    has_report_term = bool(tokens & {"reported", "report", "notice", "notified", "intake", "entry", "entered", "received", "rcvd"})

    if has_loss_term and has_date_term:
        return "date_of_loss"
    if has_closed_term and has_date_term:
        return "date_closed"
    if has_report_term and has_date_term:
        return "date_reported"

    # Description vs Cause vs Injury
    if "injury type" in clean_str or "nature of injury" in clean_str or "injury_type" in clean_str:
        return "nature_of_injury"
    if bool(tokens & {"narrative", "comments", "summary", "circumstances", "notes"}) or "full accident description" in clean_str:
        return "claim_description"
    if bool(tokens & {"cause", "peril", "reason"}):
        return "cause_of_loss"

    # Location / Department
    if "location" in clean_str or "loc" in tokens or "department" in clean_str:
        return "operating_department"

    # Claim ID & Claimant
    if bool(tokens & {"claimant", "driver", "plaintiff", "employee"}):
        return "claimant"
    
    # Legacy / Prior / Historical Claim ID
    if bool(tokens & {"legacy", "prior", "old", "previous", "hist", "historical", "former"}):
        if bool(tokens & {"claim", "file", "record", "case", "matter", "loss", "incident", "event", "claim#"}) and bool(tokens & {"id", "num", "number", "no", "key", "#"}):
            return "legacy_claim_id"
        if any(term in clean_str for term in ["claim #", "claim no", "claim number", "claim id", "file #", "file no", "record #"]):
            return "legacy_claim_id"

    if bool(tokens & {"claim", "file", "record", "case", "matter", "loss", "incident", "event", "claim#"}) and bool(tokens & {"id", "num", "number", "no", "key", "#"}):
        return "claim_id"
    if clean_str in ["loss id", "claim#", "claim #", "claim no", "claim no.", "claim num", "matter #"]:
        return "claim_id"

    # PASS 4: Compact Substring Heuristics
    compact = re.sub(r"[^a-z0-9]", "", s)
    if any(k in compact for k in ["accdt", "lossdt", "eventdt", "occurdt", "injudt", "dateevent", "lossdte", "accidentdate", "lossdate", "incidentdate"]):
        return "date_of_loss"
    if any(k in compact for k in ["rptdt", "repdt", "noticdt", "dtrpt", "reportdate", "entrydt", "rcvddt"]):
        return "date_reported"
    if any(k in compact for k in ["clsdt", "closedt", "clddt", "closedreopen", "reopeneddt", "settledt"]):
        return "date_closed"

    return None
